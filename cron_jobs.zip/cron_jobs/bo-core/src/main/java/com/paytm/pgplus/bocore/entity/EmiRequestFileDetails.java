package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 * @author dheerajtyagi
 *
 */
@Getter
@Setter
@Entity
@Table(name = "emi_request_file_details")
@XmlRootElement
public class EmiRequestFileDetails implements Serializable {
    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "file_name", length = 255)
    private String fileName;

    @Column(name = "file_path", length = 255)
    private String filePath;

    @Column(name = "success_records", length = 20)
    private long successRecords;

    @Column(name = "failure_records", length = 20)
    private long failureRecords;

    @Column(name = "total_records", length = 20)
    private long totalRecords;

    public EmiRequestFileDetails() {

    }

    @Column(name = "status", length = 20)
    private boolean status;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_on", nullable = false)
    private Date createdOn;

    /*
     * public EmiRequestFileDetails(EmiFile emiFile) { super(); this.fileName =
     * emiFile.getFileName(); this.filePath = emiFile.getFileParent();
     * this.failureRecords = 0; this.successRecords = 0; this.totalRecords = 0;
     * this.status = false; Date d = new Date(); this.createdOn = d;
     * 
     * }
     */

}
