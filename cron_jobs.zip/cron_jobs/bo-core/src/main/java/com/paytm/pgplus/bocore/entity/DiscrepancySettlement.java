package com.paytm.pgplus.bocore.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.file.util.annotation.CsvColumnMapper;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

import static com.paytm.pgplus.bocore.constants.DiscrepancyCsvFileHeadersConstant.*;
import static com.paytm.pgplus.bocore.constants.RefundProcessingColumnMapper.PAYMETHOD;

/**
 * Hibernate entity class This class responsible for hibernate entity to table
 * mapping
 *
 * @author Kulbhushan Pandey
 * @date 6 March 2016
 */
@ToString
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "PGPLUS_REPORT_DISCREPANCY_SETTLEMENT")
public class DiscrepancySettlement extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "DISCREPANCY_TYPE")
    @CsvColumnMapper(columnName = DISCREPANCY_TYPE)
    private String discrepancyType;

    @Column(name = "FLUXNET_EXT_SERIAL_NO")
    @CsvColumnMapper(columnName = FLUXNET_EXT_SERIAL_NO)
    private String fluxNetExtSerialNo;

    @Column(name = "FLUXNET_RESULT_STATUS")
    @CsvColumnMapper(columnName = FLUXNET_RESULT_STATUS)
    private String fluxNetResultStatus;

    @Column(name = "FLUXNET_REFERENCE_NO")
    @CsvColumnMapper(columnName = FLUXNET_REFERENCE_NO)
    private String fluxNetReferenceNo;

    @Column(name = "FLUXNET_EXCHANGE_CURRENCY")
    @CsvColumnMapper(columnName = FLUXNET_EXCHANGE_CURRENCY)
    private String fluxNetExchangeCurrency;

    @Column(name = "FLUXNET_EXCHANGE_AMOUNT")
    @CsvColumnMapper(columnName = FLUXNET_EXCHANGE_AMOUNT)
    private Long fluxNetExchangeAmount;

    @Column(name = "FILE_RCV_DATE")
    @CsvColumnMapper(columnName = FILE_RCV_DATE)
    private Date fileRcvDate;

    @Column(name = "FILE_NAME")
    @CsvColumnMapper(columnName = FILE_NAME)
    private String fileName;

    @Column(name = "TRANS_TYPE")
    @CsvColumnMapper(columnName = TRANS_TYPE)
    private String transType;

    @Column(name = "RESULT_STATUS")
    @CsvColumnMapper(columnName = RESULT_STATUS)
    private String resultStatus;

    @Column(name = "RESULT_CODE_ID")
    @CsvColumnMapper(columnName = RESULT_CODE_ID)
    private String resultCodeId;

    @Column(name = "EXTSERIAL_NO")
    @CsvColumnMapper(columnName = EXT_SERIAL_NO)
    private String extSerialNo;

    @Column(name = "TRACE_NO")
    @CsvColumnMapper(columnName = TRACE_NO)
    private String traceNo;

    @Column(name = "AUTH_CODE")
    @CsvColumnMapper(columnName = AUTH_CODE)
    private String authCode;

    @Column(name = "RRN_CODE")
    @CsvColumnMapper(columnName = RRN_CODE)
    private String rrnCode;

    @Column(name = "BANK_ABBR")
    @CsvColumnMapper(columnName = BANK_ABBR)
    private String bankAbbr;

    @Column(name = "REFERENCE_NO")
    @CsvColumnMapper(columnName = REFERENCE_NO)
    private String referenceNo;

    @Column(name = "MERCHANT_ID")
    @CsvColumnMapper(columnName = MERCHANT_ID)
    private String merchantId;

    @Column(name = "PAYTMM_ID")
    @CsvColumnMapper(columnName = ORIGINAL_MID)
    private String originalMID;

    @Column(name = "MBID")
    @CsvColumnMapper(columnName = MBID)
    private String mbid;

    @Column(name = "EXCHANGE_AMOUNT")
    @CsvColumnMapper(columnName = EXCHANGE_AMOUNT)
    private Long exchangeAmount;

    @Column(name = "EXCHANGE_CURRENCY")
    @CsvColumnMapper(columnName = EXCHANGE_CURRENCY)
    private String exchangeCurrency;

    @Column(name = "TRANS_VALUE_DATE")
    @CsvColumnMapper(columnName = TRANS_VALUE_DATE)
    private Date transValueDate;

    @Column(name = "LAST_UPDATE_DATE")
    @CsvColumnMapper(columnName = LAST_UPDATE_DATE)
    private Date lastUpdateDate;

    @Column(name = "ACTION")
    private String action;

    @Column(name = "COMMENT")
    private String comment;

    @Column(name = "REF_ID")
    private String refId;

    @Column(name = "REFUND_TYPE")
    private String refundType;

    @Column(name = "BANK_RESPONSE_NO")
    @CsvColumnMapper(columnName = BANK_RESPONSE_NO)
    private String bankResponseNo;

    @Column(name = "TRANS_ID")
    private String transId;

    @Column(name = "DISPUTE_ID")
    private String disputeId;

    @Column(name = "TRANS_INFO_SOURCE")
    @CsvColumnMapper(columnName = TRANS_INFO_SOURCE)
    private String transInfoSource;

    @Column(name = "APP_ID")
    private String appId;

    @Column(name = "PAYMETHOD")
    @CsvColumnMapper(columnName = PAYMETHOD)
    private String paymethod;

    @CsvColumnMapper(columnName = LAST_UPDATE_DATE)
    private transient String lastUpdateDateStr;

    @CsvColumnMapper(columnName = TRANS_VALUE_DATE)
    private transient String transValueDateStr;

    @CsvColumnMapper(columnName = FILE_RCV_DATE)
    private transient String fileRcvDateStr;

    @Column(name = "BUSINESS_TYPE")
    @CsvColumnMapper(columnName = BUSINESS_TYPE)
    private String businessType;

    @Column(name = "MERCHANT_TRANS_ID")
    @CsvColumnMapper(columnName = MERCHANT_TRANS_ID)
    private String merchantTransId;

    @Column(name = "GATEWAY")
    @CsvColumnMapper(columnName = GATEWAY)
    private String gateway;

    @Column(name = "ORDER_CREATED_TIME")
    @CsvColumnMapper(columnName = ORDER_CREATED_TIME)
    private Date orderCreatedTime;

    @Column(name = "MERCHANT_NAME")
    @CsvColumnMapper(columnName = MERCHANT_NAME)
    private String merchantName;

    @Column(name = "VPA")
    @CsvColumnMapper(columnName = VPA)
    private String vpa;

    @Column(name = "BIZ_ORDER_ID")
    @CsvColumnMapper(columnName = BIZ_ORDER_ID)
    private String bizOrderId;

    @Column(name = "SUB_BIZORDER_TYPE")
    @CsvColumnMapper(columnName = SUB_BIZORDER_TYPE)
    private String subBizOrderType;

    @Column(name = "ORDER_STATUS")
    @CsvColumnMapper(columnName = ORDER_STATUS)
    private String orderStatus;

    @Column(name = TID)
    @CsvColumnMapper(columnName = TID)
    private String tid;

    @Column(name = STAN)
    @CsvColumnMapper(columnName = STAN)
    private String stan;

    @Column(name = INTERCHANGE)
    @CsvColumnMapper(columnName = INTERCHANGE)
    private String interchange;

    @Column(name = MASKED_CARD_NO)
    @CsvColumnMapper(columnName = MASKED_CARD_NO)
    private String maskedCardNo;

    @Column(name = IS_INSTANT_SETTLEMENT)
    @CsvColumnMapper(columnName = IS_INSTANT_SETTLEMENT)
    private Boolean isInstantSettlement;

    @Column(name = ADD_MONEY_TYPE)
    @CsvColumnMapper(columnName = ADD_MONEY_TYPE)
    private String addMoneyType;

    public DiscrepancySettlement(String discrepancyType, String fluxNetExtSerialNo, String fluxNetResultStatus,
            String fluxNetReferenceNo, String fluxNetExchangeCurrency, Long fluxNetExchangeAmount, Date fileRcvDate,
            String fileName, String transType, String resultStatus, String resultCodeId, String extSerialNo,
            String traceNo, String authCode, String rrnCode, String bankAbbr, String referenceNo, String merchantId,
            String originalMID, String mbid, Long exchangeAmount, String exchangeCurrency, Date transValueDate,
            Date lastUpdateDate, String action, String transInfoSource, String businessType) {
        super();
        this.discrepancyType = discrepancyType;
        this.fluxNetExtSerialNo = fluxNetExtSerialNo;
        this.fluxNetResultStatus = fluxNetResultStatus;
        this.fluxNetReferenceNo = fluxNetReferenceNo;
        this.fluxNetExchangeCurrency = fluxNetExchangeCurrency;
        this.fluxNetExchangeAmount = fluxNetExchangeAmount;
        this.fileRcvDate = fileRcvDate;
        this.fileName = fileName;
        this.transType = transType;
        this.resultStatus = resultStatus;
        this.resultCodeId = resultCodeId;
        this.extSerialNo = extSerialNo;
        this.traceNo = traceNo;
        this.authCode = authCode;
        this.rrnCode = rrnCode;
        this.bankAbbr = bankAbbr;
        this.referenceNo = referenceNo;
        this.merchantId = merchantId;
        this.originalMID = originalMID;
        this.mbid = mbid;
        this.exchangeAmount = exchangeAmount;
        this.exchangeCurrency = exchangeCurrency;
        this.transValueDate = transValueDate;
        this.lastUpdateDate = lastUpdateDate;
        this.action = action;
        this.transInfoSource = transInfoSource;
        this.businessType = businessType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        DiscrepancySettlement that = (DiscrepancySettlement) o;

        if (!discrepancyType.equals(that.discrepancyType))
            return false;
        if (!transType.equals(that.transType))
            return false;
        return extSerialNo.equals(that.extSerialNo);
    }

    @Override
    public int hashCode() {
        int result = discrepancyType.hashCode();
        result = 31 * result + transType.hashCode();
        result = 31 * result + extSerialNo.hashCode();
        return result;
    }
}