package com.paytm.pgplus.bocore.entity;

/**
 * 
 * @author dheeraj
 *
 */
public class DigitalOpsRefundHeader {

    public static final String BANK_NAME = "BANK_NAME";
    public static final String MID = "mid";
    public static final String TXN_ID = "txn_id";
    public static final String REFUND_TXN_ID = "REFUND_TXN_ID";
    public static final String MBID = "mbid";
    public static final String TXN_DATE = "txn_date";
    public static final String REFUND_DATE = "refund_date";
    public static final String TXN_AMOUNT = "txn_amount";
    public static final String REFUND_AMOUNT = "refund_amount";
    public static final String PAYMODE = "PAYMODE";
    public static final String REFUND_BANK_TXN_ID = "refund_bank_txn_id";
    public static final String TXN_BANK_TXN_ID = "txn_bank_txn_id";
    public static final String AGE = "Age";
    public static final String REFUND_TYPE = "refund_type";
    public static final String REFUND_ESN = "refundEsn";
    public static final String TRACE_ID = "traceId";
    public static final String CHARGING_ESN = "chargingEsn";
    public static final String AUTH_CODE = "AuthCode";
    public static final String CARD_LAST_4DIGIT = "cardLast4Digit";
    public static final String DIGITAL_OPS_TEAM_STATUS = "DigitalOpsTeamStatus";
    public static final String DIGITAL_OPS_TEAM_REMARK = "DigitalOpsTeamRemark";
    public static final String MANUAL_REFUND_AGEING = "manual_refunds_ageing_";
    public static final String MANUAL_REFUND_RECENT = "manual_refunds_recent_";
    public static final String ORDER_ID = "order_id";
    public static final String STATUS = "status";
    public static final String CUST_ID = "cust_id";
    public static final String REFUND_ID = "refundId";
    public static final String TXN_TYPE = "txnType";
    public static final String REFUND_BANK_RESPONSE_CODE = "refund_bank_response_code";

    public static final String REFUND_MBID = "refund_mbid";
    public static final String BUSINESS_TYPE_NEW = "business_type";
    public static final String RESULT_STATUS_NEW = "result_status";
    public static final String REFUND_DESTINATION_TYPE = "refund_destination_type";
    public static final String REFUND_DESTINATION_MODE = "refund_destination_mode";
    public static final String REFUND_ISSUING_BANK = "refund_issuing_bank";
    public static final String TRANSACTION_ISSUING_BANK = "transaction_issuing_bank";
    public static final String TRANSACTION_ACQUIRING_BANK_NAME = "transaction_acquiring_bank_name";
    public static final String IFSC_CODE = "ifsc_code";
    public static final String TROUBLE_ID = "trouble_id";

    public static final String[] DIGITAL_OPS_HEADER_NEW = new String[] { "BANK_NAME", "mid", "txn_id", "REFUND_TXN_ID",
            "chargingEsn", "refundEsn", "mbid", "txn_date", "refund_date", "txn_amount", "refund_amount", "PAYMODE",
            "refund_bank_txn_id", "txn_bank_txn_id", "Age", "refund_type", "traceId", "AuthCode", "cardLast4Digit",
            "order_id", "cust_id", "status", "refundId", "txnType", "digitalOpsTeamStatus", "digitalOpsTeamRemark",
            "refund_bank_response_code", "refund_mbid", "business_type", "result_status", "refund_destination_type",
            "refund_destination_mode", "refund_issuing_bank", "transaction_issuing_bank",
            "transaction_acquiring_bank_name", "ifsc_code", "trouble_id" };

    public static final String[] DIGITAL_OPS_HEADER = new String[] { "BANK_NAME", "mid", "txn_id", "REFUND_TXN_ID",
            "chargingEsn", "refundEsn", "mbid", "txn_date", "refund_date", "txn_amount", "refund_amount", "PAYMODE",
            "refund_bank_txn_id", "txn_bank_txn_id", "Age", "refund_type", "traceId", "AuthCode", "cardLast4Digit",
            "order_id", "cust_id", "status", "refundId", "txnType", "digitalOpsTeamStatus", "digitalOpsTeamRemark",
            "refund_bank_response_code" };
}
