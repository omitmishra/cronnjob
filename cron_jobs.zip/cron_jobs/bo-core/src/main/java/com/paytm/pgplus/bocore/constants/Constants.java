package com.paytm.pgplus.bocore.constants;

import com.paytm.pgplus.bocore.enums.EventStatus;
import com.paytm.pgplus.bocore.enums.IssueStatus;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Constants class
 *
 * @author Dheeraj Tyagi
 */
public class Constants {

    public static final String TIME_ZONE = "IST";

    public static final String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ssXXX";

    public static final String DATE_PATTERN_WITH_TIME = "yyyy-MM-dd HH:mm:ss";

    public static final String DD_MM_YYYY_DATE_FORMAT = "ddMMyyyy";

    public static final Object CSV_SEPARATOR = ",";

    public static final String BO_TEAM_DL_FOR_FAILED_REPORT_KEY = "BoTeamDlForFailedReportsKey";

    public static final java.lang.String SEARCH_TRANSACTION_URL = "pgplus-bo.search.transaction";
    public static final java.lang.String SEARCH_REFUND_URL = "pgplus-bo.search.refund";
    public static final java.lang.String SEARCH_DISCREPANCY_URL = "pgplus-bo.search.discrepancy";
    public static final java.lang.String MAPPING_SERVICE_URL = "mapping.service.url";
    public static final java.lang.String MAPPING_SERVICE_MERCHANT_DETAILS_URL = "mapping.service.merchant.details";
    public static final java.lang.String MAPPING_SERVICE_MERCHANT_CONTRACT_DETAILS_URL = "mapping.service.merchant.contract.details";

    public static final String CHARGING_SHEET = "Charging";
    public static final String REFUND_SHEET = "Refund";

    public static final String MERCHANT_MAPPING_INFO = "MERCHANT-MAPPING-INFO";
    public static final String MERCHANT_ACQUIRING_INFO = "MERCHANT-ACQUIRING-INFO";
    public static final String MERCHANT_EMI_INFO = "MERCHANT-EMI-INFO";
    public static final String MERCHANT_EXTENDED_INFO = "MERCHANT-EXTENDED-INFO";
    public static final String MERCHANT_PREFERENCE_INFO = "MERCHANT-PREFERENCE-INFO";
    public static final String CONTRACT_AVALABLE = "CONTRACT-AVALABLE";
    public static final String CONTRACT_DETAIL = "CONTRACT-DETAIL-";
    public static final String CONTRACT_NOT_AVALABLE = "CONTRACT-NOT-AVALABLE";
    public static final String MAIL_SENT_TO = "MAIL-SENT-TO";
    public static final String MIGRATION_INFO_FOR_MID = "MIGRATION INFO FOR MID: ";
    public static final String ZABBIX_HOSTNAME_KEY = "HOSTNAME";
    public static final String EDC_CHANNEL_CODE = "09";
    public static final String BANKCARD_PAY_MODE = "BC";
    public static final String EDC_PAY_MODE = "EDC";
    public static final String UNDERSCORE = "_";

    public static final List<String> INIT_AND_INPROGRESS_ISSUE_LIST = new ArrayList<String>() {
        {
            add(IssueStatus.IN_PROGRESS.name());
            add(IssueStatus.INIT.name());
        }
    };

    public static final List<String> INPROGRESS_ISSUE_LIST = new ArrayList<String>() {
        {
            add(IssueStatus.IN_PROGRESS.name());
        }
    };

    public static final List<String> INIT_ISSUE_LIST = new ArrayList<String>() {
        {
            add(IssueStatus.INIT.name());
        }
    };
    public static final java.lang.String ZABBIX_SERVICE_URL = "zabbix.service.url";
    public static final java.lang.String ZABBIX_AUTH_TOKEN = "zabbix.auth.token";
    public static final java.lang.String LAST_N_MINS_WINDOW = "zabbix.last.n.minute.window";
    public static final List<String> ALL_STATUS_LIST = new ArrayList<String>() {
        {
            add(IssueStatus.IN_PROGRESS.name());
            add(IssueStatus.INIT.name());
            add(IssueStatus.CLOSED.name());
            add(IssueStatus.RECEIVED.name());
            add(IssueStatus.REDUNDANT.name());
        }
    };;
    public static final List<String> ACTIONABLE_STATUS_LIST = new ArrayList<String>() {
        {
            add(IssueStatus.IN_PROGRESS.name());
            add(IssueStatus.CLOSED.name());
            add(IssueStatus.REDUNDANT.name());
        }
    };;

    public static final List<Integer> PRIORITY_LIST = new ArrayList<Integer>() {
        {
            add(4);
            add(3);
            add(2);
            add(1);
        }
    };;
    public static final List<String> JOB_STATUS_LIST = new ArrayList<String>() {
        {
            add("true");
            add("false");
        }
    };

    public static final List<EventStatus> ACTIVE_JOB_EVENT_STATUS = new ArrayList<EventStatus>() {
        {
            add(EventStatus.IN_PROGRESS);
            add(EventStatus.IN_QUEUE);
        }
    };
    public static final String WALLET_PAYOUT_SOURCE = "WALLET";
    public static final String PGPLUS_PAYOUT_SOURCE = "PGPLUS";

    public static final String STATUS_POD_UPLOAD = "POD_UPLOAD";
    public static final String STATUS_POD_REJECT = "POD_REJECT";
    public static final String AUDIT_TIMEOUT_WINDOW_KEY = "7";
    public static final String PAYMENTS_CRON_HOUR_KEY = "8";
    public static final String PAYMENT_CRON_MINUTE_KEY = "0";
    public static SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("HH:mm:ss");
    public static SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public static SimpleDateFormat NEW_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public static final String CHARBACK_OPEN_DISPUTE_REPORT_WINDOW = "chargeback.dispute.report.day.window";
    public static final String CHARBACK_OPEN_DISPUTE_REPORT_LOCAL_PATH = "chargeback.dispute.report.local.base.path";
    public static final String RECON_FILE_RECEIVED_REPORT_LOCAL_PATH = "recon.file.received.report.local.path";

    // New properties added for consolidated chargeback report
    public static final String CHARGEBACK_CONSOLIDATED_REPORT_WINDOW = "chargeback.consolidated.report.window";
    public static final String CHARGEBACK_CONSOLIDATED_REPORT_LOCAL_PATH = "chargeback.consolidated.report.local.base.path";

    public static final String PGPLUS_BO_BASE_URL = "pgplus.bo.base.url";
    public static final String CHARGEBACK_UPDATE_API_URL = "dispute.update.chargeback.url";
    public static final String DISPUTE_UTR_UPDATE_REPORT_WINDOW = "dispute.utr.update.report.window";
    public static final String DISPUTE_UTR_UPDATE_REPORT_LOCAL_BASE_PATH = "dispute.utr.update.report.local.base.path";
    public static final String CURRENT_DAY = "current_day";
    public static final String PREVIOUS_DAY = "previous_day";
    public static SimpleDateFormat DISPUTE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    public static final String BULK_POD_UPLOAD_LOT1 = "lot1";
    public static final String BULK_POD_UPLOAD_LOT2 = "lot2";
    public static final String BULK_UPLOAD_AND_CLOSE_REQUEST_TOPIC = "BULK_UPLOAD_AND_CLOSE_REQUEST";
    public static final String BULK_POD_UPLOAD_DATE_FORMAT = "yyyyMMdd";
    public static final String RECON_FILE_RECEIVED_REPORT_DAY_WINDOW = "recon.file.received.report.day.window";
}
