package com.paytm.pglpus.bocore.model.merchantReportEvents.eventinfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import org.file.util.model.SftpProperty;

import java.util.List;

@Data
@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SettlementReportHttpProcessorInfo extends EventProcessorInfoBase {
    /**
     * Properties related to sftp file.
     */
    private List<MerchantReportFileInfo> merchantReportFileInfos;
}
