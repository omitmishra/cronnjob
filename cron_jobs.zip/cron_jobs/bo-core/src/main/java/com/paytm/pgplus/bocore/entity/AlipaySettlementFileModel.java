package com.paytm.pgplus.bocore.entity;

//
// package com.paytm.pgplus.scheduler.entity;
//
// import java.util.Date;
//
// public class AlipaySettlementFileModel {
//
// private Long extSerialNo;
// private String transType;
// private String resultStatus;
// private long resultCodeId;
// private String bankAbbr;
// private String referenceNo;
// private long traceNo;
// private String authCode;
// private String rrnCode;
// private String merchantId;
// private String mbid;
// private double paidAmount;
// private String paidCurrency;
// private Date transBankDate;
// private Date lastUpdateDate;
// private double feeAmount;
// private String feeCurrency;
//
// public Long getExtSerialNo() {
// return extSerialNo;
// }
//
// public void setExtSerialNo(Long extSerialNo) {
// this.extSerialNo = extSerialNo;
// }
//
// public String getTransType() {
// return transType;
// }
//
// public void setTransType(String transType) {
// this.transType = transType;
// }
//
// public String getResultStatus() {
// return resultStatus;
// }
//
// public void setResultStatus(String resultStatus) {
// this.resultStatus = resultStatus;
// }
//
// public long getResultCodeId() {
// return resultCodeId;
// }
//
// public void setResultCodeId(long resultCodeId) {
// this.resultCodeId = resultCodeId;
// }
//
// public String getBankAbbr() {
// return bankAbbr;
// }
//
// public void setBankAbbr(String bankAbbr) {
// this.bankAbbr = bankAbbr;
// }
//
// public String getReferenceNo() {
// return referenceNo;
// }
//
// public void setReferenceNo(String referenceNo) {
// this.referenceNo = referenceNo;
// }
//
// public long getTraceNo() {
// return traceNo;
// }
//
// public void setTraceNo(long traceNo) {
// this.traceNo = traceNo;
// }
//
// public String getAuthCode() {
// return authCode;
// }
//
// public void setAuthCode(String authCode) {
// this.authCode = authCode;
// }
//
// public String getRrnCode() {
// return rrnCode;
// }
//
// public void setRrnCode(String rrnCode) {
// this.rrnCode = rrnCode;
// }
//
// public String getMerchantId() {
// return merchantId;
// }
//
// public void setMerchantId(String merchantId) {
// this.merchantId = merchantId;
// }
//
// public String getMbid() {
// return mbid;
// }
//
// public void setMbid(String mbid) {
// this.mbid = mbid;
// }
//
// public double getPaidAmount() {
// return paidAmount;
// }
//
// public void setPaidAmount(double paidAmount) {
// this.paidAmount = paidAmount;
// }
//
// public String getPaidCurrency() {
// return paidCurrency;
// }
//
// public void setPaidCurrency(String paidCurrency) {
// this.paidCurrency = paidCurrency;
// }
//
// public Date getTransBankDate() {
// return transBankDate;
// }
//
// public void setTransBankDate(Date transBankDate) {
// this.transBankDate = transBankDate;
// }
//
// public Date getLastUpdateDate() {
// return lastUpdateDate;
// }
//
// public void setLastUpdateDate(Date lastUpdateDate) {
// this.lastUpdateDate = lastUpdateDate;
// }
//
// public double getFeeAmount() {
// return feeAmount;
// }
//
// public void setFeeAmount(double feeAmount) {
// this.feeAmount = feeAmount;
// }
//
// public String getFeeCurrency() {
// return feeCurrency;
// }
//
// public void setFeeCurrency(String feeCurrency) {
// this.feeCurrency = feeCurrency;
// }
//
// @Override
// public String toString() {
// return "AlipaySettlementFileModel [extSerialNo=" + extSerialNo + ",
// transType=" + transType + ", resultStatus=" + resultStatus
// + ", resultCodeId=" + resultCodeId + ", bankAbbr=" + bankAbbr + ",
// referenceNo=" + referenceNo + ", traceNo=" + traceNo
// + ", authCode=" + authCode + ", rrnCode=" + rrnCode + ", merchantId=" +
// merchantId + ", mbid=" + mbid + ", paidAmount="
// + paidAmount + ", paidCurrency=" + paidCurrency + ", transBankDate=" +
// transBankDate + ", lastUpdateDate=" + lastUpdateDate
// + ", feeAmount=" + feeAmount + ", feeCurrency=" + feeCurrency + "]";
// }
//
// public String header() {
// return ("extSerialNo" + ",transType" + ",resultStatus" + ",resultCodeId" +
// ",bankAbbr" + ",referenceNo" + ",traceNo" + ",authCode"
// + ",rrnCode" + ",merchantId" + ",mbid" + ",paidAmount" + ",paidCurrency" +
// ",transBankDate" + ",lastUpdateDate"
// + ",feeAmount" + ",feeCurrency");
// }
//
// public String valueString() {
// return "" + extSerialNo + "," + transType + "," + resultStatus + "," +
// resultCodeId + "," + bankAbbr + "," + referenceNo + ","
// + traceNo + "," + authCode + "," + rrnCode + "," + merchantId + "," + mbid +
// "," + paidAmount + "," + paidCurrency + ","
// + transBankDate + "," + lastUpdateDate + "," + feeAmount + "" + feeCurrency;
// }
//
// }
