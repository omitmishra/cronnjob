package com.paytm.pglpus.bocore.model.msr;

import com.paytm.pgplus.bocore.constants.Constants;
import com.paytm.pgplus.bocore.constants.MSRBillFileColumn;
import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import com.paytm.pgplus.bocore.enums.TransactionType;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.math.BigDecimal;

public abstract class MerchantSettlementReport implements Serializable {

    public MerchantSettlementReport(TransactionType transactionType,
            MerchantSettlementReportType merchantSettlementReportType) {
        this.transactionType = transactionType;
        this.merchantSettlementReportType = merchantSettlementReportType;
    }

    @CSVColumn(name = MSRBillFileColumn.TRANSACTION_TYPE)
    private TransactionType transactionType;

    private MerchantSettlementReportType merchantSettlementReportType;

    public abstract BigDecimal getTotalAmount();

    public abstract BigDecimal getTransactionAmount();

    public abstract BigDecimal getServiceTax();

    public abstract BigDecimal getMerchantCommission();

    public abstract String getPayoutId();

    public abstract String getUtr();

    public abstract String getPaytmMerchantId();

    public abstract String getMerchantBillId();

    public abstract String getPrnCode();

    public abstract String getOriginalMID();

    public String getPayoutSource() {
        String payoutId = getPayoutId();
        if (StringUtils.isNotEmpty(payoutId)) {
            if (payoutId.startsWith(Constants.WALLET_PAYOUT_SOURCE)) {
                return Constants.WALLET_PAYOUT_SOURCE;
            } else {
                return Constants.PGPLUS_PAYOUT_SOURCE;
            }
        }
        return null;
    }

    public TransactionType getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(TransactionType transactionType) {
        this.transactionType = transactionType;
    }

    public MerchantSettlementReportType getMerchantSettlementReportType() {
        return merchantSettlementReportType;
    }

    public void setMerchantSettlementReportType(MerchantSettlementReportType merchantSettlementReportType) {
        this.merchantSettlementReportType = merchantSettlementReportType;
    }
}
