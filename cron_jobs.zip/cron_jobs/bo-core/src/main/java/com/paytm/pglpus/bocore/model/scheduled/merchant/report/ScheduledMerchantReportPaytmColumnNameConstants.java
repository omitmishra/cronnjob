package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

public class ScheduledMerchantReportPaytmColumnNameConstants {

    public static final String PAYMENT_ID = "PAYMENT_ID";

    public static final String TXN_ID = "TXN_ID";

    public static final String ORDER_ID = "OrderId";

    public static final String M_ID = "MID";

    public static final String ALI_MID = "ALI_MID";

    public static final String M_NAME = "MerchantName";

    public static final String RESPONSE_CODE = "ResponseCode";

    public static final String PAYMENT_MODE = "PaymentMode";

    public static final String WEBSITE = "Website";

    public static final String BANK_TXN_ID = "BankTxnID";

    public static final String CUST_ID = "CustID";

    public static final String BASE_AMT = "BASE_AMOUNT";

    public static final String COMMISSION = "CommissionAmt";

    public static final String TXN_AMOUNT = "TXN_AMOUNT";

    public static final String TOTAL_AMOUNT = "TOTAL_AMOUNT";

    public static final String SETTLED_AMT = "SettledAmt";

    public static final String REFUND_AMT = "RefundAmt";

    public static final String TOTAL_CANCEL_AMOUNT = "totalCancelAmount";

    public static final String CHARGEBACK_AMT = "CB Amt";

    public static final String MERCHANT_UNQ_REF = "MerchantUnqRef";

    public static final String TXN_TYPE = "TXN_TYPE";

    public static final String S_TAX = "ServiceTax/GST";

    public static final String TXN_DATE = "TxnDate";

    public static final String UPDATED_DATE = "UPDATED_ON";

    public static final String PAYOUT_DATE = "Payout Date";

    public static final String SETTLED_DATE = "SettledDate";

    public static final String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
}
