package com.paytm.pglpus.bocore.model.merchantReportEvents.eventinfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@ToString
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventProcessorInfoBase {
    private String failureMessage;
    private int retryCount;
}
