package com.paytm.pgplus.bocore.constants;

public class EDCConstants {

    public static final String DATE_PATTERN_WITH_TIME = "yyyy-MM-dd HH:mm:ss";

    public static final int BATCH_SIZE = 400;

    public static final String DELIMITER = ",";

    public static final String HYPHEN = "-";

    public static final String APOSTROPHE = "'";

    public static final String TXN_TYPE = "txnType";

    public static final String CARD_NO = "cardNo";

    public static final String TXN_AMOUNT = "txnAmount";

    public static final String RRN = "rrn";

    public static final String AUTH_ID = "authId";

    public static final String STAN = "stan";

    public static final String BANK_CODE = "bankCode";

    public static final String TXN_TIME = "txnTime";

    public static final String BANK_MID = "bankMid";

    public static final String PAYTM_TID = "paytmTid";

    public static final String CLIENT_ID = "clientId";

    public static final String ARN = "arn";

    public static final String CSV_EXTENSION = ".csv";

    public static final String PAYTM_ID = "paytmId";

    public static final String NO_OF_SALE = "noOfSale";

    public static final String TXN_DATE = "txnDate";

    public static final String TXN_ID = "txnId";

    public static final String ORDER_ID = "orderId";

    public static final String AMOUNT_OF_DEBITS_SALE = "amountOfDebitsSale";

    public static final String NUMBER_OF_REFUND = "numberOfRefund";

    public static final String AMOUNT_OF_DEBITS_REFUND = "amountOfDebitRefund";

    public static final String BATCH_SETTELMENT_STATUS = "batchSettlementStatus";

    public static final String EDC_CHARGEBACK_FILE_PREFIX = "EDC_CHARGEBACK_";

    public static final String EDC_MERCHANT_TXN_DETAILS_FILE_PREFIX = "EDC_MERCHANT_TXN_DETAILS_";

    public static final String EDC = "edc";

    public static final Integer ZERO = Integer.valueOf(0);

    public static final Integer TODAY_DATE = Integer.valueOf(1);

    public static final Integer TWO = Integer.valueOf(2);

    public static final Integer HUNDRED = Integer.valueOf(100);

    public static final Integer ONE = Integer.valueOf(1);

    public static final Integer THREE = Integer.valueOf(3);

    /**
     * HDFC Cron Status Mapping Constant
     */
    public static final String STARTED = "STARTED";
    public static final String SETTLEMENT_COMPLETED = "SETTLEMENT_COMPLETED";
    public static final String AGGREGATED_DATA_SAVED = "AGGREGATED_DATA_SAVED";
    public static final String TRANSACTIONAL_DATA_SAVED = "TRANSACTIONAL_DATA_SAVED";
    public static final String STATUS = "status";
    public static final String BATCH_DATE = "DATE";

    /**
     * HDFC Settlement Mapping Constant
     */
    public static final String BATCH_SETTLEMENT_ID = "batchSettlementId";
    public static final String BANK_TID = "bankTid";
    public static final String ICC_DATA = "iccData";
    public static final String TRANSLATED_PAN = "translatedPan";
    public static final String AMT_DEBIT_SALES = "amtDebitSales";
    public static final String NO_CREDIT_SALES = "noCreditSales";
    public static final String AMT_CREDIT_SALES = "amtCreditSales";
    public static final String PROCESSING_CODE = "processingCode";
    public static final String TRANSACTION_AMOUNT = "transactionAmount";
    public static final String TRANSACTION_TIME = "transactionTime";
    public static final String TRANSACTION_DATE = "transactionDate";
    public static final String TRANSLATED_CARD_EXPIRY = "translatedCardExpiry";
    public static final String POS_ENTRY_MODE = "posEntryMode";
    public static final String POS_CONDITION_CODE = "posConditionCode";
    public static final String RRN_CODE = "rrnCode";
    public static final String AUTH_CODE = "authCode";
    public static final String INVOICE_NUMBER = "invoiceNumber";
    public static final String AGGREGATE_STATUS = "aggregateStatus";
    public static final String VOID_STAN = "voidStan";
    public static final String PAY_MODE = "payMethod";
    public static final String BATCH_UPLOAD_STATUS = "batchUploadStatus";
    public static final String FORCE_SETTLEMENT_STATUS = "forceSettlementStatus";
    public static final String SETTLEMENT_DATE = "settlementData";

    public static final String NO_OF_SETTLED_SALE = "noOfSettledSale";
    public static final String AMOUNT_OF_SETTLED_SALE = "amountOfSettledSale";
    public static final String NUMBER_OF_SETTLED_REFUND = "numberOfSettledRefund";
    public static final String AMOUNT_OF_SETTLED_REFUND = "amountOfSettledRefund";

    public static final String RESULT_CODE = "resultCode";
    public static final String RESULT_CODE_ID = "resultCodeId";
    public static final String RESULT_MSG = "resultMsg";
    public static final String EXTERNAL_SERIAL_NUMBER = "externalSerialNo";
    public static final String SERVICE_INST_ID = "serviceInstId";
    public static final String BANK_ABBR = "bankAbbr";

    public static final String MERCHANT_TRANS_ID = "merchantTransId";
    public static final String TRANSACTION_TYPE = "transactionType";
    public static final String TXN_UPLOAD_STATUS = "txnUploadStatus";

    /*
     * EDC TXN FILE DETAILS
     */

    public static final String EMPTY = "";

    public static final String EDC_TXN_ID = "txn_id";

    public static final String DETAIL_NO = "detail_no";

    public static final String MERCHANT_ID = "merchant_id";

    public static final String ORIGINAL_MERCHANT_ID = "original_merchant_id";

    public static final String MERCHANT_NAME = "merchant_name";

    public static final String MBID = "mbid";

    public static final String PAYMENT_DATE = "payment_date";

    public static final String TERMINAL_TYPE = "terminal_type";

    public static final String PAYMENT_AMOUNT = "payment_amount";

    public static final String PAYMENT_CURRENCY = "payment_currency";

    public static final String EDC_ORDER_ID = "order_id";

    public static final String RESPONSE_CODE = "response_code";

    public static final String PAY_METHOD = "pay_method";

    public static final String BANK_TXN_ID = "bank_txn_id";

    public static final String USER_CUST_ID = "user_cust_id";

    public static final String ISSUING_BANK = "issuing_bank";

    public static final String BANK_GATEWAY = "bank_gateway";

    public static final String BANK_FEE_CURRENCY = "bank_fee_currency";

    public static final String BANK_FEE_AMOUNT = "bank_fee_amount";

    public static final String EDC_TXN_TYPE = "txn_type";

    public static final String MERCHANT_COMMISSION = "merchant_commission";

    public static final String SERVICE_TAX = "service_tax";

    public static final String CONVENIENCE_FEE = "convenience_fee";

    public static final String CONVENIENCE_TAX = "convenience_tax";

    public static final String SETTLED_DATE = "settled_date";

    public static final String REFUND_AMOUNT = "refund_amount";

    public static final String INDUSTRY = "industry";

    public static final String SETTLEMENT_TXN_ID = "settlement_txn_id";

    public static final String INSTCODE = "instcode";

    public static final String EXTERNAL_SERIAL_NO = "external_serial_no";

    public static final String RECON_ID = "recon_id";

    public static final String SETTLEMENT_TYPE = "settlement_type";

    public static final String SETTLE_TYPE = "settle_type";

    public static final String EDC_TXN_FILE_PREFIX = "REPORTS_PAYMENT_DETAIL";

    public static final String PEDC = "PEDC";

    public static final String CREDIT_CARD = "CREDIT_CARD";

    public static final String DEBIT_CARD = "DEBIT_CARD";

    public static final String EMI = "EMI";

    public static final String CC = "CC";

    public static final String DC = "DC";

    // EDC REPORT HEADERS

    public static final String R_EDC_TXN_ID = "TXN_ID";

    public static final String R_MERCHANT_ID = "MID";

    public static final String R_MERCHANT_NAME = "Merchant Name";

    public static final String R_MBID = "MBID";

    public static final String R_PAYMENT_DATE = "Txn Date";

    public static final String R_TERMINAL_TYPE = "Txn Channel";

    public static final String R_PAYMENT_AMOUNT = "Txn Amount";

    public static final String R_PAYMENT_CURRENCY = "Currency Type";

    public static final String R_EDC_ORDER_ID = "Order Id";

    public static final String R_RESPONSE_CODE = "Response Code";

    public static final String R_PAY_METHOD = "Payment Mode";

    public static final String R_BANK_TXN_ID = "Bank Txn ID";

    public static final String R_USER_CUST_ID = "Cust ID";

    public static final String R_CC_DC_LAST_FOUR = "CC DC Last 4";

    public static final String R_ISSUING_BANK = "Issuing Bank";

    public static final String R_BANK_GATEWAY = "Bank Gateway";

    public static final String R_STATUS = "Status";

    public static final String R_BANK_FEE_CURRENCY = "bank_fee_currency";

    public static final String R_BANK_FEE_AMOUNT = "Bank Fees";

    public static final String R_GATEWAY_PAYMODE = "Gateway_PayMode";

    public static final String R_EDC_TXN_TYPE = "TXN_TYPE";

    public static final String R_MERCHANT_COMMISSION = "Merchant Commission";

    public static final String R_SERVICE_TAX = "service_tax";

    public static final String R_CONVENIENCE_FEE = "convenience_fee";

    public static final String R_CONVENIENCE_TAX = "convenience_tax";

    public static final String R_SETTLED_DATE = "Settled Date";

    public static final String R_PARENT_TXN_ID = "Parent Txn ID";

    public static final String R_CHILD_TXN_FLAG = "Child Txn Flag";

    public static final String R_REFUND_AMOUNT = "Refund Amt";

    public static final String R_INDUSTRY = "Industry";

    public static final String R_PAYOUT_ID = "Payout Id";

    public static final String R_BASE_AMOUNT = "Base Amount";

    public static final String R_BUSINESS_NAME = "Business_Name";

    public static final String R_SETTLEMENT_TXN_ID = "settlement_txn_id";

    public static final String R_INSTCODE = "instcode";

    public static final String R_EXTERNAL_SERIAL_NO = "external_serial_no";

    public static final String R_ACTUAL_CARD_TYPE = "ACTUAL_CARD_TYPE";

    public static final String R_RECON_ID = "RECON_ID";

    public static final String R_SETTLEMENT_TYPE = "SETTLEMENT_TYPE";

    public static final String R_CUST_ID_NEW = "CUST_ID_NEW";

    public static final String R_BK_DATE = "BK_DATE";

    public static final String R_DUMMY_ONE = "DUMMY1";

    public static final String R_DUMMY_TWO = "DUMMY2";

    public static final String R_SETTLE_TYPE = "sett_type";

    // Properties

    public static final String SLASH = "/";

    public static final String FALSE = "false";

    public static final String DATE_PLACEHOLDER = "date_placeholder";

    public static final String TXN_FILE_DAY_DEFAULT = "-1";

    public static final String TXN_AND_LOGON_DEFAULT_BUFFER_TIME_IN_MS = "300000";

    public static final String TXN_FILE_DAY = "txn.file.day";

    public static final String MAPPING_SERVICE_BASE_URL = "mapping.service.base.url";

    public static final String DEVICE_MAPPING_BY_PAYTMTID = "/eos/merchant/device/details/tid/bankName";
    public static final String HEDC = "HEDC";

    public static final String EDC_HDFC_TXN_FILE_DAY = "edc.hdfc.txn.file.day";

    public static final String TXN_AND_LOGON_BUFFER_TIME_DIFF = "txn.and.logon.buffer.time.diff";

    public static final String EDC_HDFC_AGGREGATE_TXN_SFTP_FILE_DIR_PATH = "edc.hdfc.aggregate.txn.sftp.file.dir.path";

    public static final String EDC_HDFC_AGGREGATE_TXN_LOCAL_FILE_DIR_PATH = "edc.hdfc.aggregate.txn.local.file.dir.path";

    public static final String EDC_HDFC_BATCH_UPLOAD_TXN_LOCAL_FILE_DIR_PATH = "edc.hdfc.batch.upload.txn.local.file.dir.path";

    public static final String EDC_HDFC_BATCH_UPLOAD_TXN_SFTP_FILE_DIR_PATH = "edc.hdfc.batch.upload.txn.sftp.file.dir.path";

    public static final String EDC_BANKS_AUTO_SETTLEMENT_AGGREGATION_NAME = "edc.banks.auto.settlement.aggregation.name";

    public static final String EDC_HDFC_LOAD_FROM_AGGREGATE_FILE_FLAG = "edc.hdfc.load.from.file";

    public static final String CRON_TIME = "txn.file.job.time";

    public static final String EDC_TXN_FILE_ENABLED = "edc.txn.file.enabled";

    public static final String EDC_HDFC_SETTLEMENT_CRON_TIME = "edc.hdfc.settlement.cron.time";

    public static final String TXN_FILE_DIR_PATH = "txn.file.dir.path";

    public static final String TXN_FILE_LOCAL_PATH = "txn.file.local.path";

    public static final String DONE_PREFIX = "Done_";

    public static final String FOLDER_MONTH = "folder.month";

    public static final String MONTH_WISE_FOLDER = "month.wise.folder";

    public static final String MERCHANT_WISE_TXN_FILE_BASENAME = "edc.file.basename";

    public static final String MERCHANT_WISE_TXN_FILE_LOCAL_PATH = "txn.file.local.path";

    public static final String TXN_FILE_NAME_PREFIX = "txn.file.name.prefix";

    public static final String EDC_HDFC_AGGREGATE_TXN_FILE_NAME_PREFIX = "edc.hdfc.aggregate.txn.file.name.prefix";

    public static final String EDC_HDFC_BATCH_UPLOAD_TXN_FILE_NAME_PREFIX = "edc.batch.upload.txn.file.name.prefix";

    public static final String SFTP_REMOTE_HOST = "sftp.upload.remote.report.host";

    public static final String SFTP_REMOTE_PORT = "sftp.upload.remote.report.port";

    public static final String SFTP_REMOTE_USER = "sftp.upload.remote.report.user";

    public static final String SFTP_REMOTE_PASSWORD = "sftp.upload.remote.report.password";

    public static final String SFTP_REMOTE_PATH = "sftp.upload.remote.report.path";

    public static final String EMAIL_CC = "txn.report.email.cc";

    public static final String EMAIL_TO = "txn.report.email.to";

    public static final String SUCCESS_MESSAGE = "txn.report.success.message";

    public static final String DEFAULT_SUCCESS_MESSAGE = "EDC-HDFC Batch Settlement is successful for fileDate:";

    public static final String FAILURE_MESSAGE = "txn.report.failure.message";

    public static final String DEFAULT_FAILURE_MESSAGE = "ALERT: Settlement failed for following Tid";

    public static final String REPORT_SUBJECT = "txn.report.subject";

    public static final String DEFAULT_REPORT_SUBJECT = "Hdfc Batch Settlement Cron Status for fileDate:";

    public static final String STATUS_CRON_FORMAT = "yyyyMMdd";

    public static final String SET_MANUAL_RUN_DATE = "set.manual.run.date";

    public static final String SUCCESS = "SUCCESS";

    public static final String FAILED = "FAILED";

    public static final String FAILED_TID_LIST = "ALERT: HDFC BATCH Settlement failed for following TID :: ";

    public static final String EDC_ACQUIRING_CHANNELS = "edc.acquiring.channels";

    public static final String PEDC_DC = "D";

    public static final String PEDC_CC = "C";

    public static final String[] EDC_CHARGEBACK_FILE_HEADER = { TXN_TYPE, CARD_NO, TXN_AMOUNT, RRN, AUTH_ID, STAN, ARN,
            PAYTM_ID, TXN_DATE, TXN_ID, ORDER_ID };

    public static final String[] EDC_TXN_FILE_HEADER = { "TXN_ID", "MID", "Merchant Name", "Txn Date", "MBID",
            "Txn Channel", "Txn Amount", "Currency Type", "Order Id", "Response Code", "Payment Mode", "Bank Txn ID",
            "Cust ID", "CC DC Last 4", "Issuing Bank", "Bank Gateway", "Status", "Bank Fees", "Gateway_PayMode",
            "TXN_TYPE", "Merchant Commission", "Settled Date", "Parent Txn ID", "Child Txn Flag", "Refund Amt",
            "Industry", "Payout Id", "Base Amount", "Business_Name", "external_serial_no", "ACTUAL_CARD_TYPE",
            "RECON_ID", "SETTLEMENT_TYPE", "CUST_ID_NEW", "BK_DATE", "DUMMY1", "DUMMY2", "sett_type" };

    // CashPos Cron Constants

    public static final String PEDC_SUCCESS_RESP_CODE = "00";
    public static final String PEDC_CASH_TRANSACTION_TYPE = "09";
    public static final String PEDC_TRANS_REVERSED_NO = "N";
    public static final String PEDC_MERCHAN_ID = "Merchant ID";
    public static final String PEDC_FILE_EXTENSION = ".xlsx";

    public static final String[] PEDC_MONTHS = { "NA", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep",
            "Oct", "Nov", "Dec" };
    public static final String PEDC_FILE_PREFIX = "pedc.file.prefix";
    public static final String PEDC_FILE_DAY = "pedc.file.day";
    public static final String PEDC_REMOTE_FILE_DIRECTORY = "pedc.remote.file.directory";
    public static final String PEDC_LOCAL_FILE_DIRECTORY = "pedc.local.file.directory";
    public static final String PEDC_INCENTIVE_GST_PERCENTAGE = "pedc.cash.incentive.percentage";

    public static final String[] PEDC_FILE_HEADER = { "Merchant ID", "Terminal ID", "Merchant Name", "Message type",
            "PAN", "Transaction type", "Amount", "Date/Time", "Retr Ref Nr", "Auth ID", "Response Code",
            "Invoice Number", "Interchange Type", "Tran Reversed", "ISSETTLED", "3DS Auth RC", "3DS Enroll", "STAN",
            "FEE_AMOUNT", "MCC", "pos_entry_mode", "Credit_debit", "card_product", "CardCountry", "ARN", "batch_nr",
            "PayTM_ID", "0.75% IncentiveAmount", "Cash@pos IncentiveAmount" };

    public static class PedcFileColumn {
        public static final String PAYTM_ID = "PayTM_ID";
        public static final String BANK_MID = "Merchant ID";
        public static final String BANK_TID = "Terminal ID";
        public static final String TXN_DATE = "Date/Time";
        public static final String RESPONSE_CODE = "Response Code";
        public static final String TRAN_REVERSED = "Tran Reversed";
        public static final String TXN_TYPE = "Transaction type";
        public static final String AMOUNT = "Amount";
        public static final String RRN = "Retr Ref Nr";
        public static final String PAYMENT_MODE = "Credit_debit";
        public static final String INCENTIVE_AMOUNT = "Cash@pos IncentiveAmount";
    }
}
