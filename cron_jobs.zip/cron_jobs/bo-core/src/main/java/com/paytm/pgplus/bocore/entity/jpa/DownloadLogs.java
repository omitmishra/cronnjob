package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by dheeraj on 20/08/17.
 */

@Entity
@Table(name = "download_logs")
@Data
public class DownloadLogs extends BaseEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", nullable = false, updatable = false)
    long id;

    @Column(name = "download_id")
    String downloadId;

    @Column(name = "request_source")
    String requestSource;

    @Column(name = "status")
    String status;

    @Column(name = "column_requested")
    String columnRequested;

    @Column(name = "request_type")
    String requestType;

    @Column(name = "request_to_noti_receive_time")
    String requestToNotiReceiveTime;

    @Column(name = "noti_received_to_noti_sent_time")
    String notiReceivedToNotiSentTime;

    @Column(name = "error_code")
    String errorCode;

    @Column(name = "request")
    String request;

}
