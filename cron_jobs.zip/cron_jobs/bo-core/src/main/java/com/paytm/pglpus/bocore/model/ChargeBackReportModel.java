package com.paytm.pglpus.bocore.model;

import com.paytm.pgplus.bocore.entity.ChargebackReportHeader;
import com.paytm.pgplus.bocore.enums.ChargebackSource;
import lombok.Data;
import org.file.util.annotation.CsvColumnMapper;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author Mayank Aggarwal
 * @since August 2020
 */

@Data
public class ChargeBackReportModel {

    @CsvColumnMapper(columnName = ChargebackReportHeader.DISPUTE_ID)
    private String disputeId;
    @CsvColumnMapper(columnName = ChargebackReportHeader.DISPUTE_CREATION_DATE)
    private String disputeCreationDate;
    @CsvColumnMapper(columnName = ChargebackReportHeader.TXN_ID)
    private String txnId;
    @CsvColumnMapper(columnName = ChargebackReportHeader.TXN_DATE)
    private Date txnDate;
    @CsvColumnMapper(columnName = ChargebackReportHeader.ORDER_ID)
    private String orderId;
    @CsvColumnMapper(columnName = ChargebackReportHeader.TXN_AMOUNT)
    private BigDecimal txnAmount;
    @CsvColumnMapper(columnName = ChargebackReportHeader.DISPUTE_AMOUNT)
    private BigDecimal disputeAmount;
    @CsvColumnMapper(columnName = ChargebackReportHeader.DISPUTE_STATUS)
    private String disputeStatus;
    @CsvColumnMapper(columnName = ChargebackReportHeader.MID)
    private String mid;
    @CsvColumnMapper(columnName = ChargebackReportHeader.ESN)
    private String esn;
    @CsvColumnMapper(columnName = ChargebackReportHeader.DISPUTE_UTR)
    private String disputeUtr;
    @CsvColumnMapper(columnName = ChargebackReportHeader.DISPUTE_UPDATE_DATE)
    private Date disputeUpdateDate;
    @CsvColumnMapper(columnName = ChargebackReportHeader.STATUS_COMMENT)
    private String comment;
    @CsvColumnMapper(columnName = ChargebackReportHeader.BANK_REFERENCE_ID)
    private String bankReferenceId;
    @CsvColumnMapper(columnName = ChargebackReportHeader.BANK_GATEWAY)
    private String bankGateway;
    @CsvColumnMapper(columnName = ChargebackReportHeader.DUE_DATE)
    private String dueDate;
    @CsvColumnMapper(columnName = ChargebackReportHeader.REASON_ACCEPTANCE)
    private String reasonAcceptance;
}