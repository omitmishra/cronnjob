package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.fasterxml.jackson.annotation.JsonValue;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.io.Serializable;

@JsonDeserialize(using = ScheduledMerchantReportColumnNameDeserializer.class)
public interface ScheduledMerchantReportColumnName extends Serializable {

    @JsonValue
    String getColumnName();
}
