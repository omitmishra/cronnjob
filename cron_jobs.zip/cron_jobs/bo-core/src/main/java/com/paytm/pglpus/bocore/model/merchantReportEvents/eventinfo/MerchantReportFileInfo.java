package com.paytm.pglpus.bocore.model.merchantReportEvents.eventinfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantReportFileInfo {
    private MerchantSettlementReportType reportType;
    private String remoteFilePath;
    private String remoteFileBaseName;
    private String remoteFileExtension;
    private String localFilePath;
}
