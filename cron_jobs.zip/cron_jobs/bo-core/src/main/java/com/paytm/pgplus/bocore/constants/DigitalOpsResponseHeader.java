package com.paytm.pgplus.bocore.constants;

/**
 * 
 * @author ankitkasat
 *
 */
public class DigitalOpsResponseHeader {

    public static final String MANUAL_REFUND_ID = "ID";
    public static final String REFUND_TRANSACTION_ID = "Refund Transaction ID";
    public static final String CHARGING_ESN = "Charging esn";
    public static final String RRN_CODE = "RRN CODE";
    public static final String BANK_REFERENCE_NO = "bankReferenceNo";
    public static final String STATUS = "Status";
    public static final String REFUND_DATE = "Refund Date";
    public static final String MESSAGE_AMOUNT = "Message+Amount";
    public static final String ERROR_REMARKS = "Error Remarks";
    public static final String PHONE_NUMBER = "Phone Number";
    public static final String ESN = "Trouble ESN";
    public static final String SERVICE_INSTANCE_ID = "Bank Name";
    public static final String MBID = "Mbid";
    public static final String PAY_METHOD = "Pay Method";
    public static final String MASKED_CARD_NUMBER = "Masked Card Number";
    public static final String VPA = "VPA";
    public static final String ISSUING_BANK_NAME = "Issuing Bank Name";
    public static final String TROUBLE_ID = "Trouble Id";
    public static final String REFUND_TYPE = "Refund Type";
    public static final String CARD_SCHEME = "Card Scheme";
    public static final String CUSTOMER_ID = "Customer Id";

    public static final String[] DIGITAL_OPS_RESPONSE_HEADER = new String[] { MANUAL_REFUND_ID, REFUND_TRANSACTION_ID,
            CHARGING_ESN, RRN_CODE, BANK_REFERENCE_NO, STATUS, REFUND_DATE, MESSAGE_AMOUNT, PHONE_NUMBER, ESN,
            SERVICE_INSTANCE_ID, MBID, PAY_METHOD, MASKED_CARD_NUMBER, VPA, ISSUING_BANK_NAME, TROUBLE_ID, REFUND_TYPE,
            CARD_SCHEME, CUSTOMER_ID };

}
