package com.paytm.pgplus.bocore.entity;

import com.paytm.pglpus.bocore.model.ManualRefundColumnMapper;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.file.util.annotation.CsvColumnMapper;

import javax.persistence.*;
import java.util.Date;

/**
 * @author dheeraj
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "manual_refunds")
@NamedQueries({
        @NamedQuery(name = "ManualRefund.findByOrderId", query = "SELECT a FROM ManualRefund a WHERE a.orderId = :orderId"),
        @NamedQuery(name = "ManualRefund.findByRefTxnId", query = "SELECT a FROM ManualRefund a WHERE a.refundTxnId = :refundTxnId"),
        @NamedQuery(name = "ManualRefund.findByRefTxnIdOrChargingEsn", query = "SELECT a FROM ManualRefund a WHERE (a.refundTxnId != '' AND a.refundTxnId IS NOT NULL AND a.refundTxnId = :refundTxnId) OR (a.chargingEsn != '' AND a.chargingEsn IS NOT NULL AND a.chargingEsn = :chargingEsn)"),
        @NamedQuery(name = "ManualRefund.findByTxnId", query = "SELECT a FROM ManualRefund a WHERE a.acquiringTxnId = :acquiringTxnId"),
        @NamedQuery(name = "ManualRefund.findByTxnAndRefTxnId", query = "SELECT a FROM ManualRefund a WHERE "
                + "a.acquiringTxnId = :acquiringTxnId and a.refundTxnId = :refundTxnId") })
@NamedQuery(name = "ManualRefund.findByRefTxnIdAndPaymode", query = "SELECT a FROM ManualRefund a WHERE a.refundTxnId = :refundTxnId and a.paymode= :paymode")
public class ManualRefund extends BaseEntity {

    /**
     *
     */
    private static final long serialVersionUID = 6944547160448929921L;

    @Basic(optional = false)
    @Column(name = "id", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.ID)
    private Long id;

    @Column(name = "manual_refund_type")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.MANUAL_REFUND_TYPE)
    private String manualRefundType;

    @Column(name = "bank_name")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.BANK_NAME)
    private String bankName;

    @Column(name = "mid")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.MID)
    private String mid;

    @Column(name = "mbid")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.MBID)
    private String mbid;

    @Column(name = "txn_date")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.TXN_DATE)
    private String txnDate;

    @Column(name = "txn_amount")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.TXN_AMOUNT)
    private String txnAmount;

    @Column(name = "paymode")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.PAYMODE)
    private String paymode;

    @Column(name = "txn_bank_txn_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.TXN_BANK_TXN_ID)
    private String txnBankTxnId;

    @Column(name = "order_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.ORDER_ID)
    private String orderId;

    @Column(name = "charging_recon_status")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.CHARGING_RECON_STATUS)
    private String chargingReconStatus;

    @Column(name = "order_status")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.ORDER_STATUS)
    private String orderStatus;

    @Column(name = "charging_esn")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.CHARGING_ESN)
    private String chargingEsn;

    @Column(name = "acquiring_txn_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.ACQUIRING_TXN_ID)
    private String acquiringTxnId;

    @Column(name = "refund_type")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_TYPE)
    private String refundType;

    @Column(name = "refund_txn_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_TXN_ID)
    private String refundTxnId;

    @Column(name = "refund_date")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_DATE)
    private Date refundDate;

    @Column(name = "refund_amount")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_AMOUNT)
    private String refundAmount;

    @Column(name = "refund_bank_txn_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_BANK_TXN_ID)
    private String refundBankTxnId;

    @Column(name = "refund_recon_status")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_RECON_STATUS)
    private String refundReconStatus;

    @Column(name = "sub_biz_order_type")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.SUB_BIZ_ORDER_TYPE)
    private String subBizOrderType;

    @Column(name = "sub_order_status")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.SUB_ORDER_STATUS)
    private String subOrderStatus;

    @Column(name = "refund_esn")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_ESN)
    private String refundEsn;

    @Column(name = "refund_payment_status")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_PAYMENT_STATUS)
    private String refundPaymentStatus;

    @Column(name = "refund_settlement_file_details_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_SETTLEMENT_FILE_DETAILS_ID)
    private Long refundSettlementFileDetailsId;

    @Column(name = "refund_discrepancy_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_DISCREPANCY_ID)
    private Long refundDiscrepancyId;

    @Column(name = "charging_settlement_file_details_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.CHARGING_SETTLEMENT_FILE_DETAILS_ID)
    private Long chargingSettlementFileDetailsId;

    @Column(name = "charging_discrepancy_id")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.CHARGING_DISCREPANCY_ID)
    private Long chargingDiscrepancyid;

    @Column(name = "refund_bank_response_code")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_BANK_RESPONSE_CODE)
    private String refundBankResponseCode;

    @Transient
    @Column(name = "refund_amount_in_inputfile")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUND_AMOUNT_IN_INPUTFILE)
    private String refundAmountInInputFile;

    @Column(name = "refunded")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.REFUNDED)
    Integer refunded;

    @Column(name = "custId")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.CUST_ID)
    private String custId;

    @Column(name = "txnType")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.TXN_TYPE)
    private String txnType;

    @Column(name = "vpa")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.VPA)
    private String vpa;

    @Column(name = "traceId")
    @CsvColumnMapper(columnName = ManualRefundColumnMapper.TRACE_ID)
    private String traceId;

    @CsvColumnMapper(columnName = ManualRefundColumnMapper.AUTH_CODE)
    private String authCode;

    @CsvColumnMapper(columnName = ManualRefundColumnMapper.CARD_LAST_4DIGIT)
    private String cardLast4Digit;

    @Column(name = "sub_refund_type")
    private String subRefundType;

    @Column(name = "isImps")
    private String isImps;

    @Column(name = "refund_mbid")
    private String refundMbid;

    @Column(name = "business_type")
    private String businessType;

    @Column(name = "result_status")
    private String resultStatus;

    @Column(name = "refund_destination_type")
    private String refundDestinationType;

    @Column(name = "refund_destination_mode")
    private String refundDestinationMode;

    @Column(name = "refund_issuing_bank")
    private String refundIssuingBank;

    @Column(name = "transaction_issuing_bank")
    private String transactionIssuingBank;

    @Column(name = "transaction_acquiring_bank_name")
    private String transactionAcquiringBankName;

    @Column(name = "TID")
    private String tid;

    @Column(name = "MERCHANT_NAME")
    private String merchantName;

    @Column(name = "trouble_id")
    String troubleId;

    @Column(name = "ifsc_code")
    String ifscCode;

    @Column(name = "STAN")
    private String stan;

    @Column(name = "INTERCHANGE")
    private String interchange;

    @Column(name = "instant_settlement")
    private boolean instantSettlement;
}
