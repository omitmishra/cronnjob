package com.paytm.pglpus.bocore.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.pgplus.common.log.Logable;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResultInfo implements Logable {

    private String resultStatus;
    private String resultCode;
    private String resultMsg;

    @Override
    public String toJson() {
        StringBuilder builder = new StringBuilder();
        builder.append("{\"resultStatus\":\"");
        builder.append(resultStatus);
        builder.append("\", \"resultCode\":\"");
        builder.append(resultCode);
        builder.append("\", \"resultMsg\":\"");
        builder.append(resultMsg);
        builder.append("\"}");
        return builder.toString();
    }

}
