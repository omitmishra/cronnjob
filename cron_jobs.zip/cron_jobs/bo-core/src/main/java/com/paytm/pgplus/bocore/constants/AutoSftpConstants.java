package com.paytm.pgplus.bocore.constants;

public interface AutoSftpConstants {
    String ALERT_MESSAGE_BASE_HEADER = "We found following mismatches while validating sftp files";
    String SFTP_ERROR_MESSAGE_BASE_HEADER = "Following error occurred while performing auto SFTP";
    String ALERT_ERROR_MESSAGE_BASE_HEADER = "Following error occurred while validating sftp files";
}
