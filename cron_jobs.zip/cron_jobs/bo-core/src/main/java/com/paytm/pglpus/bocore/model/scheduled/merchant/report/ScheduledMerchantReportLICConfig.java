package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import lombok.Data;

import java.io.Serializable;

@Data
public class ScheduledMerchantReportLICConfig implements Serializable {
    private boolean saveTransaction;
}
