package com.paytm.pgplus.bocore.dao;

import com.paytm.pgplus.bocore.entity.jpa.OnlineSettlementReversal;

import com.paytm.pgplus.bocore.repository.jpa.read.OnlineSettlementReversalReadRepository;
import com.paytm.pgplus.bocore.repository.jpa.write.OnlineSettlementReversalWriteRepository;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.ArrayList;

import java.util.List;

@Service("onlineSettlementReversalDaoImpl")
public class OnlineSettlementReversalDaoImpl implements IOnlineSettlementReversalDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(OnlineSettlementReversalDaoImpl.class);

    @Autowired
    OnlineSettlementReversalReadRepository onlineSettlementReversalReadRepository;

    @Autowired
    OnlineSettlementReversalWriteRepository onlineSettlementReversalWriteRepository;

    @Override
    public OnlineSettlementReversal addUpdateOnlineSettlementReversalTable(
            OnlineSettlementReversal onlineSettlementReversal) {
        try {
            return onlineSettlementReversalWriteRepository.save(onlineSettlementReversal);
        } catch (Exception exception) {
            LOGGER.error("Exception occurred while addUpdate OnlineSettlementReversal");
        }

        return null;
    }

    @Override
    public List<OnlineSettlementReversal> addUpdateOnlineSettlementReversalTables(
            List<OnlineSettlementReversal> onlineSettlementReversals) {
        if (CollectionUtils.isEmpty(onlineSettlementReversals)) {
            return null;
        }
        // Use batch here
        List<OnlineSettlementReversal> successful = new ArrayList<>();
        for (OnlineSettlementReversal onlineSettlementReversal : onlineSettlementReversals) {
            onlineSettlementReversal = addUpdateOnlineSettlementReversalTable(onlineSettlementReversal);
            LOGGER.info("onlineSettlementReversal received with id {}", onlineSettlementReversal.getReversalId());
            if (onlineSettlementReversal == null) {
                LOGGER.error("OnlineSettlementReversal not add or update successfully");
            }
            successful.add(onlineSettlementReversal);
        }
        return successful;
    }

    @Override
    public List<OnlineSettlementReversal> findByPayoutIdList(List<String> payoutIds) {
        return onlineSettlementReversalReadRepository.findByPayoutIdIn(payoutIds);
    }

    @Override
    public List<OnlineSettlementReversal> findByPayoutIdListAndUtrStatus(List<String> payoutId, String utrStatus) {
        return onlineSettlementReversalReadRepository.findByPayoutIdInAndUtrStatus(payoutId, utrStatus);
    }

    @Override
    public List<OnlineSettlementReversal> findAllByUpdatedOnBetweenAndUtrStatusAndNewUTRNotNull(
            Timestamp updatedOnFrom, Timestamp updatedOnTo, String utrStatus) {
        return onlineSettlementReversalReadRepository.findAllByUpdatedOnBetweenAndUtrStatusAndNewUTRNotNull(
                updatedOnFrom, updatedOnTo, utrStatus);
    }

}
