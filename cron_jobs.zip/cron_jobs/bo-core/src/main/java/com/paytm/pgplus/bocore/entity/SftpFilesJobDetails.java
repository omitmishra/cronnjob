package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import com.paytm.pgplus.bocore.enums.SftpFileStatus;
import com.paytm.pgplus.bocore.enums.SftpFileType;

/**
 * Entity model class for SFTP_FILES_JOB_DETAILS table.
 * 
 * @author Kulbhushan Pandey
 *
 */

@Entity
@Table(name = "SFTP_FILES_JOB_DETAILS")
@XmlRootElement
public class SftpFilesJobDetails extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 5882706777523753414L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "FILE_TYPE", length = 45)
    private String fileType;

    @Column(name = "LOCAL_FILE_PATH", length = 100)
    private String localFilePath;

    @Column(name = "REMOTE_FILE_PATH", length = 100)
    private String remoteFilePath;

    @Column(name = "RETRY_COUNT", length = 32)
    private Integer retryCount;

    @Column(name = "SFTP_STATUS", length = 32, nullable = false)
    private String sftpStatus;

    public SftpFilesJobDetails() {
        super();
    }

    public SftpFilesJobDetails(String fileType, String localFilePath, String remoteFilePath) {
        super();
        this.fileType = fileType;
        this.localFilePath = localFilePath;
        this.remoteFilePath = remoteFilePath;
        this.sftpStatus = SftpFileStatus.INITIAED.name();
        this.retryCount = 0;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileType() {
        return fileType;
    }

    public void setFileType(String fileType) {
        this.fileType = fileType;
    }

    public String getLocalFilePath() {
        return localFilePath;
    }

    public void setLocalFilePath(String localFilePath) {
        this.localFilePath = localFilePath;
    }

    public String getRemoteFilePath() {
        return remoteFilePath;
    }

    public void setRemoteFilePath(String remoteFilePath) {
        this.remoteFilePath = remoteFilePath;
    }

    public Integer getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(Integer retryCount) {
        this.retryCount = retryCount;
    }

    public String getSftpStatus() {
        return sftpStatus;
    }

    public void setSftpStatus(String sftpStatus) {
        this.sftpStatus = sftpStatus;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("SftpFilesJobDetails [id=").append(id).append(", fileType=").append(fileType)
                .append(", localFilePath=").append(localFilePath).append(", remoteFilePath=").append(remoteFilePath)
                .append(", retryCount=").append(retryCount).append(", sftpStatus=").append(sftpStatus).append("]");
        return builder.toString();
    }

}
