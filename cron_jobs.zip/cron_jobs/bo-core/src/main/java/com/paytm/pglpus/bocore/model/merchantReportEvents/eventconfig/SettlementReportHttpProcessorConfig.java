package com.paytm.pglpus.bocore.model.merchantReportEvents.eventconfig;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import lombok.Data;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SettlementReportHttpProcessorConfig {

    /**
     * Properties related to http.
     */
    Integer maxRetryCount = 5;
    Map<MerchantSettlementReportType, HttpConfig> httpConfig;
}
