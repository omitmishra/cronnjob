package com.paytm.pgplus.bocore.constants;

/**
 * @author Ritesh Kumar Sharma
 */
public class PayoutDownloadFileColumn {

    public static final String RECON_ID = "RECON ID";
    public static final String ENTITY_PAYOUT_ID = "Entity Payout ID";
    public static final String MERCHANT_ID = "Merchant ID";
    public static final String ALIPAY_MERCHANT_ID = "Alipay Merchant ID";
    public static final String BANK_NAME = "Bank Name";
    public static final String MERCHANT_NAME = "Merchant Name";
    public static final String TOTAL_TXN_AMOUNT = "Total Txn Amount";
    public static final String COMMISSION = "Commission";
    public static final String SERVICE_TAX = "Service Tax";
    public static final String REFUND_AMOUNT = "Refund Amount";
    public static final String CHARGEBACK_AMOUNT = "Chargeback Amount";
    public static final String CANCEL_AMOUNT = "Cancel Amount";
    public static final String CANCEL_COMMISSION = "Cancel Commission";
    public static final String CANCEL_SERVICE_TAX = "Cancel Service Tax";
    public static final String CONVENIENCE_FEE = "Convenience Fee";
    public static final String PAYOUT_AMOUNT = "Payout Amount";
    public static final String UTR = "UTR";
    public static final String MASTER_PAYOUT_ID = "MASTER PAYOUT ID";
    public static final String PAYOUT_STATUS = "PAYOUT STATUS";
    public static final String PAYOUT_DATE = "PAYOUT DATE";
    public static final String REFUND_COUNT = "Refund Count";
    public static final String CHARGEBACK_COUNT = "Chargeback Count";
    public static final String NET_AMOUNT = "NET_SETTLED(T)";
    public static final String PRE_NET_SETTLE_AMOUNT = "NET_SETTLED(T-1)";
    public static final String TXN_ID = "TXN_ID";
    public static final String DATE = "DATE";
    public static final String FROM = "FROM";
    public static final String ORIGINAL_MID = "ORIGINAL_MID";
    public static final String RELEASE_STATUS = "ReleaseStatus";
    public static final String SETTLEMENT_DATE = "Settlement Date";
    public static final String SETTLEMENT_STATUS = "SETTLEMENT_STATUS";
    public static final String VALUE_DATE = "VALUE_DATE";
    public static final String BILL_DATE = "BILL_DATE";
    public static final String UTR_NO = "UTR_NO";
    public static final String SETTLEMENT_AMOUNT = "SETTLEMENT_AMOUNT";
    public static final String SETTLEMENT_CURRENCY = "SETTLEMENT_CURRENCY";
    public static final String MERCHANT_ID_PAYTM = "MERCHANT_ID_PAYTM";
    public static final String UTR_UPLOAD_TIME = "SETTLED_DATE (dd/MM/yyyy)";
    // reversal fields
    public static final String CASH_RECHARGE = "CASH_RECHARGE";
    public static final String CASH_RECHARGE_REVERSE = "CASH_RECHARGE_REVERSE";
    public static final String CREDIT_UTR = "CREDIT_UTR";
    public static final String CREDIT_DATE = "CREDIT_DATE";
    public static final String REVERSAL_REASON = "REVERSAL_REASON";
    public static final String DEBIT_DATE = "DEBIT_DATE";
    public static final String EXTERNAL_SERIAL_NO = "EXTERNAL_SERIAL_NO";
    public static final String NEW_UTR = "NEW_UTR";
    public static final String NEW_UTR_PROCESSING_DATE = "NEW_UTR_PROCESSING_DATE";
    public static final String PAYOUT_COUNT = "PAYOUT_COUNT";
    public static final String UNSETTLED_AMOUNT = "UNSETTLED_AMOUNT";
    public static final String PAYMENT_COUNT = "PAYMENT_COUNT";
    public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
    public static final String TXN_STATUS = "TXN_STATUS";
    public static final String ERROR_CODE = "ERROR_CODE";
    public static final String WITHDRAW_MODE = "WITHDRAW_MODE";
    public static final String MERCHANT_TYPE = "MERCHANT_TYPE";
    public static final String PAYOUT_PRIORITY = "PAYOUT_PRIORITY";
    public static final String TRANSFER_MODE = "TRANSFER_MODE";
    public static final String RECOVERED_AMOUNT = "RECOVERED_AMOUNT";
    public static final String PARENT_MID = "PARENT_MID";
    public static final String MERCHANT_SOLUTION_TYPE = "Merchant Solution Type";

    public static final String[] FILE_HEADER_MAPPING = { RECON_ID, ENTITY_PAYOUT_ID, MERCHANT_ID, ALIPAY_MERCHANT_ID,
            BANK_NAME, MERCHANT_NAME, TOTAL_TXN_AMOUNT, COMMISSION, SERVICE_TAX, REFUND_AMOUNT, CHARGEBACK_AMOUNT,
            CONVENIENCE_FEE, PAYOUT_AMOUNT, UTR, MASTER_PAYOUT_ID, PAYOUT_STATUS, PAYOUT_DATE, REFUND_COUNT,
            CHARGEBACK_COUNT, NET_AMOUNT, PRE_NET_SETTLE_AMOUNT, UTR_UPLOAD_TIME, CASH_RECHARGE, CASH_RECHARGE_REVERSE };

    public static final String[] ONLINE_FILE_HEADER_MAPPING = { RECON_ID, SETTLEMENT_STATUS, VALUE_DATE, BILL_DATE,
            UTR_NO, SETTLEMENT_AMOUNT, SETTLEMENT_CURRENCY, MERCHANT_ID, MERCHANT_ID_PAYTM, UTR_UPLOAD_TIME };

}
