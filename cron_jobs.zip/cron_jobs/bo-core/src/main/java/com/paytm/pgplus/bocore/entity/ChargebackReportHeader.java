package com.paytm.pgplus.bocore.entity;

/**
 * @author Mayank Aggarwal
 * @since August 2020
 */
public class ChargebackReportHeader {

    public static final String DISPUTE_ID = "Dispute ID";
    public static final String DISPUTE_CREATION_DATE = "Dispute Creation Date";
    public static final String TXN_ID = "TXN ID";
    public static final String TXN_DATE = "TXN Date";
    public static final String ORDER_ID = "Order ID";
    public static final String TXN_AMOUNT = "Txn Amt";
    public static final String DISPUTE_AMOUNT = "Dispute Amt";
    public static final String DISPUTE_STATUS = "Dispute Status";
    public static final String MID = "MID";
    public static final String ESN = "ESN";
    public static final String DISPUTE_UTR = "Dispute UTR";
    public static final String DISPUTE_UPDATE_DATE = "Dispute Update Date";
    public static final String STATUS_COMMENT = "Status comment";
    public static final String BANK_REFERENCE_ID = "Bank reference ID";
    public static final String BANK_GATEWAY = "Bank Gateway"; // NEW
    public static final String DUE_DATE = "Due Date"; // NEW
    public static final String REASON_ACCEPTANCE = "Reason of Acceptance";

    public static final String[] CHARGEBACK_REPORT_HEADER = new String[] { DISPUTE_ID, DISPUTE_CREATION_DATE, TXN_ID,
            TXN_DATE, ORDER_ID, TXN_AMOUNT, DISPUTE_AMOUNT, DISPUTE_STATUS, MID, ESN, DISPUTE_UTR, DISPUTE_UPDATE_DATE,
            STATUS_COMMENT, BANK_REFERENCE_ID, BANK_GATEWAY, DUE_DATE, REASON_ACCEPTANCE };
}
