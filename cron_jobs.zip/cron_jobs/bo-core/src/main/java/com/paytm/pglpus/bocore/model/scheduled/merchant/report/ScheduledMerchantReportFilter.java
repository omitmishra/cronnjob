package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.paytm.pglpus.bocore.model.SearchParameter;
import com.paytm.pglpus.bocore.model.SearchType;
import com.paytm.pgplus.facade.dataservice.enums.BizOrderType;
import com.paytm.pgplus.facade.dataservice.enums.SubBizOrderType;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class ScheduledMerchantReportFilter implements Serializable {

    private List<SearchParameter> searchConditions;

    private String orderStatus;

    private SearchType searchType;

    private List<BizOrderType> bizOrderTypes;

    private List<SubBizOrderType> subBizOrderTypes;

    /**
     * @Deprecated migrated to reportFilterType use instead
     *             orderTimeFilterType.ORDER_SETTLE_COMPLETED;
     */
    @Deprecated
    private boolean isSettlementTypeReport;

    private OrderTimeFilterType orderTimeFilterType = OrderTimeFilterType.DEFAULT;
    // for NB refund backward compatibilitys
    private PaymentMode paymentMode = PaymentMode.NB;
}
