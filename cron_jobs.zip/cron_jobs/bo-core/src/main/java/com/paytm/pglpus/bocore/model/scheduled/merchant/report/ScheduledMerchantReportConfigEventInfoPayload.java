package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportConfig;
import com.paytm.pgplus.facade.dataservice.models.SettlementBill;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class ScheduledMerchantReportConfigEventInfoPayload implements Serializable {

    private ScheduledMerchantReportConfig scheduledMerchantReportConfig;

    private Date latestEventDataIncludedTo;

    List<SettlementBill> settlementBillList;

    private int settlementDayWindow;

}