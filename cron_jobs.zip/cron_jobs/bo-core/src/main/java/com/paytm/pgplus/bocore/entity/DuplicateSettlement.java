package com.paytm.pgplus.bocore.entity;

import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Hibernate entity class This class responsible for hibernate entity to table
 * mapping
 * 
 * @author Lalit Mehra
 * @since March 4, 2016
 */
@Entity
@Table(name = "PGPLUS_REPORT_DUPLICATE_SETTLEMENT")
@XmlRootElement
public class DuplicateSettlement extends BaseEntity {

    private static final long serialVersionUID = 1798473027740131394L;

    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "FILE_RCV_DATE", length = 10)
    private Date fileRcvDate;

    @Column(name = "FILE_NAME", length = 50)
    private String fileName;

    @Column(name = "TRANS_TYPE", length = 4)
    private String transType;

    @Column(name = "RESULT_STATUS", length = 1)
    private String resultStatus;

    @Column(name = "RESULT_CODE_ID", length = 8)
    private Integer resultCodeId;

    @Column(name = "EXTSERIAL_NO", length = 20)
    private String extSerialNo;

    @Column(name = "TRACE_NO", length = 10)
    private Long traceNo;

    @Column(name = "AUTH_CODE", length = 32)
    private String authCode;

    @Column(name = "RRN_CODE", length = 32)
    private String rrnCode;

    @Column(name = "BANK_ABBR", length = 32)
    private String bankAbbr;

    @Column(name = "REFERENCE_NO", length = 32)
    private String referenceNo;

    @Column(name = "MERCHANT_ID", length = 32)
    private String merchantId;

    @Column(name = "MBID", length = 32)
    private String mbid;

    @Column(name = "EXCHANGE_AMOUNT", length = 64)
    private Long exchangeAmount;

    @Column(name = "EXCHANGE_CURRENCY", length = 3)
    private String exchangeCurrency;

    @Column(name = "TRANS_VALUE_DATE")
    private Date transValueDate;

    @Column(name = "LAST_UPDATE_DATE")
    private Date lastUpdateDate;

    @Column(name = "ACTION", length = 10)
    private String action;

    @Column(name = "COMMENT", length = 64)
    private String comment;

    public DuplicateSettlement() {
        super();
    }

    public DuplicateSettlement(Date fileRcvDate, String fileName, String transType, String resultStatus,
            Integer resultCodeId, String extSerialNo, Long traceNo, String authCode, String rrnCode, String bankAbbr,
            String referenceNo, String merchantId, String mbid, Long exchangeAmount, String exchangeCurrency,
            Date transValueDate, Date lastUpdateDate, String action) {
        super();
        this.fileRcvDate = fileRcvDate;
        this.fileName = fileName;
        this.transType = transType;
        this.resultStatus = resultStatus;
        this.resultCodeId = resultCodeId;
        this.extSerialNo = extSerialNo;
        this.traceNo = traceNo;
        this.authCode = authCode;
        this.rrnCode = rrnCode;
        this.bankAbbr = bankAbbr;
        this.referenceNo = referenceNo;
        this.merchantId = merchantId;
        this.mbid = mbid;
        this.exchangeAmount = exchangeAmount;
        this.exchangeCurrency = exchangeCurrency;
        this.transValueDate = transValueDate;
        this.lastUpdateDate = lastUpdateDate;
        this.action = action;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Date getFileRcvDate() {
        return fileRcvDate;
    }

    public void setFileRcvDate(Date fileRcvDate) {
        this.fileRcvDate = fileRcvDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getResultStatus() {
        return resultStatus;
    }

    public void setResultStatus(String resultStatus) {
        this.resultStatus = resultStatus;
    }

    public Integer getResultCodeId() {
        return resultCodeId;
    }

    public void setResultCodeId(Integer resultCodeId) {
        this.resultCodeId = resultCodeId;
    }

    public String getExtSerialNo() {
        return extSerialNo;
    }

    public void setExtSerialNo(String extSerialNo) {
        this.extSerialNo = extSerialNo;
    }

    public Long getTraceNo() {
        return traceNo;
    }

    public void setTraceNo(Long traceNo) {
        this.traceNo = traceNo;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getRrnCode() {
        return rrnCode;
    }

    public void setRrnCode(String rrnCode) {
        this.rrnCode = rrnCode;
    }

    public String getBankAbbr() {
        return bankAbbr;
    }

    public void setBankAbbr(String bankAbbr) {
        this.bankAbbr = bankAbbr;
    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getMbid() {
        return mbid;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public Long getExchangeAmount() {
        return exchangeAmount;
    }

    public void setExchangeAmount(Long exchangeAmount) {
        this.exchangeAmount = exchangeAmount;
    }

    public String getExchangeCurrency() {
        return exchangeCurrency;
    }

    public void setExchangeCurrency(String exchangeCurrency) {
        this.exchangeCurrency = exchangeCurrency;
    }

    public Date getTransValueDate() {
        return transValueDate;
    }

    public void setTransValueDate(Date transValueDate) {
        this.transValueDate = transValueDate;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

}
