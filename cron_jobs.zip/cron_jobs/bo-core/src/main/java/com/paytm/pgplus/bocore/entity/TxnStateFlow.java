package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author honeyduhar
 * 
 *         Entity for txn_state_flow table
 *
 */

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "txn_state_flow")
public class TxnStateFlow implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = -5170382241062403618L;

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private Long Id;

    @Column(name = "txn_id", length = 64)
    private String txnId;

    @Column(name = "merchant_id", length = 50)
    private String merchantId;

    @Column(name = "order_id", length = 50)
    private String orderId;

    @Column(name = "ext_serial_no", length = 50)
    private String extSerialNo;

    @Column(name = "txn_state", length = 50)
    private String txnState;

    @Column(name = "txn_amount")
    private Double txnAmount;

    @Column(name = "source_epoc_time", length = 20)
    private Long sourceEpocTime;

    @Column(name = "created_timestamp")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private Date createdTimestamp;

}
