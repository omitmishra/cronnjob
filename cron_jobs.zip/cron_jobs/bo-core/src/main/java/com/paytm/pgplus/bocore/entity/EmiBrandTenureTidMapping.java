package com.paytm.pgplus.bocore.entity;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@Table(name = "emi_brand_tenure_tid_mapping")
public class EmiBrandTenureTidMapping extends BaseEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bank_code")
    private String bankCode;

    @Column(name = "brand_name")
    private String brandName;

    @Column(name = "tenure")
    private String tenure;

    @Column(name = "bank_tid")
    private String bankTid;

}
