package com.paytm.pglpus.bocore.model.msr;

import com.paytm.pgplus.bocore.constants.MSRBillFileColumn;
import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import com.paytm.pgplus.bocore.enums.TransactionType;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import com.paytm.pgplus.bocore.util.csv.converter.deserializer.BigDecimalConverter;
import com.paytm.pgplus.bocore.util.csv.converter.deserializer.DateConverter;
import lombok.Data;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

@ToString
@Data
public class MerchantRefundReport extends MerchantSettlementReport {

    private static final long serialVersionUID = 5676698655190049900L;

    @CSVColumn(name = MSRBillFileColumn.TXN_ID)
    private String txnId;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal txnAmount;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date paymentDate;

    @CSVColumn(name = MSRBillFileColumn.REFUND_ID)
    private String refundID;

    @CSVColumn(name = MSRBillFileColumn.REFUND_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date refundDate;

    @CSVColumn(name = MSRBillFileColumn.ALIPAY_MID)
    private String mid;

    @CSVColumn(name = MSRBillFileColumn.PAYTM_MID)
    private String originalMID;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_NAME)
    private String merchantName;

    @CSVColumn(name = MSRBillFileColumn.TERMINAL_TYPE)
    private String terminalType;

    @CSVColumn(name = MSRBillFileColumn.REFUND_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal refundAmount;

    @CSVColumn(name = MSRBillFileColumn.REFUND_CURRENCY)
    private String refundCurrency;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_COMMISSION, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal merchantCommission;

    @CSVColumn(name = MSRBillFileColumn.SERVICE_TAX, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal serviceTax;

    @CSVColumn(name = MSRBillFileColumn.ORDER_ID)
    private String orderId;

    @CSVColumn(name = MSRBillFileColumn.PAY_METHOD)
    private String paymentMethod;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_CUST_ID)
    private String merchantCustId;

    @CSVColumn(name = MSRBillFileColumn.ISSUING_BANK)
    private String issuingBank;

    @CSVColumn(name = MSRBillFileColumn.STATUS)
    private String status;

    @CSVColumn(name = MSRBillFileColumn.SETTLEMENT_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = {
            MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD, MSRBillFileColumn.FILE_DATE_TIME_FORMAT_1 }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date settlementDate;

    @CSVColumn(name = MSRBillFileColumn.SETTLED_BANK_TXN_ID)
    private String settlementBankTxnId;

    @CSVColumn(name = MSRBillFileColumn.SETTLED_TXN_ID)
    private String settlementTxnId;

    private Long fileId;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_BILL_ID)
    private String merchantBillId;

    @CSVColumn(name = MSRBillFileColumn.PRN_CODE)
    private String prnCode;

    @CSVColumn(name = MSRBillFileColumn.REF_ID)
    private String refId;

    @CSVColumn(name = MSRBillFileColumn.FEE_FACTOR)
    private String feeFactor;

    @CSVColumn(name = MSRBillFileColumn.TXN_TYPE)
    private String txnType;

    @CSVColumn(name = MSRBillFileColumn.REPAYMENT_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal repaymentAmount;

    @CSVColumn(name = MSRBillFileColumn.COMMENTS)
    private String comments;

    public MerchantRefundReport() {
        super(TransactionType.REFUND, MerchantSettlementReportType.REFUND);
    }

    @Override
    public BigDecimal getTotalAmount() {
        return getAmount();
    }

    private BigDecimal getAmount() {
        if (refundAmount == null || refundAmount.compareTo(new BigDecimal(0)) == 0) {
            return this.repaymentAmount;
        }
        return this.refundAmount;
    }

    @Override
    public BigDecimal getTransactionAmount() {
        return getAmount();
    }

    @Override
    public String getPayoutId() {
        return this.settlementTxnId;
    }

    @Override
    public String getUtr() {
        return this.settlementBankTxnId;
    }

    @Override
    public String getPaytmMerchantId() {
        return this.originalMID;
    }

}
