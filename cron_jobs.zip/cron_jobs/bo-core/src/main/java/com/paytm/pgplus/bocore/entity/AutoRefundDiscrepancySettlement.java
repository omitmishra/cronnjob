package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.file.util.annotation.CsvColumnMapper;

@Entity
@Table(name = "PGPLUS_REPORT_DISCREPANCY_SETTLEMENT")
@XmlRootElement
public class AutoRefundDiscrepancySettlement extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final String DISCREPANCY_TYPE = "DiscrepancyType";
    public static final String FLUXNET_EXT_SERIAL_NO = "FluxNetExtSerialNo";
    public static final String FLUXNET_RESULT_STATUS = "FluxNetResultStatus";
    public static final String FLUXNET_REFERENCE_NO = "FluxNetReferenceNo";
    public static final String FLUXNET_EXCHANGE_CURRENCY = "FluxNetExchangeCurrency";
    public static final String FLUXNET_EXCHANGE_AMOUNT = "FluxNetExchangeAmount";
    public static final String FILE_RCV_DATE = "FileRcvDate";
    public static final String FILE_NAME = "FileName";
    public static final String TRANS_TYPE = "TransType";
    public static final String RESULT_STATUS = "ResultStatus";
    public static final String RESULT_CODE_ID = "ResultCodeId";
    public static final String EXT_SERIAL_NO = "ExtSerialNo";
    public static final String TRACE_NO = "TraceNo";
    public static final String AUTH_CODE = "AuthCode";
    public static final String RRN_CODE = "RrnCode";
    public static final String BANK_ABBR = "BankAbbr";
    public static final String REFERENCE_NO = "ReferenceNo";
    public static final String MERCHANT_ID = "MerchantId";
    public static final String ORIGINAL_MID = "Original MID";
    public static final String MBID = "MBID";
    public static final String EXCHANGE_AMOUNT = "ExchangeAmount";
    public static final String EXCHANGE_CURRENCY = "ExchangeCurrency";
    public static final String TRANS_VALUE_DATE = "TransValueDate";
    public static final String LAST_UPDATE_DATE = "LastUpdateDate";

    public static final String ALIPAY_ORDER_ID = "ALIPAY ORDER ID";
    public static final String BANK_RESPONSE_NO = "BANK RESPONSE NO";
    public static final String REFUND_STATUS = "REFUND STATUS";
    public static final String REFUND_DATE = "REFUND DATE";

    public static final String ALIPAY_BIZ_ORDER_ID = "ALIPAY BIZ ORDER ID";
    public static final String ORI_EXT_SERIAL_NO = "ORI EXT SERIAL NO";
    // public static final String RRN_CODE = "RRN_CODE";
    public static final String BANK_REFERENCE_NO = "BANK REFERENCE NO";
    // public static final String REFUND_STATUS = "REFUND_STATUS";
    // public static final String REFUND_DATE = "REFUND_DATE";
    public static final String MEMO = "MEMO";

    public static final String TRANS_INFO_SOURCE = "transInfoSource";

    public static final String FEE_AMOUNT = "feeAmount";
    public static final String FEE_CURRENCY = "feeCurrency";

    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "DISCREPANCY_TYPE")
    @CsvColumnMapper(columnName = DISCREPANCY_TYPE)
    private String discrepancyType;

    @Column(name = "FLUXNET_EXT_SERIAL_NO")
    @CsvColumnMapper(columnName = FLUXNET_EXT_SERIAL_NO)
    private String fluxNetExtSerialNo;

    @Column(name = "FLUXNET_RESULT_STATUS")
    @CsvColumnMapper(columnName = FLUXNET_RESULT_STATUS)
    private String fluxNetResultStatus;

    @Column(name = "FLUXNET_REFERENCE_NO")
    @CsvColumnMapper(columnName = FLUXNET_REFERENCE_NO)
    private String fluxNetReferenceNo;

    @Column(name = "FLUXNET_EXCHANGE_CURRENCY")
    @CsvColumnMapper(columnName = FLUXNET_EXCHANGE_CURRENCY)
    private String fluxNetExchangeCurrency;

    @Column(name = "FLUXNET_EXCHANGE_AMOUNT")
    @CsvColumnMapper(columnName = FLUXNET_EXCHANGE_AMOUNT)
    private Long fluxNetExchangeAmount;

    @Column(name = "FILE_RCV_DATE")
    private Date fileRcvDate;

    @Column(name = "FILE_NAME")
    @CsvColumnMapper(columnName = FILE_NAME)
    private String fileName;

    @Column(name = "TRANS_TYPE")
    @CsvColumnMapper(columnName = TRANS_TYPE)
    private String transType;

    @Column(name = "RESULT_STATUS")
    @CsvColumnMapper(columnName = RESULT_STATUS)
    private String resultStatus;

    @Column(name = "RESULT_CODE_ID")
    @CsvColumnMapper(columnName = RESULT_CODE_ID)
    private String resultCodeId;

    @Column(name = "EXTSERIAL_NO")
    @CsvColumnMapper(columnName = EXT_SERIAL_NO)
    private String extSerialNo;

    @Column(name = "TRACE_NO")
    @CsvColumnMapper(columnName = TRACE_NO)
    private String traceNo;

    @Column(name = "AUTH_CODE")
    @CsvColumnMapper(columnName = AUTH_CODE)
    private String authCode;

    @Column(name = "RRN_CODE")
    @CsvColumnMapper(columnName = RRN_CODE)
    private String rrnCode;

    @Column(name = "BANK_ABBR")
    @CsvColumnMapper(columnName = BANK_ABBR)
    private String bankAbbr;

    @Column(name = "REFERENCE_NO")
    @CsvColumnMapper(columnName = REFERENCE_NO)
    private String referenceNo;

    @Column(name = "MERCHANT_ID")
    @CsvColumnMapper(columnName = MERCHANT_ID)
    private String merchantId;

    @Column(name = "PAYTMM_ID")
    @CsvColumnMapper(columnName = ORIGINAL_MID)
    private String originalMID;

    @Column(name = "MBID")
    @CsvColumnMapper(columnName = MBID)
    private String mbid;

    @Column(name = "EXCHANGE_AMOUNT")
    @CsvColumnMapper(columnName = EXCHANGE_AMOUNT)
    private Long exchangeAmount;

    @Column(name = "EXCHANGE_CURRENCY")
    @CsvColumnMapper(columnName = EXCHANGE_CURRENCY)
    private String exchangeCurrency;

    @Column(name = "TRANS_VALUE_DATE")
    private Date transValueDate;

    @Column(name = "LAST_UPDATE_DATE")
    private Date lastUpdateDate;

    @Column(name = "ACTION")
    private String action;

    @Column(name = "COMMENT")
    private String comment;

    @Column(name = "REF_ID")
    private String refId;

    @Column(name = "REFUND_TYPE")
    private String refundType;

    @Column(name = "BANK_RESPONSE_NO")
    private String bankResponseNo;

    @Column(name = "TRANS_ID")
    private String transId;

    @Column(name = "DISPUTE_ID")
    private String disputeId;

    @Column(name = "TRANS_INFO_SOURCE")
    @CsvColumnMapper(columnName = TRANS_INFO_SOURCE)
    private String transInfoSource;

    @Column(name = "APP_ID")
    private String appId;
    @Column(name = "PAYMETHOD")
    private String paymethod;

    @CsvColumnMapper(columnName = LAST_UPDATE_DATE)
    private transient String lastUpdateDateStr;

    @CsvColumnMapper(columnName = TRANS_VALUE_DATE)
    private transient String transValueDateStr;

    @CsvColumnMapper(columnName = FILE_RCV_DATE)
    private transient String fileRcvDateStr;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "autoRefundDiscrepancySettlement")
    private Set<PaytmAutoRefundDetails> autoRefundDetails;

    @ManyToOne
    @JoinColumn(name = "MERCHANT_ID", referencedColumnName = "paytm_merchant_id", nullable = false, updatable = false, insertable = false)
    private AlipayPaytmMerchant alipayPaytmMerchant;

    public AutoRefundDiscrepancySettlement() {
        super();
    }

    public AutoRefundDiscrepancySettlement(long id, String discrepancyType, String fluxNetExtSerialNo,
            String fluxNetResultStatus, String fluxNetReferenceNo, String fluxNetExchangeCurrency,
            Long fluxNetExchangeAmount, Date fileRcvDate, String fileName, String transType, String resultStatus,
            String resultCodeId, String extSerialNo, String traceNo, String authCode, String rrnCode, String bankAbbr,
            String referenceNo, String merchantId, String originalMID, String mbid, Long exchangeAmount,
            String exchangeCurrency, Date transValueDate, Date lastUpdateDate, String action, String comment,
            String refId, String refundType, String bankResponseNo, String transId, String disputeId,
            String transInfoSource, String appId, String paymethod, String lastUpdateDateStr, String transValueDateStr,
            String fileRcvDateStr, Set<PaytmAutoRefundDetails> autoRefundDetails,
            AlipayPaytmMerchant alipayPaytmMerchant) {
        super();
        this.id = id;
        this.discrepancyType = discrepancyType;
        this.fluxNetExtSerialNo = fluxNetExtSerialNo;
        this.fluxNetResultStatus = fluxNetResultStatus;
        this.fluxNetReferenceNo = fluxNetReferenceNo;
        this.fluxNetExchangeCurrency = fluxNetExchangeCurrency;
        this.fluxNetExchangeAmount = fluxNetExchangeAmount;
        this.fileRcvDate = fileRcvDate;
        this.fileName = fileName;
        this.transType = transType;
        this.resultStatus = resultStatus;
        this.resultCodeId = resultCodeId;
        this.extSerialNo = extSerialNo;
        this.traceNo = traceNo;
        this.authCode = authCode;
        this.rrnCode = rrnCode;
        this.bankAbbr = bankAbbr;
        this.referenceNo = referenceNo;
        this.merchantId = merchantId;
        this.originalMID = originalMID;
        this.mbid = mbid;
        this.exchangeAmount = exchangeAmount;
        this.exchangeCurrency = exchangeCurrency;
        this.transValueDate = transValueDate;
        this.lastUpdateDate = lastUpdateDate;
        this.action = action;
        this.comment = comment;
        this.refId = refId;
        this.refundType = refundType;
        this.bankResponseNo = bankResponseNo;
        this.transId = transId;
        this.disputeId = disputeId;
        this.transInfoSource = transInfoSource;
        this.appId = appId;
        this.paymethod = paymethod;
        this.lastUpdateDateStr = lastUpdateDateStr;
        this.transValueDateStr = transValueDateStr;
        this.fileRcvDateStr = fileRcvDateStr;
        this.autoRefundDetails = autoRefundDetails;
        this.alipayPaytmMerchant = alipayPaytmMerchant;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDiscrepancyType() {
        return discrepancyType;
    }

    public void setDiscrepancyType(String discrepancyType) {
        this.discrepancyType = discrepancyType;
    }

    public String getFluxNetExtSerialNo() {
        return fluxNetExtSerialNo;
    }

    public void setFluxNetExtSerialNo(String fluxNetExtSerialNo) {
        this.fluxNetExtSerialNo = fluxNetExtSerialNo;
    }

    public String getFluxNetResultStatus() {
        return fluxNetResultStatus;
    }

    public void setFluxNetResultStatus(String fluxNetResultStatus) {
        this.fluxNetResultStatus = fluxNetResultStatus;
    }

    public String getFluxNetReferenceNo() {
        return fluxNetReferenceNo;
    }

    public void setFluxNetReferenceNo(String fluxNetReferenceNo) {
        this.fluxNetReferenceNo = fluxNetReferenceNo;
    }

    public String getFluxNetExchangeCurrency() {
        return fluxNetExchangeCurrency;
    }

    public void setFluxNetExchangeCurrency(String fluxNetExchangeCurrency) {
        this.fluxNetExchangeCurrency = fluxNetExchangeCurrency;
    }

    public Long getFluxNetExchangeAmount() {
        return fluxNetExchangeAmount;
    }

    public void setFluxNetExchangeAmount(Long fluxNetExchangeAmount) {
        this.fluxNetExchangeAmount = fluxNetExchangeAmount;
    }

    public Date getFileRcvDate() {
        return fileRcvDate;
    }

    public void setFileRcvDate(Date fileRcvDate) {
        this.fileRcvDate = fileRcvDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getTransType() {
        return transType;
    }

    public void setTransType(String transType) {
        this.transType = transType;
    }

    public String getResultStatus() {
        return resultStatus;
    }

    public void setResultStatus(String resultStatus) {
        this.resultStatus = resultStatus;
    }

    public String getResultCodeId() {
        return resultCodeId;
    }

    public void setResultCodeId(String resultCodeId) {
        this.resultCodeId = resultCodeId;
    }

    public String getExtSerialNo() {
        return extSerialNo;
    }

    public void setExtSerialNo(String extSerialNo) {
        this.extSerialNo = extSerialNo;
    }

    public String getTraceNo() {
        return traceNo;
    }

    public void setTraceNo(String traceNo) {
        this.traceNo = traceNo;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getRrnCode() {
        return rrnCode;
    }

    public void setRrnCode(String rrnCode) {
        this.rrnCode = rrnCode;
    }

    public String getBankAbbr() {
        return bankAbbr;
    }

    public void setBankAbbr(String bankAbbr) {
        this.bankAbbr = bankAbbr;
    }

    public String getReferenceNo() {
        return referenceNo;
    }

    public void setReferenceNo(String referenceNo) {
        this.referenceNo = referenceNo;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getOriginalMID() {
        return originalMID;
    }

    public void setOriginalMID(String originalMID) {
        this.originalMID = originalMID;
    }

    public String getMbid() {
        return mbid;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public Long getExchangeAmount() {
        return exchangeAmount;
    }

    public void setExchangeAmount(Long exchangeAmount) {
        this.exchangeAmount = exchangeAmount;
    }

    public String getExchangeCurrency() {
        return exchangeCurrency;
    }

    public void setExchangeCurrency(String exchangeCurrency) {
        this.exchangeCurrency = exchangeCurrency;
    }

    public Date getTransValueDate() {
        return transValueDate;
    }

    public void setTransValueDate(Date transValueDate) {
        this.transValueDate = transValueDate;
    }

    public Date getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(Date lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public String getRefId() {
        return refId;
    }

    public void setRefId(String refId) {
        this.refId = refId;
    }

    public String getRefundType() {
        return refundType;
    }

    public void setRefundType(String refundType) {
        this.refundType = refundType;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    public String getDisputeId() {
        return disputeId;
    }

    public void setDisputeId(String disputeId) {
        this.disputeId = disputeId;
    }

    public String getBankResponseNo() {
        return bankResponseNo;
    }

    public void setBankResponseNo(String bankResponseNo) {
        this.bankResponseNo = bankResponseNo;
    }

    public String getTransInfoSource() {
        return transInfoSource;
    }

    public void setTransInfoSource(String transInfoSource) {
        this.transInfoSource = transInfoSource;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getPaymethod() {
        return paymethod;
    }

    public void setPaymethod(String paymethod) {
        this.paymethod = paymethod;
    }

    public String getLastUpdateDateStr() {
        return lastUpdateDateStr;
    }

    public void setLastUpdateDateStr(String lastUpdateDateStr) {
        this.lastUpdateDateStr = lastUpdateDateStr;
    }

    public String getTransValueDateStr() {
        return transValueDateStr;
    }

    public void setTransValueDateStr(String transValueDateStr) {
        this.transValueDateStr = transValueDateStr;
    }

    public String getFileRcvDateStr() {
        return fileRcvDateStr;
    }

    public void setFileRcvDateStr(String fileRcvDateStr) {
        this.fileRcvDateStr = fileRcvDateStr;
    }

    public Set<PaytmAutoRefundDetails> getAutoRefundDetails() {
        return autoRefundDetails;
    }

    public void setAutoRefundDetails(Set<PaytmAutoRefundDetails> autoRefundDetails) {
        this.autoRefundDetails = autoRefundDetails;
    }

    public AlipayPaytmMerchant getAlipayPaytmMerchant() {
        return alipayPaytmMerchant;
    }

    public void setAlipayPaytmMerchant(AlipayPaytmMerchant alipayPaytmMerchant) {
        this.alipayPaytmMerchant = alipayPaytmMerchant;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        AutoRefundDiscrepancySettlement that = (AutoRefundDiscrepancySettlement) o;
        if (!discrepancyType.equals(that.discrepancyType))
            return false;
        if (!transType.equals(that.transType))
            return false;
        return extSerialNo.equals(that.extSerialNo);
    }

    @Override
    public int hashCode() {
        int result = discrepancyType.hashCode();
        result = 31 * result + transType.hashCode();
        result = 31 * result + extSerialNo.hashCode();
        return result;
    }
}
