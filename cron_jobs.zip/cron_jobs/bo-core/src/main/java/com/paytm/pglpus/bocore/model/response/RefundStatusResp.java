package com.paytm.pglpus.bocore.model.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class RefundStatusResp implements Serializable {

    private static final long serialVersionUID = -5328812361968787642L;

    private String TXNID;
    private String ORDERID;
    private String TXNAMOUNT;
    private String STATUS;
    private Long RESPCODE;
    private String RESPMSG;
    private String MID;
    private String REFUNDAMOUNT;
    private String TXNDATE;
    private String TOTALREFUNDAMT;
    private String REFUNDDATE;
    private String REFID;
    private String BANKTXNID;
    private String GATEWAY;
    private String PAYMENTMODE;
    private String REFUNDID;
    private String REFUNDTYPE;

}
