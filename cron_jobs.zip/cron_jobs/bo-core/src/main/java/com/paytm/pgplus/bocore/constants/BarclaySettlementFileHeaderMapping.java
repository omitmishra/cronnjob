package com.paytm.pgplus.bocore.constants;

public class BarclaySettlementFileHeaderMapping {

    public static final String CLEARING_BATCH_ID = "clearingBatchId";
    public static final String PARTICIPANT_ID = "participantId";
    public static final String TXN_REQUEST_ID = "transactionRequestId";
    public static final String ORIGINAL_TXN_REQUEST_ID = "originalTransactionRequestId";
    public static final String TXN_TYPE = "transactionType";
    public static final String TXN_TIME = "transactionTime";
    public static final String FUND_DIRECTION = "fundDirection";
    public static final String SETTLEMENT_CURRENCY = "settlementCurrency";
    public static final String SETTLEMENT_AMOUNT = "settlementAmountValue";
    public static final String TXN_CURRENCY = "transactionCurrency";
    public static final String TXN_AMOUNT = "transactionAmountValue";
    public static final String EXTEND_INFO = "extendInfo";

    public static final String[] ALIPAY_SETTLEMENT_CSV_HEADER = { CLEARING_BATCH_ID, PARTICIPANT_ID, TXN_REQUEST_ID,
            ORIGINAL_TXN_REQUEST_ID, TXN_TYPE, TXN_TIME, FUND_DIRECTION, SETTLEMENT_CURRENCY, SETTLEMENT_AMOUNT,
            TXN_CURRENCY, TXN_AMOUNT, EXTEND_INFO };

}
