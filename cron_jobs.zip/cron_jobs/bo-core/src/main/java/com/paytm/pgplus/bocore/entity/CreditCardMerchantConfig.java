package com.paytm.pgplus.bocore.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

/**
 * Created by ishasinghal on 13/11/17.
 */

@Getter
@Setter
@ToString
@Entity
@Table(name = "credit_card_merchant_info")
public class CreditCardMerchantConfig {

    @Basic(optional = false)
    @Column(name = "id", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "merchant_name")
    String merchantName;

    @Column(name = "mid")
    String alipayMid;

    @Column(name = "enable")
    boolean enable;
}
