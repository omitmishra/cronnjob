package com.paytm.pgplus.bocore.constants;

public class MSRBillFileColumn {

    // Payment Specific
    public static final String TXN_ID = "TXN_ID";
    public static final String PAYMENT_DATE = "PAYMENT_DATE";
    public static final String ALIPAY_MID = "MID";
    public static final String PAYTM_MID = "ORIGINAL MID";
    public static final String MERCHANT_NAME = "MERCHANT_NAME";
    public static final String CLEARING_DATE = "CLEARING_DATE";
    public static final String TERMINAL_TYPE = "TERMINAL_TYPE";
    public static final String PAYMENT_AMOUNT = "PAYMENT_AMOUNT";
    public static final String PAYMENT_CURRENCY = "PAYMENT_CURRENCY";
    public static final String MERCHANT_COMMISSION = "MERCHANT_COMMISSION";
    public static final String SERVICE_TAX = "SERVICE_TAX";
    public static final String SETTLEMENT_AMOUNT = "SETTLEMENT_AMOUNT";
    public static final String ORDER_ID = "ORDER_ID";
    public static final String PAY_METHOD = "PAY_METHOD";
    public static final String MERCHANT_CUST_ID = "MERCHANT_CUST_ID";
    public static final String ISSUING_BANK = "ISSUING_BANK";
    public static final String STATUS = "STATUS";
    public static final String SETTLEMENT_DATE = "SETTLEMENT_DATE";
    public static final String SETTLED_BANK_TXN_ID = "SETTLED_BANK_TXN_ID";
    public static final String SETTLED_TXN_ID = "SETTLED_TXN_ID";
    public static final String MERCHANT_BILL_ID = "MERCHANT_BILL_ID";
    public static final String PRN_CODE = "PRN_CODE";
    public static final String COMMISSION_RATE = "COMMISSION_RATE";
    public static final String ALIPAY_PRODUCT_CODE = "ALIPAY_PRODUCT_CODE";
    public static final String GMV_TIER = "GMV_TIER";
    public static final String REQUEST_TYPE = "REQUEST_TYPE";
    public static final String TRANSACTION_SLAB = "TRANSACTION_SLAB";
    public static final String RESPONSE_CODE = "RESPONSE_CODE";
    public static final String TRANSACTION_TYPE = "TRANSACTION_TYPE";
    public static final String SPLIT_ID = "SPLIT_ID";
    public static final String ORIG_TXN_AMOUNT = "ORIG_TXN_AMOUNT";
    public static final String IS_SPLIT_PAYMENT = "IS_SPLIT_PAYMENT";
    public static final String SUB_TRANSACTION_TYPE = "SUB_TRANSACTION_TYPE";
    public static final String CARD_SCHEME = "CARD_SCHEME";
    public static final String FEE_FACTOR = "FEE_FACTOR";
    public static final String ACQUIRING_SERVICE_FEE = "ACQUIRING_SERVICE_FEE";
    public static final String PLATFORM_SERVICE_FEE = "PLATFORM_SERVICE_FEE";
    public static final String ACQUIRING_SERVICE_TAX = "ACQUIRING_SERVICE_TAX";
    public static final String PLATFORM_SERVICE_TAX = "PLATFORM_SERVICE_TAX";

    // MF Payment Specific
    public static final String SETTLEMENT_START_DATE = "SETTLEMENT_CYCLE_START_DATE";
    public static final String SETTLEMENT_END_DATE = "SETTLEMENT_CYCLE_END_DATE";
    public static final String BANK_ID = "BANK_ID";
    public static final String BANK_REF_NO = "BANK_REF_NO";
    public static final String PGI_REF_NO = "PGI_REF_NO";
    public static final String REF_1 = "REF_1";
    public static final String REF_2 = "REF_2";
    public static final String REF_3 = "REF_3";
    public static final String REF_4 = "REF_4";
    public static final String REF_5 = "REF_5";
    public static final String REF_6 = "REF_6";
    public static final String REF_7 = "REF_7";
    public static final String REF_8 = "REF_8";
    public static final String REF_9 = "REF_9";
    public static final String REF_10 = "REF_10";
    public static final String REF_11 = "REF_11";
    public static final String REF_12 = "REF_12";

    // Refund Specific
    public static final String REFUND_ID = "REFUND_ID";
    public static final String REFUND_DATE = "REFUND_DATE";
    public static final String REFUND_AMOUNT = "REFUND_AMOUNT";
    public static final String REFUND_CURRENCY = "REFUND_CURRENCY";
    public static final String REF_ID = "REF_ID";

    // Chargeback specific
    public static final String CHARGEBACK_ID = "CHARGEBACK_ID";
    public static final String CHARGEBACK_DATE = "CHARGEBACK_DATE";
    public static final String CHARGEBACK_AMOUNT = "CHARGEBACK_AMOUNT";
    public static final String CHARGEBACK_CURRENCY = "CHARGEBACK_CURRENCY";
    public static final String SETTLED_DATE = "SETTLED_DATE";
    public static final String DISPUTE_ID = "DISPUTE_ID";

    // Cancel specific
    public static final String CANCEL_ID = "CANCEL_ID";
    public static final String CANCEL_DATE = "CANCEL_DATE";
    public static final String CANCEL_AMOUNT = "CANCEL_AMOUNT";
    public static final String CANCEL_CURRENCY = "CANCEL_CURRENCY";

    // Other useful constants
    public static final String FILE_DATE_FORMAT_YYYYMMDD = "yyyyMMdd";
    public static final String FILE_DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd";
    public static final String FILE_DATE_TIME_FORMAT_1 = "yyyy-MM-dd HH:mm:ss";
    public static final String FILE_DATE_TIME_FORMAT_2 = "dd/MM/yyyy HH:mm:ss";
    public static final String BIG_DECIMAL_SCALE_0 = "0";
    public static final String BIG_DECIMAL_ROUNDING_MODE_HALF_DOWN = "HALF_DOWN";
    public static final String BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE = "100";

    public static final String MAIN_MERCHANT_MID = "MAIN_MERCHANT_MID";

    // BANK TRANSFER ENABLED
    public static final String RESELLER_ID = "RESELLER_ID";
    public static final String RESELLER_NAME = "RESELLER_NAME";
    public static final String VAN = "VAN";
    public static final String IFSC_CODE = "IFSC_CODE";
    public static final String BANK_NAME = "BANK_NAME";
    public static final String BENEFICIARY_NAME = "BENEFICIARY_NAME";
    public static final String PURPOSE = "PURPOSE";
    public static final String ISSUING_BANK_ID = "ISSUING_BANK_ID";
    public static final String ISSUING_BANK_NAME = "ISSUING_BANK_NAME";
    public static final String MASKED_CARD_NO = "MASKED_CARD_NO";
    public static final String INST_UNION_CODE = "INST_UNION_CODE";
    public static final String DEPOSITOR_NAME = "DEPOSITOR_NAME";
    public static final String TRANSFER_MODE = "TRANSFER_MODE";
    public static final String TRANSACTION_DATE = "TRANSACTION_DATE";
    public static final String RRN_CODE = "RRN_CODE";
    public static final String UDF1 = "UDF1";
    public static final String UDF2 = "UDF2";
    public static final String UDF3 = "UDF3";
    public static final String UDF4 = "UDF4";
    public static final String UDF5 = "UDF5";
    public static final String REFERENCE_NO = "REFERENCE_NO";
    // REPAYMENT SPECIFIC

    public static final String COMMENTS = "COMMENTS";

    public static final String TXN_TYPE = "TXN_TYPE";

    public static final String REPAYMENT_AMOUNT = "REPAYMENT_AMOUNT";

}
