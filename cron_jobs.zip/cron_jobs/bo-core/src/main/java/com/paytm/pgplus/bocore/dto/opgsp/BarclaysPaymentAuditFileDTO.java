package com.paytm.pgplus.bocore.dto.opgsp;

import lombok.Data;

@Data
public class BarclaysPaymentAuditFileDTO {

    private String clearingBatchId;
    private String txnId;
    private String auditStatusResponseCode;
    private String auditStatusDescription;

}
