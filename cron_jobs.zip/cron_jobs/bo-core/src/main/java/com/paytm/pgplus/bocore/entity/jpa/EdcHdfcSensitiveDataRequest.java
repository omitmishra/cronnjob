package com.paytm.pgplus.bocore.entity.jpa;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(name = "edc_hdfc_settlement")
public class EdcHdfcSensitiveDataRequest implements Serializable {

    @Column
    private String encrypted_pan;

    @Column
    private String encrypted_expiry;

    @Column
    private String translated_pan;

    @Column
    private String translated_expiry;

    @Column
    private Date txn_timestamp;

    @Column
    private String data_ksn;

    @Id
    @OneToOne
    @JsonBackReference
    @JoinColumn(name = "order_id", referencedColumnName = "merchant_trans_id")
    private EdcHdfcBatchUploadRequest edcHdfcBatchUploadRequest;
}