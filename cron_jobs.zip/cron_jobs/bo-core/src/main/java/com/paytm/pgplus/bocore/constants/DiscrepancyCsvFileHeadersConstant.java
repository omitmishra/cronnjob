package com.paytm.pgplus.bocore.constants;

/**
 * Constant class This class responsible for store constant for Discrepancy
 *
 * @author Kulbhushan Pandey
 * @date 6 March 2016
 */
public class DiscrepancyCsvFileHeadersConstant {
    public static final String DISCREPANCY_TYPE = "DiscrepancyType";
    public static final String FLUXNET_EXT_SERIAL_NO = "FluxNetExtSerialNo";
    public static final String FLUXNET_RESULT_STATUS = "FluxNetResultStatus";
    public static final String FLUXNET_REFERENCE_NO = "FluxNetReferenceNo";
    public static final String FLUXNET_EXCHANGE_CURRENCY = "FluxNetExchangeCurrency";
    public static final String FLUXNET_EXCHANGE_AMOUNT = "FluxNetExchangeAmount";
    public static final String BANK_MIS_EXCHANGE_AMOUNT = "BankExchangeAmount";
    public static final String IS_EXCHANGE_AMOUNT_IN_DISCREPANCY = "IsExchangeAmountInDiscrepency";
    public static final String FILE_RCV_DATE = "FileRcvDate";
    public static final String FILE_NAME = "FileName";
    public static final String TRANS_TYPE = "TransType";
    public static final String RESULT_STATUS = "ResultStatus";
    public static final String RESULT_CODE_ID = "ResultCodeId";
    public static final String EXT_SERIAL_NO = "ExtSerialNo";
    public static final String TRACE_NO = "TraceNo";
    public static final String AUTH_CODE = "AuthCode";
    public static final String RRN_CODE = "RrnCode";
    public static final String BANK_ABBR = "BankAbbr";
    public static final String REFERENCE_NO = "ReferenceNo";
    public static final String MERCHANT_ID = "MerchantId";
    public static final String ORIGINAL_MID = "Original MID";
    public static final String MBID = "MBID";
    public static final String EXCHANGE_AMOUNT = "ExchangeAmount";
    public static final String EXCHANGE_CURRENCY = "ExchangeCurrency";
    public static final String TRANS_VALUE_DATE = "TransValueDate";
    public static final String LAST_UPDATE_DATE = "LastUpdateDate";
    public static final String FLUXNET_STATUS = "FluxNetResultStatus";

    public static final String BANK_RESPONSE_NO = "BANK RESPONSE NO";
    public static final String REFUND_STATUS = "REFUND STATUS";
    public static final String REFUND_DATE = "REFUND DATE";
    public static final String STATUS = "STATUS";
    public static final String TXN_DATE = "TXN_DATE";

    public static final String ALIPAY_BIZ_ORDER_ID = "ALIPAY BIZ ORDER ID";
    public static final String ORI_EXT_SERIAL_NO = "ORI EXT SERIAL NO";
    public static final String BANK_REFERENCE_NO = "BANK REFERENCE NO";
    public static final String MEMO = "MEMO";
    public static final String STATUS_PROCESSING = "PROCESSING";
    public static final String STATUS_SUCCESS = "SUCCESS";
    public static final String STATUS_FAILED = "FAILED";

    public static final String TRANS_INFO_SOURCE = "transInfoSource";
    public static final String FEE_AMOUNT = "feeAmount";
    public static final String FEE_CURRENCY = "feeCurrency";

    public static final String BUSINESS_TYPE = "businessType";

    public static final String MERCHANT_TRANS_ID = "merchantTransId";

    public static final String PAY_METHOD = "payMethod";

    public static final String GATEWAY = "gateway";

    public static final String ORDER_CREATED_TIME = "orderCreatedTime";

    public static final String MERCHANT_NAME = "merchantName";

    public static final String VPA = "vpa";

    public static final String BIZ_ORDER_ID = "bizOrderId";

    public static final String SUB_BIZORDER_TYPE = "subBizOrderType";

    public static final String ORDER_STATUS = "orderStatus";
    // PGP-13421
    public static final String PHONE_NUMBER = "Phone Number";
    public static final String ESN = "esn";
    public static final String SERVICE_INSTANCE_ID = "Service Instance Id";
    public static final String MASKED_CARD_NUMBER = "Masked Card Number";
    public static final String ISSUING_BANK_NAME = "Issuing Bank Name";
    public static final String TROUBLE_ID = "Trouble Id";
    public static final String REFUND_TYPE = "Refund Type";
    public static final String CARD_SCHEME = "Card Scheme";
    public static final String CUSTOMER_Id = "Customer Id";
    public static final String MANUAL_REFUND_CSV_DATA= "manual_refund_csv_data";

    public static final String TID = "TID";

    public static final String STAN = "STAN";

    public static final String INTERCHANGE = "INTERCHANGE";

    public static final String MASKED_CARD_NO = "MASKED_CARD_NO";

    public static final String IS_INSTANT_SETTLEMENT = "IS_INSTANT_SETTLEMENT";

    public static final String ADD_MONEY_TYPE = "ADD_MONEY_TYPE";

    public static final String DATE = "DATE";

    public static final String[] DISCREPANCY_FILE_HEADER_MAPPING = { DISCREPANCY_TYPE, FLUXNET_EXT_SERIAL_NO,
            FLUXNET_RESULT_STATUS, FLUXNET_REFERENCE_NO, FLUXNET_EXCHANGE_CURRENCY, FLUXNET_EXCHANGE_AMOUNT,
            FILE_RCV_DATE, FILE_NAME, TRANS_TYPE, RESULT_STATUS, RESULT_CODE_ID, EXT_SERIAL_NO, TRACE_NO, AUTH_CODE,
            RRN_CODE, BANK_ABBR, REFERENCE_NO, MERCHANT_ID, ORIGINAL_MID, MBID, EXCHANGE_AMOUNT, EXCHANGE_CURRENCY,
            TRANS_VALUE_DATE, LAST_UPDATE_DATE, BUSINESS_TYPE, MERCHANT_TRANS_ID, PAY_METHOD, GATEWAY,
            ORDER_CREATED_TIME, MERCHANT_NAME, VPA, BIZ_ORDER_ID, SUB_BIZORDER_TYPE, ORDER_STATUS, TID, STAN,
            MASKED_CARD_NO, INTERCHANGE, IS_INSTANT_SETTLEMENT, ADD_MONEY_TYPE };

    public static final String[] DISCREPANCY_RESPONSE_FILE_HEADER_MAPPING = { EXT_SERIAL_NO, TRANS_TYPE, RESULT_STATUS,
            RESULT_CODE_ID, BANK_ABBR, REFERENCE_NO, TRACE_NO, AUTH_CODE, RRN_CODE, MERCHANT_ID, MBID, EXCHANGE_AMOUNT,
            EXCHANGE_CURRENCY, TRANS_VALUE_DATE, LAST_UPDATE_DATE, FEE_AMOUNT, FEE_CURRENCY, TRANS_INFO_SOURCE };

    public static final String[] DISCREPANCY_RESPONSE_FILE_UPI_HEADER_MAPPING = { EXT_SERIAL_NO, TRANS_TYPE,
            RESULT_STATUS, RESULT_CODE_ID, REFERENCE_NO, TRACE_NO, AUTH_CODE, RRN_CODE, MERCHANT_ID, MBID,
            EXCHANGE_AMOUNT, EXCHANGE_CURRENCY, TRANS_VALUE_DATE, LAST_UPDATE_DATE, FEE_AMOUNT, FEE_CURRENCY,
            TRANS_INFO_SOURCE };

    public static final String[] DUPLICATE_FILE_HEADER_MAPPING = { FILE_RCV_DATE, FILE_NAME, TRANS_TYPE, RESULT_STATUS,
            RESULT_CODE_ID, EXT_SERIAL_NO, TRACE_NO, AUTH_CODE, RRN_CODE, BANK_ABBR, REFERENCE_NO, MERCHANT_ID, MBID,
            EXCHANGE_AMOUNT, EXCHANGE_CURRENCY, TRANS_VALUE_DATE, LAST_UPDATE_DATE };

    public static final String[] REFUND_RESPONSE_FILE_HEADER_MAPPING = { ALIPAY_BIZ_ORDER_ID, ORI_EXT_SERIAL_NO,
            RRN_CODE, BANK_REFERENCE_NO, REFUND_STATUS, REFUND_DATE, MEMO, TROUBLE_ID, PHONE_NUMBER, ESN,
            SERVICE_INSTANCE_ID, MBID, PAY_METHOD, MASKED_CARD_NUMBER, VPA, ISSUING_BANK_NAME, REFUND_TYPE, CARD_SCHEME };

    public static final String[] WITHDRAW_RESPONSE_FILE_HEADER_MAPPING = { ALIPAY_BIZ_ORDER_ID, ORI_EXT_SERIAL_NO,
            BANK_REFERENCE_NO, STATUS, TRANS_VALUE_DATE, LAST_UPDATE_DATE, MEMO, FLUXNET_RESULT_STATUS,
            FLUXNET_EXCHANGE_AMOUNT, BANK_MIS_EXCHANGE_AMOUNT, IS_EXCHANGE_AMOUNT_IN_DISCREPANCY, DISCREPANCY_TYPE };

}
