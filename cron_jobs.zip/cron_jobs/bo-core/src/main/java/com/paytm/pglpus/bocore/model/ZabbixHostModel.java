package com.paytm.pglpus.bocore.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * Created by dheeraj on 27/01/18.
 */

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ZabbixHostModel {

    String name;
    String host;
    String hostid;
}
