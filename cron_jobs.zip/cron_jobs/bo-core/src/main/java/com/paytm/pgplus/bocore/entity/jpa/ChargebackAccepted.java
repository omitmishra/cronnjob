package com.paytm.pgplus.bocore.entity.jpa;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;

/**
 * @author Sharad Singh 19 april 2018
 *
 */
@Data
@Entity
public class ChargebackAccepted implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 7501884218846469510L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    String chargingEsn;
    String alipayBizOrderId;
    Date chargebackAcceptedDate;
    Double refundAmount;
    String comment;

}
