package com.paytm.pglpus.bocore.model.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class RefundStatusRespList implements Serializable {

    private static final long serialVersionUID = 4862154569837794243L;

    @JsonProperty("REFUND_LIST")
    private List<RefundStatusResp> refundStatus;

    @JsonProperty("ErrorCode")
    private String errorCode;

    @JsonProperty("ErrorMsg")
    private String errorMsg;

    @JsonProperty("CHECKSUM")
    private String checksum;

    @JsonIgnore
    private Boolean foundAtPlatformPlus;
}
