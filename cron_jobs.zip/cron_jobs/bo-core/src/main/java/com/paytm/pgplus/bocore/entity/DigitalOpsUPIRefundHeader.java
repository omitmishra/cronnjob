package com.paytm.pgplus.bocore.entity;

/**
 * Created by ishasinghal on 31/1/18.
 */
public class DigitalOpsUPIRefundHeader {

    public static final String MERCHANT_REFERENCE_NO = "Merchant reference Number";
    public static final String FLAG = "Flag";
    public static final String SHTDAT = "Shtdat";
    public static final String ADJAMT = "adjamt";
    public static final String SHSER = "shser";
    public static final String SHCRD = "shcrd";
    public static final String FILENAME = "filename";
    public static final String REASON = "reason";
    public static final String OTHER = "specifyother";
    public static final String UPI_REFUND_AGEING = "upi_refunds_ageing_";
    public static final String UPI_REFUND_RECENT = "upi_refunds_recent_";
    public static final String REFUND_DATE = "refund_date";
    public static final String ORDER_ID = "order_id";
    public static final String STATUS = "status";

    public static final String[] UPI_REFUND_FILE_HEADER = new String[] { "Merchant reference Number", "Flag", "Shtdat",
            "adjamt", "shser", "shcrd", "filename", "reason", "specifyother", "refund_date", "order_id", "status" };

}
