package com.paytm.pgplus.bocore.constants;

public enum TxnStatus {

    TXN_SUCCESS("TXN_SUCCESS"), TXN_FAILURE("TXN_FAILURE"), PENDING("PENDING"), NOT_FOUND("NOT_FOUND"), REFUND_SUCCESS(
            "REFUND_SUCCESS"), REFUND_FAILURE("Refund failure"), SUCCESS("SUCCESS"), RESPONSE_CODE_00000000("00000000");

    private String value;

    /**
     * @param value
     */
    TxnStatus(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
