package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.DownloadEventForScheduledMerchantReportEvent;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportConfig;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportEvent;
import com.paytm.pgplus.bocore.helper.DateUtil;
import lombok.Data;

import javax.validation.ValidationException;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Data
public class ScheduledMerchantReportDayWiseAndDiscreteBasedDynamicData extends
        ScheduledMerchantReportDayWiseBasedDynamicData {

    @Min(0)
    @Max(1440)
    private int endMinute;

    public ScheduledMerchantReportDayWiseAndDiscreteBasedDynamicData() {
        super(ReportGenerationModularityForDynamicData.DAY_WISE_DISCRETE);
    }

    @Override
    public List<ScheduledMerchantReportEvent> getScheduledMerchantReportEvents(
            ScheduledMerchantReportConfigEventInfoPayload payload) {

        ScheduledMerchantReportConfig scheduledMerchantReportConfig = payload.getScheduledMerchantReportConfig();
        Date latestEventDataIncludedTo = payload.getLatestEventDataIncludedTo();

        List<ScheduledMerchantReportEvent> scheduledMerchantReportEvents = new ArrayList<>();
        Date currentDate = new Date();
        Date reportTriggerTime = getReportTriggerTime(currentDate);
        Date txnIncludedFrom = this.getStartMinute() >= this.getEndMinute() ? currentDate : DateUtil.shiftDateByField(
                currentDate, Calendar.DATE, 1);
        while (true) {
            txnIncludedFrom = DateUtil.removeTimeFromDate(txnIncludedFrom);
            txnIncludedFrom = DateUtil.setDateField(txnIncludedFrom, Calendar.MINUTE, this.getStartMinute());
            txnIncludedFrom = DateUtil
                    .shiftDateByField(
                            txnIncludedFrom,
                            Calendar.DATE,
                            -1
                                    * (scheduledMerchantReportConfig.getIntervalModularityWise() + scheduledMerchantReportConfig
                                            .getReportGenerationCycle()));
            Date txnIncludedTo = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.DATE, this.getStartMinute() < this
                    .getEndMinute() ? scheduledMerchantReportConfig.getIntervalModularityWise() - 1
                    : scheduledMerchantReportConfig.getIntervalModularityWise());
            txnIncludedTo = DateUtil.removeTimeFromDate(txnIncludedTo);
            txnIncludedTo = DateUtil.setDateField(txnIncludedTo, Calendar.MINUTE, this.getEndMinute());
            if ((latestEventDataIncludedTo != null && !latestEventDataIncludedTo.after(txnIncludedFrom))
                    || latestEventDataIncludedTo == null) {
                if (!txnIncludedTo.after(reportTriggerTime) && !reportTriggerTime.after(currentDate)) {
                    scheduledMerchantReportEvents.add(getScheduledMerchantReportEvent(txnIncludedFrom, txnIncludedTo,
                            scheduledMerchantReportConfig));
                }
                if (latestEventDataIncludedTo == null) {
                    break;
                }
            } else {
                break;
            }
        }
        return scheduledMerchantReportEvents;
    }

    @Override
    public boolean isValid() {
        boolean isValid = super.isValid() && this.getStartMinute() != this.getEndMinute();
        if (!isValid) {
            throw new ValidationException(
                    "For DAY_WISE_DISCRETE dynamic data startMinute and endMinute cannot be equal other wise go for DAY_WISE_CONTINOUS");
        }
        return isValid;
    }

    private List<DownloadEventForScheduledMerchantReportEvent> getDiscreteDownloadEventForScheduledMSREvent(
            ScheduledMerchantReportEvent scheduledMerchantReportEvent, Date txnIncludedFrom, Date txnIncludedTo) {
        List<DownloadEventForScheduledMerchantReportEvent> downloadEventForScheduledMerchantReportEvent = new ArrayList<>();
        Date txnIncludedToThisDownloadEvent = null;
        while (txnIncludedFrom.before(txnIncludedTo)
                && (txnIncludedToThisDownloadEvent == null || txnIncludedTo.before(txnIncludedToThisDownloadEvent))) {
            if (this.getStartMinute() <= this.getEndMinute()) {
                txnIncludedToThisDownloadEvent = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.MINUTE,
                        this.getEndMinute() - this.getStartMinute());
            } else {
                txnIncludedToThisDownloadEvent = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.MINUTE,
                        (24 * 60 - this.getStartMinute()) + this.endMinute);
            }
            downloadEventForScheduledMerchantReportEvent.add(getDownloadEventForScheduledMerchantReportEvent(
                    scheduledMerchantReportEvent, txnIncludedFrom, txnIncludedToThisDownloadEvent));
            txnIncludedFrom = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.DATE, 1);
        }
        return downloadEventForScheduledMerchantReportEvent;
    }

    protected ScheduledMerchantReportEvent getScheduledMerchantReportEvent(Date txnIncludedFrom, Date txnIncludedTo,
            ScheduledMerchantReportConfig scheduledMerchantReportConfig) {
        ScheduledMerchantReportEvent scheduledMerchantReportEvent = new ScheduledMerchantReportEvent();
        scheduledMerchantReportEvent.setScheduledMerchantReportConfig(scheduledMerchantReportConfig);
        scheduledMerchantReportEvent
                .setDownloadEventForScheduledMerchantReportEvents(getDiscreteDownloadEventForScheduledMSREvent(
                        scheduledMerchantReportEvent, txnIncludedFrom, txnIncludedTo));
        return scheduledMerchantReportEvent;
    }
}
