package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import com.paytm.pgplus.bocore.model.autosftp.ConfigType;
import com.paytm.pgplus.bocore.model.autosftp.SftpConfig;
import com.vladmihalcea.hibernate.type.json.JsonStringType;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Map;

@Data
@TypeDefs({ @TypeDef(name = "json", typeClass = JsonStringType.class) })
@Entity
@Table(name = "auto_sftp_event")
public class AutoSftpEvent extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1306951146417394822L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    String source;
    String status;
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "config_id", nullable = false)
    private AutoSftpConfig autoSftpConfig;
    @Column(name = "retry_count")
    Integer retryCount;
    @Type(type = "json")
    @Column(name = "dynamic_map", columnDefinition = "json")
    Map<String, String> dynamicMap;
}
