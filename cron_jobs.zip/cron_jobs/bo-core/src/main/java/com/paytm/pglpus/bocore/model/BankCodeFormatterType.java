/**
 *
 */
package com.paytm.pglpus.bocore.model;

public enum BankCodeFormatterType {
    CBI, UCO, KOTAK, UBI, BOB, UNI, PNB, SVC, OBPRF, CBITPV, DEFAULT, CORP, UBICORPORATE;

}
