package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import lombok.Data;

@Data
public class ImplicitEmailConfig extends EmailConfig {

    private String emailSubject;

    public ImplicitEmailConfig() {
        super(EmailConfigType.IMPLICIT);
    }
}
