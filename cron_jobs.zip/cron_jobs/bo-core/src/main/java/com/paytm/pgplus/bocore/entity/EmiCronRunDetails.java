package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import com.paytm.pgplus.bocore.enums.EmiReportCronStatus;

/**
 * @author Rahul Verma on 02/07/2019
 */

@Getter
@Setter
@ToString
@Entity
@Table(name = "emi_cron_run_details")
public class EmiCronRunDetails implements Serializable {
    /**
     * generated serial version Id
     */
    private static final long serialVersionUID = -6442184448637506378L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @OneToOne
    @JoinColumn(name = "emi_consolidated_cron_config_id")
    private EmiConsolidatedCronConfig emiConsolidatedCronConfig;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private EmiReportCronStatus status;

    @Temporal(TemporalType.DATE)
    @Column(name = "cron_date", nullable = false)
    private Date cronDate;

    @Column(name = "alipay_records")
    private Integer alipayRecords;

    @Column(name = "sent_records")
    private Integer sentRecords;
}
