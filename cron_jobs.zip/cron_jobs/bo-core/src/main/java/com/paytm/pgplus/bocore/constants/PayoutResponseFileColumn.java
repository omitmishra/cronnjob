/**
 * 
 */
package com.paytm.pgplus.bocore.constants;

/**
 * @author riteshkumarsharma
 *
 */
public class PayoutResponseFileColumn {

    public static final String PAYOUT_ID = "payout_id";
    public static final String UTR_NO = "utrNo";
    public static final String PAYOUT_STATUS = "payout_status";
    public static final String MID = "mid";
    public static final String ORIGINAL_MID = "original_mid";
    public static final String AMOUNT = "amount";

    // public static final String[] FILE_HEADERS = new String[] { PAYOUT_ID,
    // UTR_NO, PAYOUT_STATUS, MID, ORIGINAL_MID, AMOUNT };
    public static final String[] FILE_HEADERS = new String[] { PayoutDownloadFileColumn.ENTITY_PAYOUT_ID,
            PayoutDownloadFileColumn.UTR, PayoutDownloadFileColumn.PAYOUT_STATUS,
            PayoutDownloadFileColumn.ALIPAY_MERCHANT_ID, PayoutDownloadFileColumn.MERCHANT_ID,
            PayoutDownloadFileColumn.PAYOUT_AMOUNT, PayoutDownloadFileColumn.UTR_UPLOAD_TIME };

    public static final String[] ONLINE_FILE_HEADER = new String[] { PayoutDownloadFileColumn.RECON_ID,
            PayoutDownloadFileColumn.SETTLEMENT_STATUS, PayoutDownloadFileColumn.VALUE_DATE,
            PayoutDownloadFileColumn.BILL_DATE, PayoutDownloadFileColumn.UTR_NO,
            PayoutDownloadFileColumn.SETTLEMENT_AMOUNT, PayoutDownloadFileColumn.SETTLEMENT_CURRENCY,
            PayoutDownloadFileColumn.MERCHANT_ID, PayoutDownloadFileColumn.MERCHANT_ID_PAYTM,
            PayoutDownloadFileColumn.UTR_UPLOAD_TIME };

    public static final String[] ONLINE_FILE_HEADER_REVERSAL = new String[] { PayoutDownloadFileColumn.RECON_ID,
            PayoutDownloadFileColumn.SETTLEMENT_STATUS, PayoutDownloadFileColumn.VALUE_DATE,
            PayoutDownloadFileColumn.BILL_DATE, PayoutDownloadFileColumn.UTR_NO,
            PayoutDownloadFileColumn.SETTLEMENT_AMOUNT, PayoutDownloadFileColumn.SETTLEMENT_CURRENCY,
            PayoutDownloadFileColumn.MERCHANT_ID, PayoutDownloadFileColumn.MERCHANT_ID_PAYTM,
            PayoutDownloadFileColumn.UTR_UPLOAD_TIME };

}
