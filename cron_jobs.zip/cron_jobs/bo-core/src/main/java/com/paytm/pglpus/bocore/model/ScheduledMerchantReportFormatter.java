package com.paytm.pglpus.bocore.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author rahul7.verma
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScheduledMerchantReportFormatter {

    ScheduledMerchantReportFormatterType formatterType;
    String formatterValue;
}
