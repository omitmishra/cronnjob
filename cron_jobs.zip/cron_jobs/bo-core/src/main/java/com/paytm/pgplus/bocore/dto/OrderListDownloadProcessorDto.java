package com.paytm.pgplus.bocore.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author rahul7.verma
 * @since 01 March 2021
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderListDownloadProcessorDto implements Serializable {

    private static final long serialVersionUID = 7129710809208837327L;

    private String downloadId;
    private String merchantId;

    // localFilePath is used to hold the path to file that was downloaded using
    // RTDD url
    private String localFilePath;

    // processedFilePath is used to hold the path to file that was
    // processed/re-written in respective format for merchant
    private String processedFilePath;

    // this boolean flag tells if auto sftp needs to be called or not
    private boolean autoSftpEnable;

    // this boolean flag tells if file needs to be zipped before sending on
    // email or not
    private boolean emailEnable;

    // this boolean flag tells if file needs to be send using email or not
    private boolean zipEnable;
}