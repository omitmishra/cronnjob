package com.paytm.pglpus.bocore.model.merchantReportEvents;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pglpus.bocore.model.merchantReportEvents.eventinfo.BillFileDataProcessorInfo;
import com.paytm.pglpus.bocore.model.merchantReportEvents.eventinfo.SettlementReportHttpProcessorInfo;
import lombok.*;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventInfo {
    private String failureMessage;
    private String alertMessage;
    private BillFileDataProcessorInfo eventBillDataProcessorInfo;
    private SettlementReportHttpProcessorInfo settlementReportHttpProcessorInfo;
}
