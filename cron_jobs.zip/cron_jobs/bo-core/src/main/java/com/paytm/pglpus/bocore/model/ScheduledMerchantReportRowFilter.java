package com.paytm.pglpus.bocore.model;

import com.paytm.pgplus.bocore.enums.ScheduledMerchantReportRowFilterType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author rahul7.verma
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScheduledMerchantReportRowFilter {

    ScheduledMerchantReportRowFilterType filterType;
    String filterValue;
}
