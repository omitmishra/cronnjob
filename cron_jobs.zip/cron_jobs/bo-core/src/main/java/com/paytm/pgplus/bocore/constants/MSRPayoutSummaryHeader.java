/**
 * 
 */
package com.paytm.pgplus.bocore.constants;

/**
 * @author santoshkumar
 *
 */
public class MSRPayoutSummaryHeader {

    public static final String UTR = "UTR";
    public static final String SETTLEMENT_DATE = "Settlement date";
    public static final String SETTLEMENT_AMOUNT = "Settlement Amount";
    public static final String PAYMENT_AMOUNT = "Payment Amount";
    public static final String PAYMENT_COUNT = "Payment Count";
    public static final String REFUND_AMOUNT = "Refund Amount";
    public static final String REFUND_COUNT = "Refund Count";
    public static final String CHARGEBACK_AMOUNT = "Chargeback Amount";
    public static final String CHARGEBACK_COUNT = "Chargeback Count";
    public static final String COMMISSION = "Commission";
    public static final String GST = "GST";

    public static final String[] MSR_PAYOUT_SUMMARY_FILE_HEADER = new String[] { MSRPayoutSummaryHeader.UTR,
            MSRPayoutSummaryHeader.SETTLEMENT_DATE, MSRPayoutSummaryHeader.SETTLEMENT_AMOUNT,
            MSRPayoutSummaryHeader.PAYMENT_AMOUNT, MSRPayoutSummaryHeader.PAYMENT_COUNT,
            MSRPayoutSummaryHeader.COMMISSION, MSRPayoutSummaryHeader.GST, MSRPayoutSummaryHeader.REFUND_AMOUNT,
            MSRPayoutSummaryHeader.REFUND_COUNT, MSRPayoutSummaryHeader.CHARGEBACK_AMOUNT,
            MSRPayoutSummaryHeader.CHARGEBACK_COUNT };
}
