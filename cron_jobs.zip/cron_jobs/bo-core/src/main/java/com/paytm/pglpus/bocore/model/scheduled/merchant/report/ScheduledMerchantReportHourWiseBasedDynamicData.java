package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportConfig;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportEvent;
import com.paytm.pgplus.bocore.helper.DateUtil;
import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Data
public class ScheduledMerchantReportHourWiseBasedDynamicData extends ScheduledMerchantReportModularityBasedDynamicData {

    @Min(0)
    @Max(59)
    private int startMinute;

    public ScheduledMerchantReportHourWiseBasedDynamicData() {
        super(ReportGenerationModularityForDynamicData.HOUR_WISE);
    }

    @Override
    public List<ScheduledMerchantReportEvent> getScheduledMerchantReportEvents(
            ScheduledMerchantReportConfigEventInfoPayload payload) {

        ScheduledMerchantReportConfig scheduledMerchantReportConfig = payload.getScheduledMerchantReportConfig();
        Date latestEventDataIncludedTo = payload.getLatestEventDataIncludedTo();

        List<ScheduledMerchantReportEvent> scheduledMerchantReportEvents = new ArrayList<>();
        Date currentDate = new Date();
        Date reportTriggerTime = getReportTriggerTime(currentDate);
        Date txnIncludedFrom;
        Date txnIncludedTo;
        if (latestEventDataIncludedTo == null) {
            int curMinute = DateUtil.getDateFieldValue(currentDate, Calendar.MINUTE) % 60;
            currentDate = DateUtil.setDateField(currentDate, Calendar.SECOND, 0);
            currentDate = DateUtil.setDateField(currentDate, Calendar.MILLISECOND, 0);
            if (curMinute < startMinute) {
                txnIncludedTo = DateUtil.shiftDateByField(currentDate, Calendar.MINUTE, startMinute - curMinute);
                txnIncludedTo = DateUtil.shiftDateByField(txnIncludedTo, Calendar.HOUR, -1
                        * scheduledMerchantReportConfig.getIntervalModularityWise());
            } else {
                txnIncludedTo = DateUtil.shiftDateByField(currentDate, Calendar.MINUTE, -1 * (curMinute - startMinute));
            }
            txnIncludedTo = DateUtil.shiftDateByField(txnIncludedTo, Calendar.DATE,
                    -1 * scheduledMerchantReportConfig.getReportGenerationCycle());
            txnIncludedTo = DateUtil.shiftDateByField(txnIncludedTo, Calendar.MILLISECOND, -1);
            txnIncludedFrom = DateUtil.shiftDateByField(txnIncludedTo, Calendar.HOUR, -1
                    * scheduledMerchantReportConfig.getIntervalModularityWise());
            txnIncludedFrom = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.MILLISECOND, 1);
            scheduledMerchantReportEvents.add(getScheduledMerchantReportEvent(txnIncludedFrom, txnIncludedTo,
                    scheduledMerchantReportConfig));
        } else {
            txnIncludedTo = latestEventDataIncludedTo;
            Date maxTxnIncludedTo = DateUtil.shiftDateByField(currentDate, Calendar.DATE, -1
                    * scheduledMerchantReportConfig.getReportGenerationCycle());
            while (true) {
                txnIncludedFrom = DateUtil.shiftDateByField(txnIncludedTo, Calendar.MILLISECOND, 1);
                txnIncludedTo = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.HOUR,
                        scheduledMerchantReportConfig.getIntervalModularityWise());
                txnIncludedTo = DateUtil.shiftDateByField(txnIncludedTo, Calendar.MILLISECOND, -1);
                if (!txnIncludedTo.after(reportTriggerTime) && !txnIncludedTo.after(maxTxnIncludedTo)
                        && !currentDate.before(reportTriggerTime)) {
                    scheduledMerchantReportEvents.add(getScheduledMerchantReportEvent(txnIncludedFrom, txnIncludedTo,
                            scheduledMerchantReportConfig));
                } else {
                    break;
                }
            }
        }
        return scheduledMerchantReportEvents;
    }

    protected Date getReportTriggerTime(Date currentDate) {
        return super.getReportTriggerTime(currentDate, null);
    }
}
