package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author Kulbhushan Pandey
 * @since 16 Feb 2017
 */
@Entity
@Table(name = "MONITER_REPORT_REFUND")
public class MonitorReportRefund implements Serializable {

    private static final long serialVersionUID = -3892220064455129542L;

    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "T_REF", length = 11)
    private Integer totalRefund;

    @Column(name = "T_S_REF", length = 11)
    private Integer totalSuccessRefund;

    @Column(name = "T_F_REF", length = 11)
    private Integer totalFailRefund;

    @Column(name = "T_I_REF", length = 11)
    private Integer totalInitiatedRefund;

    @Column(name = "T_P_REF", length = 11)
    private Integer totalPendingRefund;

    @Column(name = "T_AUTO_REF", length = 11)
    private Integer totalAutoRefund;

    @Column(name = "T_AUTO_S_REF", length = 11)
    private Integer totalSuccessAutoRefund;

    @Column(name = "T_AUTO_F_REF", length = 11)
    private Integer totalFailAutoRefund;

    @Column(name = "T_AUTO_I_REF", length = 11)
    private Integer totalInitiatedAutoRefund;

    @Column(name = "T_AUTO_P_REF", length = 11)
    private Integer totalPendingAutoRefund;

    @Column(name = "T_ON_REF", length = 11)
    private Integer totalOnlineRefund;

    @Column(name = "T_ON_S_REF", length = 11)
    private Integer totalSuccessOnlineRefund;

    @Column(name = "T_ON_F_REF", length = 11)
    private Integer totalFailOnlineRefund;

    @Column(name = "T_ON_I_REF", length = 11)
    private Integer totalInitiatedOnlineRefund;

    @Column(name = "T_ON_P_REF", length = 11)
    private Integer totalPendingOnlineRefund;

    @Column(name = "T_OFF_REF", length = 11)
    private Integer totalOfflineRefund;

    @Column(name = "T_OFF_S_REF", length = 11)
    private Integer totalSuccessOfflineRefund;

    @Column(name = "T_OFF_F_REF", length = 11)
    private Integer totalFailOfflineRefund;

    @Column(name = "T_OFF_I_REF", length = 11)
    private Integer totalInitiatedOfflineRefund;

    @Column(name = "T_OFF_P_REF", length = 11)
    private Integer totalPendingOfflineRefund;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_ON", nullable = false)
    private Date createdOn;

    @Basic(optional = false)
    @Column(name = "UPDATED_ON")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedOn;

    @Column(name = "IS_MAILED", length = 11)
    private Integer isMailed;

    @Basic(optional = false)
    @Column(name = "MAILED_ON")
    @Temporal(TemporalType.TIMESTAMP)
    private Date mailedOn;

    public MonitorReportRefund() {
        createdOn = new Date();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getTotalRefund() {
        return totalRefund;
    }

    public void setTotalRefund(Integer totalRefund) {
        this.totalRefund = totalRefund;
    }

    public Integer getTotalSuccessRefund() {
        return totalSuccessRefund;
    }

    public void setTotalSuccessRefund(Integer totalSuccessRefund) {
        this.totalSuccessRefund = totalSuccessRefund;
    }

    public Integer getTotalFailRefund() {
        return totalFailRefund;
    }

    public void setTotalFailRefund(Integer totalFailRefund) {
        this.totalFailRefund = totalFailRefund;
    }

    public Integer getTotalInitiatedRefund() {
        return totalInitiatedRefund;
    }

    public void setTotalInitiatedRefund(Integer totalInitiatedRefund) {
        this.totalInitiatedRefund = totalInitiatedRefund;
    }

    public Integer getTotalPendingRefund() {
        return totalPendingRefund;
    }

    public void setTotalPendingRefund(Integer totalPendingRefund) {
        this.totalPendingRefund = totalPendingRefund;
    }

    public Integer getTotalAutoRefund() {
        return totalAutoRefund;
    }

    public void setTotalAutoRefund(Integer totalAutoRefund) {
        this.totalAutoRefund = totalAutoRefund;
    }

    public Integer getTotalSuccessAutoRefund() {
        return totalSuccessAutoRefund;
    }

    public void setTotalSuccessAutoRefund(Integer totalSuccessAutoRefund) {
        this.totalSuccessAutoRefund = totalSuccessAutoRefund;
    }

    public Integer getTotalFailAutoRefund() {
        return totalFailAutoRefund;
    }

    public void setTotalFailAutoRefund(Integer totalFailAutoRefund) {
        this.totalFailAutoRefund = totalFailAutoRefund;
    }

    public Integer getTotalInitiatedAutoRefund() {
        return totalInitiatedAutoRefund;
    }

    public void setTotalInitiatedAutoRefund(Integer totalInitiatedAutoRefund) {
        this.totalInitiatedAutoRefund = totalInitiatedAutoRefund;
    }

    public Integer getTotalPendingAutoRefund() {
        return totalPendingAutoRefund;
    }

    public void setTotalPendingAutoRefund(Integer totalPendingAutoRefund) {
        this.totalPendingAutoRefund = totalPendingAutoRefund;
    }

    public Integer getTotalOnlineRefund() {
        return totalOnlineRefund;
    }

    public void setTotalOnlineRefund(Integer totalOnlineRefund) {
        this.totalOnlineRefund = totalOnlineRefund;
    }

    public Integer getTotalSuccessOnlineRefund() {
        return totalSuccessOnlineRefund;
    }

    public void setTotalSuccessOnlineRefund(Integer totalSuccessOnlineRefund) {
        this.totalSuccessOnlineRefund = totalSuccessOnlineRefund;
    }

    public Integer getTotalFailOnlineRefund() {
        return totalFailOnlineRefund;
    }

    public void setTotalFailOnlineRefund(Integer totalFailOnlineRefund) {
        this.totalFailOnlineRefund = totalFailOnlineRefund;
    }

    public Integer getTotalInitiatedOnlineRefund() {
        return totalInitiatedOnlineRefund;
    }

    public void setTotalInitiatedOnlineRefund(Integer totalInitiatedOnlineRefund) {
        this.totalInitiatedOnlineRefund = totalInitiatedOnlineRefund;
    }

    public Integer getTotalPendingOnlineRefund() {
        return totalPendingOnlineRefund;
    }

    public void setTotalPendingOnlineRefund(Integer totalPendingOnlineRefund) {
        this.totalPendingOnlineRefund = totalPendingOnlineRefund;
    }

    public Integer getTotalOfflineRefund() {
        return totalOfflineRefund;
    }

    public void setTotalOfflineRefund(Integer totalOfflineRefund) {
        this.totalOfflineRefund = totalOfflineRefund;
    }

    public Integer getTotalSuccessOfflineRefund() {
        return totalSuccessOfflineRefund;
    }

    public void setTotalSuccessOfflineRefund(Integer totalSuccessOfflineRefund) {
        this.totalSuccessOfflineRefund = totalSuccessOfflineRefund;
    }

    public Integer getTotalFailOfflineRefund() {
        return totalFailOfflineRefund;
    }

    public void setTotalFailOfflineRefund(Integer totalFailOfflineRefund) {
        this.totalFailOfflineRefund = totalFailOfflineRefund;
    }

    public Integer getTotalInitiatedOfflineRefund() {
        return totalInitiatedOfflineRefund;
    }

    public void setTotalInitiatedOfflineRefund(Integer totalInitiatedOfflineRefund) {
        this.totalInitiatedOfflineRefund = totalInitiatedOfflineRefund;
    }

    public Integer getTotalPendingOfflineRefund() {
        return totalPendingOfflineRefund;
    }

    public void setTotalPendingOfflineRefund(Integer totalPendingOfflineRefund) {
        this.totalPendingOfflineRefund = totalPendingOfflineRefund;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Integer getIsMailed() {
        return isMailed;
    }

    public void setIsMailed(Integer isMailed) {
        this.isMailed = isMailed;
    }

    public Date getMailedOn() {
        return mailedOn;
    }

    public void setMailedOn(Date mailedOn) {
        this.mailedOn = mailedOn;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("MonitorReportRefund [id=").append(id).append(", totalRefund=").append(totalRefund)
                .append(", totalSuccessRefund=").append(totalSuccessRefund).append(", totalFailRefund=")
                .append(totalFailRefund).append(", totalInitiatedRefund=").append(totalInitiatedRefund)
                .append(", totalPendingRefund=").append(totalPendingRefund).append(", totalAutoRefund=")
                .append(totalAutoRefund).append(", totalSuccessAutoRefund=").append(totalSuccessAutoRefund)
                .append(", totalFailAutoRefund=").append(totalFailAutoRefund).append(", totalInitiatedAutoRefund=")
                .append(totalInitiatedAutoRefund).append(", totalPendingAutoRefund=").append(totalPendingAutoRefund)
                .append(", totalOnlineRefund=").append(totalOnlineRefund).append(", totalSuccessOnlineRefund=")
                .append(totalSuccessOnlineRefund).append(", totalFailOnlineRefund=").append(totalFailOnlineRefund)
                .append(", totalInitiatedOnlineRefund=").append(totalInitiatedOnlineRefund)
                .append(", totalPendingOnlineRefund=").append(totalPendingOnlineRefund).append(", totalOfflineRefund=")
                .append(totalOfflineRefund).append(", totalSuccessOfflineRefund=").append(totalSuccessOfflineRefund)
                .append(", totalFailOfflineRefund=").append(totalFailOfflineRefund)
                .append(", totalInitiatedOfflineRefund=").append(totalInitiatedOfflineRefund)
                .append(", totalPendingOfflineRefund=").append(totalPendingOfflineRefund).append(", createdOn=")
                .append(createdOn).append(", updatedOn=").append(updatedOn).append(", isMailed=").append(isMailed)
                .append(", mailedOn=").append(mailedOn).append("]");
        return builder.toString();
    }

}
