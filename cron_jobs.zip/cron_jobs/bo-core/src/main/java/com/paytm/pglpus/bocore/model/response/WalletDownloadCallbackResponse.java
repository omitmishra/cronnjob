package com.paytm.pglpus.bocore.model.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * This class represents response for download callback api by wallet. It has
 * status as SUCCESS/FAILURE.
 * 
 * @author nikhilshivajiugane
 *
 */

@Getter
@Setter
@NoArgsConstructor
@ToString
public class WalletDownloadCallbackResponse {

    private String status;
}
