package com.paytm.pglpus.bocore.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.Date;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@AllArgsConstructor
public class EventMigrationInfoRequest {
    String mid;
    String event;
    String status;
    Date startDate;
    Date endDate;

}
