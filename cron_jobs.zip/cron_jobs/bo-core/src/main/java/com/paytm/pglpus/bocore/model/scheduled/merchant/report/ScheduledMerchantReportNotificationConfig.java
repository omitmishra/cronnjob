package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
public class ScheduledMerchantReportNotificationConfig implements Serializable {

    @NotNull
    @Valid
    private EmailConfig emailConfig;

    private boolean skipSendingEmptyFile;
}
