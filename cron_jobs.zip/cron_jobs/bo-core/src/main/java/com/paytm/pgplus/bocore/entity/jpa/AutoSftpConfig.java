package com.paytm.pgplus.bocore.entity.jpa;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.paytm.pgplus.bocore.entity.BaseEntity;
import com.paytm.pgplus.bocore.model.DingInfo;
import com.paytm.pgplus.bocore.model.autosftp.CallbackConfig;
import com.paytm.pgplus.bocore.model.autosftp.ConfigType;
import com.paytm.pgplus.bocore.model.autosftp.SftpConfig;
import com.paytm.pgplus.bocore.model.autosftp.storage.StorageConfig;
import com.paytm.pgplus.rabbitmq.communication.models.EmailInfo;
import com.vladmihalcea.hibernate.type.json.JsonStringType;
import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;

import javax.persistence.*;
import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author rahul7.verma
 */
@Data
@Entity
@TypeDefs({ @TypeDef(name = "json", typeClass = JsonStringType.class) })
@JsonInclude(JsonInclude.Include.NON_NULL)
@Table(name = "auto_sftp_config")
public class AutoSftpConfig extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -3335905858334625590L;

    @Basic(optional = false)
    @Column(name = "id", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "identifier")
    private String identifier;

    @Column(name = "type")
    private String identifierType;

    @Type(type = "json")
    @Column(name = "sftp_config", columnDefinition = "json")
    private List<SftpConfig> sftpConfig;

    @Type(type = "json")
    @Column(name = "storage_config", columnDefinition = "json")
    private List<StorageConfig> storageConfig;

    @Type(type = "json")
    @Column(name = "callback_config", columnDefinition = "json")
    private CallbackConfig callbackConfig;

    @Type(type = "json")
    @Column(name = "email_info", columnDefinition = "json")
    private EmailInfo emailInfo;

    @Type(type = "json")
    @Column(name = "ding_info", columnDefinition = "json")
    private DingInfo dingInfo;

    @Enumerated(EnumType.STRING)
    @Column(name = "config_type")
    private ConfigType configType;

    @Column(name = "enabled")
    private boolean enabled;

    @Column(name = "notification")
    private String notification;

    @Temporal(TemporalType.TIME)
    @Column(name = "triggered_time")
    private Date triggeredTime;

    public AutoSftpConfig() {
    }

    @JsonIgnore
    @Transient
    public String getSftpConfigString() {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(emailInfo);
        } catch (IOException e) {
            return null;
        }
    }
}