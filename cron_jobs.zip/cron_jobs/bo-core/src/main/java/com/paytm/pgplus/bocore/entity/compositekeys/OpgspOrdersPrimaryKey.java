package com.paytm.pgplus.bocore.entity.compositekeys;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OpgspOrdersPrimaryKey implements Serializable {
    private String mid;
    private String orderId;
}
