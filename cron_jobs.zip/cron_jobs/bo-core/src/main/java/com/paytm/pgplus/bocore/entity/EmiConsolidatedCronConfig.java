package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Map;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author Ankit Goel
 *
 */

@Getter
@Setter
@ToString
@Entity
@Table(name = "emi_consolidated_cron_config")
@XmlRootElement
public class EmiConsolidatedCronConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Bank_Code", length = 20, nullable = false)
    private String bankCode;

    @Column(name = "Day_Window")
    private Integer dayWindow;

    @Column(name = "Passkey")
    private String passkey;

    @Column(name = "Paymode")
    private String paymode;

    @Column(name = "email_config_cron_key")
    private String emailConfigCronKey;

    @Column(name = "enabled")
    private Boolean enabled;

    @Column(name = "separate_edc_file")
    private Boolean separateEDCFile;

    @Transient
    private Map<String, Object> additionalInfo;

    @Column(name = "monthlyEnabled")
    private Boolean monthlyEnabled;

    public EmiConsolidatedCronConfig() {
    }

    @Override
    public String toString() {
        return "Bank ==> " + this.bankCode + "   Day Window ==> " + this.dayWindow + "  Paymode ==> " + this.paymode;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((bankCode == null) ? 0 : bankCode.hashCode());
        result = prime * result + ((dayWindow == null) ? 0 : dayWindow.hashCode());
        result = prime * result + ((enabled == null) ? 0 : enabled.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((paymode == null) ? 0 : paymode.hashCode());
        result = prime * result + ((separateEDCFile == null) ? 0 : separateEDCFile.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EmiConsolidatedCronConfig other = (EmiConsolidatedCronConfig) obj;
        if (bankCode == null) {
            if (other.bankCode != null)
                return false;
        } else if (!bankCode.equals(other.bankCode))
            return false;
        if (dayWindow == null) {
            if (other.dayWindow != null)
                return false;
        } else if (!dayWindow.equals(other.dayWindow))
            return false;
        if (enabled == null) {
            if (other.enabled != null)
                return false;
        } else if (!enabled.equals(other.enabled))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (paymode == null) {
            if (other.paymode != null)
                return false;
        } else if (!paymode.equals(other.paymode))
            return false;
        if (separateEDCFile == null) {
            if (other.separateEDCFile != null)
                return false;
        } else if (!separateEDCFile.equals(other.separateEDCFile))
            return false;
        return true;
    }

}