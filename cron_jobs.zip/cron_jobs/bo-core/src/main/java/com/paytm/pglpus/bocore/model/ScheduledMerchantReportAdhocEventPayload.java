package com.paytm.pglpus.bocore.model;

import lombok.Data;

import java.io.Serializable;

@Data
public class ScheduledMerchantReportAdhocEventPayload implements Serializable {

    private Long parentEventId;
    private String fileName;
    private String fileNameSuffix;
}
