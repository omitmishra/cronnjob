package com.paytm.pgplus.bocore.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Created by ishasinghal on 15/9/17.
 */
@Setter
@Getter
@AllArgsConstructor
@ToString
public class InstaRefundResponse<T> {

    private T response;
    private String signature;

    public String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"response\":");
        sb.append(response);
        sb.append(", \"signature\":\"");
        sb.append(signature);
        sb.append("\"}");
        return sb.toString();
    }
}