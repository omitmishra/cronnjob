package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

public enum ReportGenerationModularity {

    HOUR_WISE, DAY_WISE, MONTH_WISE;
}
