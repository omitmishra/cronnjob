package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

public enum EmailConfigType {

    EXPLICIT, IMPLICIT;
}
