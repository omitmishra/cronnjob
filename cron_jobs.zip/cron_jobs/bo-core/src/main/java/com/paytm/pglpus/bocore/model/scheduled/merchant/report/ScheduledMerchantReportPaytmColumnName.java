package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.google.common.collect.Maps;

import javax.annotation.Nullable;
import java.util.Arrays;
import java.util.Map;

public enum ScheduledMerchantReportPaytmColumnName implements ScheduledMerchantReportColumnName {
    PAYMENT_ID(ScheduledMerchantReportPaytmColumnNameConstants.PAYMENT_ID), TXN_ID(
            ScheduledMerchantReportPaytmColumnNameConstants.TXN_ID), REF_ID("REF ID"), PARENT_TXN_ID("ParentTxnID"), CHILD_TXN_FLAG(
            "ChildTxnFlag"), PARENT_REFUND_ID("Parent Refund ID"), REFUND_TYPE("Refund Type"), COMMISSION(
            ScheduledMerchantReportPaytmColumnNameConstants.COMMISSION), REFUND_DATE("Refund Date"), REFUND_AMT(
            ScheduledMerchantReportPaytmColumnNameConstants.REFUND_AMT), REFUND_ID("Refund ID"), STATUS_TYPE(
            "Statustype"), RESP_MSG("ResponseMessage"), M_NAME(ScheduledMerchantReportPaytmColumnNameConstants.M_NAME), M_LOCAL_NAME(
            "MerchantLocalName"), MB_ID("MBID"), BANK_FEES("BankFees"), MER_COMM("MerchantCommission"), SETTLED_DATE(
            ScheduledMerchantReportPaytmColumnNameConstants.SETTLED_DATE), UPDATED_DATE(
            ScheduledMerchantReportPaytmColumnNameConstants.UPDATED_DATE), INDUSTRY("Industry"), CARD_NUM("CARD_NUM"), THEME(
            "Theme"), TXN_ID_TO_BANK("Txn Id(Bank)"), TXN_AMT_TO_BANK("TXN_AMT_TO_BANK"), TXN_DATE(
            ScheduledMerchantReportPaytmColumnNameConstants.TXN_DATE), TXN_CHANNEL("TxnChannel"), TXN_AMT("TxnAmount"), CUR_TYPE(
            "CurrencyType"), ORDER_ID(ScheduledMerchantReportPaytmColumnNameConstants.ORDER_ID), LAST_FOUR(
            "CC/DCLast 4"), COMMENTS("Comments"), STATUS("Status"), ERROR_CODE("ERROR_CODE"), ERROR_MSG("ERROR_MSG"), BANK_TXN_ID(
            ScheduledMerchantReportPaytmColumnNameConstants.BANK_TXN_ID), CUST_ID(
            ScheduledMerchantReportPaytmColumnNameConstants.CUST_ID), S_TAX(
            ScheduledMerchantReportPaytmColumnNameConstants.S_TAX), NET_AMT("NET_AMT"), WEBSITE(
            ScheduledMerchantReportPaytmColumnNameConstants.WEBSITE), RETRY("RETRY"), COMPOSITE_TXN_ID(
            "COMPOSITE_TXN_ID"), OPERATION_TYPE("OPERATION_TYPE"), PAYOUT_DATE(
            ScheduledMerchantReportPaytmColumnNameConstants.PAYOUT_DATE), UTR("UTR"), USER_CUST_ID("UserCustID"), PROMO_CODE(
            "PROMOCODE"), PROMO_RESP("PromoResponse"), PAYOUT_ID("PayoutId"), POS_ID("PosId"), MERCHANT_UNQ_REF(
            ScheduledMerchantReportPaytmColumnNameConstants.MERCHANT_UNQ_REF), IS_BLOCKED("IS_BLOCKED"), GATEWAY_PAY_MODE(
            "Gateway_PayMode"), TRACE_INFO("TraceInfo"), BIN_NUMBER("BinNumber"), TXN_BANK("Txn(Bank)"), BANK_GATEWAY(
            "Bank/Gateway"), PAYMENT_MODE(ScheduledMerchantReportPaytmColumnNameConstants.PAYMENT_MODE), AUTH_CODE(
            "AuthCode"), RRN("RRN"), RESPONSE_CODE(ScheduledMerchantReportPaytmColumnNameConstants.RESPONSE_CODE), RAISED_ON(
            "Raised Date"), RAISED_BY("Raised By"), BANK_NAME("Bank Name"), TXN_AMOUNT(
            ScheduledMerchantReportPaytmColumnNameConstants.TXN_AMOUNT), TXN_DATE_STR("TXN_DATE_STR"), FILE_NAME(
            "FILE_NAME"), TOTAL_AMOUNT(ScheduledMerchantReportPaytmColumnNameConstants.TOTAL_AMOUNT), PRODUCT_CODE(
            "PRODUCT_CODE"), REF_TXN_ID("REF_TXN_ID"), BASE_AMT(
            ScheduledMerchantReportPaytmColumnNameConstants.BASE_AMT), ALI_MID(
            ScheduledMerchantReportPaytmColumnNameConstants.ALI_MID), M_ID(
            ScheduledMerchantReportPaytmColumnNameConstants.M_ID), INVOICE_ID("Invoice ID"), CHARGEBACK_AMT(
            ScheduledMerchantReportPaytmColumnNameConstants.CHARGEBACK_AMT), ISSUING_BANK("IssuingBank"), CB_RAISED_BY(
            "CB_RAISED_BY"), CB_RAISED_ON("CB Raised On"), REASON("Reason"), DUE_DATE("Due Date"), AUTHORISED_BY(
            "Authorized By"), DISPUTE_EXTEND_INFO("DISPUTE_EXTEND_INFO"), AGGREGATOR("AGGREGATOR"), RECON_ID("RECON_ID"), SETTLED_AMT(
            ScheduledMerchantReportPaytmColumnNameConstants.SETTLED_AMT), TXN_TYPE(
            ScheduledMerchantReportPaytmColumnNameConstants.TXN_TYPE), EXT_SERIAL_NO("EXT_SERIAL_NO"), SETTLEMENT_ORDER_ID(
            "SETTLEMENT_ORDER_ID"), BILL_DATE("BILL_DATE"), SETTLE_STATUS("SETTLE_STATUS"), SETTLE_TXN_TYPE(
            "SETTLE_TXN_TYPE"), ARN("ARN"), VALIDATE_TIME("PRN ValidateTime"), PRN_CODE("PRN"), POS_ORDER_ID(
            "Merchant PosOrderId"), IS_VALIDATE("PRN Validated"), TOTAL_REFUND_AMT("totalRefundAmt"), WITHDRAW_MODE(
            "withdrawMode"), IS_CANCEL("isCancel"), TOTAL_CANCEL_AMOUNT(
            ScheduledMerchantReportPaytmColumnNameConstants.TOTAL_CANCEL_AMOUNT), TOTAL_CANCEL_MERCHANT_COMMISSION(
            "totalCancelMerchantCommission"), TOTAL_CANCEL_SERVICE_TAX("totalCancelServiceTax"), TOTAL_REFUND_MERCHANT_COMMISSION(
            "totalRefundMerchantCommission"), TOTAL_REFUND_SERVICE_TAX("totalRefundServiceTax"), HOLD_REASON(
            "holdReason"), HOLD_STATUS("holdStatus"), HOLD_TIME("holdTime"), UNHOLD_TIME("unHoldTime"), RISK_INFO(
            "RISKINFO"), PAYMENT_STATUS("PaymentStatus"), IS_CB_RAISED("IsCbRaised"), SUB_ORDER_STATUS("SubOrderStatus"), SETTLEMENT_PAYMENT_COUNT(
            "SettlementPaymentCount"), SETTLEMENT_REFUND_COUNT("SettlementRefundCount"), SETTLEMENT_CHARGEBACK_COUNT(
            "SettlementChargebackCount"), SETTLEMENT_PAYMENT_AMOUNT("SettlementPaymentAmount"), SETTLEMENT_REFUND_AMOUNT(
            "SettlementRefundAmount"), SETTLEMENT_CHARGEBACK_AMOUNT("SettlementChargebackAmount"), EXT_EMAIL("Email"), EXT_PHONE(
            "Phone No"), PAYTM_TXN_ID("Paytm TxnId"), ACCOUNT_NAME("AccountName"), ACCOUNT_NO("AccountNo"), ADDITIONAL_COMMENT(
            "additionalComment"), SUB_MERCHANT_NAME("subMerchantName"), ADD_AND_PAY_TYPE("addAndPayType"), LINK_DESCRIPTION(
            "linkDescription"), USER_NAME("userName"), USER_VPA("userVPA"), MASKED_CARD_NO("maskedCardNo"), USER_MOBILE(
            "userMobile"), USER_EMAIL("userEmail"), LOYALITY_POINT("loyalityPoint"), EXCHANGE_RATE("exchangeRate"), BANK_RESPONSE_CODE(
            "bankResponseCode"), BANK_RESPONSE_MESSAGE("bankResponseMessage"), IMPS_ACCOUNT_NO("impsAccountNo"), ACCOUNT_HOLDER_NAME(
            "acountHolderName"), BANK_TID("bankTid"), CANCEL_REQUEST_TYPE("cancelRequestType"), DISPUTE_ID("disputeId"),
            NARRATION("NARRATION"),PAYOUT_MODE("PAYOUT_MODE"),BRANCH_CODE("extraParamsMap.AdditionalInfo2"),CASE_ID("extraParamsMap.AdditionalInfo1"),
            CHARGES("CHARGES"),SERVICE_TAX("SERVICE_TAX"),SURCHARGE("SURCHARGE"),TDS("TDS");

    private String columnName;

    ScheduledMerchantReportPaytmColumnName(String columnName) {
        this.columnName = columnName;
    }

    @Override
    public String getColumnName() {
        return columnName;
    }

    private static final Map<String, ScheduledMerchantReportPaytmColumnName> LOOKUP = Maps.uniqueIndex(
            Arrays.asList(ScheduledMerchantReportPaytmColumnName.values()),
            ScheduledMerchantReportPaytmColumnName::getColumnName);

    @Nullable
    public static ScheduledMerchantReportPaytmColumnName fromColumnName(String columnName) {
        return LOOKUP.get(columnName);
    }
}
