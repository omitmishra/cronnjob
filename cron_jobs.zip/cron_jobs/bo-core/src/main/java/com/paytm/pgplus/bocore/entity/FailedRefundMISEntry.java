package com.paytm.pgplus.bocore.entity;

import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.Entity;

/**
 * Created by ishasinghal on 31/7/17.
 */
@Setter
@Getter
public class FailedRefundMISEntry {

    Logger LOGGER = LoggerFactory.getLogger(FailedRefundMISEntry.class);

    public FailedRefundMISEntry(String line) {
        LOGGER.info("Processing entry {}", line);

        try {

            if (line != null && !line.isEmpty()) {
                String[] vals = line.split(",");
                if (vals != null) {
                    LOGGER.info("Total number of vals {}", vals.length);

                    if (vals.length >= 1) {
                        this.merchantCode = vals[0].trim();
                    }

                    if (vals.length >= 2) {
                        this.txnDate = vals[1].trim();
                    }

                    if (vals.length >= 3) {
                        this.txnAmount = vals[2].trim();
                    }

                    if (vals.length >= 4) {
                        this.refundDate = vals[3].trim();
                    }

                    if (vals.length >= 5) {
                        this.refundAmount = vals[4].trim();
                    }

                    if (vals.length >= 6) {
                        this.orderId = vals[5].trim();
                    }

                    if (vals.length >= 7) {
                        this.bankTxnId = vals[6].trim();
                    }

                    if (vals.length >= 8) {
                        this.neftNo = vals[7].trim();
                    }

                    if (vals.length >= 9) {
                        this.RRN = vals[8].trim();
                    }

                    if (vals.length >= 10) {
                        this.status = vals[9].trim();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception while setting constructor FailesMISEntry", e);
        }
    }

    private String merchantCode;
    private String txnDate;
    private String txnAmount;
    private String refundDate;
    private String refundAmount;
    private String orderId;
    private String bankTxnId;
    private String neftNo;
    private String RRN;
    private String status;

    @Override
    public String toString() {
        return "FailedRefundMISEntry{" + "merchantCode='" + merchantCode + '\'' + ", txnDate='" + txnDate + '\''
                + ", txnAmount='" + txnAmount + '\'' + ", refundDate='" + refundDate + '\'' + ", refundAmount='"
                + refundAmount + '\'' + ", orderId='" + orderId + '\'' + ", bankTxnId='" + bankTxnId + '\''
                + ", neftNo='" + neftNo + '\'' + ", RRN='" + RRN + '\'' + ", status='" + status + '\'' + '}';
    }
}
