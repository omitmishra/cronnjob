package com.paytm.pglpus.bocore.model;

import lombok.Data;

/**
 * Created by dheeraj on 24/01/18.
 */

@Data
public class NewZabbixMonitor {

    Long id;

    String monitoringScope;

    String idList;

    Long teamId;

    String remark;
}
