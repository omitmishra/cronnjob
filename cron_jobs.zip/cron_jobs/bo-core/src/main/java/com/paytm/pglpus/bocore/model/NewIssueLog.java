package com.paytm.pglpus.bocore.model;

import lombok.Data;

/**
 * Created by dheeraj on 15/11/17.
 */

@Data
public class NewIssueLog {
    long issueId;
    String comment;
    long teamMemberId;

}
