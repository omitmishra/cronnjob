package com.paytm.pgplus.bocore.dao;

import com.paytm.pgplus.bocore.entity.jpa.OnlineSettlementReversal;

import java.sql.Timestamp;
import java.util.List;

public interface IOnlineSettlementReversalDao {

    OnlineSettlementReversal addUpdateOnlineSettlementReversalTable(OnlineSettlementReversal onlineSettlementReversal);

    List<OnlineSettlementReversal> addUpdateOnlineSettlementReversalTables(
            List<OnlineSettlementReversal> onlineSettlementReversal);

    List<OnlineSettlementReversal> findByPayoutIdList(List<String> payoutId);

    List<OnlineSettlementReversal> findByPayoutIdListAndUtrStatus(List<String> payoutId, String utrStatus);

    List<OnlineSettlementReversal> findAllByUpdatedOnBetweenAndUtrStatusAndNewUTRNotNull(

    Timestamp updatedOnFrom, Timestamp updatedOnTo, String utrStatus);

}
