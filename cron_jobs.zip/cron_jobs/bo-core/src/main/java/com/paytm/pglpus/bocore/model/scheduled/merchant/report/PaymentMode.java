package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

public enum PaymentMode {

    ATM, BC, CC, DC, EDC, EMI_DC, NB, UPI;
}
