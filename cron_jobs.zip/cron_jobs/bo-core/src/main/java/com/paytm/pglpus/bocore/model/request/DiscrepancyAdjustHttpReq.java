package com.paytm.pglpus.bocore.model.request;

public class DiscrepancyAdjustHttpReq {
    private Long requestId;
    private Long id;
    private String mid;
    private String discrepancyType;
    private String adjustmentValue;
    private String action;
    private String comments;
    private String discrepancyOriginatedFrom;
    private String boOperatorName;
    private String requestSource;

    public DiscrepancyAdjustHttpReq() {
        super();
    }

    public DiscrepancyAdjustHttpReq(Long requestId, Long id, String mid, String discrepancyType,
            String adjustmentValue, String action, String comments, String discrepancyOriginatedFrom,
            String boOperatorName) {
        super();
        this.requestId = requestId;
        this.id = id;
        this.mid = mid;
        this.discrepancyType = discrepancyType;
        this.adjustmentValue = adjustmentValue;
        this.action = action;
        this.comments = comments;
        this.discrepancyOriginatedFrom = discrepancyOriginatedFrom;
        this.boOperatorName = boOperatorName;
    }

    public DiscrepancyAdjustHttpReq(Long id, String mid, String discrepancyType, String adjustmentValue) {
        super();
        this.id = id;
        this.mid = mid;
        this.discrepancyType = discrepancyType;
        this.adjustmentValue = adjustmentValue;
        this.action = "SETTLED";
        this.comments = "Settled through BO API";
        this.discrepancyOriginatedFrom = "PG-Plus";
        this.boOperatorName = "API";
    }

    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getDiscrepancyType() {
        return discrepancyType;
    }

    public void setDiscrepancyType(String discrepancyType) {
        this.discrepancyType = discrepancyType;
    }

    public String getAdjustmentValue() {
        return adjustmentValue;
    }

    public void setAdjustmentValue(String adjustmentValue) {
        this.adjustmentValue = adjustmentValue;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getDiscrepancyOriginatedFrom() {
        return discrepancyOriginatedFrom;
    }

    public void setDiscrepancyOriginatedFrom(String discrepancyOriginatedFrom) {
        this.discrepancyOriginatedFrom = discrepancyOriginatedFrom;
    }

    public String getBoOperatorName() {
        return boOperatorName;
    }

    public void setBoOperatorName(String boOperatorName) {
        this.boOperatorName = boOperatorName;
    }

    public String getRequestSource() {
        return requestSource;
    }

    public void setRequestSource(String requestSource) {
        this.requestSource = requestSource;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DiscrepancyAdjustHttpReq [requestId=").append(requestId).append(", id=").append(id)
                .append(", mid=").append(mid).append(", discrepancyType=").append(discrepancyType)
                .append(", adjustmentValue=").append(adjustmentValue).append(", action=").append(action)
                .append(", comments=").append(comments).append(", discrepancyOriginatedFrom=")
                .append(discrepancyOriginatedFrom).append(", boOperatorName=").append(boOperatorName)
                .append(", requestSource=").append(requestSource).append("]");
        return builder.toString();
    }

}
