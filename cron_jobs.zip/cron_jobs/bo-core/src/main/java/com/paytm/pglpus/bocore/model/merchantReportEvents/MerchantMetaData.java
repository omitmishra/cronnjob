package com.paytm.pglpus.bocore.model.merchantReportEvents;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantMetaData {
    boolean isCreateChildEvents;
}
