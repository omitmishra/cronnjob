package com.paytm.pglpus.bocore.model.request;

import lombok.Data;

import java.io.Serializable;

@Data
public class BulkPodUploadAndCBCloseConsumerPayload implements Serializable {

    String proofUploadDate;
    String lotName;
}
