package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.paytm.pgplus.bocore.constants.Constants;

/**
 * Hibernate entity class This class responsible for hibernate entity to table
 * mapping
 * 
 * @author Kulbhushan Pandey
 * @date 6 March 2016
 */
@Entity
@Table(name = "FORMATTER_DETAILS")
public class BankFormattorDetails implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "BANK_CODE", length = 20)
    private String bankCode;

    @Column(name = "PAY_METHOD", length = 20)
    private String payMethod;

    @Column(name = "FORMATTER_NAME")
    private String formatterName;

    @Column(name = "STATUS")
    private Boolean status;

    @Column(name = "REFUND_TYPE", length = 3)
    private Boolean refundType;

    @Column(name = "UPDATED_BY", length = 64)
    private Long updatedBy;

    @Column(name = "CREATED_BY")
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_ON")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_PATTERN, timezone = Constants.TIME_ZONE)
    private Date createdOn;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATED_ON")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_PATTERN, timezone = Constants.TIME_ZONE)
    private Date updatedOn;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getPayMethod() {
        return payMethod;
    }

    public void setPayMethod(String payMethod) {
        this.payMethod = payMethod;
    }

    public String getFormatterName() {
        return formatterName;
    }

    public void setFormatterName(String formatterName) {
        this.formatterName = formatterName;
    }

    public Boolean getStatus() {
        return status;
    }

    public void setStatus(Boolean status) {
        this.status = status;
    }

    public Boolean getRefundType() {
        return refundType;
    }

    public void setRefundType(Boolean refundType) {
        this.refundType = refundType;
    }

    public Long getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(Long updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    @Override
    public String toString() {
        return "BankFormattorDetails [id=" + id + ", bankCode=" + bankCode + ", payMethod=" + payMethod
                + ", formatterName=" + formatterName + ", status=" + status + ", refundType=" + refundType
                + ", updatedBy=" + updatedBy + ", createdBy=" + createdBy + ", createdOn=" + createdOn + ", updatedOn="
                + updatedOn + "]";
    }

}
