package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.constants.BulkPodUploadReportColumns;
import com.paytm.pgplus.bocore.entity.BaseEntity;
import com.paytm.pgplus.facade.enums.EnumCurrency;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.file.util.annotation.CsvColumnMapper;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "bulk_pod_upload_result")
@Data
public class BulkPodUploadResult extends BaseEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @CsvColumnMapper(columnName = BulkPodUploadReportColumns.ACQUIRING_REF_NUM)
    @Column(name = "acquiring_ref_num")
    private String acquiringRefNum;

    @CsvColumnMapper(columnName = BulkPodUploadReportColumns.STATUS)
    @Column(name = "result_status")
    private String resultStatus;

    @CsvColumnMapper(columnName = BulkPodUploadReportColumns.STATUS_MESSAGE)
    @Column(name = "result_msg")
    private String resultMsg;

    @CsvColumnMapper(columnName = BulkPodUploadReportColumns.PROOF_UPLOAD_DATE)
    @Column(name = "proof_upload_date")
    private String proofUploadDate;

    @CsvColumnMapper(columnName = BulkPodUploadReportColumns.LOT_NAME)
    @Column(name = "lot_name")
    private String lotName;

}
