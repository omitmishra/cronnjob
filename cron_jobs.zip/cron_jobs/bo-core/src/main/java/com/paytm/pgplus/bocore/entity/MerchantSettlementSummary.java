package com.paytm.pgplus.bocore.entity;

import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import lombok.*;
import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Objects;

/**
 * @author Himanshu Sardana
 * @since 5 Oct 2016
 */
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "merchant_settlement_report_file_details")
@NamedQueries({
        @NamedQuery(name = "MerchantSettlementSummary.findAllMerchantIdsForDate", query = "SELECT DISTINCT(m.merchantId) FROM MerchantSettlementSummary m WHERE m.fileSource = :fileSource AND m.totalRecords > 0 AND m.statusCode != :statusCode AND m.createdOn >= :createdOnStart AND m.createdOn <= :createdOnEnd"),
        @NamedQuery(name = "MerchantSettlementSummary.findAllMerchantSummaryForMID", query = "SELECT m FROM MerchantSettlementSummary m WHERE m.merchantId  = :merchantId AND m.totalRecords > 0 AND m.statusCode != :statusCode AND m.createdOn >= :createdOnStart AND m.createdOn <= :createdOnEnd ORDER BY m.reportType"),
        @NamedQuery(name = "MerchantSettlementSummary.findByFileName", query = "SELECT m FROM MerchantSettlementSummary m WHERE m.fileName =:fileName"),
        @NamedQuery(name = "MerchantSettlementSummary.findByPgPayoutId", query = "SELECT m FROM MerchantSettlementSummary m WHERE m.payoutId =:payoutId"),
        @NamedQuery(name = "MerchantSettlementSummary.findByMidAndPayoutIdAndReportType", query = "SELECT m FROM MerchantSettlementSummary m WHERE m.merchantId = :merchantId and m.payoutId = :payoutId and m.reportType = :reportType"),
        @NamedQuery(name = "MerchantSettlementSummary.findByWalletPayoutId", query = "SELECT m FROM MerchantSettlementSummary m WHERE m.walletPayoutId =:payoutId"),
        @NamedQuery(name = "MerchantSettlementSummary.findPendingReports", query = "SELECT m FROM MerchantSettlementSummary m WHERE m.fileSource =:fileSource AND m.createdOn < :createdOn"),
        @NamedQuery(name = "MerchantSettlementSummary.findPendingReportsGroupByStatusAndCreationDate", query = "SELECT m.status, min(m.createdOn), COUNT(m) FROM MerchantSettlementSummary m WHERE m.fileSource =:fileSource AND m.createdOn < :createdOn group by m.status, DATE(m.createdOn)")

})
public class MerchantSettlementSummary extends BaseEntity {

    /**
     *
     */
    private static final long serialVersionUID = 1236392017472976522L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "file_path")
    private String filePath;

    @Column(name = "utr")
    private String utr;

    @Column(name = "payout_id")
    private String payoutId;

    @Column(name = "wallet_utr")
    private String walletUtr;

    @Column(name = "wallet_payout_id")
    private String walletPayoutId;

    @Column(name = "file_source")
    private String fileSource;

    @Column(name = "total_records")
    private Long totalRecords;

    @Column(name = "success_records")
    private Long successRecords;

    @Column(name = "mid")
    private String merchantId;

    @Column(name = "payout_date")
    private Date payoutDate;

    @Column(name = "report_type")
    @Enumerated(EnumType.STRING)
    private MerchantSettlementReportType reportType;

    @Column(name = "total_amount")
    private BigDecimal totalAmount;

    @Column(name = "transaction_amount")
    private BigDecimal transactionAmount;

    @Column(name = "service_tax")
    private BigDecimal serviceTax;

    @Column(name = "merchant_commission")
    private BigDecimal merchantCommission;

    @Column(name = "status_code")
    private Short statusCode;

    @Column(name = "status")
    private String status;

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        MerchantSettlementSummary summary = (MerchantSettlementSummary) o;
        return Objects.equals(payoutId, summary.payoutId) && Objects.equals(merchantId, summary.merchantId)
                && Objects.equals(reportType, summary.reportType);
    }

    @Override
    public int hashCode() {

        return Objects.hash(payoutId, merchantId, reportType);
    }
}