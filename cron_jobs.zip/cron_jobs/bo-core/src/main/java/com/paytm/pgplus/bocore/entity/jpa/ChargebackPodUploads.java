package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "chargeback_pod_uploads")
@Getter
@Setter
public class ChargebackPodUploads extends BaseEntity implements Serializable {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "dispute_id")
    private String disputeId;

    @Column(name = "document_name")
    private String documentName;

    @Column(name = "document_id")
    private String documentId;

    @Column(name = "actor")
    private String actor;

    @Column(name = "actor_info")
    private String actorInfo;

    @Column(name = "pod_uploaded_date")
    private Date podUploadedDate;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dispute_id", nullable = false, insertable = false, updatable = false)
    private ChargeBackDetails chargeBackDetails;

}
