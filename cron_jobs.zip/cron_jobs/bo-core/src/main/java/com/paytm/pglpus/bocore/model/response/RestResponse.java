package com.paytm.pglpus.bocore.model.response;

import com.paytm.pgplus.bocore.enums.RestStatus;

/**
 * Model class This class has generic parameters for rest report response
 * 
 * @author Kulbhushan Pandey
 * @date 6 March 2016
 */
public class RestResponse {
    RestStatus status;
    Integer count;
    Object result;

    public RestResponse() {

    }

    public RestResponse(RestStatus status, Object error) {
        super();
        this.status = status;
        this.count = 0;
        this.result = error;
    }

    public RestResponse(RestStatus status, Integer count, Object result) {
        super();
        this.status = status;
        this.count = count;
        this.result = result;
    }

    public RestStatus getStatus() {
        return status;
    }

    public void setStatus(RestStatus status) {
        this.status = status;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Object getResult() {
        return result;
    }

    public void setResult(Object result) {
        this.result = result;
    }

    @Override
    public String toString() {
        return "RestResponse [status=" + status + ", count=" + count + ", result=" + result + "]";
    }

}
