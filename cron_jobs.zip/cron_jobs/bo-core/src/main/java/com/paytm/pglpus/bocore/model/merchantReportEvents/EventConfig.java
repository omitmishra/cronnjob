package com.paytm.pglpus.bocore.model.merchantReportEvents;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pglpus.bocore.model.merchantReportEvents.eventconfig.BillFileDataProcessorConfig;
import com.paytm.pglpus.bocore.model.merchantReportEvents.eventconfig.SettlementReportHttpProcessorConfig;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventConfig {
    SettlementReportHttpProcessorConfig settlementReportHttpProcessorConfig;
    BillFileDataProcessorConfig billFileDataProcessorConfig;
}
