package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.annotations.Where;
import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name = "refund_txn_details")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "PaytmAutoRefundDetails.findByOrigTxnCreatedTimeStamp", query = "SELECT o FROM PaytmAutoRefundDetails o WHERE o.refundCreationTime > :from and o.refundCreationTime <= :to and refundTxnSource = 'AUTO'") })
public class PaytmAutoRefundDetails implements Serializable {
    private static final long serialVersionUID = -8653258888550021911L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "refund_ext_serial_num", length = 20)
    private String refundExtSerialNum;

    @Column(name = "orig_ext_serial_num")
    private String origExtSerialNum;

    @Column(name = "refund_amount")
    private BigDecimal refundAmount;

    @Column(name = "orig_txn_amount")
    private BigDecimal origTxnAmount;

    @Column(name = "bank_code", length = 20)
    private String bankCode;

    @Column(name = "bank_reference_number", length = 32)
    private String bankReferenceNumber;

    @Column(name = "status_code", length = 20)
    private Integer statusCode;

    @Column(name = "status_message", length = 32)
    private String statusMessage;

    @Column(name = "refund_txn_source", length = 20)
    private String refundTxnSource;

    @Column(name = "refund_creation_time")
    private Date refundCreationTime;

    @Column(name = "orig_txn_creation_time")
    private Date origTxnCreationTime;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_on", nullable = false)
    private Date createdOn;

    @Basic(optional = false)
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedOn;

    @Column(name = "sent_for_recon", columnDefinition = "int default 0")
    private Integer sentForRecon;

    @ManyToOne
    @JoinColumn(name = "orig_ext_serial_num", referencedColumnName = "EXTSERIAL_NO", nullable = false, updatable = false, insertable = false)
    private AutoRefundDiscrepancySettlement autoRefundDiscrepancySettlement;

    /*
     * 
     * @OneToOne
     * 
     * @JoinColumn(name = "orig_ext_serial_num", referencedColumnName =
     * "RELEASES") private AlipayPaytmMerchant alipayPaytmMerchant;
     */

    public PaytmAutoRefundDetails(RefundTxnDetails refundTxn) {
        this.refundExtSerialNum = refundTxn.getRefundExtSerialNum();
        this.origExtSerialNum = refundTxn.getOrigExtSerialNum();
        this.refundAmount = refundTxn.getRefundAmount();
        this.origTxnAmount = refundTxn.getOrigTxnAmount();
        this.bankCode = refundTxn.getBankCode();
        this.bankReferenceNumber = refundTxn.getBankReferenceNumber();
        this.statusCode = refundTxn.getStatusCode();
        this.statusMessage = refundTxn.getStatusMessage();
        this.refundTxnSource = refundTxn.getRefundTxnSource();
        this.refundCreationTime = refundTxn.getRefundCreationTime();
        this.origTxnCreationTime = refundTxn.getOrigTxnCreationTime();
        this.createdOn = refundTxn.getCreatedOn();
        this.updatedOn = refundTxn.getUpdatedOn();
    }

    public PaytmAutoRefundDetails() {
        super();
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getRefundExtSerialNum() {
        return refundExtSerialNum;
    }

    public void setRefundExtSerialNum(String refundExtSerialNum) {
        this.refundExtSerialNum = refundExtSerialNum;
    }

    public String getOrigExtSerialNum() {
        return origExtSerialNum;
    }

    public void setOrigExtSerialNum(String origExtSerialNum) {
        this.origExtSerialNum = origExtSerialNum;
    }

    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }

    public BigDecimal getOrigTxnAmount() {
        return origTxnAmount;
    }

    public void setOrigTxnAmount(BigDecimal origTxnAmount) {
        this.origTxnAmount = origTxnAmount;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankReferenceNumber() {
        return bankReferenceNumber;
    }

    public void setBankReferenceNumber(String bankReferenceNumber) {
        this.bankReferenceNumber = bankReferenceNumber;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getRefundTxnSource() {
        return refundTxnSource;
    }

    public void setRefundTxnSource(String refundTxnSource) {
        this.refundTxnSource = refundTxnSource;
    }

    public Date getRefundCreationTime() {
        return refundCreationTime;
    }

    public void setRefundCreationTime(Date refundCreationTime) {
        this.refundCreationTime = refundCreationTime;
    }

    public Date getOrigTxnCreationTime() {
        return origTxnCreationTime;
    }

    public void setOrigTxnCreationTime(Date origTxnCreationTime) {
        this.origTxnCreationTime = origTxnCreationTime;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Integer getSentForRecon() {
        return sentForRecon;
    }

    public void setSentForRecon(Integer sentForRecon) {
        this.sentForRecon = sentForRecon;
    }

    public AutoRefundDiscrepancySettlement getAutoRefundDiscrepancySettlement() {
        return autoRefundDiscrepancySettlement;
    }

    public void setAutoRefundDiscrepancySettlement(AutoRefundDiscrepancySettlement autoRefundDiscrepancySettlement) {
        this.autoRefundDiscrepancySettlement = autoRefundDiscrepancySettlement;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("PaytmAutoRefundDetails [id=");
        builder.append(id);
        builder.append(", refundExtSerialNum=");
        builder.append(refundExtSerialNum);
        builder.append(", origExtSerialNum=");
        builder.append(origExtSerialNum);
        builder.append(", refundAmount=");
        builder.append(refundAmount);
        builder.append(", origTxnAmount=");
        builder.append(origTxnAmount);
        builder.append(", bankCode=");
        builder.append(bankCode);
        builder.append(", bankReferenceNumber=");
        builder.append(bankReferenceNumber);
        builder.append(", statusCode=");
        builder.append(statusCode);
        builder.append(", statusMessage=");
        builder.append(statusMessage);
        builder.append(", refundTxnSource=");
        builder.append(refundTxnSource);
        builder.append(", refundCreationTime=");
        builder.append(refundCreationTime);
        builder.append(", origTxnCreationTime=");
        builder.append(origTxnCreationTime);
        builder.append(", createdOn=");
        builder.append(createdOn);
        builder.append(", updatedOn=");
        builder.append(updatedOn);
        builder.append(", sentForRecon=");
        builder.append(sentForRecon);
        builder.append(", autoRefundDiscrepancySettlement=");
        builder.append(autoRefundDiscrepancySettlement);
        builder.append("]");
        return builder.toString();
    }
}
