/**
 *
 */
package com.paytm.pglpus.bocore.model;

/**
 * @author rahul7.verma
 *
 */
public enum ScheduledMerchantReportFormatterType {
    MAP, DATE, AMOUNT, CONSTANT, COLUMN_PAIR, EXPRESSION, SEQUENCE, EVENT_DATE, SPLIT_VALUE, DATE_STRING, JSON;
}
