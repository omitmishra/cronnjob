package com.paytm.pglpus.bocore.model;

import lombok.Data;

import java.util.HashMap;

/**
 * Created by dheeraj on 15/11/17.
 */

@Data
public class NewIssue {
    Long id;
    String subject;
    String content;
    Integer priority;
    Long teamId;
    Long teamMemberId;
    String remark;
    String status;
    Long parentIssueId;
    Long issueTemplateId;
    String issueSource;

    HashMap<String, String> params;
}
