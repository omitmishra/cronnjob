package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "paytm_merchant")
@XmlRootElement
public class AlipayPaytmMerchant implements Serializable {
    private static final long serialVersionUID = -7252052140028259492L;

    @Basic(optional = false)
    @Column(name = "id", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Basic(optional = false)
    @Column(name = "alipay_merchant_id", length = 64, nullable = false, updatable = false)
    private String alipayMerchantId;

    @Basic(optional = false)
    @Column(name = "paytm_merchant_id", length = 64, nullable = false, updatable = false)
    private String paytmMerchantId;

    @Column(name = "alipay_merchant_wallet_id", length = 64)
    private String alipayMerchantWalletId;

    @Column(name = "paytm_merchant_wallet_id", length = 45)
    private String paytmMerchantWalletId;

    @Column(name = "merchant_type", length = 100)
    private String merchantType;

    @Column(name = "official_name", length = 300)
    private String officialName;

    @Column(name = "create_timestamp")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date createdTimestamp;

    @Column(name = "update_timestamp")
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date updateTimestamp;

    @Column(name = "updated_count", length = 64)
    private Long updatedCount;

    @Column(name = "industry_type_id", length = 64)
    private Long industryTypeId;

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AlipayPaytmMerchant [id=");
        builder.append(id);
        builder.append(", alipayMerchantId=");
        builder.append(alipayMerchantId);
        builder.append(", paytmMerchantId=");
        builder.append(paytmMerchantId);
        builder.append(", alipayMerchantWalletId=");
        builder.append(alipayMerchantWalletId);
        builder.append(", paytmMerchantWalletId=");
        builder.append(paytmMerchantWalletId);
        builder.append(", merchantType=");
        builder.append(merchantType);
        builder.append(", officialName=");
        builder.append(officialName);
        builder.append(", createdTimestamp=");
        builder.append(createdTimestamp);
        builder.append(", updateTimestamp=");
        builder.append(updateTimestamp);
        builder.append(", updatedCount=");
        builder.append(updatedCount);
        builder.append(", industryTypeId=");
        builder.append(industryTypeId);
        builder.append("]");
        return builder.toString();
    }

    public AlipayPaytmMerchant() {

    }

    public AlipayPaytmMerchant(Long id, String alipayMerchantId, String paytmMerchantId, String alipayMerchantWalletId,
            String paytmMerchantWalletId, String merchantType, String officialName, Date createdTimestamp,
            Date updateTimestamp, Long updatedCount, Long industryTypeId) {
        super();
        this.id = id;
        this.alipayMerchantId = alipayMerchantId;
        this.paytmMerchantId = paytmMerchantId;
        this.alipayMerchantWalletId = alipayMerchantWalletId;
        this.paytmMerchantWalletId = paytmMerchantWalletId;
        this.merchantType = merchantType;
        this.officialName = officialName;
        this.createdTimestamp = createdTimestamp;
        this.updateTimestamp = updateTimestamp;
        this.updatedCount = updatedCount;
        this.industryTypeId = industryTypeId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((paytmMerchantId == null) ? 0 : paytmMerchantId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AlipayPaytmMerchant other = (AlipayPaytmMerchant) obj;
        if (paytmMerchantId == null) {
            if (other.paytmMerchantId != null)
                return false;
        } else if (!paytmMerchantId.equals(other.paytmMerchantId))
            return false;
        return true;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAlipayMerchantId() {
        return alipayMerchantId;
    }

    public void setAlipayMerchantId(String alipayMerchantId) {
        this.alipayMerchantId = alipayMerchantId;
    }

    public String getPaytmMerchantId() {
        return paytmMerchantId;
    }

    public void setPaytmMerchantId(String paytmMerchantId) {
        this.paytmMerchantId = paytmMerchantId;
    }

    public String getAlipayMerchantWalletId() {
        return alipayMerchantWalletId;
    }

    public void setAlipayMerchantWalletId(String alipayMerchantWalletId) {
        this.alipayMerchantWalletId = alipayMerchantWalletId;
    }

    public String getPaytmMerchantWalletId() {
        return paytmMerchantWalletId;
    }

    public void setPaytmMerchantWalletId(String paytmMerchantWalletId) {
        this.paytmMerchantWalletId = paytmMerchantWalletId;
    }

    public String getMerchantType() {
        return merchantType;
    }

    public void setMerchantType(String merchantType) {
        this.merchantType = merchantType;
    }

    public String getOfficialName() {
        return officialName;
    }

    public void setOfficialName(String officialName) {
        this.officialName = officialName;
    }

    public Date getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(Date createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public Date getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(Date updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    public Long getUpdatedCount() {
        return updatedCount;
    }

    public void setUpdatedCount(Long updatedCount) {
        this.updatedCount = updatedCount;
    }

    public Long getIndustryTypeId() {
        return industryTypeId;
    }

    public void setIndustryTypeId(Long industryTypeId) {
        this.industryTypeId = industryTypeId;
    }

}
