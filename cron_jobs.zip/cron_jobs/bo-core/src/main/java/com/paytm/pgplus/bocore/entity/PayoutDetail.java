/**
 *
 */
package com.paytm.pgplus.bocore.entity;

import com.paytm.pgplus.bocore.constants.PayoutDownloadFileColumn;
import com.paytm.pgplus.bocore.enums.DataSource;
import com.paytm.pgplus.bocore.enums.MerchantSolutionType;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter;
import com.paytm.pgplus.bocore.util.csv.converter.serializer.DoubleConverter;
import com.paytm.pgplus.common.model.PayoutType;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @author riteshkumarsharma
 *
 */
@Entity
@Table(name = "payout_info")
@NamedQueries({ @NamedQuery(name = PayoutDetail.FIND_PAYOUTS, query = "SELECT p FROM PayoutDetail p WHERE p.createdOn<:startDate AND p.dataSource = :dataSource") })
public class PayoutDetail extends BaseEntity implements Serializable {
    public static final String FIND_PAYOUTS = "findPayouts";

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "payout_id")
    @CSVColumn(name = PayoutDownloadFileColumn.ENTITY_PAYOUT_ID)
    private String payoutId;

    @Column(name = "recon_id")
    @CSVColumn(name = PayoutDownloadFileColumn.RECON_ID)
    private Long reconId;

    @Column(name = "merchant_id")
    @CSVColumn(name = PayoutDownloadFileColumn.MERCHANT_ID)
    private String merchantId;

    @Column(name = "alipay_merchant_id")
    @CSVColumn(name = PayoutDownloadFileColumn.ALIPAY_MERCHANT_ID)
    private String alipayMerchantId;

    @Column(name = "bank_name")
    @CSVColumn(name = PayoutDownloadFileColumn.BANK_NAME)
    private String bankName;

    @Column(name = "merchant_name")
    @CSVColumn(name = PayoutDownloadFileColumn.MERCHANT_NAME)
    private String merchantName;

    @Column(name = "total_txn_amount")
    @CSVColumn(name = PayoutDownloadFileColumn.TOTAL_TXN_AMOUNT)
    private Double totalTxnAmount;

    @Column(name = "commission")
    @CSVColumn(name = PayoutDownloadFileColumn.COMMISSION)
    private Double commission;

    @Column(name = "service_tax")
    @CSVColumn(name = PayoutDownloadFileColumn.SERVICE_TAX)
    private Double serviceTax;

    @Column(name = "refund_amount")
    @CSVColumn(name = PayoutDownloadFileColumn.REFUND_AMOUNT)
    private Double refundAmount;

    @Column(name = "charge_back_amount")
    @CSVColumn(name = PayoutDownloadFileColumn.CHARGEBACK_AMOUNT)
    private Double chargeBackAmount;

    @Column(name = "convenience_fee")
    @CSVColumn(name = PayoutDownloadFileColumn.CONVENIENCE_FEE)
    private Double convenienceFee;

    @Column(name = "pre_net_settle_amount")
    @CSVColumn(name = PayoutDownloadFileColumn.PRE_NET_SETTLE_AMOUNT)
    private Double preNetSettleAmount;

    @Column(name = "net_amount")
    @CSVColumn(name = PayoutDownloadFileColumn.NET_AMOUNT)
    private Double netAmount;

    @Column(name = "payout_amount")
    @CSVColumn(name = PayoutDownloadFileColumn.PAYOUT_AMOUNT, objectValueConverterClass = DoubleConverter.class, objectValueConvertorFormat = "############.####")
    private Double payoutAmount;

    @Column(name = "payout_date")
    @CSVColumn(name = PayoutDownloadFileColumn.PAYOUT_DATE)
    private Date payoutDate;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "data_source")
    @Enumerated(EnumType.STRING)
    private DataSource dataSource;

    @Column(name = "payout_computation_status")
    private Integer payoutComputationStatus;

    @Column(name = "payment_cnt")
    private Integer paymentCnt;

    @Column(name = "refund_cnt")
    @CSVColumn(name = PayoutDownloadFileColumn.REFUND_COUNT)
    private Integer refundCnt;

    @Column(name = "chargeback_cnt")
    @CSVColumn(name = PayoutDownloadFileColumn.CHARGEBACK_COUNT)
    private Integer chargebackCnt;

    @Column(name = "utr")
    @CSVColumn(name = PayoutDownloadFileColumn.UTR)
    private String utr;

    @Column(name = "payout_status")
    @CSVColumn(name = PayoutDownloadFileColumn.PAYOUT_STATUS)
    private String payoutStatus;

    @Column(name = "utr_upload_time")
    @CSVColumn(name = PayoutDownloadFileColumn.UTR_UPLOAD_TIME, objectValueConverterClass = DateConverter.class, objectValueConvertorFormat = "dd/MM/yyyy")
    private Date utrUploadTime;

    @Column(name = "utr_status")
    private String utrStatus;

    @Column(name = "settlement_status")
    private String settlementStatus;

    @Column(name = "cancel_amount")
    @CSVColumn(name = PayoutDownloadFileColumn.CANCEL_AMOUNT)
    private Double cancelAmount;

    @Column(name = "cancel_merchant_commission")
    @CSVColumn(name = PayoutDownloadFileColumn.CANCEL_COMMISSION)
    private Double cancelCommission;

    @Column(name = "cancel_service_tax")
    @CSVColumn(name = PayoutDownloadFileColumn.CANCEL_SERVICE_TAX)
    private Double cancelServiceTax;

    @Column(name = "cancel_cnt")
    private Integer cancelCnt;

    @Column(name = "refund_merchant_commission")
    private Double refundMerchantCommission;

    @Column(name = "refund_service_tax")
    private Double refundServiceTax;

    @Column(name = "isMFMerchant")
    private boolean isMFMerchant;

    @Column(name = "utr_insert_date")
    private Date utrInsertDate;

    @Column(name = "payoutType")
    @Enumerated(EnumType.STRING)
    private PayoutType payoutType;

    @Column(name = "cash_recharge")
    @CSVColumn(name = PayoutDownloadFileColumn.CASH_RECHARGE)
    private Double cashRecharge;

    @Column(name = "cash_recharge_reverse")
    @CSVColumn(name = PayoutDownloadFileColumn.CASH_RECHARGE_REVERSE)
    private Double cashRechargeReverse;

    @CSVColumn(name = PayoutDownloadFileColumn.MERCHANT_SOLUTION_TYPE)
    @Column(name = "merchant_solution_type")
    @Enumerated(EnumType.STRING)
    private MerchantSolutionType merchantSolutionType;

    public PayoutDetail() {
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getPayoutId() {
        return payoutId;
    }

    public void setPayoutId(String payoutId) {
        this.payoutId = payoutId;
    }

    public Long getReconId() {
        return reconId;
    }

    public void setReconId(Long reconId) {
        this.reconId = reconId;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getAlipayMerchantId() {
        return alipayMerchantId;
    }

    public void setAlipayMerchantId(String alipayMerchantId) {
        this.alipayMerchantId = alipayMerchantId;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public Double getTotalTxnAmount() {
        return totalTxnAmount;
    }

    public void setTotalTxnAmount(Double totalTxnAmount) {
        this.totalTxnAmount = totalTxnAmount;
    }

    public Double getCommission() {
        return commission;
    }

    public void setCommission(Double commission) {
        this.commission = commission;
    }

    public Double getServiceTax() {
        return serviceTax;
    }

    public String getUtrStatus() {
        return utrStatus;
    }

    public void setUtrStatus(String utrStatus) {
        this.utrStatus = utrStatus;
    }

    public void setServiceTax(Double serviceTax) {
        this.serviceTax = serviceTax;
    }

    public Double getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(Double refundAmount) {
        this.refundAmount = refundAmount;
    }

    public Double getChargeBackAmount() {
        return chargeBackAmount;
    }

    public void setChargeBackAmount(Double chargeBackAmount) {
        this.chargeBackAmount = chargeBackAmount;
    }

    public Double getConvenienceFee() {
        return convenienceFee;
    }

    public void setConvenienceFee(Double convenienceFee) {
        this.convenienceFee = convenienceFee;
    }

    public Double getPreNetSettleAmount() {
        return preNetSettleAmount;
    }

    public void setPreNetSettleAmount(Double preNetSettleAmount) {
        this.preNetSettleAmount = preNetSettleAmount;
    }

    public Double getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(Double netAmount) {
        this.netAmount = netAmount;
    }

    public Double getPayoutAmount() {
        return payoutAmount;
    }

    public void setPayoutAmount(Double payoutAmount) {
        this.payoutAmount = payoutAmount;
    }

    public Date getPayoutDate() {
        return payoutDate;
    }

    public void setPayoutDate(Date payoutDate) {
        this.payoutDate = payoutDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Integer getPayoutComputationStatus() {
        return payoutComputationStatus;
    }

    public void setPayoutComputationStatus(Integer payoutComputationStatus) {
        this.payoutComputationStatus = payoutComputationStatus;
    }

    public Integer getPaymentCnt() {
        return paymentCnt;
    }

    public void setPaymentCnt(Integer paymentCnt) {
        this.paymentCnt = paymentCnt;
    }

    public Integer getRefundCnt() {
        return refundCnt;
    }

    public void setRefundCnt(Integer refundCnt) {
        this.refundCnt = refundCnt;
    }

    public Integer getChargebackCnt() {
        return chargebackCnt;
    }

    public void setChargebackCnt(Integer chargebackCnt) {
        this.chargebackCnt = chargebackCnt;
    }

    public String getUtr() {
        return utr;
    }

    public void setUtr(String utr) {
        this.utr = utr;
    }

    public String getPayoutStatus() {
        return payoutStatus;
    }

    public void setPayoutStatus(String payoutStatus) {
        this.payoutStatus = payoutStatus;
    }

    public String getSettlementStatus() {
        return settlementStatus;
    }

    public void setSettlementStatus(String settlementStatus) {
        this.settlementStatus = settlementStatus;
    }

    public Double getCancelAmount() {
        return cancelAmount;
    }

    public void setCancelAmount(Double cancelAmount) {
        this.cancelAmount = cancelAmount;
    }

    public Double getCancelCommission() {
        return cancelCommission;
    }

    public void setCancelCommission(Double cancelCommission) {
        this.cancelCommission = cancelCommission;
    }

    public Double getCancelServiceTax() {
        return cancelServiceTax;
    }

    public void setCancelServiceTax(Double cancelServiceTax) {
        this.cancelServiceTax = cancelServiceTax;
    }

    public Double getRefundMerchantCommission() {
        return refundMerchantCommission;
    }

    public void setRefundMerchantCommission(Double refundMerchantCommission) {
        this.refundMerchantCommission = refundMerchantCommission;
    }

    public Integer getCancelCnt() {
        return cancelCnt;
    }

    public void setCancelCnt(Integer cancelCnt) {
        this.cancelCnt = cancelCnt;
    }

    public Double getRefundServiceTax() {
        return refundServiceTax;
    }

    public void setRefundServiceTax(Double refundServiceTax) {
        this.refundServiceTax = refundServiceTax;
    }

    public boolean isMFMerchant() {
        return isMFMerchant;
    }

    public void setMFMerchant(boolean MFMerchant) {
        isMFMerchant = MFMerchant;
    }

    public Date getUtrInsertDate() {
        return utrInsertDate;
    }

    public void setUtrInsertDate(Date utrInsertDate) {
        this.utrInsertDate = utrInsertDate;
    }

    public PayoutType getPayoutType() {
        return payoutType;
    }

    public void setPayoutType(PayoutType payoutType) {
        this.payoutType = payoutType;
    }

    public Double getCashRecharge() {
        return cashRecharge;
    }

    public void setCashRecharge(Double cashRecharge) {
        this.cashRecharge = cashRecharge;
    }

    public Double getCashRechargeReverse() {
        return cashRechargeReverse;
    }

    public MerchantSolutionType getMerchantSolutionType() {
        return merchantSolutionType;
    }

    public void setMerchantSolutionType(MerchantSolutionType merchantSolutionType) {
        this.merchantSolutionType = merchantSolutionType;
    }

    public void setCashRechargeReverse(Double cashRechargeReverse) {
        this.cashRechargeReverse = cashRechargeReverse;
    }

    @Override
    public String toString() {
        return "PayoutDetail{" + "createdOn=" + createdOn + ", updatedOn=" + updatedOn + ", payoutId='" + payoutId
                + '\'' + ", reconId=" + reconId + ", merchantId='" + merchantId + '\'' + ", alipayMerchantId='"
                + alipayMerchantId + '\'' + ", bankName='" + bankName + '\'' + ", merchantName='" + merchantName + '\''
                + ", totalTxnAmount=" + totalTxnAmount + ", commission=" + commission + ", serviceTax=" + serviceTax
                + ", refundAmount=" + refundAmount + ", chargeBackAmount=" + chargeBackAmount + ", convenienceFee="
                + convenienceFee + ", preNetSettleAmount=" + preNetSettleAmount + ", netAmount=" + netAmount
                + ", payoutAmount=" + payoutAmount + ", payoutDate=" + payoutDate + ", fileName='" + fileName + '\''
                + ", dataSource=" + dataSource + ", payoutComputationStatus=" + payoutComputationStatus
                + ", paymentCnt=" + paymentCnt + ", refundCnt=" + refundCnt + ", chargebackCnt=" + chargebackCnt
                + ", utr='" + utr + '\'' + ", payoutStatus='" + payoutStatus + '\'' + ", utrUploadTime="
                + utrUploadTime + '\'' + ", utrStatus='" + utrStatus + '\'' + ", settlementStatus=" + settlementStatus
                + '\'' + ", utrInsertDate=" + utrInsertDate + ", payoutType=" + payoutType + ", cashRechargeReverse="
                + cashRechargeReverse + ", cashRecharge=" + cashRecharge + '}';
    }

    public Date getUtrUploadTime() {
        return utrUploadTime;
    }

    public void setUtrUploadTime(Date utrUploadTime) {
        this.utrUploadTime = utrUploadTime;
    }

    public PayoutDetail(String payoutId, Long reconId, String merchantId, String alipayMerchantId, String bankName,
            String merchantName, Double totalTxnAmount, Double commission, Double serviceTax, Double refundAmount,
            Double chargeBackAmount, Double convenienceFee, Double preNetSettleAmount, Double netAmount,
            Double payoutAmount, Date payoutDate, String fileName, DataSource dataSource,
            Integer payoutComputationStatus, Integer paymentCnt, Integer refundCnt, Integer chargebackCnt, String utr,
            String payoutStatus, Date utrUploadTime, String utrStatus, Date utrInsertDate, PayoutType payoutType,
            Double cashRecharge, Double cashRechargeReverse, MerchantSolutionType merchantSolutionType) {

        this.payoutId = payoutId;
        this.reconId = reconId;
        this.merchantId = merchantId;
        this.alipayMerchantId = alipayMerchantId;
        this.bankName = bankName;

        this.merchantName = merchantName;
        this.totalTxnAmount = totalTxnAmount;
        this.commission = commission;
        this.serviceTax = serviceTax;
        this.refundAmount = refundAmount;
        this.chargeBackAmount = chargeBackAmount;
        this.convenienceFee = convenienceFee;
        this.preNetSettleAmount = preNetSettleAmount;
        this.netAmount = netAmount;
        this.payoutAmount = payoutAmount;
        this.payoutDate = payoutDate;
        this.fileName = fileName;
        this.dataSource = dataSource;

        this.payoutComputationStatus = payoutComputationStatus;
        this.paymentCnt = paymentCnt;
        this.refundCnt = refundCnt;
        this.chargebackCnt = chargebackCnt;
        this.utr = utr;
        this.payoutStatus = payoutStatus;
        this.utrUploadTime = utrUploadTime;
        this.utrStatus = utrStatus;
        this.utrInsertDate = utrInsertDate;
        this.payoutType = payoutType;
        this.cashRecharge = cashRecharge;
        this.cashRechargeReverse = cashRechargeReverse;
        this.merchantSolutionType = merchantSolutionType;
    }

}