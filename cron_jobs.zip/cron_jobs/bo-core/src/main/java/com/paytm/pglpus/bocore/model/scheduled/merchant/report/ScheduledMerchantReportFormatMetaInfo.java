package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
public class ScheduledMerchantReportFormatMetaInfo implements Serializable {

    private String fileNameExtension;

    private String fileNameFormatter;

    private String columnDelimiter;

    private String columnWrapper;

    private boolean zip;

    private boolean includeHeader = true;

    private Map<String, String> columnNameToFormatterMap;

    private boolean isAutoSftp;

}
