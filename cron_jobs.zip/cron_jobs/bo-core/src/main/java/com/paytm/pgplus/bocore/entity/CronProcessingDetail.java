package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import org.hibernate.annotations.Type;

/**
 * @author himanshusardana
 *
 */
@Entity
@Table(name = "cron_processing_details")
@XmlRootElement
public class CronProcessingDetail implements Serializable {
    /**
     * generated serial version Id
     */
    private static final long serialVersionUID = -6442184448637506378L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "cron_name", length = 100)
    private String cronName;

    @Column(name = "total_no_of_files")
    private int totalNoOfFiles;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "start_time", nullable = false)
    private Date startTime;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "end_time", nullable = false)
    private Date endTime;

    @Column(name = "successful_files", length = 20)
    private int successfulFiles;

    @Column(name = "failure_files", length = 20)
    private int failureFiles;

    @Column(name = "processed_file_names")
    @Type(type = "text")
    private String processedFileNames;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_on", nullable = false)
    private Date createdOn;

    public CronProcessingDetail(String cronName, int totalCount) {
        super();
        this.cronName = cronName;
        this.startTime = new Date();
        this.totalNoOfFiles = totalCount;
    }

    public CronProcessingDetail() {
        this.startTime = new Date();
    }

    public long getId() {
        return id;
    }

    public String getCronName() {
        return cronName;
    }

    public void setCronName(String cronName) {
        this.cronName = cronName;
    }

    public int getTotalNoOfFiles() {
        return totalNoOfFiles;
    }

    public void setTotalNoOfFiles(int totalNoOfFiles) {
        this.totalNoOfFiles = totalNoOfFiles;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public int getSuccessfulFiles() {
        return successfulFiles;
    }

    public void setSuccessfulFiles(int successfulFiles) {
        this.successfulFiles = successfulFiles;
    }

    public int getFailureFiles() {
        return failureFiles;
    }

    public void setFailureFiles(int failureFiles) {
        this.failureFiles = failureFiles;
    }

    public String getProcessedFileNames() {
        return processedFileNames;
    }

    public void setProcessedFileNames(String processedFileNames) {
        this.processedFileNames = processedFileNames;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

}