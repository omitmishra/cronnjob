package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.enums.ConsolidatedCronQueue;
import lombok.Data;

import javax.persistence.*;

/**
 * Created by dheeraj on 07/02/18.
 */

@Entity
@Data
public class FileNotifierConfig {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    String configType;

    @ManyToOne
    @JoinColumn
    ScheduleConfig defaultScheduleConfig;

    @Enumerated(EnumType.STRING)
    ConsolidatedCronQueue queue;

    @Override
    public String toString() {
        return queue.getVal();
    }

}
