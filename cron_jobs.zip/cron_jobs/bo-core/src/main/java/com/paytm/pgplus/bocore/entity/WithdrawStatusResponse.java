package com.paytm.pgplus.bocore.entity;

import static com.paytm.pgplus.bocore.constants.DiscrepancyCsvFileHeadersConstant.TRANS_TYPE;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.file.util.annotation.CsvColumnMapper;

import com.paytm.pgplus.bocore.constants.DiscrepancyCsvFileHeadersConstant;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Entity
@Table(name = "standard_withdraw_response")
@XmlRootElement
public class WithdrawStatusResponse extends BaseEntity implements Serializable {
    /**
	 * 
	 */
    private static final long serialVersionUID = 5882706777523753414L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.ALIPAY_BIZ_ORDER_ID)
    @Column(name = "alipay_biz_order_id", length = 64)
    private String alipayBizOrderId;

    @Column(name = "trans_type", length = 32)
    @CsvColumnMapper(columnName = TRANS_TYPE)
    private String transType;

    @Column(name = "discrepancy_type", length = 32, nullable = false)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.DISCREPANCY_TYPE)
    private String discrepancyType;

    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.ORI_EXT_SERIAL_NO)
    @Column(name = "ori_ext_serial_no", length = 20)
    private String oriExtSerialNo;

    @Column(name = "bank_reference_no", length = 32)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.BANK_REFERENCE_NO)
    private String bankReferenceNo;

    @Column(name = "status", length = 32, nullable = false)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.STATUS)
    private String status;

    @Column(name = "trans_value_date")
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.TRANS_VALUE_DATE)
    private Date transValueDate;

    @Column(name = "last_update_date")
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.LAST_UPDATE_DATE)
    private Date lastUpdateDate;

    @Column(name = "memo", length = 1024, nullable = false)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.MEMO)
    private String memo;

    @Column(name = "fluxnet_status", length = 32)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.FLUXNET_RESULT_STATUS)
    private String fluxNetResultStatus;

    @Column(name = "fluxnet_exchange_amount")
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.FLUXNET_EXCHANGE_AMOUNT)
    private Long fluxNetExchangeAmount;

    @Column(name = "bank_mis_exchange_amount")
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.BANK_MIS_EXCHANGE_AMOUNT)
    private Long bankExchangeAmount;

    @Column(name = "exchange_amount_in_discrepancy")
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.IS_EXCHANGE_AMOUNT_IN_DISCREPANCY)
    private Boolean isExchangeDiscrepancy;

    @Column(name = "is_notified", nullable = false)
    private Boolean isNotified;

    @Column(name = "notification_sent_date", length = 20)
    private Date notificationSentDate;

}
