package com.paytm.pgplus.bocore.entity;

/**
 * Created by ishasinghal on 23/8/17.
 */
public class ManualRefundHeader {

    public static final String id = "id";
    public static final String manualRefundType = "manual_refund_type";
    public static final String bankName = "bank_name";
    public static final String mid = "mid";
    public static final String mbid = "mbid";
    public static final String txnDate = "txn_date";
    public static final String txnAmount = "txn_amount";
    public static final String paymode = "pay_mode";
    public static final String txnBankTxnId = "txn_bank_txnid";
    public static final String orderId = "orderId";
    public static final String chargingReconStatus = "charging_recon_status";
    public static final String orderStatus = "orderStatus";
    public static final String chargingEsn = "charging_esn";
    public static final String acquiringTxnId = "acquiring_txn_id";
    public static final String refundType = "refund_type";
    public static final String refundTxnId = "refund_txn_id";
    public static final String refundDate = "refund_date";
    public static final String refundAmount = "refund_amount";
    public static final String refundBankTxnId = "refund_bankTxnId";
    public static final String refundReconStatus = "refund_recon_status";
    public static final String subBizOrderType = "sub_biz_order_type";
    public static final String subOrderStatus = "sub_order_status";
    public static final String refundEsn = "refund_esn";
    public static final String refundPaymentStatus = "refund_payment_status";
    public static final String refundSettlementFileDetailsId = "refund_settlement_id";
    public static final String refundDiscrepancyId = "refund_discrepancy_id";
    public static final String chargingSettlementFileDetailsId = "charging_settlement_id";
    public static final String chargingDiscrepancyid = "charging_discrepancy_id";
    public static final String refundBankResponseCode = "refund_bank_response_code";
    public static final String refunded = "refunded";
    public static final String MANUAL_REFUND = "error_manual_refunds_";

    public static final String[] CSV_FILE_HEADER = new String[] { "id", "manualRefundType", "bankName", "mid", "mbid",
            "txnDate", "txnAmount", "payMode", "txnBankTxnid", "orderId", "chargingReconStatus", "orderStatus",
            "chargingEsn", "acquiringTxnId", "refundType", "refundTxnId", "refundDate", "refundAmount",
            "refundBankTxnId", "refundReconStatus", "subBizOrderType", "subOrderStatus", "refundEsn",
            "refundPaymentStatus", "refundSettlementId", "refundDiscrepancyId", "chargingSettlementId",
            "chargingDiscrepancyId", "refundBankResponseCode", "refunded" };
}
