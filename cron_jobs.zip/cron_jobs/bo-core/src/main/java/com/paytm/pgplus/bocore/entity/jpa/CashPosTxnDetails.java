package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.constants.EDCConstants;
import com.paytm.pgplus.bocore.entity.BaseEntity;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "CASH_POS_SETTLEMENT_TXN")
public class CashPosTxnDetails extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    @Column(name = "PAYTM_ID")
    @CSVColumn(name = EDCConstants.PedcFileColumn.PAYTM_ID)
    private String paytmId;

    @Column(name = "BANK_MID")
    @CSVColumn(name = EDCConstants.PedcFileColumn.BANK_MID)
    private String bankMid;

    @Column(name = "BANK_TID")
    @CSVColumn(name = EDCConstants.PedcFileColumn.BANK_TID)
    private String bankTid;

    @CSVColumn(name = EDCConstants.PedcFileColumn.TXN_DATE)
    private String pedcDateTime;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "TXN_DATE", nullable = false, updatable = false)
    private Date txnDate;

    @Column(name = "TXN_TYPE")
    @CSVColumn(name = EDCConstants.PedcFileColumn.TXN_TYPE)
    private String txnType;

    @Column(name = "AMOUNT")
    @CSVColumn(name = EDCConstants.PedcFileColumn.AMOUNT)
    private String amount;

    @Column(name = "RRN")
    @CSVColumn(name = EDCConstants.PedcFileColumn.RRN)
    private String rrn;

    @Column(name = "RESPONSE_CODE")
    @CSVColumn(name = EDCConstants.PedcFileColumn.RESPONSE_CODE)
    private String responseCode;

    @Column(name = "TRANS_REVERSED")
    @CSVColumn(name = EDCConstants.PedcFileColumn.TRAN_REVERSED)
    private String transReversed;

    @Column(name = "PAYMENT_MODE")
    @CSVColumn(name = EDCConstants.PedcFileColumn.PAYMENT_MODE)
    private String paymentMode;

    @Column(name = "GATEWAY")
    private String gateway;

    @Column(name = "INCENTIVE_AMOUNT")
    @CSVColumn(name = EDCConstants.PedcFileColumn.INCENTIVE_AMOUNT)
    private String incentiveAmount;

    @Column(name = "INCENTIVE_GST_AMOUNT")
    private String incentiveGstAmount;

    @Column(name = "PAYTM_EARNING")
    private String paytmEarning;

}
