package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.DownloadEventForScheduledMerchantReportEvent;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportConfig;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportEvent;
import com.paytm.pgplus.bocore.helper.DateUtil;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Data
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "reportGenerationModularity")
@JsonSubTypes({
        @JsonSubTypes.Type(value = ScheduledMerchantReportDayWiseAndContinousBasedDynamicData.class, name = "DAY_WISE_CONTINOUS"),
        @JsonSubTypes.Type(value = ScheduledMerchantReportDayWiseAndDiscreteBasedDynamicData.class, name = "DAY_WISE_DISCRETE"),
        @JsonSubTypes.Type(value = ScheduledMerchantReportDayWiseAndSameDayBasedDynamicData.class, name = "SAME_DAY"),
        @JsonSubTypes.Type(value = ScheduledMerchantReportHourWiseBasedDynamicData.class, name = "HOUR_WISE"),
        @JsonSubTypes.Type(value = ScheduledMerchantReportValidatedDayWiseAndContinousBasedDynamicData.class, name = "VALIDATED_DAY_WISE_CONTINOUS") })
public abstract class ScheduledMerchantReportModularityBasedDynamicData implements Serializable {

    private static final Logger LOGGER = LoggerFactory
            .getLogger(ScheduledMerchantReportModularityBasedDynamicData.class);

    @NotNull
    private ReportGenerationModularityForDynamicData reportGenerationModularity;

    @Min(0)
    @Max(60)
    protected int reportTriggerTimeCutoffInMinutes = 20;

    @Min(-60)
    @Max(60)
    protected int rtddDeviationEndTimeInSeconds;

    public ScheduledMerchantReportModularityBasedDynamicData(
            ReportGenerationModularityForDynamicData reportGenerationModularity) {
        this.reportGenerationModularity = reportGenerationModularity;
    }

    protected DownloadEventForScheduledMerchantReportEvent getDownloadEventForScheduledMerchantReportEvent(
            ScheduledMerchantReportEvent scheduledMerchantReportEvent, Date txnIncludedFrom, Date txnIncludedTo) {
        DownloadEventForScheduledMerchantReportEvent downloadEventForScheduledMerchantReportEvent = new DownloadEventForScheduledMerchantReportEvent();
        downloadEventForScheduledMerchantReportEvent.setScheduledMerchantReportEvent(scheduledMerchantReportEvent);
        downloadEventForScheduledMerchantReportEvent.setTxnIncludedFrom(txnIncludedFrom);
        downloadEventForScheduledMerchantReportEvent.setTxnIncludedTo(txnIncludedTo);
        return downloadEventForScheduledMerchantReportEvent;
    }

    protected ScheduledMerchantReportEvent getScheduledMerchantReportEvent(Date txnIncludedFrom, Date txnIncludedTo,
            ScheduledMerchantReportConfig scheduledMerchantReportConfig) {
        ScheduledMerchantReportEvent scheduledMerchantReportEvent = new ScheduledMerchantReportEvent();
        scheduledMerchantReportEvent.setScheduledMerchantReportConfig(scheduledMerchantReportConfig);
        List<DownloadEventForScheduledMerchantReportEvent> downloadEventsForScheduledMSREvent = new ArrayList<>();
        downloadEventsForScheduledMSREvent.add(getDownloadEventForScheduledMerchantReportEvent(
                scheduledMerchantReportEvent, txnIncludedFrom, txnIncludedTo));
        scheduledMerchantReportEvent
                .setDownloadEventForScheduledMerchantReportEvents(downloadEventsForScheduledMSREvent);
        return scheduledMerchantReportEvent;
    }

    public abstract List<ScheduledMerchantReportEvent> getScheduledMerchantReportEvents(
            ScheduledMerchantReportConfigEventInfoPayload payload);

    protected Date getReportTriggerTime(Date currentDate, Integer reportTriggerTimeInMinute) {
        Date reportTriggerTime;
        if (reportTriggerTimeInMinute != null) {
            reportTriggerTime = DateUtil.shiftDateByField(DateUtil.removeTimeFromDate(currentDate), Calendar.MINUTE,
                    reportTriggerTimeInMinute - reportTriggerTimeCutoffInMinutes);
            LOGGER.info(" Report trigger time calculated {} for reportTriggerTimeInMinute !null  ", reportTriggerTime);
        } else {
            reportTriggerTime = DateUtil.shiftDateByField(currentDate, Calendar.MINUTE,
                    -reportTriggerTimeCutoffInMinutes);
            LOGGER.info(" Report trigger time calculated {} for reportTriggerTimeInMinute == null  ", reportTriggerTime);
        }

        return reportTriggerTime;
    }

    public boolean isValid() {
        return true;
    }
}
