/**
 * 
 */
package com.paytm.pgplus.bocore.entity;

import static com.paytm.pgplus.bocore.constants.PayoutResponseFileColumn.AMOUNT;
import static com.paytm.pgplus.bocore.constants.PayoutResponseFileColumn.MID;
import static com.paytm.pgplus.bocore.constants.PayoutResponseFileColumn.ORIGINAL_MID;
import static com.paytm.pgplus.bocore.constants.PayoutResponseFileColumn.PAYOUT_ID;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.csv.CSVRecord;
import org.file.util.annotation.CsvColumnMapper;

import com.paytm.pgplus.bocore.enums.DataSource;

import lombok.NoArgsConstructor;

/**
 * @author riteshkumarsharma
 *
 */
@NoArgsConstructor
@Entity
@Table(name = "payout_details")
public class PgplusPayoutDetail extends BaseEntity implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "payout_id")
    @CsvColumnMapper(columnName = PAYOUT_ID)
    private String payoutId;

    @Column(name = "recon_id")
    private Long reconId;

    @Column(name = "merchant_id")
    @CsvColumnMapper(columnName = ORIGINAL_MID)
    private String merchantId;

    @Column(name = "alipay_merchant_id")
    @CsvColumnMapper(columnName = MID)
    private String alipayMerchantId;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "merchant_name")
    private String merchantName;

    @Column(name = "total_txn_amount")
    private Double totalTxnAmount;

    @Column(name = "commission")
    private Double commission;

    @Column(name = "service_tax")
    private Double serviceTax;

    @Column(name = "refund_amount")
    private Double refundAmount;

    @Column(name = "charge_back_amount")
    private Double chargeBackAmount;

    @Column(name = "convenience_fee")
    private Double convenienceFee;

    @Column(name = "payout_amount")
    @CsvColumnMapper(columnName = AMOUNT)
    private Double payoutAmount;

    @Column(name = "payout_date")
    private Date payoutDate;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "data_source")
    @Enumerated(EnumType.STRING)
    private DataSource dataSource;

    @Column(name = "settlement_status")
    private String settlementStatus;

    @Column(name = "payout_computation_status")
    private Integer payoutComputationStatus;

    @Transient
    private List<CSVRecord> corruptedRecords = new ArrayList<CSVRecord>();

    @ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JoinColumn(name = "master_payout_id")
    @CsvColumnMapper(isParent = true)
    private PgplusPayoutAggregate pgplusPayoutAggregate;

    @Column(name = "payment_cnt")
    private int paymentCnt;

    @Column(name = "refund_cnt")
    private int refundCnt;

    @Column(name = "chargeback_cnt")
    private int chargebackCnt;

    /**
     * @param payoutId
     * @param merchantId
     * @param bankName
     * @param merchantName
     * @param totalTxnAmount
     * @param commission
     * @param serviceTax
     * @param refundAmount
     * @param chargeBackAmount
     * @param convenienceFee
     * @param payoutAmount
     * @param utr
     * @param masterPayout
     */
    public PgplusPayoutDetail(String payoutId, String merchantId, String bankName, String merchantName,
            Double totalTxnAmount, Double commission, Double serviceTax, Double refundAmount, Double chargeBackAmount,
            Double convenienceFee, Double payoutAmount) {
        super();
        this.payoutId = payoutId;
        this.merchantId = merchantId;
        this.bankName = bankName;
        this.merchantName = merchantName;
        this.totalTxnAmount = totalTxnAmount;
        this.commission = commission;
        this.serviceTax = serviceTax;
        this.refundAmount = refundAmount;
        this.chargeBackAmount = chargeBackAmount;
        this.convenienceFee = convenienceFee;
        this.payoutAmount = payoutAmount;
    }

    /**
     * @param payoutId
     * @param merchantId
     * @param bankName
     * @param merchantName
     * @param totalTxnAmount
     * @param commission
     * @param serviceTax
     * @param refundAmount
     * @param chargeBackAmount
     * @param convenienceFee
     * @param payoutAmount
     * @param masterPayout
     */
    public PgplusPayoutDetail(String payoutId, String merchantId, String bankName, String merchantName,
            Double totalTxnAmount, Double commission, Double serviceTax, Double refundAmount, Double chargeBackAmount,
            Double convenienceFee, Double payoutAmount, Date payoutDate, String fileName, DataSource dataSource) {
        this.payoutId = payoutId;
        this.merchantId = merchantId;
        this.bankName = bankName;
        this.merchantName = merchantName;
        this.totalTxnAmount = totalTxnAmount;
        this.commission = commission;
        this.serviceTax = serviceTax;
        this.refundAmount = refundAmount;
        this.chargeBackAmount = chargeBackAmount;
        this.convenienceFee = convenienceFee;
        this.payoutAmount = payoutAmount;
        this.payoutDate = payoutDate;
        this.fileName = fileName;
        this.dataSource = dataSource;
    }

    /**
     * @return the payoutId
     */
    public String getPayoutId() {
        return payoutId;
    }

    /**
     * @param payoutId
     *            the payoutId to set
     */
    public void setPayoutId(String payoutId) {
        this.payoutId = payoutId;
    }

    /**
     * @return the merchantId
     */
    public String getMerchantId() {
        return merchantId;
    }

    /**
     * @param merchantId
     *            the merchantId to set
     */
    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    /**
     * @return the bankName
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * @param bankName
     *            the bankName to set
     */
    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    /**
     * @return the merchantName
     */
    public String getMerchantName() {
        return merchantName;
    }

    /**
     * @param merchantName
     *            the merchantName to set
     */
    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    /**
     * @return the totalTxnAmount
     */
    public Double getTotalTxnAmount() {
        return totalTxnAmount;
    }

    /**
     * @param totalTxnAmount
     *            the totalTxnAmount to set
     */
    public void setTotalTxnAmount(Double totalTxnAmount) {
        this.totalTxnAmount = totalTxnAmount;
    }

    /**
     * @return the commission
     */
    public Double getCommission() {
        return commission;
    }

    /**
     * @param commission
     *            the commission to set
     */
    public void setCommission(Double commission) {
        this.commission = commission;
    }

    /**
     * @return the serviceTax
     */
    public Double getServiceTax() {
        return serviceTax;
    }

    /**
     * @param serviceTax
     *            the serviceTax to set
     */
    public void setServiceTax(Double serviceTax) {
        this.serviceTax = serviceTax;
    }

    /**
     * @return the refundAmount
     */
    public Double getRefundAmount() {
        return refundAmount;
    }

    /**
     * @param refundAmount
     *            the refundAmount to set
     */
    public void setRefundAmount(Double refundAmount) {
        this.refundAmount = refundAmount;
    }

    /**
     * @return the chargeBackAmount
     */
    public Double getChargeBackAmount() {
        return chargeBackAmount;
    }

    /**
     * @param chargeBackAmount
     *            the chargeBackAmount to set
     */
    public void setChargeBackAmount(Double chargeBackAmount) {
        this.chargeBackAmount = chargeBackAmount;
    }

    /**
     * @return the convenienceFee
     */
    public Double getConvenienceFee() {
        return convenienceFee;
    }

    /**
     * @param convenienceFee
     *            the convenienceFee to set
     */
    public void setConvenienceFee(Double convenienceFee) {
        this.convenienceFee = convenienceFee;
    }

    /**
     * @return the payoutAmount
     */
    public Double getPayoutAmount() {
        return payoutAmount;
    }

    /**
     * @param payoutAmount
     *            the payoutAmount to set
     */
    public void setPayoutAmount(Double payoutAmount) {
        this.payoutAmount = payoutAmount;
    }

    public Date getPayoutDate() {
        return payoutDate;
    }

    public void setPayoutDate(Date payoutDate) {
        this.payoutDate = payoutDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public Long getReconId() {
        return reconId;
    }

    public void setReconId(Long reconId) {
        this.reconId = reconId;
    }

    public String getAlipayMerchantId() {
        return alipayMerchantId;
    }

    public void setAlipayMerchantId(String alipayMerchantId) {
        this.alipayMerchantId = alipayMerchantId;
    }

    public String getSettlementStatus() {
        return settlementStatus;
    }

    public void setSettlementStatus(String settlementStatus) {
        this.settlementStatus = settlementStatus;
    }

    public Integer getPayoutComputationStatus() {
        return payoutComputationStatus;
    }

    public void setPayoutComputationStatus(Integer payoutComputationStatus) {
        this.payoutComputationStatus = payoutComputationStatus;
    }

    public List<CSVRecord> getCorruptedRecords() {
        return corruptedRecords;
    }

    public void setcorruptedRecords(List<CSVRecord> corruptedReords) {
        this.corruptedRecords = corruptedReords;
    }

    /**
     * @return the pgplusPayoutAggregate
     */
    public PgplusPayoutAggregate getPgplusPayoutAggregate() {
        return pgplusPayoutAggregate;
    }

    /**
     * @param pgplusPayoutAggregate
     *            the pgplusPayoutAggregate to set
     */
    public void setPgplusPayoutAggregate(PgplusPayoutAggregate pgplusPayoutAggregate) {
        this.pgplusPayoutAggregate = pgplusPayoutAggregate;
    }

    public int getPaymentCnt() {
        return paymentCnt;
    }

    public void setPaymentCnt(int paymentCnt) {
        this.paymentCnt = paymentCnt;
    }

    public int getRefundCnt() {
        return refundCnt;
    }

    public void setRefundCnt(int refundCnt) {
        this.refundCnt = refundCnt;
    }

    public int getChargebackCnt() {
        return chargebackCnt;
    }

    public void setChargebackCnt(int chargebackCnt) {
        this.chargebackCnt = chargebackCnt;
    }

}
