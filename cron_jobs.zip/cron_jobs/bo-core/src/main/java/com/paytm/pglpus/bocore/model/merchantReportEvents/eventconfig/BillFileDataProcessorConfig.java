package com.paytm.pglpus.bocore.model.merchantReportEvents.eventconfig;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import lombok.Data;
import lombok.ToString;
import java.util.Set;

@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillFileDataProcessorConfig {
    private Integer billFileThresholdTime;
    private BillFileThresholdAction action;
    private Set<MerchantSettlementReportType> reportTypes;
}
