package com.paytm.pglpus.bocore.model.msr;

import com.paytm.pgplus.bocore.constants.MSRBillFileColumn;
import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import com.paytm.pgplus.bocore.enums.TransactionType;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import com.paytm.pgplus.bocore.util.csv.converter.deserializer.BigDecimalConverter;
import com.paytm.pgplus.bocore.util.csv.converter.deserializer.DateConverter;
import lombok.Data;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

@ToString
@Data
public class MFMerchantChargingReport extends MerchantSettlementReport {

    private static final long serialVersionUID = -2571800672083821784L;

    @CSVColumn(name = MSRBillFileColumn.SETTLEMENT_START_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_TIME_FORMAT_2 }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date settlementStartDate;

    @CSVColumn(name = MSRBillFileColumn.SETTLEMENT_END_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_TIME_FORMAT_2 }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date settlementEndDate;

    @CSVColumn(name = MSRBillFileColumn.PAYTM_MID)
    private String paytmMid;

    @CSVColumn(name = MSRBillFileColumn.BANK_ID)
    private String bankId;

    @CSVColumn(name = MSRBillFileColumn.BANK_REF_NO)
    private String bankRefNo;

    @CSVColumn(name = MSRBillFileColumn.PGI_REF_NO)
    private String pgiRefNo;

    @CSVColumn(name = MSRBillFileColumn.REF_1)
    private String fundIdentifier;

    @CSVColumn(name = MSRBillFileColumn.REF_2)
    private String folio;

    @CSVColumn(name = MSRBillFileColumn.REF_3)
    private String emailIdOfInvestor;

    @CSVColumn(name = MSRBillFileColumn.REF_4)
    private String subBrokerCode;

    @CSVColumn(name = MSRBillFileColumn.REF_5)
    private String amcCode;

    @CSVColumn(name = MSRBillFileColumn.REF_6)
    private String fundType;

    @CSVColumn(name = MSRBillFileColumn.REF_7)
    private String residentStatus;

    @CSVColumn(name = MSRBillFileColumn.REF_8)
    private String systemGenerated;

    @CSVColumn(name = MSRBillFileColumn.REF_9)
    private String beneficiaryBankAccountNumber;

    @CSVColumn(name = MSRBillFileColumn.REF_10)
    private String beneficiaryBankIFSCode;

    @CSVColumn(name = MSRBillFileColumn.REF_11)
    private String ref11;

    @CSVColumn(name = MSRBillFileColumn.REF_12)
    private String ref12;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_TIME_FORMAT_2 }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date transactionDate;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal transactionAmount;

    @CSVColumn(name = MSRBillFileColumn.STATUS)
    private String status;

    @CSVColumn(name = MSRBillFileColumn.REQUEST_TYPE)
    private String requestType;

    @CSVColumn(name = MSRBillFileColumn.SETTLED_BANK_TXN_ID)
    private String settlementBankTxnId;

    @CSVColumn(name = MSRBillFileColumn.SETTLED_TXN_ID)
    private String settlementTxnId;

    private long fileId;

    public MFMerchantChargingReport() {
        super(TransactionType.PAYMENT, MerchantSettlementReportType.MF_CHARGING);
    }

    @Override
    public BigDecimal getTotalAmount() {
        return this.transactionAmount;
    }

    @Override
    public BigDecimal getTransactionAmount() {
        return this.transactionAmount;
    }

    @Override
    public String getPayoutId() {
        return this.settlementTxnId;
    }

    @Override
    public String getUtr() {
        return this.settlementBankTxnId;
    }

    @Override
    public String getPaytmMerchantId() {
        return this.paytmMid;
    }

    @Override
    public String getMerchantBillId() {
        return null;
    }

    @Override
    public String getPrnCode() {
        return null;
    }

    @Override
    public String getOriginalMID() {
        return getPaytmMerchantId();
    }

    @Override
    public BigDecimal getServiceTax() {
        return BigDecimal.ZERO;
    }

    @Override
    public BigDecimal getMerchantCommission() {
        return BigDecimal.ZERO;
    }
}
