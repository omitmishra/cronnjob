package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.constants.EDCConstants;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import lombok.*;
import org.hibernate.annotations.DynamicUpdate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @author akash8.singh@paytm.com
 */

@NoArgsConstructor
@Entity
@Table(name = "edc_banks_batch_settlement")
@Data
@ToString
public class EdcHdfcBatchSettlementRequest extends EdcHdfcBaseRquest implements Serializable {

    @Id
    @Column(name = "id")
    private String edcBankSettlementId;

    @Column(name = "bank_tid")
    @CSVColumn(name = EDCConstants.BANK_TID)
    private String bankTid;

    @Column(name = "paytm_tid")
    @CSVColumn(name = EDCConstants.PAYTM_TID)
    private String paytmTid;

    @Column(name = "bank_mid")
    @CSVColumn(name = EDCConstants.BANK_MID)
    private String bankMid;

    @Column(name = "bank_code")
    @CSVColumn(name = EDCConstants.BANK_CODE)
    private String bankCode;

    @Column(name = "no_of_sale")
    @CSVColumn(name = EDCConstants.NO_OF_SALE)
    private String noOfSale;

    @Column(name = "amount_of_debits_sale")
    @CSVColumn(name = EDCConstants.AMOUNT_OF_DEBITS_SALE)
    private String amountOfDebitsSale;

    @Column(name = "number_of_refund")
    @CSVColumn(name = EDCConstants.NUMBER_OF_REFUND)
    private String numberOfRefund;

    @Column(name = "amount_of_debit_refund")
    @CSVColumn(name = EDCConstants.AMOUNT_OF_DEBITS_REFUND)
    private String amountOfDebitRefund;

    @Column(name = "batch_settlement_status")
    private String batchSettlementStatus;

    @Column(name = "batch_upload_status")
    private String batchUploadStatus;

    @Column(name = "force_settlement_status")
    private String forceSettlementStatus;

    @Column(name = "no_of_settled_sale")
    private String noOfSettledSale;

    @Column(name = "amount_of_settled_sale")
    private String amountOfSettledSale;

    @Column(name = "number_of_settled_refund")
    private String numberOfSettledRefund;

    @Column(name = "amount_of_settled_refund")
    private String amountOfSettledRefund;

    @Column(name = "cron_id")
    private long cronId;

    @Transient
    private String batchNumber;

    @Transient
    private long uniqueStan;
}
