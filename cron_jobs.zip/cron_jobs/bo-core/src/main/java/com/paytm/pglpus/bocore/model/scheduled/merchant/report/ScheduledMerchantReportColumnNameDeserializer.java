package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

import java.io.IOException;

public class ScheduledMerchantReportColumnNameDeserializer extends JsonDeserializer<ScheduledMerchantReportColumnName> {

    @Override
    public ScheduledMerchantReportColumnName deserialize(JsonParser jsonParser,
            DeserializationContext deserializationContext) throws IOException {
        ObjectCodec oc = jsonParser.getCodec();
        JsonNode node = oc.readTree(jsonParser);
        String nodeValue = node.textValue();
        if (node != null)
            for (ScheduledMerchantReportPaytmColumnName scheduledMerchantReportPaytmColumnName : ScheduledMerchantReportPaytmColumnName
                    .values()) {
                if (scheduledMerchantReportPaytmColumnName.getColumnName().equals(nodeValue))
                    return scheduledMerchantReportPaytmColumnName;
            }
        return new DynamicScheduledMerchantReportColumnName(nodeValue);
    }
}
