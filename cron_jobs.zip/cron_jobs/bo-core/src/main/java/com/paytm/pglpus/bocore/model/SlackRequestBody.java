package com.paytm.pglpus.bocore.model;

import lombok.Data;

@Data
public class SlackRequestBody {

    private String channel;

    private String username;

    private String text;

    private String icon_emoji;

}
