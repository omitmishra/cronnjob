package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

public enum ReportGenerationModularityForDynamicData {

    DAY_WISE_CONTINOUS, DAY_WISE_DISCRETE, HOUR_WISE, SAME_DAY, VALIDATED_DAY_WISE_CONTINOUS;
}
