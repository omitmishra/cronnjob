package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.paytm.pgplus.common.enums.EventNameEnum;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
public class ScheduledMerchantReportDynamicData implements Serializable {

    @NotNull
    @Valid
    private ScheduledMerchantReportNotificationConfig scheduledMerchantReportNotificationConfig;

    @NotNull
    @Valid
    private ScheduledMerchantReportModularityBasedDynamicData scheduledMerchantReportModularityBasedDynamicData;

    private ScheduledMerchantReportDwhConfig scheduledMerchantReportDwhConfig;

    private ScheduledMerchantReportLICConfig scheduledMerchantReportLICConfig;

    @Valid
    private ScheduledMerchantReportFilter scheduledMerchantReportFilter;

    @Valid
    private ScheduledMerchantReportFormatMetaInfo scheduledMerchantReportFormatMetaInfo;

    @Valid
    private EventNameEnum callbackTopic;

    public boolean isValid() {
        if (scheduledMerchantReportNotificationConfig != null
                && scheduledMerchantReportModularityBasedDynamicData != null) {
            return scheduledMerchantReportModularityBasedDynamicData.isValid();
        }
        return false;
    }
}
