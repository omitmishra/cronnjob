package com.paytm.pglpus.bocore.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pglpus.bocore.model.request.DocumentInfo;
import lombok.*;

import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateDisputeRequestBody {
    private String disputeId;
    private String comment;
    private String actor;
    private String actorInfo;
    private String flow;
    private String source;
    private String transType;
    private String judgePayerType;
    private String boOperatorName;
    private String orderStatus;
    private String disputeCloseType;
    private List<DocumentInfo> documentList;
}
