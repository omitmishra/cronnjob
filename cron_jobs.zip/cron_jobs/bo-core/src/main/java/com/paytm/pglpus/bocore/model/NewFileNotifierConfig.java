package com.paytm.pglpus.bocore.model;

import lombok.Data;

/**
 * Created by dheeraj on 14/02/18.
 */
@Data
public class NewFileNotifierConfig {
    String configType;
    long defaultScheduleConfigId;
    String queue;
}
