package com.paytm.pglpus.bocore.model;

import lombok.Data;

/**
 * Created by dheeraj on 03/03/18.
 */
@Data
public class NewJobEvent {
    long jobId;
    String customPayload;
    String jobBean;
}
