package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@Table(name = "edc_hdfc_cron_status_details")
public class EdcHdfcCronStatusRequest implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "status")
    private String status;

    @Column(name = "sub_status")
    private String subStatus;

    @Column(name = "file_date")
    private String fileDate;
}
