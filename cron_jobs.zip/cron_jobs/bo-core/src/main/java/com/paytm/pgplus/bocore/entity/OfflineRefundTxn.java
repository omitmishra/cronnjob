package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;

import com.paytm.pgplus.bocore.constants.Constants;
import com.paytm.pgplus.common.model.ResultInfo;

/**
 *
 * @author Himanshu Sardana
 * @since 05 Feb 2016
 */
@Entity
@Table(name = "offline_refund_txn")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "OfflineRefundTxn.findTxnsByFileId", query = "SELECT o FROM OfflineRefundTxn o WHERE o.fileId = :fileId"),
        @NamedQuery(name = "OfflineRefundTxn.findTxnByRefundIdAndStatus", query = "SELECT o FROM OfflineRefundTxn o WHERE o.extSerialNum = :refundExtSerialNum AND o.resultStatus = :status"),
        @NamedQuery(name = "OfflineRefundTxn.findTxnsByBankCodeAndPaymodeAndCreatedOn", query = "SELECT o FROM OfflineRefundTxn o WHERE o.bankCode = :bankCode AND o.origTxnType = :origTxnType And o.createdOn > :createdOn"),
        @NamedQuery(name = "OfflineRefundTxn.findCountByBankAndPaymode", query = "SELECT count(o) FROM OfflineRefundTxn o WHERE o.origTxnType = :paymode AND o.bankCode = :bankCode AND DATE(o.createdOn) = :createdOn") })
public class OfflineRefundTxn implements Serializable/* ,CsvExportable */{

    /**
	 * 
	 */
    private static final long serialVersionUID = -3892220064455129542L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "TRANS_ID", length = 100)
    private String transId;

    @Column(name = "EXT_SERIAL_NUM", length = 20)
    private String extSerialNum;

    @Column(name = "BANK_CODE", length = 20)
    private String bankCode;

    @Column(name = "TRACE_NUMBER", length = 10)
    private String traceNumber;

    @Column(name = "AUTH_CODE", length = 64)
    private String authCode;

    @Column(name = "RRN_CODE", length = 32)
    private String rrnCode;

    @Column(name = "BANK_REFERENCE_NUMBER", length = 32)
    private String bankReferenceNumber;

    @Column(name = "MERCHANT_ID", length = 32)
    private String merchantId;

    @Column(name = "MERCHANT_NAME", length = 128)
    private String merchantName;

    @Column(name = "MERCHANT_TRANS_ID", length = 64)
    private String merchantTransId;

    @Column(name = "MERCHANT_MBID", length = 32)
    private String merchantMbid;

    @Column(name = "ORIG_TXN_TYPE", length = 64)
    private String origTxnType;

    @Column(name = "ORIG_EXT_SERIAL_NUM", length = 20)
    private String origExtSerialNum;

    @Column(name = "ORIG_TXN_CURRENCY", length = 3)
    private String origTxnCurrency;

    @Column(name = "ORIG_TXN_AMOUNT")
    private BigDecimal origTxnAmount;

    @Column(name = "REFUND_CURRENCY", length = 3)
    private String refundCurrency;

    @Column(name = "REFUND_AMOUNT")
    private BigDecimal refundAmount;

    @Column(name = "REFUND_CREATION_TIME")
    private Date refundCreationTime;

    @Column(name = "ORIG_TXN_CREATION_TIME")
    private Date origTxnCreationTime;

    @Column(name = "FILE_ID", length = 20)
    private Long fileId;

    @Column(name = "RESULT_CODE_ID", length = 20)
    private String resultCodeId;

    @Column(name = "RESULT_CODE", length = 50)
    private String resultCode;

    @Column(name = "RESULT_STATUS", length = 50)
    private String resultStatus;

    @Column(name = "RESULT_MESSAGE")
    @Type(type = "text")
    private String resultMsg;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_on", nullable = false)
    private Date createdOn;

    @Basic(optional = false)
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedOn;

    @Column(name = "TID")
    private String tid;

    @Column(name = "STAN")
    private String stan;

    @Column(name = "INTERCHANGE")
    private String interchange;

    @Column(name = "MASKED_CARD_NO")
    private String maskedCardNo;

    @Column(name = "CARD_TYPE")
    private String cardType;

    @Column(name = "CARD_NO")
    private String cardNo;

    @Column(name = "TENURE")
    private Long tenure;

    public OfflineRefundTxn() {
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((extSerialNum == null) ? 0 : extSerialNum.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        OfflineRefundTxn other = (OfflineRefundTxn) obj;
        if (extSerialNum == null) {
            if (other.extSerialNum != null)
                return false;
        } else if (!extSerialNum.equals(other.extSerialNum))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }

    public String getTransId() {
        return transId;
    }

    public void setTransId(String transId) {
        this.transId = transId;
    }

    public String getExtSerialNum() {
        return extSerialNum;
    }

    public void setExtSerialNum(String extSerialNum) {
        this.extSerialNum = extSerialNum;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getTraceNumber() {
        return traceNumber;
    }

    public void setTraceNumber(String traceNumber) {
        this.traceNumber = traceNumber;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getRrnCode() {
        return rrnCode;
    }

    public void setRrnCode(String rrnCode) {
        this.rrnCode = rrnCode;
    }

    public String getBankReferenceNumber() {
        return bankReferenceNumber;
    }

    public void setBankReferenceNumber(String bankReferenceNumber) {
        this.bankReferenceNumber = bankReferenceNumber;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getMerchantTransId() {
        return merchantTransId;
    }

    public void setMerchantTransId(String merchantTransId) {
        this.merchantTransId = merchantTransId;
    }

    public String getMerchantMbid() {
        return merchantMbid;
    }

    public void setMerchantMbid(String merchantMbid) {
        this.merchantMbid = merchantMbid;
    }

    public String getOrigTxnType() {
        return origTxnType;
    }

    public void setOrigTxnType(String origTxnType) {
        this.origTxnType = origTxnType;
    }

    public String getOrigExtSerialNum() {
        return origExtSerialNum;
    }

    public void setOrigExtSerialNum(String origExtSerialNum) {
        this.origExtSerialNum = origExtSerialNum;
    }

    public String getOrigTxnCurrency() {
        return origTxnCurrency;
    }

    public void setOrigTxnCurrency(String origTxnCurrency) {
        this.origTxnCurrency = origTxnCurrency;
    }

    public BigDecimal getOrigTxnAmount() {
        return origTxnAmount;
    }

    public void setOrigTxnAmount(BigDecimal origTxnAmount) {
        this.origTxnAmount = origTxnAmount;
    }

    public String getRefundCurrency() {
        return refundCurrency;
    }

    public void setRefundCurrency(String refundCurrency) {
        this.refundCurrency = refundCurrency;
    }

    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }

    public Date getRefundCreationTime() {
        return refundCreationTime;
    }

    public void setRefundCreationTime(Date refundCreationTime) {
        this.refundCreationTime = refundCreationTime;
    }

    public Date getOrigTxnCreationTime() {
        return origTxnCreationTime;
    }

    public void setOrigTxnCreationTime(Date origTxnCreationTime) {
        this.origTxnCreationTime = origTxnCreationTime;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

    public String getResultCodeId() {
        return resultCodeId;
    }

    public void setResultCodeId(String resultCodeId) {
        this.resultCodeId = resultCodeId;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultStatus() {
        return resultStatus;
    }

    public void setResultStatus(String resultStatus) {
        this.resultStatus = resultStatus;
    }

    public String getResultMsg() {
        return resultMsg;
    }

    public void setResultMsg(String resultMsg) {
        this.resultMsg = resultMsg;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getStan() {
        return stan;
    }

    public void setStan(String stan) {
        this.stan = stan;
    }

    public String getInterchange() {
        return interchange;
    }

    public void setInterchange(String interchange) {
        this.interchange = interchange;
    }

    public String getMaskedCardNo() {
        return maskedCardNo;
    }

    public void setMaskedCardNo(String maskedCardNo) {
        this.maskedCardNo = maskedCardNo;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardNo() {
        return cardNo;
    }

    public void setCardNo(String cardNo) {
        this.cardNo = cardNo;
    }

    public Long getTenure() {
        return tenure;
    }

    public void setTenure(Long tenure) {
        this.tenure = tenure;
    }

    @Override
    public String toString() {
        return "OfflineRefundTxn [id=" + id + ", transId=" + transId + ", extSerialNum=" + extSerialNum + ", bankCode="
                + bankCode + ", traceNumber=" + traceNumber + ", authCode=" + authCode + ", rrnCode=" + rrnCode
                + ", bankReferenceNumber=" + bankReferenceNumber + ", merchantId=" + merchantId + ", merchantName="
                + merchantName + ", merchantTransId=" + merchantTransId + ", merchantMbid=" + merchantMbid
                + ", origTxnType=" + origTxnType + ", origExtSerialNum=" + origExtSerialNum + ", origTxnCurrency="
                + origTxnCurrency + ", origTxnAmount=" + origTxnAmount + ", refundCurrency=" + refundCurrency
                + ", refundAmount=" + refundAmount + ", refundCreationTime=" + refundCreationTime
                + ", origTxnCreationTime=" + origTxnCreationTime + ", fileId=" + fileId + ", resultCodeId="
                + resultCodeId + ", resultCode=" + resultCode + ", resultStatus=" + resultStatus + ", resultMsg="
                + resultMsg + ", createdOn=" + createdOn + ", updatedOn=" + updatedOn + "]";
    }

    public void setResultInfo(ResultInfo resultInfo) {
        if (resultInfo != null) {
            this.resultCodeId = resultInfo.getResultCodeId();
            this.resultCode = resultInfo.getResultCode();
            this.resultStatus = resultInfo.getResultStatus();
            this.resultMsg = resultInfo.getResultMsg();
        }
    }

    public String csvValue() {
        StringBuilder csvVal = new StringBuilder(StringUtils.EMPTY);
        String ALIPAY_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssXXX";
        DateFormat dateFormat = new SimpleDateFormat(ALIPAY_DATE_FORMAT);
        String refundCreationTimeStr = dateFormat.format(refundCreationTime);
        String origTxnCreationTimeStr = dateFormat.format(origTxnCreationTime);
        csvVal.append(StringUtils.isNotBlank(transId) ? transId : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(extSerialNum) ? extSerialNum : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(rrnCode) ? rrnCode : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(bankReferenceNumber) ? bankReferenceNumber : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(traceNumber) ? traceNumber : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(authCode) ? authCode : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(merchantId) ? merchantId : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(merchantName) ? merchantName : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(merchantTransId) ? merchantTransId : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(merchantMbid) ? merchantMbid : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(origExtSerialNum) ? origExtSerialNum : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(origTxnCurrency) ? origTxnCurrency : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(origTxnAmount.toString()) ? origTxnAmount.toString() : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(refundCurrency) ? refundCurrency : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(refundAmount.toString()) ? refundAmount.toString() : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(refundCreationTimeStr) ? refundCreationTimeStr : StringUtils.EMPTY)
                .append(Constants.CSV_SEPARATOR)
                .append(StringUtils.isNotBlank(origTxnCreationTimeStr) ? origTxnCreationTimeStr : StringUtils.EMPTY);
        return csvVal.toString();
    }

}
