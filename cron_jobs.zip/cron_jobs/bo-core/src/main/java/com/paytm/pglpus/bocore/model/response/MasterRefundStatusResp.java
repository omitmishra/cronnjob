package com.paytm.pglpus.bocore.model.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class MasterRefundStatusResp implements Serializable {

    private static final long serialVersionUID = 6378389960409152245L;
    @JsonProperty("REFUND_TXN_ID")
    private String REFUNDTXNID;
    @JsonProperty("BANK_TXN_ID")
    private String BANKTXNID;
    private String STATUS;
    private String REFUNDAMOUNT;
    private String PAYMENTMODE;
    private String GATEWAY;
    @JsonProperty("CARD_ISSUER")
    private String CARDISSUER;

}
