package com.paytm.pglpus.bocore.model;

import lombok.Data;

/**
 * Created by dheeraj on 22/01/18.
 */

@Data
public class NewIssueTemplate {

    long id;
    String template;
    String heading;
    Integer priority;
    String comment;

    Long teamId;

    Long parentTemplateId;
}
