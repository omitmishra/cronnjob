package com.paytm.pgplus.bocore.entity.jpa;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author manish.jha
 */
@Entity
@NoArgsConstructor
@Data
public class BulkRefund implements Serializable {

    private static final long serialVersionUID = -509720251078609273L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String bulkRefundType;

    private String mid;

    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private Date txnDate;

    private BigDecimal txnAmount;

    private BigDecimal baseAmount;

    private String orderId;

    private String refundType;

    private String refId;

    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private Date refundDate;

    private BigDecimal refundAmount;

    private Integer refunded;

    private Integer retryCount;

    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "Asia/Kolkata")
    private Date filedate;

    private long bulkRefundStatusFileId;

    private String txnId;

    private Boolean error = false;

    private Long errorCode;

    private String errorMsg;

    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private Date lastUpdated;

    private String bankTxnId;

    private Boolean isApproved;

    private String paymode;

    private String gateway;

    private String rrn;

    private Boolean rrnUpdated = false;

    private String refundId;

    private String orderStatus;

}
