package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import com.paytm.pgplus.bocore.enums.ChargeBackCommentType;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "chargeback_comment")
@Getter
@Setter
public class ChargeBackComment extends BaseEntity implements Serializable {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "comment")
    private String comment;

    @Column(name = "comment_by")
    @Enumerated(EnumType.STRING)
    private ChargeBackCommentType commentBy;

    @OneToMany(mappedBy = "chargeBackComment", fetch = FetchType.LAZY)
    private List<ChargeBackDetails> chargeBackDetails;

    @OneToMany(mappedBy = "chargeBackComment", fetch = FetchType.LAZY)
    private List<ChargeBackDetailsHistory> chargeBackDetailsHistory;
}
