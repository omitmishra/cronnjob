package com.paytm.pglpus.bocore.model.merchantReportEvents;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class AgentInfo {

    private Long id;
    private String parentMid;
    private String childMid;
    private String agentId;
    private String extendedInfo;
    private boolean status;

}
