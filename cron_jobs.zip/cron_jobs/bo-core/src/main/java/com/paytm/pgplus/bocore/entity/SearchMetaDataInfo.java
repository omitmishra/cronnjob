/**
 * 
 */
package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * @author riteshkumarsharma
 *
 */
@Entity
@Table(name = "search_meta_data_info")
@NamedQueries({ @NamedQuery(name = "SearchMetadataInfo.getSearchMetadataForDownloadId", query = "SELECT s FROM SearchMetaDataInfo s WHERE s.downloadId=:download_id") })
public class SearchMetaDataInfo implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "download_id")
    private String downloadId;

    @Column(name = "search_type", length = 100)
    private String searchType;

    @Column(name = "search_create_date_time")
    private Date searchCreateDateTime;

    @Column(name = "notify_date_time")
    private Date notifyDateTime;

    @Column(name = "status", length = 50)
    private String status;

    @Column(name = "request_source", length = 20)
    private String requestSource;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDownloadId() {
        return downloadId;
    }

    public void setDownloadId(String downloadId) {
        this.downloadId = downloadId;
    }

    public String getSearchType() {
        return searchType;
    }

    public void setSearchType(String searchType) {
        this.searchType = searchType;
    }

    public Date getSearchCreateDateTime() {
        return searchCreateDateTime;
    }

    public void setSearchCreateDateTime(Date searchCreateDateTime) {
        this.searchCreateDateTime = searchCreateDateTime;
    }

    public Date getNotifyDateTime() {
        return notifyDateTime;
    }

    public void setNotifyDateTime(Date notifyDateTime) {
        this.notifyDateTime = notifyDateTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRequestSource() {
        return requestSource;
    }

    public void setRequestSource(String requestSource) {
        this.requestSource = requestSource;
    }

}
