package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

/**
 * Created by dheeraj on 15/11/17.
 */

@Entity
@Data
public class AdditionalParam {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    Long foreignEntryId;

    String entryKey;

    String entryValue;

    Boolean enabled;

    Date createdOn;
    Date updatedOn;
}
