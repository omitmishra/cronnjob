/**
 * 
 */
package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author riteshkumarsharma
 *
 */
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "PAYOUT_ALIPAY_DETAIL")
public class PgplusPayoutAlipayDetail extends BaseEntity implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @Column(name = "PAYOUT_ID")
    private String payoutId;

    @Column(name = "MERCHANT_ID")
    private String merchantId;

    @Column(name = "ALIPAY_MERCHANT_ID")
    private String alipayMerchantId;

    @Column(name = "BANK_NAME")
    private String bankName;

    @Column(name = "MERCHANT_NAME")
    private String merchantName;

    @Column(name = "COMMISSION")
    private Double commission;

    @Column(name = "SERVICE_TAX")
    private Double serviceTax;

    @Column(name = "REFUND_AMOUNT")
    private Double refundAmount;

    @Column(name = "CHARGE_BACK_AMOUNT")
    private Double chargeBackAmount;

    @Column(name = "CONVENIENCE_FEE")
    private Double convenienceFee;

    @Column(name = "PAYMENT_AMOUNT")
    private Double paymentAmount;

    @Column(name = "PAYOUT_DATE")
    private Date payoutDate;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "PAYMENT_CNT")
    private int paymentCnt;

    @Column(name = "REFUND_CNT")
    private int refundCnt;

    @Column(name = "CHARGEBACK_CNT")
    private int chargebackCnt;

    @Column(name = "PRE_NET_SETTLE_AMOUNT")
    private Double preNetSettleAmount;

    @Column(name = "NET_SETTLE_AMOUNT")
    private Double netSettleAmount;

    @Column(name = "SETTLEMENT_STATUS")
    private String settlementStatus;

    @Column(name = "NET_AMOUNT")
    private Double netAmount;
}
