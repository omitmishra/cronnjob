package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "irctc_ppbl_upi_refund_detail")
public class IRCTCPPBLUPIRefundDetail extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "trans_id")
    private String transId;

    @Column(name = "bank_abbr")
    private String bankAbbr;


    @Column(name = "merchant_id")
    private String merchantId;

    @Column(name = "orig_merchant_id")
    private String origMerchantId;

    @Column(name = "mbid")
    private String mbid;

    @Column(name = "payment_mode")
    private String paymentMode;

    @Column(name = "orig_trans_currency")
    private String origTransCurrency;

    @Column(name = "orig_trans_amount")
    private String origTransAmount;

    @Column(name = "refund_currency")
    private String refundCurrency;

    @Column(name = "refund_amount")
    private String refundAmount;

    @Column(name = "orig_created_time")
    private Date origCreatedTime;

    @Column(name = "orig_ext_serial_no")
    private String origExtSerialNo;

    @Column(name = "refund_txn_source")
    private String refundTxnSource;

    @Column(name = "bo_generated_ext_serial_no")
    private String boGeneratedExtSerialNo;

    @Column(name = "bo_created_time")
    private String boCretaedTime;

    @Column(name = "status")
    private String status;

    @Column(name = "file_date")
    private String fileDate;

    @Column(name = "comment")
    private String comment;

    @Column(name = "bank_reference_no")
    private String bankReferenceNo;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "ref_id")
    private String refId;

    @Column(name = "result_code")
    private String resultCode;

    @Column(name = "result_msg")
    private String resultMsg;

    @Column(name = "result_code_id")
    private String resultCodeId;

}