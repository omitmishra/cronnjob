/**
 * 
 */
package com.paytm.pglpus.bocore.model.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * * This class represents request of download summary callback api by
 * WALLET_PANEL. Reference url:
 * https://wiki.mypaytm.com/display/WD/Offline+PG+Phase+II
 * 
 * @author nikhilshivajiugane
 *
 */
@Getter
@Setter
@AllArgsConstructor
public class WalletDownloadCallbackRequest {
    private String downloadFileId;
    private String status;
}
