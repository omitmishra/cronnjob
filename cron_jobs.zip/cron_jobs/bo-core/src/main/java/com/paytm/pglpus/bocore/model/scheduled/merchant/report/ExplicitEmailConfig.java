package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import lombok.Data;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
public class ExplicitEmailConfig extends EmailConfig {

    private String emailFrom;

    @NotNull
    @Size(min = 1)
    @Pattern(regexp = "[\\w.]+@\\w+\\.\\w+(\\.+\\w+)?(,[\\w.]+@\\w+\\.\\w+(\\.+\\w+)?)*")
    private String emailTo;

    @Pattern(regexp = "[\\w.]+@\\w+\\.\\w+(\\.+\\w+)?(,[\\w.]+@\\w+\\.\\w+(\\.+\\w+)?)*")
    private String emailCc;

    @Pattern(regexp = "[\\w.]+@\\w+\\.\\w+(\\.+\\w+)?(,[\\w.]+@\\w+\\.\\w+(\\.+\\w+)?)*")
    private String emailBcc;

    private String emailSubject;

    private String emailBody;

    public ExplicitEmailConfig() {
        super(EmailConfigType.EXPLICIT);
    }
}
