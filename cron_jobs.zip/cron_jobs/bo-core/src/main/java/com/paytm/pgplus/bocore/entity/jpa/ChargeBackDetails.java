package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import com.paytm.pgplus.bocore.enums.ChargeBackDefendOrderStatusType;
import com.paytm.pgplus.facade.enums.EnumCurrency;
import com.paytm.pgplus.facade.resolution.enums.DisputeLevel;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "chargeback_details")
@Getter
@Setter
public class ChargeBackDetails extends BaseEntity implements Serializable {

    @Id
    @Column(name = "dispute_id")
    private String disputeId;

    @Column(name = "external_serial_number")
    private String externalSerialNumber;

    @Column(name = "chargeback_amount")
    private BigDecimal chargebackAmount;

    @Column(name = "chargeback_currency")
    @Enumerated(EnumType.STRING)
    private EnumCurrency chargebackCurrency;

    @Column(name = "acquiring_ref_num")
    private String acquiringRefNum;

    @Column(name = "chargeback_type")
    private String chargebackType;

    @Column(name = "chargeback_reason")
    private String chargebackReason;

    @Column(name = "chargeback_closure_date")
    private Date chargeBackClosureDate;

    @Column(name = "defend_order_status")
    @Enumerated(EnumType.STRING)
    private ChargeBackDefendOrderStatusType orderStatus;

    @Column(name = "merchant_id")
    private String merchantId;

    @Column(name = "dispute_utr")
    private String disputeUtr;

    @Column(name = "from_status")
    private String fromStatus;

    @Column(name = "to_status")
    private String toStatus;

    @Column(name = "transaction_id")
    private String transactionId;

    @Column(name = "transaction_date")
    private Date transactionDate;

    @Column(name = "transaction_amount")
    private BigDecimal transactionAmount;

    @Column(name = "bank_gateway")
    private String bankGateway;

    @Column(name = "actor")
    private String actor;

    @Column(name = "actor_info")
    private String actorInfo;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "bank_txn_Id")
    private String bankTxnId;

    @Column(name = "pod_uploaded_date")
    private Date podUploadDate;

    @Column(name = "cust_id")
    private String custId;

    @Column(name = "chargeback_level")
    private String chargebackLevel;

    @Column(name = "is_payout_hold")
    private Boolean isPayoutHold;

    @OneToMany(mappedBy = "chargeBackDetails")
    @LazyCollection(value = LazyCollectionOption.FALSE)
    private List<ChargeBackDetailsHistory> chargeBackDetailsHistoryList;

    @OneToMany(mappedBy = "chargeBackDetails")
    @LazyCollection(value = LazyCollectionOption.FALSE)
    private List<ChargebackPodUploads> chargebackPodUploadsList;

    @ManyToOne
    @LazyCollection(value = LazyCollectionOption.FALSE)
    @JoinColumn(name = "comment_id", referencedColumnName = "id")
    private ChargeBackComment chargeBackComment;

}
