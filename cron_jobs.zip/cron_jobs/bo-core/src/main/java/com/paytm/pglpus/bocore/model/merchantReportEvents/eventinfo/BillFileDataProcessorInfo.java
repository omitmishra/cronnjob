package com.paytm.pglpus.bocore.model.merchantReportEvents.eventinfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Data
@ToString
@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class BillFileDataProcessorInfo extends EventProcessorInfoBase {
}
