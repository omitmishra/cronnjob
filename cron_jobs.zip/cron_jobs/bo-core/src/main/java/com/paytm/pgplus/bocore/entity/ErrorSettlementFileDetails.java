package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "error_settlement_file_details")
@NamedQueries({ @NamedQuery(name = "ErrorSettlementFileDetails.getAllErrorSettlementData", query = "SELECT a FROM ErrorSettlementFileDetails a WHERE a.fileUploadId=:fileUploadId") })
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ErrorSettlementFileDetails implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 3524917590819333368L;

    @Id
    @Basic(optional = false)
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "auth_code", length = 25)
    private String authCode;

    @Basic(optional = false)
    @Column(name = "txn_id", length = 40, nullable = false, updatable = false)
    private String txnId;

    @Column(name = "bank_txn_id", length = 25)
    private String bankTxnId;

    @Column(name = "chargeback_amount")
    private String chargebackAmount;

    @Column(name = "debit_date", nullable = true)
    private String debitDate;

    @Column(name = "discount")
    private String discount;

    @Column(name = "gross")
    private String gross;

    @Column(name = "merchant_code", length = 30)
    private String merchantCode;

    @Column(name = "neft_date")
    private String neftDate;

    @Column(name = "neft_no", length = 30)
    private String neftNo;

    @Column(name = "net_amount")
    private String netAmount;

    @Column(name = "payment_mode", length = 20)
    private String paymentMode;

    @Column(name = "refund_amount")
    private String refundAmout;

    @Column(name = "refund_date", nullable = true)
    private String refundDate;

    @Column(name = "reson_code", length = 25)
    private String resonCode;

    @Column(name = "s_tax")
    private String sTax;

    @Column(name = "sheet_type", length = 20)
    private String sheetType;

    @Column(name = "txn_amount")
    private String txnAmount;

    @Column(name = "txn_currency")
    private String txnCurrency;

    @Column(name = "txn_date", nullable = true)
    private String txnDate;

    @Column(name = "merchant_id", length = 40)
    private String merchantId;

    @Column(name = "fee_amount")
    private String feeAmount;

    @Column(name = "rrn_code", length = 40)
    private String rrnCode;

    @Column(name = "result_code_id")
    private String resultCodeId;

    @Column(name = "file_upload_details_id", length = 11)
    private long fileUploadId;

    @Column(name = "bank_name", length = 20)
    private String bankName;

    @Column(name = "refund_txn_id", length = 20)
    private String refundTxnId;

    @Column(name = "txn_info_source", length = 20)
    private String txnInfoSource;

    @Column(name = "error_message", length = 250)
    private String errorMessage;

    @Column(name = "corrected_settlement_file_name")
    private String correctedSettlementFileName;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_timestamp", nullable = true)
    private Date createTimestamp;

    @OneToMany(mappedBy = "errorSettlementFileDetails", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<ErrorSettlementCostDetails> errorSettlementCostDetails = new ArrayList<>();

}
