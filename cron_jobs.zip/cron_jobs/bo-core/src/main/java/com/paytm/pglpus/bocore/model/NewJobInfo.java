package com.paytm.pglpus.bocore.model;

import lombok.Data;

/**
 * Created by dheeraj on 14/02/18.
 */

@Data
public class NewJobInfo {
    long id;
    long fileNotifierConfigId;
    String jobBean;
    long scheduleConfigId;
    Boolean enabled;
    String jobDescription;
}
