package com.paytm.pgplus.bo.model.request;

import com.paytm.pgplus.validator.DateFormatValidate;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 * @author rahul7.verma
 * @since 14 Dec 2020
 */
public class SettlementBillListRequest implements Serializable {

    private static final long serialVersionUID = 5342387460729154991L;

    @NotNull(message = "ipRoleId must be present in request")
    @Size(min = 1, max = 64, message = "ipRoleId must be between {min} and {max} characters")
    private String ipRoleId;

    @NotNull(message = "settlementStartTime must be present in request")
    @Size(min = 1, max = 32, message = "settlementStartTime must be between {min} and {max} characters")
    @DateFormatValidate(message = "settlementStartTime is invalid")
    private String settlementStartTime;

    @NotNull(message = "settlementEndTime must be present in request")
    @Size(min = 1, max = 32, message = "settlementEndTime must be between {min} and {max} characters")
    @DateFormatValidate(message = "settlementEndTime is invalid")
    private String settlementEndTime;

    @NotNull(message = "pageSize must be present in request")
    @Size(min = 1, max = 10, message = "pageSize must be between {min} and {max} characters")
    private String pageSize;

    @NotNull(message = "pageNum must be present in request")
    @Size(min = 1, max = 10, message = "pageNum must be between {min} and {max} characters")
    private String pageNum;

    // optional field , default true
    private Boolean isFilterZeroAmount = true;

    public String getIpRoleId() {
        return ipRoleId;
    }

    public void setIpRoleId(String ipRoleId) {
        this.ipRoleId = ipRoleId;
    }

    public String getSettlementStartTime() {
        return settlementStartTime;
    }

    public void setSettlementStartTime(String settlementStartTime) {
        this.settlementStartTime = settlementStartTime;
    }

    public String getSettlementEndTime() {
        return settlementEndTime;
    }

    public void setSettlementEndTime(String settlementEndTime) {
        this.settlementEndTime = settlementEndTime;
    }

    public String getPageSize() {
        return pageSize;
    }

    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }

    public String getPageNum() {
        return pageNum;
    }

    public void setPageNum(String pageNum) {
        this.pageNum = pageNum;
    }

    public Boolean getFilterZeroAmount() {
        return isFilterZeroAmount;
    }

    public void setFilterZeroAmount(Boolean filterZeroAmount) {
        isFilterZeroAmount = filterZeroAmount;
    }

    @Override
    public String toString() {
        return "SettlementBillListRequest{" + "ipRoleId='" + ipRoleId + '\'' + ", settlementStartTime='"
                + settlementStartTime + '\'' + ", settlementEndTime='" + settlementEndTime + '\'' + ", pageSize='"
                + pageSize + '\'' + ", pageNum='" + pageNum + '\'' + ", isFilterZeroAmount=" + isFilterZeroAmount + '}';
    }
}
