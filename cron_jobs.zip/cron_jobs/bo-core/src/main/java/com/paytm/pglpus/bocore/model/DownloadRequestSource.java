package com.paytm.pglpus.bocore.model;

/**
 * Created by dheeraj on 20/07/17.
 */
public enum DownloadRequestSource {
    // DOWNLOAD_SCRIPT("DOWNLOAD_SCRIPT"),
    PG_PANEL("PG_PANEL"), MERCHANT_SCHEDULED_REPORT("MERCHANT_SCHEDULED_REPORT"), NB_OFFLINE_REFUND("NB_OFFLINE_REFUND");

    String s;

    DownloadRequestSource(String src) {
        s = src;
    }

    public String get() {
        return s;
    }

}
