package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.file.util.annotation.CsvColumnMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.paytm.pgplus.bocore.constants.RefundProcessingColumnMapper;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author dheeraj
 *
 */
@Setter
@Getter
@Entity
@ToString(exclude = "LOGGER")
@Table(name = "refund_processing")
public class RefundProcessingEntry extends BaseEntity implements Serializable {

    @Transient
    Logger LOGGER = LoggerFactory.getLogger(RefundProcessingEntry.class);

    public RefundProcessingEntry(String line) {
        LOGGER.info("Processing entry {}", line);
        try {

            if (line != null && !line.isEmpty()) {
                String[] vals = line.split(",");
                if (vals != null) {

                    LOGGER.info("Total number of vals {}", vals.length);

                    // Original External serial no of the transaction
                    if (vals.length >= 1) {
                        this.extSerialNo = vals[0].trim();
                    }
                    // Refund amount to be refunded
                    if (vals.length >= 2) {
                        this.refundAmount = vals[1].trim();
                    }
                    // External serial number corresponding to refund
                    if (vals.length >= 3) {
                        this.refundEsn = vals[2].trim();
                    }

                    // be default this value will be true
                    this.isRetry = Boolean.TRUE;

                    // isRetry flag value(true if refund already raised once)
                    if (vals.length >= 4) {
                        String retVal = vals[3].trim().toLowerCase();
                        if ("true".equals(retVal) || "false".equals(retVal)) {
                            this.isRetry = Boolean.valueOf(vals[3].trim().toLowerCase());
                        }
                    }

                    // Mandatory attribute to specify refunt_txn_source
                    if (vals.length >= 5) {
                        this.refundType = vals[4].trim();
                    }

                    // optional:Mbid field for the transaction
                    if (vals.length >= 6) {
                        this.mbid = vals[5].trim();
                    }
                    // optional: bank_refrence number for the transaction
                    if (vals.length >= 7) {
                        this.referenceNo = vals[6].trim();
                    }

                    if (vals.length >= 8) {
                        this.rrnCode = vals[7].trim();
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception while setting constructor RefundProcessingEntry", e);
        }
    }

    /**
	 *
	 */
    private static final long serialVersionUID = 7348673858659205106L;

    @Id
    @Basic(optional = false)
    @Column(name = "id")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.ID)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "file_name")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.FILE_NAME)
    private String fileName;

    @Column(name = "trans_type")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.TRANS_TYPE)
    private String transType;

    @Column(name = "result_status")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.RESULT_STATUS)
    private String resultStatus;

    @Column(name = "extserial_no")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.EXT_SERIAL_NO)
    private String extSerialNo;

    @Column(name = "trace_no")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.TRACE_NO)
    private String traceNo;

    @Column(name = "auth_code")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.AUTH_CODE)
    private String authCode;

    @Column(name = "rrn_code")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.RRN_CODE)
    private String rrnCode;

    @Column(name = "bank_abbr")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.BANK_ABBR)
    private String bankAbbr;

    @Column(name = "reference_no")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.REFERENCE_NO)
    private String referenceNo;

    @Column(name = "merchant_id")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.MERCHANT_ID)
    private String merchantId;

    @Column(name = "paytmm_id")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.ORIGINAL_MID)
    private String originalMID;

    @Column(name = "mbid")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.MBID)
    private String mbid;

    @Column(name = "exchange_amount")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.EXCHANGE_AMOUNT)
    private Long exchangeAmount;

    @Column(name = "exchange_currency")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.EXCHANGE_CURRENCY)
    private String exchangeCurrency;

    @Column(name = "trans_value_date")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.TRANS_VALUE_DATE)
    private Date transValueDate;

    @Column(name = "last_update_date")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.LAST_UPDATE_DATE)
    private Date lastUpdateDate;

    @Column(name = "action")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.ACTION)
    private String action;

    @Column(name = "comment")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.COMMENT)
    private String comment;

    @Column(name = "ref_id")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.REF_ID)
    private String refId;

    @Column(name = "refund_type")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.REFUND_TYPE)
    private String refundType;

    @Column(name = "bank_response_no")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.BANK_RESPONSE_NO)
    private String bankResponseNo;

    @Column(name = "trans_id")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.TRANS_ID)
    private String transId;

    @Column(name = "dispute_id")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.DISPUTE_ID)
    private String disputeId;

    @Column(name = "trans_info_source")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.TRANS_INFO_SOURCE)
    private String transInfoSource;

    @Column(name = "app_id")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.APP_ID)
    private String appId;

    @Column(name = "paymethod")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.PAYMETHOD)
    private String paymethod;

    @Column(name = "refundAmount")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.REFUND_AMOUNT)
    private String refundAmount;

    @Column(name = "refundEsn")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.REFUND_ESN)
    private String refundEsn;

    @Column(name = "isRetry")
    @CsvColumnMapper(columnName = RefundProcessingColumnMapper.IS_RETRY)
    private Boolean isRetry;

    private String virtualPaymentAddr;

}
