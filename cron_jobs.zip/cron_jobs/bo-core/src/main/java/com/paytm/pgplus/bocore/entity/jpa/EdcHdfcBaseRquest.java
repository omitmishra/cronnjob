package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;

@Data
public class EdcHdfcBaseRquest {
}
