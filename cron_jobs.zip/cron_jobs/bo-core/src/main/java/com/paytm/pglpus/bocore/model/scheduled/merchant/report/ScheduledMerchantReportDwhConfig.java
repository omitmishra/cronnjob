package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import lombok.Data;

import java.io.Serializable;

@Data
public class ScheduledMerchantReportDwhConfig implements Serializable {
    private boolean saveTransactions;
}
