package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "bank_paymode_master")
@Data
public class BankPayModeMaster extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -7252052140028259492L;

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "pay_mode")
    private String payMode;

    @Column(name = "priority")
    private Integer priority;
}
