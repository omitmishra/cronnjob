/**
 * 
 */
package com.paytm.pgplus.bocore.entity;

import static com.paytm.pgplus.bocore.constants.PayoutResponseFileColumn.PAYOUT_STATUS;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.file.util.annotation.CsvColumnMapper;

import com.paytm.pgplus.bocore.constants.PayoutDownloadFileColumn;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * 
 * @author dheerajtyagi
 *
 */

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "payout_aggregated")
public class PgplusPayoutAggregate extends BaseEntity implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.ENTITY_PAYOUT_ID)
    private Long id;

    @Column(name = "aggregated_txn_amount")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.TOTAL_TXN_AMOUNT)
    private Double aggregatedTxnAmount;

    @Column(name = "aggregated_commission")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.COMMISSION)
    private Double aggregatedCommission;

    @Column(name = "aggregated_service_tax")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.SERVICE_TAX)
    private Double aggregatedServiceTax;

    @Column(name = "aggregated_refund_amount")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.REFUND_AMOUNT)
    private Double aggregatedRefundAmount;

    @Column(name = "aggregated_charge_back_amount")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.CHARGEBACK_AMOUNT)
    private Double aggregatedChargeBackAmount;

    @Column(name = "aggregated_convenience_fee")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.CONVENIENCE_FEE)
    private Double aggregatedConvenienceFee;

    @Column(name = "payout_amount")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.PAYOUT_AMOUNT)
    private Double payoutAmount;

    @Column(name = "utr")
    @CsvColumnMapper(columnName = PayoutDownloadFileColumn.UTR)
    private String utr;

    @Column(name = "payout_date")
    private Date payoutDate;

    @CsvColumnMapper(columnName = PAYOUT_STATUS)
    @Column(name = "payout_status")
    private String payoutStatus;

    @Column(name = "merchant_id")
    private String merchantId;

    @Column(name = "merchant_name")
    private String merchantName;

    @Column(name = "bank_name")
    private String bankName;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "pgplusPayoutAggregate")
    private Set<PgplusPayoutDetail> pgplusPayoutDetails = new HashSet<PgplusPayoutDetail>();

}
