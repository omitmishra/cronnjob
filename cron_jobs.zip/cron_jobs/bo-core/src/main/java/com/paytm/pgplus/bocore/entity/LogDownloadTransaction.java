/**
 * 
 */
package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;

import javax.persistence.*;

import lombok.Getter;
import lombok.Setter;

/**
 * @author naman
 *
 */
@Getter
@Setter
@Entity
@Table(name = "download_logs")
@NamedQueries({
        @NamedQuery(name = "LogDownloadTransaction.findByDownloadId", query = "SELECT a FROM LogDownloadTransaction a WHERE a.downloadID = :downloadID"),
        @NamedQuery(name = "LogDownloadTransaction.findByStatus", query = "SELECT d FROM LogDownloadTransaction d WHERE d.status=:status and d.createdOn >:startDate and d.createdOn < :endDate") })
public class LogDownloadTransaction extends BaseEntity implements Serializable {

    private static final long serialVersionUID = -7956979228006806027L;

    @Basic(optional = false)
    @Column(name = "id", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "download_id")
    private String downloadID;

    @Column(name = "request_source")
    private String requestSource;

    @Column(name = "status")
    private String status;

    @Column(name = "request_type")
    private String requestType;

    @Column(name = "column_requested")
    private String columnRequested;

    @Column(name = "request_to_noti_receive_time")
    private Long requestToNotiFicationReceiveTime;

    @Column(name = "noti_received_to_noti_sent_time")
    private Long notificationReceivedToNotificationSentTime;

    @Column(name = "error_code")
    private String errorCode;

    @Column(name = "request")
    private String request;

    public LogDownloadTransaction(String downloadID, String requestSource, String status, String requestType,
            String columnRequested, Long requestToNotiFicationReceiveTime,
            Long notificationReceivedToNotificationSentTime, String errorCode, String request) {
        this.downloadID = downloadID;
        this.requestSource = requestSource;
        this.status = status;
        this.requestType = requestType;
        this.columnRequested = columnRequested;
        this.requestToNotiFicationReceiveTime = requestToNotiFicationReceiveTime;
        this.notificationReceivedToNotificationSentTime = notificationReceivedToNotificationSentTime;
        this.errorCode = errorCode;
        this.request = request;
    }

    public LogDownloadTransaction() {

    }

    @Override
    public String toString() {
        return "LogDownloadTransaction [id=" + id + ", downloadID=" + downloadID + ", requestSource=" + requestSource
                + ", status=" + status + ", requestType=" + requestType + ", columnRequested=" + columnRequested
                + ", requestToNotiFicationReceiveTime=" + requestToNotiFicationReceiveTime
                + ", notificationReceivedToNotificationSentTime=" + notificationReceivedToNotificationSentTime
                + ", errorCode=" + errorCode + ", request=" + request + "]";
    }

}
