package com.paytm.pglpus.bocore.model.request;

import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class DocumentInfo {
    private String documentName;
    private String documentId;
}
