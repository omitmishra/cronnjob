package com.paytm.pglpus.bocore.model.response;

import com.paytm.pgplus.facade.dataservice.models.SettlementBill;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author rahul7.verma
 * @since 15 Dec 2020
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SettlementBillListResponse implements Serializable {

    private static final long serialVersionUID = 134350885776671991L;

    private ResultInfo resultInfo;

    private List<SettlementBill> settlementBillList;
}
