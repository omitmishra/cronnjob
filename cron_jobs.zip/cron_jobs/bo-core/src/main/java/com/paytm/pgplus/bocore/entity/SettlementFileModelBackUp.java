package com.paytm.pgplus.bocore.entity;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "settlement_file_details_final")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "SettlementFileModelBackUp.getAllOldRowOfFile", query = "SELECT a FROM SettlementFileModelBackUp a WHERE a.fileUploadId=:fileUploadId AND a.txnId<=:txnId"),
        @NamedQuery(name = "SettlementFileModelBackUp.getAllNewRowOfOneSheetType", query = "SELECT a FROM SettlementFileModelBackUp a WHERE a.fileUploadId=:fileUploadId AND a.sheetType=:sheetType"),
        @NamedQuery(name = "SettlementFileModelBackUp.getAllNewRowOfFile", query = "SELECT a FROM SettlementFileModelBackUp a WHERE a.fileUploadId=:fileUploadId AND a.txnId>:txnId"),
        @NamedQuery(name = "SettlementFileModelBackUp.getAllSettlementData", query = "SELECT a FROM SettlementFileModelBackUp a WHERE a.fileUploadId=:fileUploadId"),
        @NamedQuery(name = "SettlementFileModelBackUp.getDuplicateTxnId", query = "SELECT a FROM SettlementFileModelBackUp a WHERE a.txnId IN (:txnIdList) AND a.createTimestamp>=:timeStamp AND a.sheetType=:sheetType"),
        @NamedQuery(name = "SettlementFileModelBackUp.getAllRefundDataWithNotificationFlagFalse", query = "SELECT a FROM SettlementFileModelBackUp a WHERE a.refundTxnId = :refundTxnId AND a.notificationSent=:notificationSent AND a.rrnCode!=:rrnCode AND a.rrnCode IS NOT NULL"),
        @NamedQuery(name = "SettlementFileModelBackUp.getAllRefundDataWithRefundId", query = "SELECT a FROM SettlementFileModelBackUp a WHERE a.refundTxnId = :refundTxnId"),
        @NamedQuery(name = "SettlementFileModelBackUp.updateNotificationFlagForRRNCode", query = "UPDATE SettlementFileModelBackUp a SET a.notificationSent=:notificationSent WHERE a.rrnCode=:rrnCode"),
        @NamedQuery(name = "SettlementFileModelBackUp.updateESNInDB", query = "UPDATE SettlementFileModelBackUp a SET a.txnId=:esn WHERE a.bankTxnId =:bankTxnId"),
        @NamedQuery(name = "SettlementFileModelBackUp.getAllByRrnCode", query = "SELECT a FROM SettlementFileModelBackUp a WHERE a.rrnCode!=:rrnCode") })
public class SettlementFileModelBackUp implements Serializable {

    @Id
    @Basic(optional = false)
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "merchant_code", length = 30)
    private String merchantCode;

    @Column(name = "gross")
    private BigDecimal gross;

    @Column(name = "discount")
    private BigDecimal discount;

    @Column(name = "s_tax")
    private BigDecimal sTax;

    @Column(name = "net_amount")
    private BigDecimal netAmount;

    @Basic(optional = false)
    @Column(name = "txn_id", length = 40, nullable = false, updatable = false)
    private String txnId;

    @Column(name = "bank_txn_id", length = 25)
    private String bankTxnId;

    @Column(name = "auth_code", length = 25)
    private String authCode;

    @Column(name = "reson_code", length = 25)
    private String resonCode;

    @Column(name = "neft_no", length = 30)
    private String neftNo;

    @Column(name = "txn_amount")
    private BigDecimal txnAmount;

    @Column(name = "refund_amount")
    private BigDecimal refundAmout;

    @Column(name = "chargeback_amount")
    private BigDecimal chargebackAmount;

    @Column(name = "sheet_type", length = 20)
    private String sheetType;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "refund_date", nullable = true)
    private Date refundDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "debit_date", nullable = true)
    private Date debitDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "txn_date", nullable = true)
    private Date txnDate;

    @Column(name = "neft_date")
    private String neftDate;

    @Column(name = "file_upload_details_id", length = 11)
    private long fileUploadId;

    @Column(name = "payment_mode", length = 20)
    private String paymentMode;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_timestamp", nullable = true)
    private Date createTimestamp;

    @Column(name = "merchant_id", length = 40)
    private String merchantId;

    @Column(name = "fee_amount")
    private BigDecimal feeAmount;

    @Column(name = "rrn_code", length = 40)
    private String rrnCode;

    @Column(name = "mbid", length = 40)
    private String mbid;

    @Column(name = "result_code_id")
    private long resultCodeId;

    @Column(name = "trace_no", length = 10)
    private long traceNo;

    @Column(name = "bank_name", length = 20)
    private String bankName;

    @Column(name = "refund_txn_id", length = 20)
    private String refundTxnId;

    @Column(name = "txn_info_source", length = 20)
    private String txnInfoSource;

    @Column(name = "notification_sent")
    private boolean notificationSent;

    /*
     * @OneToMany(mappedBy = "settlementFileModel", cascade = CascadeType.ALL,
     * fetch = FetchType.EAGER)
     * 
     * @NotFound(action = NotFoundAction.IGNORE) private
     * List<SettlementCostModel> settlementCostModel = new ArrayList<>();
     */

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMerchantCode() {
        return merchantCode;
    }

    public void setMerchantCode(String merchantCode) {
        this.merchantCode = merchantCode;
    }

    public BigDecimal getGross() {
        return gross;
    }

    public void setGross(BigDecimal gross) {
        this.gross = gross;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public BigDecimal getsTax() {
        return sTax;
    }

    public void setsTax(BigDecimal sTax) {
        this.sTax = sTax;
    }

    public BigDecimal getNetAmount() {
        return netAmount;
    }

    public void setNetAmount(BigDecimal netAmount) {
        this.netAmount = netAmount;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getBankTxnId() {
        return bankTxnId;
    }

    public void setBankTxnId(String bankTxnId) {
        this.bankTxnId = bankTxnId;
    }

    public String getAuthCode() {
        return authCode;
    }

    public void setAuthCode(String authCode) {
        this.authCode = authCode;
    }

    public String getResonCode() {
        return resonCode;
    }

    public void setResonCode(String resonCode) {
        this.resonCode = resonCode;
    }

    public String getNeftNo() {
        return neftNo;
    }

    public void setNeftNo(String neftNo) {
        this.neftNo = neftNo;
    }

    public BigDecimal getTxnAmount() {
        return txnAmount;
    }

    public void setTxnAmount(BigDecimal txnAmount) {
        this.txnAmount = txnAmount;
    }

    public BigDecimal getRefundAmout() {
        return refundAmout;
    }

    public void setRefundAmout(BigDecimal refundAmout) {
        this.refundAmout = refundAmout;
    }

    public BigDecimal getChargebackAmount() {
        return chargebackAmount;
    }

    public void setChargebackAmount(BigDecimal chargebackAmount) {
        this.chargebackAmount = chargebackAmount;
    }

    public String getSheetType() {
        return sheetType;
    }

    public void setSheetType(String sheetType) {
        this.sheetType = sheetType;
    }

    public Date getRefundDate() {
        return refundDate;
    }

    public void setRefundDate(Date refundDate) {
        this.refundDate = refundDate;
    }

    public Date getDebitDate() {
        return debitDate;
    }

    public void setDebitDate(Date debitDate) {
        this.debitDate = debitDate;
    }

    public Date getTxnDate() {
        return txnDate;
    }

    public void setTxnDate(Date txnDate) {
        this.txnDate = txnDate;
    }

    public String getNeftDate() {
        return neftDate;
    }

    public void setNeftDate(String neftDate) {
        this.neftDate = neftDate;
    }

    public long getFileUploadId() {
        return fileUploadId;
    }

    public void setFileUploadId(long fileUploadId) {
        this.fileUploadId = fileUploadId;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public Date getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(Date createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public BigDecimal getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(BigDecimal feeAmount) {
        this.feeAmount = feeAmount;
    }

    public String getRrnCode() {
        return rrnCode;
    }

    public void setRrnCode(String rrnCode) {
        this.rrnCode = rrnCode;
    }

    public String getMbid() {
        return mbid;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public long getResultCodeId() {
        return resultCodeId;
    }

    public void setResultCodeId(long resultCodeId) {
        this.resultCodeId = resultCodeId;
    }

    public long getTraceNo() {
        return traceNo;
    }

    public void setTraceNo(long traceNo) {
        this.traceNo = traceNo;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public String getRefundTxnId() {
        return refundTxnId;
    }

    public void setRefundTxnId(String refundTxnId) {
        this.refundTxnId = refundTxnId;
    }

    public String getTxnInfoSource() {
        return txnInfoSource;
    }

    public void setTxnInfoSource(String txnInfoSource) {
        this.txnInfoSource = txnInfoSource;
    }

    public boolean isNotificationSent() {
        return notificationSent;
    }

    public void setNotificationSent(boolean notificationSent) {
        this.notificationSent = notificationSent;
    }

    /*
     * public List<SettlementCostModel> getSettlementCostModel() { return
     * settlementCostModel; }
     * 
     * public void setSettlementCostModel(List<SettlementCostModel>
     * settlementCostModel) { this.settlementCostModel = settlementCostModel; }
     */
}
