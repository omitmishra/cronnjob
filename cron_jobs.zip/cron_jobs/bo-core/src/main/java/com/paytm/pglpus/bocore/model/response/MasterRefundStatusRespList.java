package com.paytm.pglpus.bocore.model.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class MasterRefundStatusRespList implements Serializable {

    private static final long serialVersionUID = 4862154569837794243L;

    @JsonProperty("CHILD_REFUND_STATUS")
    private List<MasterRefundStatusResp> childRefundStatusList;

    @JsonProperty("ErrorCode")
    private String errorCode;

    @JsonProperty("ErrorMsg")
    private String errorMsg;

    @JsonProperty("CHECKSUM")
    private String checksum;

    @JsonIgnore
    private Boolean foundAtPlatformPlus;

    private String MID;
    private String TXNID;
    private String ORDERID;
    private String TXNAMOUNT;
    private String REFUNDAMOUNT;
    private String TXNDATE;
    private Long RESPCODE;
    private String RESPMSG;
    private String STATUS;
    private String REFID;
    private String BANKTXNID;
    private String REFUNDID;
}
