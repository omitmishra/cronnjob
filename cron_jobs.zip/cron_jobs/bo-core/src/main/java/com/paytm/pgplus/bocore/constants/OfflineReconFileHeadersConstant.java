package com.paytm.pgplus.bocore.constants;

/**
 *
 * @author santoshkumar
 *
 */
public class OfflineReconFileHeadersConstant {

    public static final String MERCHANT_CODE = "merchantCode";
    public static final String NET_AMOUNT = "netAmount";
    public static final String TXN_ID = "txnId";
    public static final String BANK_TXN_ID = "bankTxnId";
    public static final String TXN_AMOUNT = "txnAmount";
    public static final String TXN_DATE = "txnDate";
    public static final String AUTH_CODE = "authCode";
    public static final String PAYMENT_MODE = "paymentMode";
    public static final String BANK_NAME = "bankName";
    public static final String MERCHANT_ID = "merchantId";
    public static final String RRN_CODE = "rrnCode";
    public static final String TRANSACTION_STATUS = "transactionStatus";
    public static final String TRANSACTION_TYPE = "transactionType";

    public static final String[] FILE_HEADER_MAPPING_FOR_EMAIL_ALERT = { BANK_TXN_ID, TXN_AMOUNT, TRANSACTION_TYPE,
            TRANSACTION_STATUS };

    // Offline recon file Header
    public static final String ESN = "esn";
    public static final String ORDER_ID = "orderId";
    public static final String ACQUIREMENT_ID = "acquirementId";
    public static final String UTR = "utr";
    public static final String ESN_CREATED_ON = "esnCreatedOn";
    public static final String ORDER_CREATED_ON = "orderCreatedOn";
    public static final String FILE_BASE_NAME = "Bank_Transfer_Recon";
    public static final String FILE_BASE_NAME_FOR_EMAIL_ALERT = "Bank_Transfer_Recon_missing_txn_";
    public static final String RECON_FILE_DAY_WINDOW = "recon.banktransfer.generation.offline.day.window";
    public static final String RECON_FILE_DAY_START_WINDOW = "recon.banktransfer.generation.start.window";
    public static final String RECON_FILE_DAY_END_WINDOW = "recon.banktransfer.generation.end.window";
    public static final String RECON_FILE_LOCAL_PATH = "recon.banktransfer.local.file.path";
    public static final String PAYMODE_BANKTRANSFER = "BANK_TRANSFER";
    public static final String BANKTRANSFER_FILE_LOCAL_PATH = "/paytm/sftp/upload/reports";
    public static final String DONE_PREFIX = "DONE_";
    public static final String RECON_FILES_FROM_S3 = "recon.file.from.s3";
    public static final String RECON_FILES_S3DIRPATH = "recon.files.s3.path";
    public static final String RECON_FILES_SUFFIX = "recon.files.suffix";
    public static final String RECON_BANK_TRANSFER_UPDATE_ESN_WINDOW = "recon.banktransfer.update.esn.window";

    public static final String[] FILE_HEADER_MAPPING = { ESN, ORDER_ID, ACQUIREMENT_ID, UTR, BANK_TXN_ID,
            ESN_CREATED_ON, ORDER_CREATED_ON };

}
