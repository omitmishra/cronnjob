package com.paytm.pglpus.bocore.model;

/*
 * Enum to enumerate different types of search requests coming on BO
 */
public enum SearchType {
    ACQUIRING("ACQUIRING"), REFUND("REFUND"), DISPUTE("DISPUTE"), SETTLEMENT("SETTLEMENT"), AUTO_REFUND("AUTO_REFUND"), P2B(
            "P2B"), ALL("ALL"), CANCEL("CANCEL"), DISCREPANCY("DISCREPANCY"), CUSTOM("CUSTOM"), NB_OFFLINE_REFUND(
            "NB_OFFLINE_REFUND"), CHARGEBACK("CHARGEBACK");

    String type;

    SearchType(String s) {
        type = s;
    }

    public String toString() {
        return type;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

}
