package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Entity for holding consolidated reports merchant
 *
 * @author Mayank Aggarwal
 */

@Entity
@Table(name = "chargeback_consolidated_report_merchants")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ChargebackConsolidatedReportMerchants extends BaseEntity implements Serializable {

    @Id()
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "mid", columnDefinition = "varchar(255) NOT NULL UNIQUE")
    private String mid;

    @Column(name = "consolidated_report_flag", columnDefinition = "bit(1) default 1")
    private boolean consolidatedReportFlag;

}
