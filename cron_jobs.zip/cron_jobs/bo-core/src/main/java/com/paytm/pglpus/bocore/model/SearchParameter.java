package com.paytm.pglpus.bocore.model;

public class SearchParameter {

    private String searchBy;
    private String searchValue;

    public SearchParameter() {
        super();
    }

    public SearchParameter(String searchBy, String searchValue) {
        super();
        this.searchBy = searchBy;
        this.searchValue = searchValue;
    }

    public String getSearchBy() {
        return searchBy;
    }

    public void setSearchBy(String searchBy) {
        this.searchBy = searchBy;
    }

    public String getSearchValue() {
        return searchValue;
    }

    public void setSearchValue(String searchValue) {
        this.searchValue = searchValue;
    }

    @Override
    public String toString() {
        return "SearchCondition [searchBy=" + searchBy + ", searchValue=" + searchValue + "]";
    }

}
