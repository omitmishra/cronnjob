package com.paytm.pglpus.bocore.model.merchantReportEvents.eventconfig;

public enum BillFileThresholdAction {
    SKIP, PROCESS, PROCESS_WITH_ALERT, FAIL, ERROR
}
