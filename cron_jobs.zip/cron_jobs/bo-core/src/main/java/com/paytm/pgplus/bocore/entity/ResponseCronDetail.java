package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.Setter;

/**
 * Entity class for response_cron_details table.
 * 
 * @author dheerajtyagi
 *
 */
@Entity
@Table(name = "response_cron_details")
@XmlRootElement
@Getter
@Setter
public class ResponseCronDetail extends BaseEntity implements Serializable {
    /**
     * generated serial version Id
     */
    private static final long serialVersionUID = -6442184448637506378L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "response_date", length = 100)
    private Date responseDate;

    @Column(name = "status")
    private int status;

    @Column(name = "cron_name")
    private String cronName;

}