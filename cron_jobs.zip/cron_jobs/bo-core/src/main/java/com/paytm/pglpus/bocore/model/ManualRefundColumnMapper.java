package com.paytm.pglpus.bocore.model;

/**
 * 
 * @author dheeraj
 *
 */
public class ManualRefundColumnMapper {
    public static final String ACQUIRING_TXN_ID = "acquiringTxnId";
    public static final String BANK_NAME = "bankName";
    public static final String CHARGING_DISCREPANCY_ID = "chargingDiscrepancyid";
    public static final String CHARGING_ESN = "chargingEsn";
    public static final String CHARGING_RECON_STATUS = "chargingReconStatus";
    public static final String CHARGING_SETTLEMENT_FILE_DETAILS_ID = "chargingSettlementFileDetailsId";
    public static final String ID = "id";
    public static final String MANUAL_REFUND_TYPE = "manualRefundType";
    public static final String MBID = "mbid";
    public static final String MID = "mid";
    public static final String ORDER_ID = "orderId";
    public static final String ORDER_STATUS = "orderStatus";
    public static final String PAYMODE = "paymode";
    public static final String REFUND_AMOUNT = "refundAmount";
    public static final String REFUND_BANK_TXN_ID = "refundBankTxnId";
    public static final String REFUND_DATE = "refundDate";
    public static final String REFUND_DISCREPANCY_ID = "refundDiscrepancyId";
    public static final String REFUND_ESN = "refundEsn";
    public static final String REFUND_PAYMENT_STATUS = "refundPaymentStatus";
    public static final String REFUND_RECON_STATUS = "refundReconStatus";
    public static final String REFUND_SETTLEMENT_FILE_DETAILS_ID = "refundSettlementFileDetailsId";
    public static final String REFUND_TXN_ID = "refundTxnId";
    public static final String REFUND_TYPE = "refundType";
    public static final String SUB_BIZ_ORDER_TYPE = "subBizOrderType";
    public static final String SUB_ORDER_STATUS = "subOrderStatus";
    public static final String TXN_AMOUNT = "txnAmount";
    public static final String TXN_BANK_TXN_ID = "txnBankTxnId";
    public static final String TXN_DATE = "txnDate";
    public static final String REFUND_BANK_RESPONSE_CODE = "refundBankResponseCode";
    public static final String REFUND_AMOUNT_IN_INPUTFILE = "refundAmountInInputFile";
    public static final String REFUNDED = "refunded";
    public static final String MANUAL_REFUND_WALLET = "manual_refunds_wallet_";
    public static final String MANUAL_REFUND_WALLET_CONSOLIDATED = "manual_refunds_wallet_consolidated";
    public static final String CUST_ID = "custId";
    public static final String TXN_TYPE = "txnType";
    public static final String VPA = "vpa";
    public static final String TRACE_ID = "traceId";
    public static final String AUTH_CODE = "AuthCode";
    public static final String CARD_LAST_4DIGIT = "cardLast4Digit";

    public static final String[] MANUAL_REFUND_HEADER = { "id", "manualRefundType", "acquiringTxnId", "chargingEsn",
            "bankName", "mbid", "mid", "orderId", "orderStatus", "paymode", "txnBankTxnId", "txnDate", "txnAmount",
            "refundAmount", "refundAmountInInputFile", "refundTxnId", "refundBankTxnId", "refundDate", "refundEsn",
            "refundPaymentStatus", "refundType", "subBizOrderType", "subOrderStatus", "chargingReconStatus",
            "chargingSettlementFileDetailsId", "chargingDiscrepancyid", "refundReconStatus",
            "refundSettlementFileDetailsId", "refundDiscrepancyId", "refundBankResponseCode", "refunded", "custId",
            "txnType", "vpa", "traceId", "AuthCode", "cardLast4Digit" };

}
