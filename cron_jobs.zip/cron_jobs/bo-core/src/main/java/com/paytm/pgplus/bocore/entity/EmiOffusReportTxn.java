package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.csv.CSVRecord;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * 
 * @author dheerajtyagi
 *
 */

@Getter
@Setter
@ToString
@Entity
@Table(name = "emi_offus_report_txn")
@XmlRootElement
public class EmiOffusReportTxn implements Serializable {

    private static final long serialVersionUID = 1L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "EXT_SERIAL_NUM", length = 20)
    private String extSerialNum;

    @Column(name = "CARD_NO", length = 100)
    private String cardNo;

    @Column(name = "BANK_ABBR", length = 32)
    private String bankAbbr;

    @Column(name = "MERCHANT_TRANS_ID", length = 64)
    private String merchantTransId;

    @Column(name = "MBID", length = 32)
    private String mbid;

    @Column(name = "AUTH_CODE", length = 32)
    private String authCode;

    @Column(name = "RRN_CODE", length = 32)
    private String rrnCode;

    @Column(name = "EXCHANGE_CURRENCY", length = 3)
    private String exchangeCurrency;

    @Column(name = "EXCHANGE_AMOUNT", length = 32)
    private Long exchangeAmount;

    @Column(name = "CREATE_TIME", length = 14)
    private Date createTime;

    @Column(name = "EMI_TENURE_ID", length = 12)
    private String emiTenureId;

    @Column(name = "EMI_PLAN_ID", length = 12)
    private String emiPlanId;

    @Column(name = "EMI_MONTHS", length = 3)
    private Long emiMonths;

    @Column(name = "EMI_INTEREST", length = 6)
    private String emiInterest;

    @Column(name = "MERCHANT_NAME")
    private String merchantName;

    @Column(name = "BANK_REFERENCE_NO")
    private String bankReferenceNo;

    @Column(name = "ISSUING_BANK_CODE")
    private String issuingBankCode;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_on", nullable = false)
    private Date createdOn;

    @Basic(optional = false)
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedOn;

    @Column(name = "emi_file_update_status")
    private Integer emiFileUpdateStatus;

    @Column(name = "EMI_DATE")
    @Temporal(TemporalType.DATE)
    private Date emiDate;

    @Column(name = "ADDITIONAL_INFO")
    private String additionalInfo;

    @Column(name = "PAYMODE")
    private String payMode;

    @Column(name = "TRACE_NO")
    private String traceNum;

    @Transient
    private List<CSVRecord> corruptedRecords = new ArrayList<>();

    @Transient
    private boolean cardPresentEmi;

    @Transient
    private String bankTid;

    @Transient
    private String acquirer;

    // following are additional fields for brandEmi
    @Transient
    private String subvention;

    @Transient
    private String subventionAmount;

    @Transient
    private String address;

    @Transient
    private String storeCity;

    @Transient
    private String storeState;

    @Transient
    private String categoryName;

    @Transient
    private String modelName;

    @Transient
    private String additionalCashback;

    @Transient
    private String additionalCashbackAmount;

    @Transient
    private String maxCashbackAmount;

    @Transient
    private String productSerialNo;

    @Transient
    private String brandName;

    @Transient
    private String brandId;

    @Transient
    private String customerName;

    @Transient
    private String mobileNumber;

    @Transient
    private String bankInvoiceNumber;

    @Transient
    private String mid;

    // merchantName for POS(EDC) for brandEmi
    @Transient
    private String PosMerchantName;

    @Transient
    private String cardHash;

    @Transient
    private String emiType;

    @Transient
    private String paytmTid;

    @Transient
    private boolean isSubventionCreated;

    @Transient
    private boolean isBrandEmi;

    public EmiOffusReportTxn() {
    }
}
