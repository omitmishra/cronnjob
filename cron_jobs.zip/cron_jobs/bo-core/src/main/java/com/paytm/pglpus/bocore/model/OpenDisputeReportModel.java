package com.paytm.pglpus.bocore.model;

import com.paytm.pgplus.bocore.entity.DigitalOpsRefundHeader;
import com.paytm.pgplus.bocore.entity.OpenDisputeReportHeader;
import com.paytm.pgplus.bocore.enums.ChargebackSource;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.file.util.annotation.CsvColumnMapper;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author santoshkumar
 */

@Data
public class OpenDisputeReportModel {

    @CsvColumnMapper(columnName = OpenDisputeReportHeader.MID)
    private String mid;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPLAY_NAME)
    private String displayName;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.BUSINESS_NAME)
    private String businessName;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_ID)
    private String disputeId;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.ESN)
    private String esn;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_TYPE)
    private String disputeType;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_CREATION_DATE)
    private String disputeCreationDate;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_CREATED_TIME)
    private String disputeCreatedTime;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.TXN_DATE)
    private Date txnDate;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.TXN_AMOUNT)
    private BigDecimal txnAmount;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_AMOUNT)
    private BigDecimal disputeAmount;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.TXN_UTR)
    private String txnUtr;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_UTR)
    private String disputeUtr;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.TXN_ID)
    private String txnId;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.ORDER_ID)
    private String orderId;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_STATUS)
    private String disputeStatus;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.REASON_ACCEPTANCE)
    private String reasonAcceptance;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_UPDATE_DATE)
    private Date disputeUpdateDate;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.STATUS_COMMENT)
    private String comment;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DEFENCE_DOC1)
    private String defenceDoc1;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DEFENCE_DOC2)
    private String defenceDoc2;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.ONUS_OFFUS)
    private String onUSOffUS;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.SOURCE)
    private ChargebackSource source;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.BANK_REFERENCE_ID)
    private String bankReferenceId;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_PAYOUT_ID)
    private String disputePayoutId;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_DUE_DATE)
    private String disputeDueDate;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.BANK_GATEWAY)
    private String bankGateway;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_CLOSURE_DATE)
    private String closureDate;
    @CsvColumnMapper(columnName = OpenDisputeReportHeader.DISPUTE_LOST_DATE)
    private String lostDate;

}
