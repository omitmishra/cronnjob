package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by dheeraj on 18/01/18.
 */

@Getter
@Setter
@Data
@Entity
public class EscalationLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    @ManyToOne
    @JoinColumn
    Issue issue;

    @OneToOne
    @JoinColumn
    EscalationHierarchy escalationHierarchy;

    @ManyToOne
    @JoinColumn
    TeamMember oncallMember;

    @ManyToOne
    @JoinColumn
    Team oncallTeam;

    Date createdOn;
    Date updatedOn;

}
