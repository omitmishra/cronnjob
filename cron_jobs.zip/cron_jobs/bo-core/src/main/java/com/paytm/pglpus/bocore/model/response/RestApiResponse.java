package com.paytm.pglpus.bocore.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.paytm.pgplus.facade.common.model.ResultInfo;
import lombok.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RestApiResponse {
    ResultInfo resultInfo;
    Long count;
    Object response;
}