package com.paytm.pgplus.bocore.constants;

public class OpgspScheduledMerchantReportParser {
    public static final String TXN_ID = "TXN_ID";
    public static final String ORDER_ID = "OrderId";
    public static final String M_ID = "MID";
    public static final String TXN_AMT = "TxnAmount";
    public static final String REFUND_AMT = "RefundAmt";
    public static final String REF_ID = "REF ID";
    public static final String CHARGEBACK_AMT = "CB Amt";
    public static final String DISPUTE_ID = "disputeId";
    public static final String PARENT_TXN_ID = "PARENT_TXN_ID";

    public static final String[] REFUND_FILE_HEADER_MAPPING = { PARENT_TXN_ID, TXN_ID, ORDER_ID, REFUND_AMT, TXN_AMT,
            M_ID, REF_ID };
    public static final String[] CHARGEBACK_FILE_HEADER_MAPPING = { TXN_ID, ORDER_ID, CHARGEBACK_AMT, TXN_AMT, M_ID,
            DISPUTE_ID };

}
