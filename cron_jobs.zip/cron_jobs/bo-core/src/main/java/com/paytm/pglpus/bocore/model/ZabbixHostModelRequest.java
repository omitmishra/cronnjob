package com.paytm.pglpus.bocore.model;

import lombok.Data;

import java.util.List;

/**
 * Created by dheeraj on 27/01/18.
 */

@Data
public class ZabbixHostModelRequest {

    String prefix;
    List<ZabbixHostModel> zabbixHostModelList;
}
