package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.EXISTING_PROPERTY, property = "emailConfigType")
@JsonSubTypes({ @JsonSubTypes.Type(value = ImplicitEmailConfig.class, name = "IMPLICIT"),
        @JsonSubTypes.Type(value = ExplicitEmailConfig.class, name = "EXPLICIT") })
@JsonIgnoreProperties(value = { "retryAllowed" })
public abstract class EmailConfig implements Serializable {

    @NotNull
    private EmailConfigType emailConfigType;

    private Integer retryAllowed;

    public EmailConfig(EmailConfigType emailConfigType) {
        this.emailConfigType = emailConfigType;
    }
}
