package com.paytm.pgplus.bocore.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.paytm.pgplus.bocore.enums.CronStatus;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author honeyduhar
 *
 */
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "cron_details")
public class CronDetail extends BaseEntity {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "CRON_NAME")
    private String cronName;

    @Column(name = "TOTAL_FILES")
    private Integer totalFiles;

    @Column(name = "SUCCESS_FILES")
    private Integer successFiles;

    @Column(name = "FAIL_FILES")
    private Integer failedFiles;

    @Column(name = "OVERALL_STATUS")
    @Enumerated(EnumType.STRING)
    private CronStatus overallStatus;

    @OneToMany(mappedBy = "cronDetail")
    private List<CronFileDetails> cronFileDetails;

    @Column(name = "CRON_RAN_FOR_DATE")
    private Date cronRanForDate;

    public CronDetail(String cronName, CronStatus overallStatus) {
        this.cronName = cronName;
        this.overallStatus = overallStatus;
    }

}
