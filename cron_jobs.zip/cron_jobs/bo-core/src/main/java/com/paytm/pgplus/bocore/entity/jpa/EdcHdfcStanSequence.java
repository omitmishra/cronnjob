package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "edc_hdfc_stan_sequence")
@Data
public class EdcHdfcStanSequence implements Serializable {

    private static final long serialVersionUID = 1306951146418394822L;

    @Column(name = "stan_num")
    long stan_num;

    @Id
    @Column(name = "bank_tid")
    private String bankTid;

    @UpdateTimestamp
    @Column(name = "updated_on")
    private Date updatedOn;
}