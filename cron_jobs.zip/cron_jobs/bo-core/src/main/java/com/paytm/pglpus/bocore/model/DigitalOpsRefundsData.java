package com.paytm.pglpus.bocore.model;

import com.paytm.pgplus.bocore.entity.DigitalOpsRefundHeader;
import lombok.Getter;
import lombok.Setter;
import org.file.util.annotation.CsvColumnMapper;

/**
 * Created by ishasinghal on 23/10/17.
 */

@Setter
@Getter
public class DigitalOpsRefundsData {

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.BANK_NAME)
    String bankName;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.MID)
    String mid;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_ID)
    String txnId;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_TXN_ID)
    String refundTxnId;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.MBID)
    String mbid;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_DATE)
    String txnDate;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_DATE)
    String refundDate;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_AMOUNT)
    String txnAmount;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_AMOUNT)
    String refundAmount;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.PAYMODE)
    String paymode;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_BANK_TXN_ID)
    String refundBankTxnId;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_BANK_TXN_ID)
    String txnBankTxnId;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.AGE)
    String age;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_TYPE)
    String refundType;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.CHARGING_ESN)
    String chargingEsn;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_ESN)
    String refundEsn;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TRACE_ID)
    String traceId;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.AUTH_CODE)
    String authCode;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.CARD_LAST_4DIGIT)
    String cardLast4Digit;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.ORDER_ID)
    String orderId;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.CUST_ID)
    String custId;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_BANK_RESPONSE_CODE)
    String refundBankResponseCode;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.STATUS)
    String status;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.DIGITAL_OPS_TEAM_STATUS)
    String digitalOpsTeamStatus;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.DIGITAL_OPS_TEAM_REMARK)
    String digitalOpsTeamRemark;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_ID)
    String refundId;
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_TYPE)
    String txnType;
    String createdOn;
    String updatedOn;
    String vpa;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_MBID)
    String refundMbid;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.BUSINESS_TYPE_NEW)
    String businessType;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.RESULT_STATUS_NEW)
    String resultStatus;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_DESTINATION_TYPE)
    String refundDestinationType;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_DESTINATION_MODE)
    String refundDestinationMode;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_ISSUING_BANK)
    String refundIssuingBank;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TRANSACTION_ISSUING_BANK)
    String transactionIssuingBank;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TRANSACTION_ACQUIRING_BANK_NAME)
    String transactionAcquiringBankName;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TROUBLE_ID)
    String troubleId;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.IFSC_CODE)
    String ifscCode;

}
