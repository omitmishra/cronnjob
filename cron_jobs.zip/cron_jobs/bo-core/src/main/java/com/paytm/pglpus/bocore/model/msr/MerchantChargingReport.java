package com.paytm.pglpus.bocore.model.msr;

import com.paytm.pgplus.bocore.constants.MSRBillFileColumn;
import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import com.paytm.pgplus.bocore.enums.TransactionType;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import com.paytm.pgplus.bocore.util.csv.converter.deserializer.BigDecimalConverter;
import com.paytm.pgplus.bocore.util.csv.converter.deserializer.DateConverter;
import lombok.Data;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.Date;

@Data
@ToString
public class MerchantChargingReport extends MerchantSettlementReport {

    private static final long serialVersionUID = -2571800672083821784L;

    @CSVColumn(name = MSRBillFileColumn.TXN_ID)
    private String txnId;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date paymentDate;

    @CSVColumn(name = MSRBillFileColumn.ALIPAY_MID)
    private String mid;

    @CSVColumn(name = MSRBillFileColumn.PAYTM_MID)
    private String originalMID;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_NAME)
    private String merchantName;

    @CSVColumn(name = MSRBillFileColumn.CLEARING_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date clearingDate;

    @CSVColumn(name = MSRBillFileColumn.TERMINAL_TYPE)
    private String terminalType;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal paymentAmount;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_CURRENCY)
    private String paymentCurrency;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_COMMISSION, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal merchantCommission;

    @CSVColumn(name = MSRBillFileColumn.SERVICE_TAX, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal serviceTax;

    @CSVColumn(name = MSRBillFileColumn.SETTLEMENT_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal settlementAmount;

    @CSVColumn(name = MSRBillFileColumn.ORDER_ID)
    private String orderId;

    @CSVColumn(name = MSRBillFileColumn.PAY_METHOD)
    private String paymentMethod;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_CUST_ID)
    private String merchantCustId;

    @CSVColumn(name = MSRBillFileColumn.ISSUING_BANK)
    private String issuingBank;

    @CSVColumn(name = MSRBillFileColumn.STATUS)
    private String status;

    @CSVColumn(name = MSRBillFileColumn.SETTLEMENT_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = {
            MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD, MSRBillFileColumn.FILE_DATE_TIME_FORMAT_1 }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date settlementDate;

    @CSVColumn(name = MSRBillFileColumn.SETTLED_BANK_TXN_ID)
    private String settlementBankTxnId;

    @CSVColumn(name = MSRBillFileColumn.SETTLED_TXN_ID)
    private String settlementTxnId;

    private Long fileId;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_BILL_ID)
    private String merchantBillId;

    @CSVColumn(name = MSRBillFileColumn.PRN_CODE)
    private String prnCode;

    @CSVColumn(name = MSRBillFileColumn.COMMISSION_RATE)
    private String commissionRate;

    @CSVColumn(name = MSRBillFileColumn.GMV_TIER)
    private String gmvTier;

    @CSVColumn(name = MSRBillFileColumn.TRANSACTION_SLAB)
    private String transactionSlab;

    @CSVColumn(name = MSRBillFileColumn.ALIPAY_PRODUCT_CODE)
    private String alipayProductCode;

    @CSVColumn(name = MSRBillFileColumn.REQUEST_TYPE)
    private String requestType;

    @CSVColumn(name = MSRBillFileColumn.SPLIT_ID)
    private String splitId;

    @CSVColumn(name = MSRBillFileColumn.ORIG_TXN_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal originalTxnAmount;

    @CSVColumn(name = MSRBillFileColumn.IS_SPLIT_PAYMENT)
    private String isSplitPayment;

    @CSVColumn(name = MSRBillFileColumn.SUB_TRANSACTION_TYPE)
    private String subTransactionType;

    @CSVColumn(name = MSRBillFileColumn.CARD_SCHEME)
    private String cardScheme;

    @CSVColumn(name = MSRBillFileColumn.FEE_FACTOR)
    private String feeFactor;

    @CSVColumn(name = MSRBillFileColumn.ACQUIRING_SERVICE_FEE, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal acquiringServiceFee;

    @CSVColumn(name = MSRBillFileColumn.ACQUIRING_SERVICE_TAX, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal acquiringServiceTax;

    @CSVColumn(name = MSRBillFileColumn.PLATFORM_SERVICE_FEE, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal platformServiceFee;

    @CSVColumn(name = MSRBillFileColumn.PLATFORM_SERVICE_TAX, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal platformServiceTax;

    @CSVColumn(name = MSRBillFileColumn.RESELLER_ID)
    private String resellerId;

    @CSVColumn(name = MSRBillFileColumn.RESELLER_NAME)
    private String resellerName;

    @CSVColumn(name = MSRBillFileColumn.VAN)
    private String van;

    @CSVColumn(name = MSRBillFileColumn.IFSC_CODE)
    private String ifscCode;

    @CSVColumn(name = MSRBillFileColumn.BANK_NAME)
    private String bankName;

    @CSVColumn(name = MSRBillFileColumn.BENEFICIARY_NAME)
    private String beneficiaryName;

    @CSVColumn(name = MSRBillFileColumn.PURPOSE)
    private String purpose;

    @CSVColumn(name = MSRBillFileColumn.ISSUING_BANK_ID)
    private String issuingBankId;

    @CSVColumn(name = MSRBillFileColumn.ISSUING_BANK_NAME)
    private String issuingBankName;

    @CSVColumn(name = MSRBillFileColumn.MASKED_CARD_NO)
    private String maskedCardNo;

    @CSVColumn(name = MSRBillFileColumn.INST_UNION_CODE)
    private String instUnionCode;

    @CSVColumn(name = MSRBillFileColumn.DEPOSITOR_NAME)
    private String depositorName;

    @CSVColumn(name = MSRBillFileColumn.TRANSFER_MODE)
    private String transferMode;

    @CSVColumn(name = MSRBillFileColumn.TRANSACTION_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = {
            MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD, MSRBillFileColumn.FILE_DATE_TIME_FORMAT_1 }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date transactionDate;

    @CSVColumn(name = MSRBillFileColumn.RRN_CODE)
    private String rrnCode;

    @CSVColumn(name = MSRBillFileColumn.UDF1)
    private String udf1;

    @CSVColumn(name = MSRBillFileColumn.UDF2)
    private String udf2;

    @CSVColumn(name = MSRBillFileColumn.UDF3)
    private String udf3;

    @CSVColumn(name = MSRBillFileColumn.UDF4)
    private String udf4;

    @CSVColumn(name = MSRBillFileColumn.UDF5)
    private String udf5;

    @CSVColumn(name = MSRBillFileColumn.REFERENCE_NO)
    private String referenceNo;

    public MerchantChargingReport() {
        super(TransactionType.PAYMENT, MerchantSettlementReportType.CHARGING);
    }

    @Override
    public BigDecimal getTotalAmount() {
        return this.settlementAmount;
    }

    @Override
    public BigDecimal getTransactionAmount() {
        return this.paymentAmount;
    }

    @Override
    public String getPayoutId() {
        return this.settlementTxnId;
    }

    @Override
    public String getUtr() {
        return this.settlementBankTxnId;
    }

    @Override
    public String getPaytmMerchantId() {
        return this.originalMID;
    }
}
