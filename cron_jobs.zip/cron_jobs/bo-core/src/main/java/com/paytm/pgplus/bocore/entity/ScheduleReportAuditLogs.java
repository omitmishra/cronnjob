package com.paytm.pgplus.bocore.entity;

import com.paytm.pgplus.bocore.enums.EmailStatus;
import com.paytm.pgplus.bocore.enums.ReportType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "schedule_report_audit_logs")
public class ScheduleReportAuditLogs extends BaseEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "download_id")
    private String downloadId;

    @Column(name = "report_type")
    @Enumerated(EnumType.STRING)
    private ReportType reportType;

    // report_type_id is id of the source for which report is scheduled (e.g
    // merchantId, bankId)
    @Column(name = "report_type_id")
    private String reportTypeId;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "download_url")
    private String downloadUrl;

    @Column(name = "db_txn_count")
    private Long dbTxnCount;

    @Column(name = "file_txn_count")
    private Long fileTxnCount;

    @Column(name = "db_sum_amount")
    private Double dbSumAmt;

    @Column(name = "file_sum_amount")
    private Double fileSumAmt;

    @Column(name = "email_ids_to")
    private String emailIdsTo;

    @Column(name = "email_ids_cc")
    private String emailIdsCc;

    @Column(name = "email_subject")
    private String emailSubject;

    @Column(name = "email_status")
    @Enumerated(EnumType.STRING)
    private EmailStatus emailStatus;

    @Column(name = "no_of_retry_allowed")
    private Integer numberOfRetryAllowed;

    @Column(name = "no_of_retry_used")
    private Integer numberOfRetryUsed;

    @Column(name = "email_body")
    private String emailBody;

}
