package com.paytm.pgplus.bocore.entity.jpa;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.paytm.pgplus.bocore.constants.EDCConstants;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import lombok.*;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.hibernate.validator.constraints.NotBlank;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @author akash8.singh@paytm.com
 */

@Entity
@Table(name = "edc_banks_batch_upload")
@Getter
@Setter
public class EdcHdfcBatchUploadRequest extends EdcHdfcBaseRquest implements Serializable {

    @Column(name = "processing_code")
    @CSVColumn(name = EDCConstants.PROCESSING_CODE)
    @NotBlank(message = "processing code should not be blank")
    private String processingCode;

    @Column(name = "transaction_amount")
    @CSVColumn(name = EDCConstants.TRANSACTION_AMOUNT)
    @NotBlank(message = "Amount must not be blank")
    private String transactionAmount;

    @Column(name = EDCConstants.STAN)
    @CSVColumn(name = EDCConstants.STAN)
    @NotBlank(message = "stan should not be blank")
    private String stan;

    @Column(name = "transaction_time")
    @CSVColumn(name = EDCConstants.TRANSACTION_TIME)
    @NotBlank(message = "transactionTime must not be blank")
    private String transactionTime;

    @Column(name = "transaction_date")
    @CSVColumn(name = EDCConstants.TRANSACTION_DATE)
    @NotBlank(message = "transactionDate must not be blank")
    private String transactionDate;

    @Column(name = "pos_entry_mode")
    @CSVColumn(name = EDCConstants.POS_ENTRY_MODE)
    @NotBlank(message = "pos entry mode must not be blank")
    private String posEntryMode;

    @Column(name = "pos_condition_code")
    @CSVColumn(name = EDCConstants.POS_CONDITION_CODE)
    @NotBlank(message = "pos condition code must not be blank")
    private String posConditionCode;

    @Column(name = "rrn_code")
    @CSVColumn(name = EDCConstants.RRN_CODE)
    @NotBlank(message = "rrnCode code must not be blank")
    private String rrnCode;

    @Column(name = "auth_code")
    @CSVColumn(name = EDCConstants.AUTH_CODE)
    @NotBlank(message = "authorizationCode code must not be blank")
    private String authCode;

    @Column(name = "result_code")
    @CSVColumn(name = EDCConstants.RESULT_CODE)
    private String resultCode;

    @Column(name = "result_code_id")
    @CSVColumn(name = EDCConstants.RESULT_CODE_ID)
    private String resultCodeId;

    @Column(name = "result_msg")
    @CSVColumn(name = EDCConstants.RESULT_MSG)
    private String resultMsg;

    @Column(name = "bank_tid")
    @CSVColumn(name = EDCConstants.BANK_TID)
    @NotBlank(message = "terminal id must not be blank")
    private String bankTid;

    @Column(name = "mbid")
    @CSVColumn(name = EDCConstants.MBID)
    @NotBlank(message = "bank merchant id must not be blank")
    private String mbid;

    @Column(name = "icc_data")
    @CSVColumn(name = EDCConstants.ICC_DATA)
    private String iccData;

    @Column(name = "invoice_number")
    @CSVColumn(name = EDCConstants.INVOICE_NUMBER)
    @NotBlank(message = "Invoice Number must not be blank")
    private String invoiceNumber;

    @Column(name = "pay_method")
    @CSVColumn(name = EDCConstants.PAY_MODE)
    private String payMethod;

    @Column(name = "external_serial_no")
    @CSVColumn(name = EDCConstants.EXTERNAL_SERIAL_NUMBER)
    @NotBlank(message = "external_serial_no id must not be blank")
    private String externalSerialNo;

    @Column(name = "service_inst_id")
    @CSVColumn(name = EDCConstants.SERVICE_INST_ID)
    @NotBlank(message = "service_inst_id id must not be blank")
    private String serviceInstId;

    @Column(name = "bank_abbr")
    @CSVColumn(name = EDCConstants.BANK_ABBR)
    private String bankAbbr;

    @Id
    @Column(name = "merchant_trans_id")
    @NotBlank(message = "merchant_trans_id id must not be blank")
    @CSVColumn(name = EDCConstants.MERCHANT_TRANS_ID)
    private String merchantTransId;

    @Column(name = "transaction_type")
    @CSVColumn(name = EDCConstants.TRANSACTION_TYPE)
    @NotBlank(message = "transaction_type must not be blank")
    private String transactionType;

    @Column(name = "bank_code")
    @CSVColumn(name = EDCConstants.BANK_CODE)
    @NotBlank(message = "bank_code must not be blank")
    private String bankCode;

    @Column(name = "txn_time")
    @CSVColumn(name = EDCConstants.TXN_TIME)
    @NotBlank(message = "txn_time must not be blank")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private String txnTime;

    @Column(name = "client_id")
    @CSVColumn(name = EDCConstants.CLIENT_ID)
    @NotBlank(message = "client_id must not be blank")
    private String clientId;

    @Column(name = "txn_upload_status")
    private String txnUploadStatus;

    @Column(name = "settlement_id")
    private String edcBankSettlementId;

    @Column(name = "bank_mid")
    private String bankMid;

    @Column(name = "paytm_tid")
    private String paytmTid;

    @Transient
    private long uniqueStan;

    @ToString.Exclude
    @LazyCollection(LazyCollectionOption.FALSE)
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "edcHdfcBatchUploadRequest")
    private EdcHdfcSensitiveDataRequest edcHdfcSensitiveDataRequest;
}
