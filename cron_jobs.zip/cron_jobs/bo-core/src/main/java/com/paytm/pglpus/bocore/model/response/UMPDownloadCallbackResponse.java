package com.paytm.pglpus.bocore.model.response;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * This class represents response for download callback api by UMP. It has
 * status as SUCCESS/FAILURE.
 *
 * @author nitinbhola27
 *
 */

@Getter
@Setter
@NoArgsConstructor
@ToString
public class UMPDownloadCallbackResponse {
    private String status;
    private String statusCode;
    private String statusMessage;
}
