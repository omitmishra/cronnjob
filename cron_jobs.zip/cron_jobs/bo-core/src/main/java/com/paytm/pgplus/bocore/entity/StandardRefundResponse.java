package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;
import javax.xml.bind.annotation.XmlRootElement;

import org.file.util.annotation.CsvColumnMapper;

import com.paytm.pgplus.bocore.constants.DiscrepancyCsvFileHeadersConstant;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Entity model class for STANDARD_REFUND_RESPONSE table.
 * 
 * @author Kulbhushan Pandey
 *
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Entity
@Table(name = "STANDARD_REFUND_RESPONSE")
@XmlRootElement
public class StandardRefundResponse extends BaseEntity implements Serializable {
    /**
	 * 
	 */
    private static final long serialVersionUID = 5882706777523753414L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.ALIPAY_BIZ_ORDER_ID)
    @Column(name = "ALIPAY_BIZ_ORDER_ID", length = 64)
    private String alipayBizOrderId;

    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.ORI_EXT_SERIAL_NO)
    @Column(name = "ORI_EXTSERIAL_NO", length = 20)
    private String oriExtSerialNo;

    @Column(name = "RRN_CODE", length = 32)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.RRN_CODE)
    private String rrnCode;

    @Column(name = "BANK_REFERENCE_NO", length = 32)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.BANK_REFERENCE_NO)
    private String bankReferenceNo;

    @Column(name = "REFUND_STATUS", length = 32, nullable = false)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.REFUND_STATUS)
    private String refundStatus;

    @Column(name = "REFUND_DATE", length = 20, nullable = false)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.REFUND_DATE)
    private String refundDate;

    @Column(name = "MEMO", length = 1024, nullable = false)
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.MEMO)
    private String memo;

    @Column(name = "IS_SENT_IN_FILE", nullable = false)
    private Integer isSentInFile;

    @Column(name = "FILE_SENT_DATE", length = 20)
    private Date fileSentDate;

    // JIRA-PGP-13421
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.PHONE_NUMBER)
    private String phoneNumber;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.ESN)
    private String esn;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.SERVICE_INSTANCE_ID)
    private String serviceInstId;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.MBID)
    private String mbid;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.PAY_METHOD)
    private String payMethod;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.MASKED_CARD_NUMBER)
    private String maskedCardNumber;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.VPA)
    private String vpa;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.ISSUING_BANK_NAME)
    private String issuingBankName;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.TROUBLE_ID)
    private String troubleId;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.REFUND_TYPE)
    private String refundType;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.CARD_SCHEME)
    private String cardScheme;
    @Transient
    @CsvColumnMapper(columnName = DiscrepancyCsvFileHeadersConstant.CUSTOMER_Id)
    private String customerId;

}
