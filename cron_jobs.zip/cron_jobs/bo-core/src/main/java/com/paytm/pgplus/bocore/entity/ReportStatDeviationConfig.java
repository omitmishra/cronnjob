package com.paytm.pgplus.bocore.entity;

import com.paytm.pgplus.bocore.enums.ReportType;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;

@ToString
@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "report_stat_deviation_config")
public class ReportStatDeviationConfig implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "report_type")
    @Enumerated(EnumType.STRING)
    private ReportType reportType;

    // report_type_id is id of the source for which report is scheduled (e.g
    // merchantId, bankId)
    @Column(name = "report_type_id")
    private String reportTypeId;

    @Column(name = "threshold_max_count")
    private Integer thresholdMaxCount;

    @Column(name = "threshold_max_amount")
    private Double thresholdMaxAmount;

    // this represents deviation percentage allowed from configured threshold on
    // count
    @Column(name = "threshold_min_count")
    private Integer thresholdMinCount;

    @Column(name = "threshold_min_amount")
    private Integer thresholdMinAmt;

}
