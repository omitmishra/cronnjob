package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "edc_hdfc_batch_sequence")
@Data
public class EdcHdfcBatchSequence implements Serializable {

    private static final long serialVersionUID = 1300951146418394822L;

    @Column(name = "batch_num")
    long batch_num;

    @Id
    @Column(name = "bank_tid")
    private String bankTid;

    @Column(name = "created_on")
    private Date createdOn;
}
