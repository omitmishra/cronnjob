package com.paytm.pglpus.bocore.model.response;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pglpus.bocore.model.request.DiscrepancyAdjustHttpReq;

@JsonIgnoreProperties
public class DiscrepancyAdjustHttpRes {

    private String RespCode;
    private String errorMsg;
    private List<Map<DiscrepancyAdjustHttpReq, Exception>> errorList;

    public DiscrepancyAdjustHttpRes() {
        super();
    }

    public DiscrepancyAdjustHttpRes(String respCode, String errorMsg) {
        super();
        this.RespCode = respCode;
        this.errorMsg = errorMsg;
    }

    public DiscrepancyAdjustHttpRes(String respCode, String errorMsg,
            List<Map<DiscrepancyAdjustHttpReq, Exception>> errorList) {
        super();
        this.RespCode = respCode;
        this.errorMsg = errorMsg;
        this.errorList = errorList;
    }

    public String getRespCode() {
        return RespCode;
    }

    public void setRespCode(String respCode) {
        RespCode = respCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public List<Map<DiscrepancyAdjustHttpReq, Exception>> getErrorList() {
        return errorList;
    }

    public void setErrorList(List<Map<DiscrepancyAdjustHttpReq, Exception>> errorList) {
        this.errorList = errorList;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("ManualAdjustmentResponse [RespCode=").append(RespCode).append(", errorMsg=").append(errorMsg)
                .append(", errorList=").append(errorList).append("]");
        return builder.toString();
    }

}
