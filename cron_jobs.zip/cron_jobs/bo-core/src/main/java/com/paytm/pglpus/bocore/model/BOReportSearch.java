package com.paytm.pglpus.bocore.model;

import com.paytm.pglpus.bocore.model.scheduled.merchant.report.PaymentMode;
import com.paytm.pgplus.bocore.enums.MSRRunTriggerType;
import com.paytm.pgplus.bocore.enums.MSRSettlementType;
import com.paytm.pgplus.facade.common.model.CustomReportColumn;
import com.paytm.pgplus.facade.dataservice.enums.BizOrderType;
import com.paytm.pgplus.facade.dataservice.enums.SubBizOrderType;
import com.paytm.pgplus.facade.dataservice.enums.SyncScenarioId;
import lombok.Data;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Data
public class BOReportSearch {

    private List<SearchParameter> searchConditions;

    private String orderStatus;
    private String startDate;
    private String endDate;
    private String settleStartDate;
    private String settleEndDate;
    private String orderSettledCompletedStartTime;
    private String orderSettledCompletedEndTime;
    private String utrUpdatedStartTime;
    private String utrUpdatedEndTime;
    private String downloadFileType;
    private String requestSource;
    private SearchType searchType;
    private Date startDueDate;
    private Date endDueDate;
    private String columnsName;
    private SyncScenarioId scenarioId;
    private List<BizOrderType> bizOrderTypeList;
    private List<SubBizOrderType> subBizOrderTypes;

    private String columnDelimiter;
    private String columnWrapper;
    private Map<String, String> columnNameToFormatterMap;
    private Map<String, ScheduledMerchantReportFormatter> columnCustomValueFormatter;
    private Map<String, ScheduledMerchantReportRowFilter> rowFilterMap;
    private List<CustomReportColumn> customReportColumnList;
    private PaymentMode paymentMode;
    private ScheduledMerchantReportAdhocEventPayload scheduledMerchantReportAdhocEventPayload;
    private long scheduledMerchantReportPayoutInfoId;
    private MSRRunTriggerType msrRunTriggerType;
    private MSRSettlementType settlementType;
    private Long recordId;

    public BOReportSearch() {
        super();
        searchConditions = new ArrayList<>();
    }

}
