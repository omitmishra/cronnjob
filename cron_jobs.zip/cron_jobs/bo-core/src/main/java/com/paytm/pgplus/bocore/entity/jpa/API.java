package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "sla_api")
public class API {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long apiId;
    String apiName;
    String productCode;
    Long serviceId;
    String description;
    String createdOn;
    String updatedOn;
}
