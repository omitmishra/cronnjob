/**
 *
 */
package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @author Shubham Goyal
 *
 */
@Getter
@Setter
@ToString
@Entity
@Table(name = "settlement_status_report_file")
public class SettlementStatusReportTable implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bank_name")
    private String bankName;

    @Column(name = "closed_count")
    private Long closedCount;

    @Column(name = "closed_total_amount")
    private BigDecimal closedTotalAmount;

    @Column(name = "failed_count")
    private Long failedCount;

    @Column(name = "failed_total_amount")
    private BigDecimal failedTotalAmount;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "file_type")
    private int fileType;

    @Column(name = "paytm_pending_amount")
    private BigDecimal paytmPendingAmount;

    @Column(name = "paytm_total_amount")
    private BigDecimal paytmTotalAmount;

    @Column(name = "pending_count")
    private Long pendingCount;

    @Column(name = "sftp_alipay_file")
    private boolean sftpAlipayFile;

    @Column(name = "sftp_paytm_file")
    private boolean sftpPaytmFile;

    @Column(name = "status")
    private Short status;

    @Column(name = "status_message")
    private String statusMessage;

    @Column(name = "success_count")
    private Long successCount;

    @Column(name = "success_total_amount")
    private BigDecimal successTotalAmount;

    @Column(name = "total_row")
    private Long totalRow;

    @Column(name = "upload_timestamp")
    private Date uploadTimestamp;

    @Column(name = "has_child")
    private Boolean hasChild;

    @Column(name = "is_child")
    private Boolean isChild;

    @Column(name = "biz_type")
    private String bizType;

    @Column(name = "refund_type")
    private Long refundType;
}