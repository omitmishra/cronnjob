package com.paytm.pglpus.bocore.model.merchantReportEvents.eventconfig;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class HttpConfig {
    String url;
    HttpMethod httpMethod;
    @JsonDeserialize(using = MediaTypeDeserializer.class)
    MediaType mediaType;
}
