package com.paytm.pgplus.bocore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.paytm.pgplus.bocore.enums.FileStatus;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * @author honeyduhar
 *
 */
@Setter
@Getter
@ToString
@NoArgsConstructor
@Entity
@Table(name = "cron_file_details")
public class CronFileDetails extends BaseEntity {

    /**
	 * 
	 */
    private static final long serialVersionUID = 8375457202305840911L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "TOTAL_RECORDS")
    private Long totalRecords;

    @Column(name = "SUCCESS_RECORDS")
    private Long successRecords;

    @Column(name = "FAIL_RECORDS")
    private Long failedRecords;

    @Column(name = "FILE_STATUS")
    @Enumerated(EnumType.STRING)
    private FileStatus fileStatus;

    @Column(name = "FILE_DIR_PATH")
    private String fileDirPath;

    @ManyToOne
    @JoinColumn(name = "CRON_DETAIL_ID", nullable = false)
    private CronDetail cronDetail;

    public CronFileDetails(Long totalRecords, Long successRecords, Long failedRecords, FileStatus fileStatus) {
        this.totalRecords = totalRecords;
        this.successRecords = successRecords;
        this.failedRecords = failedRecords;
        this.fileStatus = fileStatus;
    }

    public CronFileDetails(String fileName, String fileDirPath) {
        this.fileName = fileName;
        this.fileDirPath = fileDirPath;
        this.failedRecords = 0l;
        this.successRecords = 0l;
        this.totalRecords = 0l;
    }
}
