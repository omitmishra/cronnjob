package com.paytm.pgplus.bocore.entity;

import java.math.BigDecimal;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author Lalit Mehra
 * @since March 4, 2016
 */
@Entity
@Table(name = "PGPLUS_REPORT_RECON_SUMMARY")
@XmlRootElement
public class AlipayReconSummary extends BaseEntity {

    private static final long serialVersionUID = 1798473027740131394L;

    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "FILE_NAME")
    private String fileName;

    @Column(name = "DISCREPANCY_COUNT")
    private Integer discrepancyCount;

    @Column(name = "DUPLICATE_COUNT")
    private Integer duplicateCount;

    @Column(name = "DISCREPANCY_SUM")
    private BigDecimal discrepancySum;

    @Column(name = "DUPLICATE_SUM")
    private BigDecimal duplicateSum;

    public AlipayReconSummary() {
        super();
        this.discrepancyCount = 0;
        this.discrepancySum = new BigDecimal(0);
        this.duplicateCount = 0;
        this.duplicateSum = new BigDecimal(0);
    }

    public long getId() {
        return id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getDiscrepancyCount() {
        return discrepancyCount;
    }

    public Integer getDuplicateCount() {
        return duplicateCount;
    }

    public BigDecimal getDiscrepancySum() {
        return discrepancySum;
    }

    public BigDecimal getDuplicateSum() {
        return duplicateSum;
    }

    public void incrementDiscrepancySumByX(BigDecimal x) {
        this.discrepancySum = this.discrepancySum.add(x);
    }

    public void incrementDiscrepancyCountBy1() {
        this.discrepancyCount += 1;
    }

    public void incrementDuplicateSumByX(BigDecimal x) {
        this.duplicateSum = this.duplicateSum.add(x);
    }

    public void incrementDuplicateCountBy1() {
        this.duplicateCount += 1;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AlipayReconSummary [id=");
        builder.append(id);
        builder.append(", fileName=");
        builder.append(fileName);
        builder.append(", discrepancyCount=");
        builder.append(discrepancyCount);
        builder.append(", duplicateCount=");
        builder.append(duplicateCount);
        builder.append(", discrepancySum=");
        builder.append(discrepancySum);
        builder.append(", duplicateSum=");
        builder.append(duplicateSum);
        builder.append(", createdOn=");
        builder.append(createdOn);
        builder.append(", updatedOn=");
        builder.append(updatedOn);
        builder.append("]");
        return builder.toString();
    }

}
