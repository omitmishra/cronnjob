package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.Date;

@Data
public abstract class ScheduledMerchantReportDayWiseBasedDynamicData extends
        ScheduledMerchantReportModularityBasedDynamicData {

    @Min(0)
    @Max(1440)
    private int startMinute;

    @Min(0)
    @Max(1440)
    private Integer reportTriggerTimeInMinute;

    public ScheduledMerchantReportDayWiseBasedDynamicData(ReportGenerationModularityForDynamicData dayWiseContinuity) {
        super(dayWiseContinuity);
    }

    protected Date getReportTriggerTime(Date currentDate) {
        return super.getReportTriggerTime(currentDate, this.reportTriggerTimeInMinute);
    }
}
