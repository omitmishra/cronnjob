package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.paytm.pgplus.bocore.constants.FileProcessingStatus;
import com.paytm.pgplus.bocore.constants.OfflineRefundFile;

/**
 * @author Himanshu Sardana
 * @since 05 Feb 2016
 *
 */
@Entity
@Table(name = "offline_refund_request_file_details")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = "OfflineRefundFileDetails.findByFileName", query = "SELECT o FROM OfflineRefundFileDetails o WHERE o.fileName = :fileName"),
        @NamedQuery(name = "OfflineRefundFileDetails.findByFileId", query = "SELECT o FROM OfflineRefundFileDetails o WHERE o.id = :fileId") })
public class OfflineRefundFileDetails implements Serializable {
    /**
	 * 
	 */
    private static final long serialVersionUID = 3638378349235211944L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name", length = 255)
    private String fileName;

    @Column(name = "file_path", length = 255)
    private String filePath;

    @Column(name = "success_records", length = 20)
    private Long successRecords;

    @Column(name = "failure_records", length = 20)
    private Long failureRecords;

    @Column(name = "total_records", length = 20)
    private Long totalRecords;

    @Column(name = "app_id", length = 20)
    private String appId;

    @Column(name = "result_file_name", length = 50)
    private String resultFileName;

    @Column(name = "file_batch_number", length = 50)
    private String filebatchNumber;

    public OfflineRefundFileDetails() {

    }

    public OfflineRefundFileDetails(OfflineRefundFile refundFile, FileProcessingStatus fileStatus) {
        super();
        this.fileName = refundFile.getFileName();
        this.filePath = refundFile.getFileParent();
        this.failureRecords = 0L;
        this.successRecords = 0L;
        this.totalRecords = 0L;
        this.filebatchNumber = refundFile.getFileSeq();
        this.statusCode = fileStatus.getCode();
        this.status = fileStatus.getMessage();
        Date d = new Date();
        this.createdOn = d;
        this.updatedOn = d;

    }

    @Column(name = "status_code", length = 20)
    private Short statusCode;

    @Column(name = "status", length = 20)
    private String status;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_on", nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private Date createdOn;

    @Basic(optional = false)
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private Date updatedOn;

    public Long getId() {
        return id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public Long getSuccessRecords() {
        return successRecords;
    }

    public void setSuccessRecords(long successRecords) {
        this.successRecords = successRecords;
    }

    public Long getFailureRecords() {
        return failureRecords;
    }

    public void setFailureRecords(long failureRecords) {
        this.failureRecords = failureRecords;
    }

    public Long getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(long totalRecords) {
        this.totalRecords = totalRecords;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getResultFileName() {
        return resultFileName;
    }

    public void setResultFileName(String resultFileName) {
        this.resultFileName = resultFileName;
    }

    public String getFilebatchNumber() {
        return filebatchNumber;
    }

    public void setFilebatchNumber(String filebatchNumber) {
        this.filebatchNumber = filebatchNumber;
    }

    public Short getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(short statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

}
