package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name = "settlement_file_processed_details")
@NamedQueries({
        @NamedQuery(name = "SettlementFileUploadDetails.getFileDetails", query = "SELECT c FROM SettlementFileUploadDetails c WHERE c.fileName=:fileName "),
        @NamedQuery(name = "SettlementFileUploadDetails.getFileDetailsForAlipayFiles", query = "SELECT c FROM SettlementFileUploadDetails c WHERE c.alipayTxnFile in ( :alipayFileNameList) "),
        @NamedQuery(name = "SettlementFileUploadDetails.getFileDetailsUploadedAfter", query = "SELECT c FROM SettlementFileUploadDetails c WHERE c.uploadTimestamp >:uploadTimestamp") })
public class SettlementFileUploadDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name", length = 100)
    private String fileName;

    @Column(name = "total_data", length = 10)
    private Integer totalData;

    @Column(name = "no_of_paytm_txn_id", length = 10)
    private Integer paytmTxnIdCount;

    @Column(name = "no_of_alipay_txn_id", length = 10)
    private Integer alipayTxnIdCount;

    @Column(name = "file_alipay_txn_id", length = 100)
    private String alipayTxnFile;

    @Column(name = "file_paytm_txn_id", length = 100)
    private String paytmTxnFile;

    @Column(name = "success_row", length = 10)
    private Integer successRow;
    @Column(name = "failed_row", length = 10)
    private Integer failedRow;

    @Column(name = "status")
    private Short status;

    @Column(name = "sftp_paytm_file")
    private boolean sftpPaytmFile;

    @Column(name = "sftp_alipay_file")
    private boolean sftpAlipayFile;

    @Column(name = "status_message", length = 20)
    private String statusMessage;

    @Column(name = "bank_name", length = 20)
    private String bankName;
    @Column(name = "total_amount")
    private BigDecimal totalAmount;

    @Column(name = "alipay_total_amount")
    private BigDecimal alipayTotalAmount;

    @Column(name = "paytm_total_amount")
    private BigDecimal paytmTotalAmount;

    @Column(name = "upload_timestamp", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private Date uploadTimestamp;

    public Long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Integer getTotalData() {
        return totalData;
    }

    public void setTotalData(int totalData) {
        this.totalData = totalData;
    }

    public Integer getPaytmTxnIdCount() {
        return paytmTxnIdCount;
    }

    public void setPaytmTxnIdCount(int paytmTxnIdCount) {
        this.paytmTxnIdCount = paytmTxnIdCount;
    }

    public Integer getAlipayTxnIdCount() {
        return alipayTxnIdCount;
    }

    public void setAlipayTxnIdCount(int alipayTxnIdCount) {
        this.alipayTxnIdCount = alipayTxnIdCount;
    }

    public String getAlipayTxnFile() {
        return alipayTxnFile;
    }

    public void setAlipayTxnFile(String alipayTxnFile) {
        this.alipayTxnFile = alipayTxnFile;
    }

    public String getPaytmTxnFile() {
        return paytmTxnFile;
    }

    public void setPaytmTxnFile(String paytmTxnFile) {
        this.paytmTxnFile = paytmTxnFile;
    }

    public Integer getSuccessRow() {
        return successRow;
    }

    public void setSuccessRow(int successRow) {
        this.successRow = successRow;
    }

    public Integer getFailedRow() {
        return failedRow;
    }

    public void setFailedRow(int failedRow) {
        this.failedRow = failedRow;
    }

    public Date getUploadTimestamp() {
        return uploadTimestamp;
    }

    public void setUploadTimestamp(Date uploadTimestamp) {
        this.uploadTimestamp = uploadTimestamp;
    }

    public Short getStatus() {
        return status;
    }

    public void setStatus(short status) {
        this.status = status;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public boolean isSftpPaytmFile() {
        return sftpPaytmFile;
    }

    public void setSftpPaytmFile(boolean sftpPaytmFile) {
        this.sftpPaytmFile = sftpPaytmFile;
    }

    public boolean isSftpAlipayFile() {
        return sftpAlipayFile;
    }

    public void setSftpAlipayFile(boolean sftpAlipayFile) {
        this.sftpAlipayFile = sftpAlipayFile;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public BigDecimal getAlipayTotalAmount() {
        return alipayTotalAmount;
    }

    public void setAlipayTotalAmount(BigDecimal alipayTotalAmount) {
        this.alipayTotalAmount = alipayTotalAmount;
    }

    public BigDecimal getPaytmTotalAmount() {
        return paytmTotalAmount;
    }

    public void setPaytmTotalAmount(BigDecimal paytmTotalAmount) {
        this.paytmTotalAmount = paytmTotalAmount;
    }

    @Override
    public String toString() {
        return "SettlementFileUploadDetails [fileName=" + fileName + ", totalData=" + totalData + ", paytmTxnIdCount="
                + paytmTxnIdCount + ", alipayTxnIdCount=" + alipayTxnIdCount + ", alipayTxnFile=" + alipayTxnFile
                + ", paytmTxnFile=" + paytmTxnFile + ", successRow=" + successRow + ", failedRow=" + failedRow
                + ", status=" + status + ", sftpPaytmFile=" + sftpPaytmFile + ", sftpAlipayFile=" + sftpAlipayFile
                + ", statusMessage=" + statusMessage + ", bankName=" + bankName + ", totalAmount=" + totalAmount
                + ", alipayTotalAmount=" + alipayTotalAmount + ", paytmTotalAmount=" + paytmTotalAmount
                + ", uploadTimestamp=" + uploadTimestamp + "]";
    }

}
