package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DynamicScheduledMerchantReportColumnName implements ScheduledMerchantReportColumnName {

    @NotNull
    @Size(min = 1)
    private String columnName;

    @Override
    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }
}
