package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import com.paytm.pgplus.bocore.enums.ChargebackSource;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "chargeback_details_history")
@Getter
@Setter
public class ChargeBackDetailsHistory extends BaseEntity implements Serializable {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "dispute_id")
    private String disputeId;

    @Column(name = "from_status")
    private String fromStatus;

    @Column(name = "to_status")
    private String toStatus;

    @Column(name = "actor")
    private String actor;

    @Column(name = "actor_info")
    private String actorInfo;

    @Column(name = "pod_uploaded_date")
    private Date podUploadDate;

    @Column(name = "source")
    @Enumerated(EnumType.STRING)
    private ChargebackSource chargebackSource;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "dispute_id", nullable = false, insertable = false, updatable = false)
    private ChargeBackDetails chargeBackDetails;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "comment_id", referencedColumnName = "id")
    private ChargeBackComment chargeBackComment;

}
