package com.paytm.pglpus.bocore.model.msr;

import com.paytm.pgplus.bocore.constants.MSRBillFileColumn;
import com.paytm.pgplus.bocore.enums.MerchantSettlementReportType;
import com.paytm.pgplus.bocore.enums.TransactionType;
import com.paytm.pgplus.bocore.util.csv.CSVColumn;
import com.paytm.pgplus.bocore.util.csv.converter.deserializer.BigDecimalConverter;
import com.paytm.pgplus.bocore.util.csv.converter.deserializer.DateConverter;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class MerchantSplitChargingReport extends MerchantSettlementReport {

    @CSVColumn(name = MSRBillFileColumn.TXN_ID)
    private String txnId;

    @CSVColumn(name = MSRBillFileColumn.SPLIT_ID)
    private String splitId;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date splitDate;

    @CSVColumn(name = MSRBillFileColumn.MAIN_MERCHANT_MID)
    private String mainMerchantId;

    @CSVColumn(name = MSRBillFileColumn.ALIPAY_MID)
    private String splitMid;

    @CSVColumn(name = MSRBillFileColumn.PAYTM_MID)
    private String splitOriginalMid;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_NAME)
    private String splitMerchantName;

    @CSVColumn(name = MSRBillFileColumn.CLEARING_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date clearingDate;

    @CSVColumn(name = MSRBillFileColumn.TERMINAL_TYPE)
    private String terminalType;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal splitAmount;

    @CSVColumn(name = MSRBillFileColumn.PAYMENT_CURRENCY)
    private String splitCurrency;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_COMMISSION, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal merchantCommission;

    @CSVColumn(name = MSRBillFileColumn.SERVICE_TAX, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal serviceTax;

    @CSVColumn(name = MSRBillFileColumn.SETTLEMENT_AMOUNT, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal settlementAmount;

    @CSVColumn(name = MSRBillFileColumn.ORDER_ID)
    private String orderId;

    @CSVColumn(name = MSRBillFileColumn.PAY_METHOD)
    private String paymentMethod;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_CUST_ID)
    private String merchantCustId;

    @CSVColumn(name = MSRBillFileColumn.ISSUING_BANK)
    private String issuingBank;

    @CSVColumn(name = MSRBillFileColumn.STATUS)
    private String status;

    @CSVColumn(name = MSRBillFileColumn.SETTLEMENT_DATE, rawValueConverterClass = DateConverter.class, rawValueConverterRuntimeInputs = {
            MSRBillFileColumn.FILE_DATE_FORMAT_YYYYMMDD, MSRBillFileColumn.FILE_DATE_TIME_FORMAT_1 }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.DateConverter.class, objectValueConvertorFormat = MSRBillFileColumn.FILE_DATE_FORMAT_YYYY_MM_DD)
    private Date settlementDate;

    @CSVColumn(name = MSRBillFileColumn.SETTLED_BANK_TXN_ID)
    private String settlementBankTxnId;

    @CSVColumn(name = MSRBillFileColumn.SETTLED_TXN_ID)
    private String settlementTxnId;

    @CSVColumn(name = MSRBillFileColumn.MERCHANT_BILL_ID)
    private String merchantBillId;

    @CSVColumn(name = MSRBillFileColumn.PRN_CODE)
    private String prnCode;

    @CSVColumn(name = MSRBillFileColumn.COMMISSION_RATE)
    private String commissionRate;

    @CSVColumn(name = MSRBillFileColumn.ALIPAY_PRODUCT_CODE)
    private String productCode;

    @CSVColumn(name = MSRBillFileColumn.GMV_TIER)
    private String gmvTier;

    @CSVColumn(name = MSRBillFileColumn.REQUEST_TYPE)
    private String requestType;

    @CSVColumn(name = MSRBillFileColumn.TRANSACTION_SLAB)
    private String transactionSlab;

    @CSVColumn(name = MSRBillFileColumn.TRANSACTION_TYPE)
    private String txnType;

    @CSVColumn(name = MSRBillFileColumn.CARD_SCHEME)
    private String cardScheme;

    @CSVColumn(name = MSRBillFileColumn.FEE_FACTOR)
    private String feeFactor;

    @CSVColumn(name = MSRBillFileColumn.ACQUIRING_SERVICE_FEE, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal mdrCommission;

    @CSVColumn(name = MSRBillFileColumn.ACQUIRING_SERVICE_TAX, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal mdrServiceTax;

    @CSVColumn(name = MSRBillFileColumn.PLATFORM_SERVICE_FEE, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal platformFee;

    @CSVColumn(name = MSRBillFileColumn.PLATFORM_SERVICE_TAX, rawValueConverterClass = BigDecimalConverter.class, rawValueConverterRuntimeInputs = { MSRBillFileColumn.BIG_DECIMAL_DIVISOR_PAISE_TO_RUPEE }, objectValueConverterClass = com.paytm.pgplus.bocore.util.csv.converter.serializer.BigDecimalConverter.class)
    private BigDecimal platformTax;

    public MerchantSplitChargingReport() {
        super(TransactionType.SPLIT_PAYMENT, MerchantSettlementReportType.SPLIT_CHARGING);
    }

    @Override
    public BigDecimal getTotalAmount() {
        return this.settlementAmount;
    }

    @Override
    public BigDecimal getTransactionAmount() {
        return this.splitAmount;
    }

    @Override
    public String getPayoutId() {
        return this.settlementTxnId;
    }

    @Override
    public String getUtr() {
        return this.settlementBankTxnId;
    }

    @Override
    public String getPaytmMerchantId() {
        return this.splitOriginalMid;
    }

    @Override
    public String getOriginalMID() {
        return getPaytmMerchantId();
    }
}
