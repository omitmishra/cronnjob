package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "auto_refund")
@XmlRootElement
@NamedQueries({ @NamedQuery(name = "AutoRefundDetails.findByUpdatedTimeStamp", query = "SELECT o FROM AutoRefundDetails o WHERE o.txnDate >= :from  and o.txnDate <= :to") })
public class AutoRefundDetails implements Serializable {

    private static final long serialVersionUID = -2252052140028259492L;

    @Id
    @Basic(optional = false)
    @Column(name = "txnId", length = 50, nullable = false, updatable = false)
    private String txnId;

    @Column(name = "externalSerialNo", length = 25)
    private String externalSerialNo;

    @Column(name = "mid", length = 40)
    private String mid;

    @Column(name = "merchantName", length = 25)
    private String merchantName;

    @Temporal(TemporalType.DATE)
    @Column(name = "txnDate", nullable = false)
    private Date txnDate;

    @Column(name = "mbid")
    private String mbid;

    @Column(name = "txnChannel", length = 40)
    private String txnChannel;

    @Column(name = "txnAmount")
    private String txnAmount;

    @Column(name = "currencyType", length = 10)
    private String currencyType;

    @Column(name = "orderId")
    private String orderId;

    @Column(name = "responseCode")
    private String responseCode;

    @Column(name = "payMode", length = 20)
    private String payMode;

    @Column(name = "bankTxnId", length = 25)
    private String bankTxnId;

    @Column(name = "customerId", length = 20)
    private String custId;

    @Column(name = "ccdcLast4", length = 5)
    private String ccdcLast4;

    @Column(name = "issuingBank", length = 50)
    private String issuingBank;

    @Column(name = "bankGateway")
    private String bankGateway;

    @Column(name = "status")
    private String status;

    @Column(name = "bankFees")
    private String bankFees;

    @Column(name = "gatewayPaymode", length = 50)
    private String gatewayPaymode;

    @Column(name = "autoRefundBrf", length = 5)
    private String autoRefundBrf;

    @Column(name = "isSameDay", length = 5)
    private String isTheSameDay;

    @Column
    @Temporal(TemporalType.DATE)
    private Date created;

    @Column
    @Temporal(TemporalType.DATE)
    private Date updated;

    public String getAutoRefundBrf() {
        return autoRefundBrf;
    }

    public void setAutoRefundBrf(String autoRefundBrf) {
        this.autoRefundBrf = autoRefundBrf;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public void setExternalSerialNo(String externalSerialNo) {
        this.externalSerialNo = externalSerialNo;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public void setTxnDate(Date txnDate) {
        this.txnDate = txnDate;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public void setTxnChannel(String txnChannel) {
        this.txnChannel = txnChannel;
    }

    public void setTxnAmount(String txnAmount) {
        this.txnAmount = txnAmount;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public void setBankTxnId(String bankTxnId) {
        this.bankTxnId = bankTxnId;
    }

    public void setCustId(String custId) {
        this.custId = custId;
    }

    public void setCcdcLast4(String ccdcLast4) {
        this.ccdcLast4 = ccdcLast4;
    }

    public void setIssuingBank(String issuingBank) {
        this.issuingBank = issuingBank;
    }

    public void setBankGateway(String bankGateway) {
        this.bankGateway = bankGateway;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setBankFees(String bankFees) {
        this.bankFees = bankFees;
    }

    public void setGatewayPaymode(String gatewayPaymode) {
        this.gatewayPaymode = gatewayPaymode;
    }

    public void setIsTheSameDay(String isTheSameDay) {
        this.isTheSameDay = isTheSameDay;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

    public String getTxnId() {
        return txnId;
    }

    public String getExternalSerialNo() {
        return externalSerialNo;
    }

    public String getMid() {
        return mid;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public Date getTxnDate() {
        return txnDate;
    }

    public String getMbid() {
        return mbid;
    }

    public String getTxnChannel() {
        return txnChannel;
    }

    public String getTxnAmount() {
        return txnAmount;
    }

    public String getCurrencyType() {
        return currencyType;
    }

    public String getOrderId() {
        return orderId;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public String getPayMode() {
        return payMode;
    }

    public String getBankTxnId() {
        return bankTxnId;
    }

    public String getCustId() {
        return custId;
    }

    public String getCcdcLast4() {
        return ccdcLast4;
    }

    public String getIssuingBank() {
        return issuingBank;
    }

    public String getBankGateway() {
        return bankGateway;
    }

    public String getStatus() {
        return status;
    }

    public String getBankFees() {
        return bankFees;
    }

    public String getGatewayPaymode() {
        return gatewayPaymode;
    }

    public String getIsTheSameDay() {
        return isTheSameDay;
    }

    public Date getCreated() {
        return created;
    }

    public Date getUpdated() {
        return updated;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("AutoRefundDetails [txnId=");
        builder.append(txnId);
        builder.append(", externalSerialNo=");
        builder.append(externalSerialNo);
        builder.append(", mid=");
        builder.append(mid);
        builder.append(", merchantName=");
        builder.append(merchantName);
        builder.append(", txnDate=");
        builder.append(txnDate);
        builder.append(", mbid=");
        builder.append(mbid);
        builder.append(", txnChannel=");
        builder.append(txnChannel);
        builder.append(", txnAmount=");
        builder.append(txnAmount);
        builder.append(", currencyType=");
        builder.append(currencyType);
        builder.append(", orderId=");
        builder.append(orderId);
        builder.append(", responseCode=");
        builder.append(responseCode);
        builder.append(", payMode=");
        builder.append(payMode);
        builder.append(", bankTxnId=");
        builder.append(bankTxnId);
        builder.append(", custId=");
        builder.append(custId);
        builder.append(", ccdcLast4=");
        builder.append(ccdcLast4);
        builder.append(", issuingBank=");
        builder.append(issuingBank);
        builder.append(", bankGateway=");
        builder.append(bankGateway);
        builder.append(", status=");
        builder.append(status);
        builder.append(", bankFees=");
        builder.append(bankFees);
        builder.append(", gatewayPaymode=");
        builder.append(gatewayPaymode);
        builder.append(", autoRefundBrf=");
        builder.append(autoRefundBrf);
        builder.append(", isTheSameDay=");
        builder.append(isTheSameDay);
        builder.append(", created=");
        builder.append(created);
        builder.append(", updated=");
        builder.append(updated);
        builder.append("]");
        return builder.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((externalSerialNo == null) ? 0 : externalSerialNo.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((txnId == null) ? 0 : txnId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AutoRefundDetails other = (AutoRefundDetails) obj;
        if (externalSerialNo == null) {
            if (other.externalSerialNo != null)
                return false;
        } else if (!externalSerialNo.equals(other.externalSerialNo))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        } else if (!status.equals(other.status))
            return false;
        if (txnId == null) {
            if (other.txnId != null)
                return false;
        } else if (!txnId.equals(other.txnId))
            return false;
        return true;
    }

}
