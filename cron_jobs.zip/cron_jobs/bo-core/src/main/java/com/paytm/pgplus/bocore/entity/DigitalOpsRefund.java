package com.paytm.pgplus.bocore.entity;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.file.util.annotation.CsvColumnMapper;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Entity
@Table(name = "digital_ops_refund")
@NamedQueries({
        @NamedQuery(name = "DigitalOpsRefund.findByTxnAndRefTxnId", query = "SELECT a FROM DigitalOpsRefund a WHERE a.txnId = :txnId and "
                + "a.refundTxnId = :refundTxnId"),
        @NamedQuery(name = "DigitalOpsRefund.findByRefTxnId", query = "SELECT a FROM DigitalOpsRefund a WHERE a.refundTxnId = :refundTxnId"),
        @NamedQuery(name = "DigitalOpsRefund.findByTxnId", query = "SELECT a FROM DigitalOpsRefund a WHERE a.txnId = :txnId") })
public class DigitalOpsRefund extends BaseEntity {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1853618020743912284L;

    @Basic(optional = false)
    @Column(name = "id", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.BANK_NAME)
    @Column(name = "bank_name")
    String bankName;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.MID)
    @Column(name = "mid")
    String mid;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_ID)
    @Column(name = "txn_id")
    String txnId;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_TXN_ID)
    @Column(name = "refund_txn_id")
    String refundTxnId;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.MBID)
    @Column(name = "mbid")
    String mbid;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_DATE)
    @Column(name = "txn_date")
    String txnDate;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_DATE)
    @Column(name = "refund_date")
    String refundDate;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_AMOUNT)
    @Column(name = "txn_amount")
    String txnAmount;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_AMOUNT)
    @Column(name = "refund_amount")
    String refundAmount;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.PAYMODE)
    @Column(name = "paymode")
    String paymode;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_BANK_TXN_ID)
    @Column(name = "refund_bank_txn_id")
    String refundBankTxnId;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.TXN_BANK_TXN_ID)
    @Column(name = "txn_bank_txn_id")
    String txnBankTxnId;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.AGE)
    @Column(name = "age")
    String age;

    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_TYPE)
    @Column(name = "refund_type")
    String refundType;

    @Column(name = "charging_esn")
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.CHARGING_ESN)
    String chargingEsn;

    @Column(name = "refund_esn")
    @CsvColumnMapper(columnName = DigitalOpsRefundHeader.REFUND_ESN)
    String refundEsn;

}