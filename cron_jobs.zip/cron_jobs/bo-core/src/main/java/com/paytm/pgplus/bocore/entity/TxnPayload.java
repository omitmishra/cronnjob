package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import com.fasterxml.jackson.annotation.JsonFormat;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "txn_payload")
public class TxnPayload implements Serializable {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false, updatable = false)
    private Long Id;

    @Column(name = "txn_id", length = 100)
    private String txnId;

    @Column(name = "merchant_id", length = 50)
    private String merchantId;

    @Column(name = "order_id", length = 50)
    private String orderId;

    @Column(name = "ext_serial_no", length = 20)
    private String extSerialNo;

    @Column(name = "payload")
    @Type(type = "text")
    private String payload;

    @Column(name = "source_epoc_time", length = 20)
    private Long sourceEpocTime;

    @Column(name = "created_timestamp")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private Date createdTimestamp;

}
