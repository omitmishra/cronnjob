package com.paytm.pgplus.bocore.entity.jpa;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.cache.model.MappingServiceResultInfo;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class EosMerchantResponse implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = -5115977087709342512L;

    private MerchantDeviceMapping response;

    private MappingServiceResultInfo resultInfo;

}
