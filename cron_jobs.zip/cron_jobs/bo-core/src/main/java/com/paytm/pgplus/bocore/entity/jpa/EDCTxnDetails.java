package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.constants.EDCConstants;
import lombok.Data;
import org.file.util.annotation.CsvColumnMapper;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.util.Date;

@Entity
@Data
public class EDCTxnDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    String msgType;

    @CsvColumnMapper(columnName = EDCConstants.CARD_NO)
    String cardNo;

    @CsvColumnMapper(columnName = EDCConstants.TXN_TYPE)
    String txnType;

    String txnCode;

    @CsvColumnMapper(columnName = EDCConstants.TXN_AMOUNT)
    String txnAmount;

    @CsvColumnMapper(columnName = EDCConstants.RRN)
    String rrn;

    @CsvColumnMapper(columnName = EDCConstants.AUTH_ID)
    String authId;

    String respCode;

    String invoiceNo;

    String isTransReversed;

    String isSettled;

    @CsvColumnMapper(columnName = EDCConstants.STAN)
    String stan;

    String creditDebit;

    @CsvColumnMapper(columnName = EDCConstants.ARN)
    String arn;

    @CsvColumnMapper(columnName = EDCConstants.PAYTM_ID)
    String paytmId;

    @CsvColumnMapper(columnName = EDCConstants.TXN_DATE)
    Date txnDate;

    @CsvColumnMapper(columnName = EDCConstants.TXN_ID)
    String txnId;

    @CsvColumnMapper(columnName = EDCConstants.ORDER_ID)
    String orderId;
}
