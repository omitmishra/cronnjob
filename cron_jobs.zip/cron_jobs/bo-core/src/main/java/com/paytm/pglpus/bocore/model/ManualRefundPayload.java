package com.paytm.pglpus.bocore.model;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class ManualRefundPayload implements Serializable {

    private String bizOrderId;
    private String fluxEventSerialNo;
    private String rrnCode;
    private String bankReferenceNo;
    private String refundStatus;
    private String refundDate;
    private String memo;
    private Date msgPushTime;
}
