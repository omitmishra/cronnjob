package com.paytm.pglpus.bocore.model.merchantReportEvents.eventconfig;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import org.springframework.http.MediaType;

import java.io.IOException;

public class MediaTypeDeserializer extends StdDeserializer<MediaType> {

    public MediaTypeDeserializer() {
        this(null);
    }

    public MediaTypeDeserializer(Class<?> vc) {
        super(vc);
    }

    @Override
    public MediaType deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException,
            JsonProcessingException {
        JsonNode node = jp.getCodec().readTree(jp);
        String mediaType = node.asText();
        return MediaType.parseMediaType(mediaType);
    }
}
