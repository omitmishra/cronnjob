package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Hibernate entity class This class responsible for hibernate entity to table
 * mapping
 * 
 * @author Isha Singhal
 * @date 15 May 2017
 */

@Entity
@Table(name = "OFFLINE_REFUND_DOWNLOAD_REQUEST")
public class OfflineRefundDownloadRequestLog implements Serializable {

    @Id
    @Basic(optional = false)
    @Column(name = "ID", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "USER_NAME")
    private String userName;

    @Column(name = "PLATFORM")
    private String platform;

    @Column(name = "REQUEST_BODY")
    private String requestBody;

    @Column(name = "RESPONSE_FILE")
    private String responseFile;

    @Column(name = "RESPONSE_COUNT")
    private Integer responseCount;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getRequestBody() {
        return requestBody;
    }

    public void setRequestBody(String requestBody) {
        this.requestBody = requestBody;
    }

    public String getResponseFile() {
        return responseFile;
    }

    public void setResponseFile(String responseFile) {
        this.responseFile = responseFile;
    }

    public Integer getResponseCount() {
        return responseCount;
    }

    public void setResponseCount(Integer responseCount) {
        this.responseCount = responseCount;
    }

    public OfflineRefundDownloadRequestLog(String userName, String platform, String requestBody, String responseFile,
            Integer responseCount) {
        super();
        this.userName = userName;
        this.platform = platform;
        this.requestBody = requestBody;
        this.responseFile = responseFile;
        this.responseCount = responseCount;
    }

    public OfflineRefundDownloadRequestLog() {

    }

    @Override
    public String toString() {
        return "OfflineRefundDownloadRequestLog [id=" + id + ", userName=" + userName + ", platform=" + platform
                + ", requestBody=" + requestBody + ", responseFile=" + responseFile + ", responseCount="
                + responseCount + "]";
    }

}
