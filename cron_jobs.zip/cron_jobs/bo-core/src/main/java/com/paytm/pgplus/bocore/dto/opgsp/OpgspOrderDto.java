package com.paytm.pgplus.bocore.dto.opgsp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.paytm.pgplus.bocore.enums.opgsp.PurposeCode;
import com.paytm.pgplus.bocore.model.opgsp.*;
import com.paytm.pgplus.validator.ConstrainedValue;
import com.paytm.pgplus.validator.DateFormatValidate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OpgspOrderDto implements Serializable {

    private static final long serialVersionUID = 4920003599485653118L;

    @NotNull(message = "requestId must not be present in request")
    @Size(min = 1, max = 64, message = "requestId must be between {min} and {max} characters")
    private String requestId;

    @NotNull(message = "requestTimestamp must not be empty")
    @Size(min = 1, max = 16, message = "requestTimestamp must be between {min} and {max} characters")
    private String requestTimestamp;

    @NotNull(message = "orderId must not be empty")
    @Size(min = 1, max = 64, message = "orderId must be between {min} and {max} characters")
    private String orderId;

    @NotNull(message = "txnId must not be empty")
    @Size(min = 1, max = 64, message = "txnId must be between {min} and {max} characters")
    private String txnId;

    @NotNull(message = "mid must not be empty")
    @Size(min = 1, max = 64, message = "mid must be between {min} and {max} characters")
    private String mid;

    @NotNull(message = "paymentTerms must not be empty")
    @Size(min = 1, max = 100, message = "paymentTerms must be between {min} and {max} characters")
    private String paymentTerms;

    @NotNull(message = "paymentDate must not be empty")
    @Size(min = 1, max = 32, message = "paymentDate must be between {min} and {max} characters")
    @DateFormatValidate(message = "paymentDate is invalid", isFutureDateAllowed = false)
    private String paymentDate;

    @NotNull(message = "purposeCode must not be empty")
    // @ConstrainedValue(enumClass = PurposeCode.class, message =
    // "Invalid value for purposeCode.")
    @Enumerated(EnumType.STRING)
    private PurposeCode purposeCode;

    @NotNull(message = "seller must not be empty")
    @Valid
    private SellerInfo seller;

    @NotNull(message = "acquirer must not be empty")
    @Valid
    private AcquirerInfo acquirer;

    @NotNull(message = "buyer must not be empty")
    @Valid
    private BuyerInfo buyer;

    @NotNull(message = "invoices must not be empty")
    @Valid
    private List<InvoiceInfo> invoices;

    @NotNull(message = "goods must not be empty")
    @Valid
    private List<GoodsInfo> goods;

    @NotNull(message = "shipping must not be empty")
    @Valid
    private ShippingInfo shipping;

    @Size(max = 4096, message = "extendInfo must not contain more than {max} characters")
    private String extendInfo;
}