package com.paytm.pgplus.bocore.constants;

public class RefundProcessingColumnMapper {

    public static final String ID = "id";
    public static final String ACTION = "action";
    public static final String APP_ID = "appId";
    public static final String AUTH_CODE = "authCode";
    public static final String BANK_ABBR = "bankAbbr";
    public static final String BANK_RESPONSE_NO = "bankResponseNo";
    public static final String COMMENT = "comment";
    public static final String DISPUTE_ID = "disputeId";
    public static final String EXCHANGE_AMOUNT = "exchangeAmount";
    public static final String EXCHANGE_CURRENCY = "exchangeCurrency";
    public static final String EXT_SERIAL_NO = "extSerialNo";
    public static final String FILE_NAME = "fileName";
    public static final String LAST_UPDATE_DATE = "lastUpdateDate";
    public static final String MBID = "mbid";
    public static final String MERCHANT_ID = "merchantId";
    public static final String ORIGINAL_MID = "originalMID";
    public static final String PAYMETHOD = "paymethod";
    public static final String REFERENCE_NO = "referenceNo";
    public static final String REF_ID = "refId";
    public static final String REFUND_TYPE = "refundType";
    public static final String RESULT_STATUS = "resultStatus";
    public static final String RRN_CODE = "rrnCode";
    public static final String TRACE_NO = "traceNo";
    public static final String TRANS_ID = "transId";
    public static final String TRANS_INFO_SOURCE = "transInfoSource";
    public static final String TRANS_TYPE = "transType";
    public static final String TRANS_VALUE_DATE = "transValueDate";

    public static final String[] REFUND_PROCESSING_HEADER = { "action", "appId", "authCode", "bankAbbr",
            "bankResponseNo", "comment", "disputeId", "exchangeAmount", "exchangeCurrency", "extSerialNo", "refundEsn",
            "refundAmount", "isRetry", "fileName", "lastUpdateDate", "mbid", "merchantId", "originalMID", "paymethod",
            "referenceNo", "refId", "refundType", "resultStatus", "rrnCode", "traceNo", "transId", "transInfoSource",
            "transType", "transValueDate", };
    public static final String REFUNDS_PROCESSED = "refund_processed_";
    public static final String REFUND_AMOUNT = "refundAmount";
    public static final String REFUND_ESN = "refundEsn";
    public static final String IS_RETRY = "isRetry";

}
