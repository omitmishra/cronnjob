package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;

import javax.persistence.*;

/**
 * Created by dheeraj on 30/08/17.
 */
@Entity
@Data
@Table(name = "paytm_merchant")
public class AlipayPaytmMerchantEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    String id;
    String alipayMerchantId;
    String paytmMerchantId;
    String alipayMerchantWalletId;
    String paytmMerchantWalletId;
    String merchantType;
    String officialName;
    String createTimestamp;
    String updateTimestamp;
    String updatedCount;
    String industryTypeId;

}
