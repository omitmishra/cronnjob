package com.paytm.pglpus.bocore.model;

import lombok.Data;

/**
 * Created by dheeraj on 18/01/18.
 */

@Data
public class NewEscalationLog {

    Long issueId;

    Long escalationHierarchyId;

    Long oncallMemberId;

    Long oncallTeamId;

    public NewEscalationLog(Long escalationHierarchyId, long issueId, Long oncallMemberId, Long oncallTeamId) {
        this.escalationHierarchyId = escalationHierarchyId;
        this.issueId = issueId;
        this.oncallMemberId = oncallMemberId;
        this.oncallTeamId = oncallTeamId;
    }
}
