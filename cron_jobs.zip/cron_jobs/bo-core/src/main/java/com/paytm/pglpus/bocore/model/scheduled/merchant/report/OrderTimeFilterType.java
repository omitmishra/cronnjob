package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

public enum OrderTimeFilterType {

    DEFAULT, ORDER_SETTLE, ORDER_SETTLE_COMPLETED, UTR_UPDATE_TIME;
}
