package com.paytm.pgplus.bocore.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.file.util.annotation.CsvColumnMapper;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

import static com.paytm.pgplus.bocore.constants.DiscrepancyCsvFileHeadersConstant.*;

/**
 * Hibernate entity class This class responsible for hibernate entity to table
 * mapping
 *
 * @author Kulbhushan Pandey
 * @date 18 July 2017
 */
@Entity
@Table(name = "PGPLUS_REPORT_DISCREPANCY_SETTLEMENT_BCP")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class DiscrepancySettlementBcp extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "DISCREPANCY_TYPE")
    @CsvColumnMapper(columnName = DISCREPANCY_TYPE)
    private String discrepancyType;

    @Column(name = "FLUXNET_EXT_SERIAL_NO")
    @CsvColumnMapper(columnName = FLUXNET_EXT_SERIAL_NO)
    private String fluxNetExtSerialNo;

    @Column(name = "FLUXNET_RESULT_STATUS")
    @CsvColumnMapper(columnName = FLUXNET_RESULT_STATUS)
    private String fluxNetResultStatus;

    @Column(name = "FLUXNET_REFERENCE_NO")
    @CsvColumnMapper(columnName = FLUXNET_REFERENCE_NO)
    private String fluxNetReferenceNo;

    @Column(name = "FLUXNET_EXCHANGE_CURRENCY")
    @CsvColumnMapper(columnName = FLUXNET_EXCHANGE_CURRENCY)
    private String fluxNetExchangeCurrency;

    @Column(name = "FLUXNET_EXCHANGE_AMOUNT")
    @CsvColumnMapper(columnName = FLUXNET_EXCHANGE_AMOUNT)
    private Long fluxNetExchangeAmount;

    @Column(name = "FILE_RCV_DATE")
    private Date fileRcvDate;

    @Column(name = "FILE_NAME")
    @CsvColumnMapper(columnName = FILE_NAME)
    private String fileName;

    @Column(name = "TRANS_TYPE")
    @CsvColumnMapper(columnName = TRANS_TYPE)
    private String transType;

    @Column(name = "RESULT_STATUS")
    @CsvColumnMapper(columnName = RESULT_STATUS)
    private String resultStatus;

    @Column(name = "RESULT_CODE_ID")
    @CsvColumnMapper(columnName = RESULT_CODE_ID)
    private String resultCodeId;

    @Column(name = "EXTSERIAL_NO")
    @CsvColumnMapper(columnName = EXT_SERIAL_NO)
    private String extSerialNo;

    @Column(name = "TRACE_NO")
    @CsvColumnMapper(columnName = TRACE_NO)
    private String traceNo;

    @Column(name = "AUTH_CODE")
    @CsvColumnMapper(columnName = AUTH_CODE)
    private String authCode;

    @Column(name = "RRN_CODE")
    @CsvColumnMapper(columnName = RRN_CODE)
    private String rrnCode;

    @Column(name = "BANK_ABBR")
    @CsvColumnMapper(columnName = BANK_ABBR)
    private String bankAbbr;

    @Column(name = "REFERENCE_NO")
    @CsvColumnMapper(columnName = REFERENCE_NO)
    private String referenceNo;

    @Column(name = "MERCHANT_ID")
    @CsvColumnMapper(columnName = MERCHANT_ID)
    private String merchantId;

    @Column(name = "PAYTMM_ID")
    @CsvColumnMapper(columnName = ORIGINAL_MID)
    private String originalMID;

    @Column(name = "MBID")
    @CsvColumnMapper(columnName = MBID)
    private String mbid;

    @Column(name = "EXCHANGE_AMOUNT")
    @CsvColumnMapper(columnName = EXCHANGE_AMOUNT)
    private Long exchangeAmount;

    @Column(name = "EXCHANGE_CURRENCY")
    @CsvColumnMapper(columnName = EXCHANGE_CURRENCY)
    private String exchangeCurrency;

    @Column(name = "TRANS_VALUE_DATE")
    private Date transValueDate;

    @Column(name = "LAST_UPDATE_DATE")
    private Date lastUpdateDate;

    @Column(name = "ACTION")
    private String action;

    @Column(name = "COMMENT")
    private String comment;

    @Column(name = "REF_ID")
    private String refId;

    @Column(name = "REFUND_TYPE")
    private String refundType;

    @Column(name = "BANK_RESPONSE_NO")
    private String bankResponseNo;

    @Column(name = "TRANS_ID")
    private String transId;

    @Column(name = "DISPUTE_ID")
    private String disputeId;

    @Column(name = "TRANS_INFO_SOURCE")
    @CsvColumnMapper(columnName = TRANS_INFO_SOURCE)
    private String transInfoSource;

    @Column(name = "APP_ID")
    private String appId;
    @Column(name = "PAYMETHOD")
    private String paymethod;

    @CsvColumnMapper(columnName = LAST_UPDATE_DATE)
    private transient String lastUpdateDateStr;

    @CsvColumnMapper(columnName = TRANS_VALUE_DATE)
    private transient String transValueDateStr;

    @CsvColumnMapper(columnName = FILE_RCV_DATE)
    private transient String fileRcvDateStr;

    @Column(name = "BUSINESS_TYPE")
    private String businessType;

    @Column(name = TID)
    private String tid;

    @Column(name = STAN)
    private String stan;

    @Column(name = INTERCHANGE)
    private String interchange;

    @Column(name = MASKED_CARD_NO)
    private String maskedCardNo;

    public DiscrepancySettlementBcp(DiscrepancySettlement discrepancySettlement) {
        super();
        this.id = discrepancySettlement.getId();
        this.discrepancyType = discrepancySettlement.getDiscrepancyType();
        this.fluxNetExtSerialNo = discrepancySettlement.getFluxNetExtSerialNo();
        this.fluxNetResultStatus = discrepancySettlement.getFluxNetResultStatus();
        this.fluxNetReferenceNo = discrepancySettlement.getFluxNetReferenceNo();
        this.fluxNetExchangeCurrency = discrepancySettlement.getFluxNetExchangeCurrency();
        this.fluxNetExchangeAmount = discrepancySettlement.getExchangeAmount();
        this.fileRcvDate = discrepancySettlement.getFileRcvDate();
        this.fileName = discrepancySettlement.getFileName();
        this.transType = discrepancySettlement.getTransType();
        this.resultStatus = discrepancySettlement.getResultStatus();
        this.resultCodeId = discrepancySettlement.getResultCodeId();
        this.extSerialNo = discrepancySettlement.getExtSerialNo();
        this.traceNo = discrepancySettlement.getTraceNo();
        this.authCode = discrepancySettlement.getAuthCode();
        this.rrnCode = discrepancySettlement.getRrnCode();
        this.bankAbbr = discrepancySettlement.getBankAbbr();
        this.referenceNo = discrepancySettlement.getReferenceNo();
        this.merchantId = discrepancySettlement.getMerchantId();
        this.originalMID = discrepancySettlement.getOriginalMID();
        this.mbid = discrepancySettlement.getMbid();
        this.exchangeAmount = discrepancySettlement.getExchangeAmount();
        this.exchangeCurrency = discrepancySettlement.getExchangeCurrency();
        this.transValueDate = discrepancySettlement.getTransValueDate();
        this.lastUpdateDate = discrepancySettlement.getLastUpdateDate();
        this.action = discrepancySettlement.getAction();
        this.transInfoSource = discrepancySettlement.getTransInfoSource();
        this.comment = discrepancySettlement.getComment();
        this.refId = discrepancySettlement.getRefId();
        this.refundType = discrepancySettlement.getRefundType();
        this.bankResponseNo = discrepancySettlement.getBankResponseNo();
        this.transId = discrepancySettlement.getTransId();
        this.disputeId = discrepancySettlement.getDisputeId();
        this.appId = discrepancySettlement.getAppId();
        this.paymethod = discrepancySettlement.getPaymethod();
        this.createdOn = discrepancySettlement.getCreatedOn();
        this.updatedOn = discrepancySettlement.getUpdatedOn();
        this.businessType = discrepancySettlement.getBusinessType();
        this.tid = discrepancySettlement.getTid();
        this.stan = discrepancySettlement.getStan();
        this.interchange = discrepancySettlement.getInterchange();
        this.maskedCardNo = discrepancySettlement.getMaskedCardNo();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        DiscrepancySettlementBcp that = (DiscrepancySettlementBcp) o;

        if (discrepancyType != null ? !discrepancyType.equals(that.discrepancyType) : that.discrepancyType != null)
            return false;
        if (transType != null ? !transType.equals(that.transType) : that.transType != null)
            return false;
        return extSerialNo != null ? extSerialNo.equals(that.extSerialNo) : that.extSerialNo == null;
    }

    @Override
    public int hashCode() {
        int result = discrepancyType != null ? discrepancyType.hashCode() : 0;
        result = 31 * result + (transType != null ? transType.hashCode() : 0);
        result = 31 * result + (extSerialNo != null ? extSerialNo.hashCode() : 0);
        return result;
    }
}
