package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * Hibernate entity class This class responsible for hibernate entity to table
 * mapping
 * 
 * @author Kulbhushan Pandey
 * @date 6 March 2016
 */
@Entity
@Table(name = "DISCREPANCY_ADJUSTMENT_REQUEST")
public class DiscrepancyAdjustmentRequest extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "REQ_ID")
    private Long reqId;

    @Column(name = "DIS_ID")
    private Long discrepancyId;

    @Column(name = "DIS_MID")
    private String discrepancyMid;

    @Column(name = "DIS_TYPE")
    private String discrepancyType;

    @Column(name = "DIS_ADJUST_VALUE")
    private String discrepancyAdjustValue;

    @Column(name = "DIS_ACTION")
    private String discrepancyAction;

    @Column(name = "DIS_COMMENTS")
    private String discrepancyComments;

    @Column(name = "DIS_ORIGINATED_FROM")
    private String discrepancyOrginFrom;

    @Column(name = "REQ_BO_OPERATOR")
    private String reqBoOperatorName;

    @Column(name = "REQ_SOURCE")
    private String reqSource;

    @Column(name = "RETRY_COUNT")
    private Integer retryCount;

    @Column(name = "REQ_PROCESS_STATUS")
    private Integer reqProcessStatus;

    @OneToOne
    @JoinColumn(name = "DIS_ID", insertable = false, updatable = false)
    private DiscrepancySettlement discrepancySettlement;

    public DiscrepancyAdjustmentRequest() {
        super();
    }

    public DiscrepancyAdjustmentRequest(Long reqId, Long discrepancyId, String discrepancyMid, String discrepancyType,
            String discrepancyAdjustValue, String discrepancyComments, String reqBoOperatorName,
            String discrepancyAction, String reqSource) {
        super();
        initiateValues();
        this.reqId = reqId;
        this.discrepancyId = discrepancyId;
        this.discrepancyMid = discrepancyMid;
        this.discrepancyType = discrepancyType;
        this.discrepancyAdjustValue = discrepancyAdjustValue;
        this.discrepancyComments = discrepancyComments;
        this.reqBoOperatorName = reqBoOperatorName;
        this.discrepancyAction = discrepancyAction;
        this.reqSource = reqSource;
    }

    private void initiateValues() {
        createdOn = new Date();
        updatedOn = new Date();
        retryCount = 0;
        reqProcessStatus = 0;
        discrepancyOrginFrom = "PGPLUS";
    }

    public Long getReqId() {
        return reqId;
    }

    public void setReqId(Long reqId) {
        this.reqId = reqId;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getDiscrepancyId() {
        return discrepancyId;
    }

    public void setDiscrepancyId(Long discrepancyId) {
        this.discrepancyId = discrepancyId;
    }

    public String getDiscrepancyMid() {
        return discrepancyMid;
    }

    public void setDiscrepancyMid(String discrepancyMid) {
        this.discrepancyMid = discrepancyMid;
    }

    public String getDiscrepancyType() {
        return discrepancyType;
    }

    public void setDiscrepancyType(String discrepancyType) {
        this.discrepancyType = discrepancyType;
    }

    public String getDiscrepancyAdjustValue() {
        return discrepancyAdjustValue;
    }

    public void setDiscrepancyAdjustValue(String discrepancyAdjustValue) {
        this.discrepancyAdjustValue = discrepancyAdjustValue;
    }

    public String getDiscrepancyAction() {
        return discrepancyAction;
    }

    public void setDiscrepancyAction(String discrepancyAction) {
        this.discrepancyAction = discrepancyAction;
    }

    public String getDiscrepancyComments() {
        return discrepancyComments;
    }

    public void setDiscrepancyComments(String discrepancyComments) {
        this.discrepancyComments = discrepancyComments;
    }

    public String getDiscrepancyOrginFrom() {
        return discrepancyOrginFrom;
    }

    public void setDiscrepancyOrginFrom(String discrepancyOrginFrom) {
        this.discrepancyOrginFrom = discrepancyOrginFrom;
    }

    public String getReqBoOperatorName() {
        return reqBoOperatorName;
    }

    public void setReqBoOperatorName(String reqBoOperatorName) {
        this.reqBoOperatorName = reqBoOperatorName;
    }

    public Integer getRetryCount() {
        return retryCount;
    }

    public void setRetryCount(Integer retryCount) {
        this.retryCount = retryCount;
    }

    public Integer getReqProcessStatus() {
        return reqProcessStatus;
    }

    public void setReqProcessStatus(Integer reqProcessStatus) {
        this.reqProcessStatus = reqProcessStatus;
    }

    public String getReqSource() {
        return reqSource;
    }

    public void setReqSource(String reqSource) {
        this.reqSource = reqSource;
    }

    public DiscrepancySettlement getDiscrepancySettlement() {
        return discrepancySettlement;
    }

    public void setDiscrepancySettlement(DiscrepancySettlement discrepancySettlement) {
        this.discrepancySettlement = discrepancySettlement;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("DiscrepancyAdjustmentRequest [id=").append(id).append(", reqId=").append(reqId)
                .append(", discrepancyId=").append(discrepancyId).append(", discrepancyMid=").append(discrepancyMid)
                .append(", discrepancyType=").append(discrepancyType).append(", discrepancyAdjustValue=")
                .append(discrepancyAdjustValue).append(", discrepancyAction=").append(discrepancyAction)
                .append(", discrepancyComments=").append(discrepancyComments).append(", discrepancyOrginFrom=")
                .append(discrepancyOrginFrom).append(", reqBoOperatorName=").append(reqBoOperatorName)
                .append(", reqSource=").append(reqSource).append(", retryCount=").append(retryCount)
                .append(", reqProcessStatus=").append(reqProcessStatus).append(", discrepancySettlement=")
                .append(discrepancySettlement).append("]");
        return builder.toString();
    }

}
