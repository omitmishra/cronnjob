package com.paytm.pgplus.bocore.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.paytm.pgplus.bocore.enums.State;
import com.paytm.pgplus.bocore.mapping.enums.OperationType;

/**
 * @author honey.duhar
 */

@Entity
@Table(name = "migration_event_info")
public class MigrationEventInfo extends BaseEntity implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 4700879394678349806L;

    @Id
    @Basic(optional = false)
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "merchant_id")
    private String merchantId;

    @Column(name = "event_name")
    @Enumerated(EnumType.STRING)
    private OperationType event;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "event_create_time", nullable = false, updatable = false)
    private Date eventCreateTime;

    @Column(name = "event_status")
    @Enumerated(EnumType.STRING)
    private State eventStatus;

    @Column(name = "job_id")
    private long jobId;

    @Enumerated(EnumType.STRING)
    public State getEventStatus() {
        return eventStatus;
    }

    public long getJobId() {
        return jobId;
    }

    public void setJobId(long jobId) {
        this.jobId = jobId;
    }

    public void setEventStatus(State eventStatus) {
        this.eventStatus = eventStatus;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMerchantId() {
        return merchantId;
    }

    public void setMerchantId(String merchantId) {
        this.merchantId = merchantId;
    }

    public OperationType getEvent() {
        return event;
    }

    public void setEvent(OperationType event) {
        this.event = event;
    }

    public Date getEventCreateTime() {
        return eventCreateTime;
    }

    public void setEventCreateTime(Date eventCreateTime) {
        this.eventCreateTime = eventCreateTime;
    }

    public MigrationEventInfo(String merchantId, OperationType event, Date eventCreateTime, State eventStatus) {
        super();
        this.merchantId = merchantId;
        this.event = event;
        this.eventCreateTime = eventCreateTime;
        this.eventStatus = eventStatus;
    }

    public MigrationEventInfo() {
    }

}
