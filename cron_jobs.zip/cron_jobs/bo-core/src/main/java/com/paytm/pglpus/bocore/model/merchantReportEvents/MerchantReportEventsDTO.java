package com.paytm.pglpus.bocore.model.merchantReportEvents;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.io.Serializable;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantReportEventsDTO implements Serializable {
    private Long eventId;
    private String merchantId;
    private String currentEventProcessor;

    @Override
    public String toString() {
        return "MerchantReportEventsDTO{" + "eventId=" + eventId + ", merchantId='" + merchantId + '\''
                + ", currentEventProcessor='" + currentEventProcessor + '\'' + '}';
    }
}
