package com.paytm.pglpus.bocore.model;

import com.paytm.pgplus.bocore.constants.OfflineReconFileHeadersConstant;
import com.paytm.pgplus.bocore.entity.OpenDisputeReportHeader;
import com.paytm.pgplus.bocore.enums.ChargebackSource;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.file.util.annotation.CsvColumnMapper;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author santoshkumar
 */

@Data
public class BankTransferReconReportModel {

    @CsvColumnMapper(columnName = OfflineReconFileHeadersConstant.BANK_TXN_ID)
    private String bankTxnId;
    @CsvColumnMapper(columnName = OfflineReconFileHeadersConstant.TXN_AMOUNT)
    private BigDecimal txnAmount;
    @CsvColumnMapper(columnName = OfflineReconFileHeadersConstant.TRANSACTION_TYPE)
    private String transactionType;
    @CsvColumnMapper(columnName = OfflineReconFileHeadersConstant.TRANSACTION_STATUS)
    private String transactionStatus;

    public BankTransferReconReportModel(String bankTxnId, BigDecimal txnAmount, String transactionType,
            String transactionStatus) {

        this.bankTxnId = bankTxnId;
        this.txnAmount = txnAmount;
        this.transactionType = transactionType;
        this.transactionStatus = transactionStatus;
    }

}
