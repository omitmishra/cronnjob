package com.paytm.pglpus.bocore.model.request;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * * This class represents request of download summary callback api by
 * UMP_PANEL. Reference url:
 * https://wiki.mypaytm.com/display/PPD/Download+Notification+Callback
 *
 * @author nitinbhola27
 *
 */
@Getter
@Setter
@AllArgsConstructor
public class UMPDownloadCallbackRequest {
    private String downloadId;
    private String fileURL;
    private String status;
}
