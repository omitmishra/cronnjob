package com.paytm.pgplus.bocore.entity;

import lombok.*;

/**
 * Created by ishasinghal on 15/9/17.
 */
@Setter
@Getter
@AllArgsConstructor
// @ToString
public class InstaRefundRequest<T> {

    private T request;
    private String signature;

    public String toJson() {
        StringBuilder sb = new StringBuilder();
        sb.append("{\"request\":");
        sb.append(request);
        sb.append(", \"signature\":\"");
        sb.append(signature);
        sb.append("\"}");
        return sb.toString();
    }

}