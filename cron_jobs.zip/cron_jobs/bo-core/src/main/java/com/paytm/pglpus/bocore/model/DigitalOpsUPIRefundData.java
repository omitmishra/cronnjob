package com.paytm.pglpus.bocore.model;

import org.file.util.annotation.CsvColumnMapper;

import com.paytm.pgplus.bocore.entity.DigitalOpsUPIRefundHeader;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by ishasinghal on 31/1/18.
 */

@Getter
@Setter
public class DigitalOpsUPIRefundData {

    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.MERCHANT_REFERENCE_NO)
    String origExtSerialNum;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.FLAG)
    String flag;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.SHTDAT)
    String txnDate;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.ADJAMT)
    String refundAmount;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.SHSER)
    String bankTxnId;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.SHCRD)
    String virtualPaymentAddr;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.FILENAME)
    String fileName;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.REASON)
    String reason;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.OTHER)
    String specifyOther;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.REFUND_DATE)
    String refundDate;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.ORDER_ID)
    String orderId;
    @CsvColumnMapper(columnName = DigitalOpsUPIRefundHeader.STATUS)
    String status;

    @Override
    public String toString() {
        return "DigitalOpsUPIRefundData{" + "origExtSerialNum='" + origExtSerialNum + '\'' + ", flag='" + flag + '\''
                + ", txnDate='" + txnDate + '\'' + ", refundAmount='" + refundAmount + '\'' + ", bankTxnId='"
                + bankTxnId + '\'' + ", virtualPaymentAddr='" + virtualPaymentAddr + '\'' + ", fileName='" + fileName
                + '\'' + ", reason='" + reason + '\'' + ", specifyOther='" + specifyOther + '\'' + '}';
    }
}
