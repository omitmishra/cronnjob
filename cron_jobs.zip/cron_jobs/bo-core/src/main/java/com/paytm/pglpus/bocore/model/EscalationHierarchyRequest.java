package com.paytm.pglpus.bocore.model;

import lombok.Getter;
import lombok.Setter;

/**
 * Created by dheeraj on 21/11/17.
 */

@Getter
@Setter
public class EscalationHierarchyRequest {
    long teamId;
    long teamMemberId;
    Integer beforeLevel;
}
