package com.paytm.pgplus.bocore.constants;

public class BulkPodUploadReportColumns {

    public static final String ACQUIRING_REF_NUM = "ACQUIRING_REF_NUM";
    public static final String STATUS = "STATUS";
    public static final String STATUS_MESSAGE = "STATUS_MESSAGE";
    public static final String PROOF_UPLOAD_DATE = "PROOF_UPLOAD_DATE";
    public static final String LOT_NAME = "LOT_NAME";

    public static final String[] BULK_POD_UPLOAD_REPORT_COLUMNS = { ACQUIRING_REF_NUM, STATUS, STATUS_MESSAGE,
            PROOF_UPLOAD_DATE, LOT_NAME };
}
