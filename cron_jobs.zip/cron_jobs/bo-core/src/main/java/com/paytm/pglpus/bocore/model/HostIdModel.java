package com.paytm.pglpus.bocore.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Created by dheeraj on 27/01/18.
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HostIdModel {
    String hostIdList;
    List<ZabbixHostModel> zabbixHostModelList;
}
