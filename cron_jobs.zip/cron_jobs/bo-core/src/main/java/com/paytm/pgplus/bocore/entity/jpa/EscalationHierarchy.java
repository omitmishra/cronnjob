package com.paytm.pgplus.bocore.entity.jpa;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by dheeraj on 21/11/17.
 */

@Getter
@Setter
@Entity
@Data
public class EscalationHierarchy {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    long id;

    @JoinColumn
    @ManyToOne
    Team team;

    Integer level;

    @JoinColumn
    @ManyToOne
    TeamMember teamMember;

    Date createdOn;
    Date updatedOn;

}
