package com.paytm.pgplus.bocore.entity;

public class OpenDisputeReportHeader {

    public static final String MID = "MID";
    public static final String DISPLAY_NAME = "Display Name";
    public static final String BUSINESS_NAME = "Business Name";
    public static final String DISPUTE_ID = "Dispute ID";
    public static final String ESN = "ESN";
    public static final String DISPUTE_TYPE = "Dispute Type";
    public static final String DISPUTE_CREATION_DATE = "Dispute Creation Date";
    public static final String DISPUTE_CREATED_TIME = "Dispute Created Time";
    public static final String TXN_DATE = "TXN Date";
    public static final String TXN_AMOUNT = "Txn Amt";
    public static final String DISPUTE_AMOUNT = "Dispute Amt";
    public static final String TXN_UTR = "Txn UTR";
    public static final String DISPUTE_UTR = "Dispute UTR";
    public static final String TXN_ID = "TXN ID";
    public static final String ORDER_ID = "Order ID";
    public static final String DISPUTE_STATUS = "Dispute Status";
    public static final String REASON_ACCEPTANCE = "Reason of Acceptance";
    public static final String DISPUTE_UPDATE_DATE = "Dispute Update Date";
    public static final String STATUS_COMMENT = "Status comment";
    public static final String STATUS = "Status";
    public static final String REASON_REJECTION = "Reason of Rejection";
    public static final String DEFENCE_DOC1 = "Defense Doc 1";
    public static final String DEFENCE_DOC2 = "Defense Doc 2";
    public static final String ONUS_OFFUS = "ONUS/OFFUS";
    public static final String SOURCE = "Source";
    public static final String BANK_REFERENCE_ID = "Bank reference ID";
    public static final String DISPUTE_PAYOUT_ID = "Dispute payout ID";
    public static final String DISPUTE_DUE_DATE = "Due Date";
    public static final String BANK_GATEWAY = "Bank/Gateway";
    public static final String DISPUTE_CLOSURE_DATE = "Settlement Date";
    public static final String DISPUTE_LOST_DATE = "Dispute Lost Date";
    public static final String BANK_NAME = "Bank Name";
    public static final String PAY_MODE = "Pay Mode";
    public static final String TRANSACTION_DATE = "Transaction Date";
    public static final String PRIORITY = "Priority";
    public static final String DATA_UPLOAD = "Data uploaded";

    public static final String[] OPEN_DISPUTE_REPORT_HEADER = new String[] { MID, DISPLAY_NAME, BUSINESS_NAME,
            DISPUTE_ID, ESN, DISPUTE_TYPE, DISPUTE_CREATION_DATE, DISPUTE_CREATED_TIME, TXN_DATE, TXN_AMOUNT,
            DISPUTE_AMOUNT, TXN_UTR, DISPUTE_UTR, TXN_ID, ORDER_ID, DISPUTE_STATUS, REASON_ACCEPTANCE,
            DISPUTE_UPDATE_DATE, STATUS_COMMENT, REASON_REJECTION, DEFENCE_DOC1, DEFENCE_DOC2, ONUS_OFFUS, SOURCE,
            BANK_REFERENCE_ID, DISPUTE_PAYOUT_ID };

    public static final String[] UBER_OPEN_DISPUTE_REPORT_HEADER = new String[] { DISPUTE_ID, DISPUTE_CREATION_DATE,
            TXN_ID, TXN_DATE, ORDER_ID, TXN_AMOUNT, DISPUTE_AMOUNT, DISPUTE_STATUS, MID, ESN, DISPUTE_UTR,
            DISPUTE_UPDATE_DATE, STATUS_COMMENT, BANK_REFERENCE_ID, BANK_GATEWAY, DISPUTE_DUE_DATE, REASON_ACCEPTANCE };
    public static final String[] DISPUTE_UTR_UPDATE_REPORT_HEADERS = new String[] { MID, DISPUTE_ID, ESN,
            BANK_REFERENCE_ID, TXN_ID, ORDER_ID, DISPUTE_UTR, DISPUTE_CLOSURE_DATE, DISPUTE_CREATION_DATE, TXN_AMOUNT,
            DISPUTE_AMOUNT, DISPUTE_LOST_DATE };
    public static final String[] RECON_FILE_RECEIVED_HEADER = new String[] { BANK_NAME, PAY_MODE, TRANSACTION_DATE,
            PRIORITY, DATA_UPLOAD };
    public static final String[] LIC_NOT_POSTED_DATA = new String[] { MID, TXN_ID, ORDER_ID, STATUS };
}
