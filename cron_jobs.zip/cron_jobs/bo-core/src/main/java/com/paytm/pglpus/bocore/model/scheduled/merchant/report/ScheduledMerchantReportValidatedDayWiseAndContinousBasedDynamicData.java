package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportConfig;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportEvent;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportEventPayoutInfo;
import com.paytm.pgplus.bocore.enums.ScheduledMerchantReportPayoutStatus;
import com.paytm.pgplus.bocore.helper.DateUtil;
import com.paytm.pgplus.bocore.repository.jpa.read.ScheduledMerchantReportEventPayoutInfoReadRepository;
import com.paytm.pgplus.bocore.repository.jpa.write.ScheduledMerchantReportEventPayoutInfoWriteRepository;

import com.paytm.pgplus.bocore.util.AppContextProvider;
import com.paytm.pgplus.facade.consume.enums.SettleStatus;
import com.paytm.pgplus.facade.dataservice.models.SettlementBill;
import lombok.Data;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

@Data
public class ScheduledMerchantReportValidatedDayWiseAndContinousBasedDynamicData extends
        ScheduledMerchantReportDayWiseBasedDynamicData {

    private static final Logger LOGGER = LoggerFactory
            .getLogger(ScheduledMerchantReportValidatedDayWiseAndContinousBasedDynamicData.class);

    private ScheduledMerchantReportEventPayoutInfoReadRepository scheduledMerchantReportEventPayoutInfoReadRepository;

    private ScheduledMerchantReportEventPayoutInfoWriteRepository scheduledMerchantReportEventPayoutInfoWriteRepository;

    public ScheduledMerchantReportValidatedDayWiseAndContinousBasedDynamicData() {
        super(ReportGenerationModularityForDynamicData.VALIDATED_DAY_WISE_CONTINOUS);
    }

    @Override
    public List<ScheduledMerchantReportEvent> getScheduledMerchantReportEvents(
            ScheduledMerchantReportConfigEventInfoPayload payload) {

        List<ScheduledMerchantReportEvent> scheduledMerchantReportEvents = new ArrayList<>();

        if (CollectionUtils.isEmpty(payload.getSettlementBillList())) {
            LOGGER.info("Empty settlementBillList received, will not be creating any event for config: {}", payload
                    .getScheduledMerchantReportConfig().getScheduleMerchantReportId());
            return scheduledMerchantReportEvents;
        }

        LOGGER.info("settlementBillList received for config: {} ==> {}", payload.getScheduledMerchantReportConfig()
                .getScheduleMerchantReportId(), payload.getSettlementBillList());

        scheduledMerchantReportEventPayoutInfoReadRepository = (ScheduledMerchantReportEventPayoutInfoReadRepository) AppContextProvider
                .getBean("scheduledMerchantReportEventPayoutInfoReadRepository");

        scheduledMerchantReportEventPayoutInfoWriteRepository = (ScheduledMerchantReportEventPayoutInfoWriteRepository) AppContextProvider
                .getBean("scheduledMerchantReportEventPayoutInfoWriteRepository");

        ScheduledMerchantReportConfig scheduledMerchantReportConfig = payload.getScheduledMerchantReportConfig();
        Date latestEventDataIncludedTo = payload.getLatestEventDataIncludedTo();

        Date currentDate = new Date();
        Date reportTriggerTime = getReportTriggerTime(currentDate);
        Date txnIncludedFrom = currentDate;

        // create event for all settled payout (if not created)
        for (SettlementBill bill : payload.getSettlementBillList()) {

            long scheduledMerchantReportPayoutInfoId;

            // fetch entity from DB by payoutId
            Optional<ScheduledMerchantReportEventPayoutInfo> payoutInfo = scheduledMerchantReportEventPayoutInfoReadRepository
                    .findByPayoutId(bill.getSettlementBillId());

            // calculate txn time range
            txnIncludedFrom = DateUtil.removeTimeFromDate(bill.getSettlementTime());
            txnIncludedFrom = DateUtil.setDateField(txnIncludedFrom, Calendar.MINUTE, this.getStartMinute());
            txnIncludedFrom = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.DATE,
                    -1 * payload.getSettlementDayWindow());

            Date txnIncludedTo = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.DATE,
                    scheduledMerchantReportConfig.getIntervalModularityWise());
            txnIncludedTo = DateUtil.shiftDateByField(txnIncludedTo, Calendar.MILLISECOND, 1);

            LOGGER.info(
                    "calculated txnIncludedFrom: {}, txnIncludedTo: {}, currentDate: {} for configId: {}, settlementBillId: {}, status: {}",
                    txnIncludedFrom, txnIncludedTo, currentDate, payload.getScheduledMerchantReportConfig()
                            .getScheduleMerchantReportId(), bill.getSettlementBillId(), bill.getSettleStatus());

            // if this is new payout info, that does not exists in DB
            if (!payoutInfo.isPresent()) {

                // save this payout detail in DB with INIT status
                ScheduledMerchantReportEventPayoutInfo obj = new ScheduledMerchantReportEventPayoutInfo();
                obj.setMid(bill.getIpRoleId());
                obj.setPayoutId(bill.getSettlementBillId());
                obj.setPayoutProcessingDate(bill.getSettlementTime());

                obj.setStatus(ScheduledMerchantReportPayoutStatus.INIT);

                LOGGER.info("going to insert ScheduledMerchantReportEventPayoutInfo: {}", obj);

                scheduledMerchantReportPayoutInfoId = scheduledMerchantReportEventPayoutInfoWriteRepository.save(obj)
                        .getId();
            } else {
                LOGGER.info("found ScheduledMerchantReportEventPayoutInfo: {} by billId: {}", payoutInfo,
                        bill.getSettlementBillId());
                scheduledMerchantReportPayoutInfoId = payoutInfo.get().getId();
            }

            // event must be created if payout is settled and it is either a new
            // entry or was in INIT earlier
            if (SettleStatus.PAYOUT_SETTLED.equals(bill.getSettleStatus())
                    && (!payoutInfo.isPresent() || ScheduledMerchantReportPayoutStatus.INIT.equals(payoutInfo.get()
                            .getStatus()))) {

                if (!txnIncludedTo.after(reportTriggerTime) && !currentDate.before(reportTriggerTime)) {

                    // add this event into list
                    ScheduledMerchantReportEvent event = getScheduledMerchantReportEvent(txnIncludedFrom,
                            txnIncludedTo, scheduledMerchantReportConfig);

                    // assign payoutInfoId to each event
                    event.getDownloadEventForScheduledMerchantReportEvents().forEach(
                            e -> e.setScheduledMerchantReportPayoutInfoId(scheduledMerchantReportPayoutInfoId));

                    scheduledMerchantReportEvents.add(event);
                }
            }
        }

        return scheduledMerchantReportEvents;
    }
}
