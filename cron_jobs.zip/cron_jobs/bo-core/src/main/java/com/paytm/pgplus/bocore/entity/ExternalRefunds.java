package com.paytm.pgplus.bocore.entity;

import java.sql.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Isha Singhal
 *
 */
@Getter
@Setter
@Entity
@Table(name = "external_refunds")
public class ExternalRefunds {

    @Basic(optional = false)
    @Column(name = "id", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "charging_esn")
    private String chargingEsn;

    @Column(name = "biz_order_id")
    private String bizOrderId;

    @Column(name = "refunded_date")
    private String refundedDate;

    @Column(name = "refund_amount")
    private Double refundAmount;

    @Column(name = "comment")
    private String comment;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "enabled")
    private Boolean enabled;

    @Column(name = "refund_mode")
    private String refundMode;

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((bizOrderId == null) ? 0 : bizOrderId.hashCode());
        result = prime * result + ((chargingEsn == null) ? 0 : chargingEsn.hashCode());
        result = prime * result + ((comment == null) ? 0 : comment.hashCode());
        result = prime * result + ((enabled == null) ? 0 : enabled.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
        result = prime * result + ((refundAmount == null) ? 0 : refundAmount.hashCode());
        result = prime * result + ((refundMode == null) ? 0 : refundMode.hashCode());
        result = prime * result + ((refundedDate == null) ? 0 : refundedDate.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        ExternalRefunds other = (ExternalRefunds) obj;
        if (bizOrderId == null) {
            if (other.bizOrderId != null)
                return false;
        } else if (!bizOrderId.equals(other.bizOrderId))
            return false;
        if (chargingEsn == null) {
            if (other.chargingEsn != null)
                return false;
        } else if (!chargingEsn.equals(other.chargingEsn))
            return false;
        if (comment == null) {
            if (other.comment != null)
                return false;
        } else if (!comment.equals(other.comment))
            return false;
        if (enabled == null) {
            if (other.enabled != null)
                return false;
        } else if (!enabled.equals(other.enabled))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (orderId == null) {
            if (other.orderId != null)
                return false;
        } else if (!orderId.equals(other.orderId))
            return false;
        if (refundAmount == null) {
            if (other.refundAmount != null)
                return false;
        } else if (!refundAmount.equals(other.refundAmount))
            return false;
        if (refundMode == null) {
            if (other.refundMode != null)
                return false;
        } else if (!refundMode.equals(other.refundMode))
            return false;
        if (refundedDate == null) {
            if (other.refundedDate != null)
                return false;
        } else if (!refundedDate.equals(other.refundedDate))
            return false;
        return true;
    }

}
