package com.paytm.pgplus.bocore.constants;

import java.util.HashMap;
import java.util.Map;

public enum FileProcessingStatus {

    INIT((short) 0, "INIT"), PENDING((short) 1, "PENDING"), SUCCESS((short) 2, "SUCCESS"), SFTP((short) 3, "SFTP"), EMAIL_SENT(
            (short) 4, "EMAIL_SENT"), EMPTY((short) 5, "EMPTY"), COMPLETE_FAILURE((short) 6, "COMPLETE_FAILURE"), EMAIL_NOT_SENT(
            (short) 7, "EMAIL_NOT_SENT"), VALIDATION_FAIL((short) 8, "VALIDATION_FAIL"), WALLET_ONLY((short) 9,
            "WALLET_ONLY");

    private short code;
    private String message;

    public static final Map<Short, FileProcessingStatus> STATUSMAP = new HashMap<Short, FileProcessingStatus>();

    static {
        STATUSMAP.put(INIT.getCode(), INIT);
        STATUSMAP.put(PENDING.getCode(), PENDING);
        STATUSMAP.put(SUCCESS.getCode(), SUCCESS);
        STATUSMAP.put(SFTP.getCode(), SFTP);
        STATUSMAP.put(EMAIL_SENT.getCode(), EMAIL_SENT);
        STATUSMAP.put(EMPTY.getCode(), EMPTY);
        STATUSMAP.put(WALLET_ONLY.getCode(), WALLET_ONLY);
        STATUSMAP.put(COMPLETE_FAILURE.getCode(), COMPLETE_FAILURE);
        STATUSMAP.put(EMAIL_NOT_SENT.getCode(), EMAIL_NOT_SENT);
        STATUSMAP.put(VALIDATION_FAIL.getCode(), VALIDATION_FAIL);
    }

    private FileProcessingStatus(short code, String message) {

        this.code = code;
        this.message = message;

    }

    public short getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }

    public static String getMessage(Short code) {
        return STATUSMAP.get(code).getMessage();
    }

    public static FileProcessingStatus getFileProcessingStatus(Short code) {
        return STATUSMAP.get(code);
    }

}
