package com.paytm.pgplus.bocore.entity.jpa;

import com.paytm.pgplus.bocore.entity.BaseEntity;
import com.paytm.pgplus.bocore.entity.OpenDisputeReportHeader;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.file.util.annotation.CsvColumnMapper;

import javax.persistence.*;
import java.io.Serializable;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "files_meta_data")
public class FilesMetaData extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name")
    private String fileName;

    @Column(name = "file_path")
    private String filePath;

    @Column(name = "file_type")
    private String fileType;

    @Column(name = "server_ip")
    private String serverIp;

    @Column(name = "status")
    private String status;

    public FilesMetaData(String fileName, String filePath, String fileType, String status, String serverIp) {
        this.fileName = fileName;
        this.filePath = filePath;
        this.fileType = fileType;
        this.status = status;
        this.serverIp = serverIp;
    }
}
