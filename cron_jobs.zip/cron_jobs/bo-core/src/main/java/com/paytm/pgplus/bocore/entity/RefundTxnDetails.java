package com.paytm.pgplus.bocore.entity;

import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author Himanshu Sardana
 * @since 03 June 2016
 */
@Entity
@Table(name = "refund_txn_details")
@XmlRootElement
@NamedQueries({
        @NamedQuery(name = RefundTxnDetails.FIND_AUTO_REFUND, query = "SELECT o FROM RefundTxnDetails o WHERE o.refundTxnSource='AUTO' and o.createdOn > :startDate"),
        @NamedQuery(name = "RefundTxnDetails.findByRefundTxnByOrigTxnId", query = "SELECT o FROM RefundTxnDetails o WHERE o.origExtSerialNum = :txnId ORDER BY createdOn ASC"),
        @NamedQuery(name = "RefundTxnDetails.findByRefundTxnByRefundTxnId", query = "SELECT o FROM RefundTxnDetails o WHERE o.refundExtSerialNum = :txnId ORDER BY createdOn ASC"),
        @NamedQuery(name = "RefundTxnDetails.findByRefundTxnByRowId", query = "SELECT o FROM RefundTxnDetails o WHERE o.id = :id"),
        @NamedQuery(name = "RefundTxnDetails.updateSentForRecon", query = "UPDATE RefundTxnDetails o SET o.sentForRecon = :sentForRecon WHERE o.refundExtSerialNum IN (:refundExtSerialNum)"),
        @NamedQuery(name = "RefundTxnDetails.findByUpdatedTimeStampAndSentForRecon", query = "SELECT o FROM RefundTxnDetails o WHERE o.sentForRecon = :sentForRecon AND o.updatedOn > :updatedOn") })
public class RefundTxnDetails implements Serializable {
    public static final String FIND_AUTO_REFUND = "findByRefundTxnSource";

    /**
	 * 
	 */
    private static final long serialVersionUID = -8253258888550021911L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "refund_ext_serial_num", length = 20)
    private String refundExtSerialNum;

    @Column(name = "orig_ext_serial_num", length = 20)
    private String origExtSerialNum;

    @Column(name = "refund_amount")
    private BigDecimal refundAmount;

    @Column(name = "orig_txn_amount")
    private BigDecimal origTxnAmount;

    @Column(name = "bank_code", length = 20)
    private String bankCode;

    @Column(name = "bank_reference_number", length = 32)
    private String bankReferenceNumber;

    @Column(name = "bank_response_code")
    private String bankResponseCode;

    @Column(name = "status_code", length = 20)
    private Integer statusCode;

    @Column(name = "status_message", length = 32)
    private String statusMessage;

    @Column(name = "refund_txn_source", length = 20)
    private String refundTxnSource;

    @Column(name = "refund_creation_time")
    private Date refundCreationTime;

    @Column(name = "orig_txn_creation_time")
    private Date origTxnCreationTime;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_on", nullable = false)
    private Date createdOn;

    @Basic(optional = false)
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedOn;

    @Column(name = "sent_for_recon", columnDefinition = "int default 0")
    private Integer sentForRecon;

    @Column(name = "paymode", length = 32)
    private String paymode;

    public Integer getSentForRecon() {
        return sentForRecon;
    }

    public void setSentForRecon(Integer sentForRecon) {
        this.sentForRecon = sentForRecon;
    }

    public String getRefundExtSerialNum() {
        return refundExtSerialNum;
    }

    public void setRefundExtSerialNum(String refundExtSerialNum) {
        this.refundExtSerialNum = refundExtSerialNum;
    }

    public String getOrigExtSerialNum() {
        return origExtSerialNum;
    }

    public void setOrigExtSerialNum(String origExtSerialNum) {
        this.origExtSerialNum = origExtSerialNum;
    }

    public BigDecimal getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(BigDecimal refundAmount) {
        this.refundAmount = refundAmount;
    }

    public BigDecimal getOrigTxnAmount() {
        return origTxnAmount;
    }

    public void setOrigTxnAmount(BigDecimal origTxnAmount) {
        this.origTxnAmount = origTxnAmount;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getBankReferenceNumber() {
        return bankReferenceNumber;
    }

    public void setBankReferenceNumber(String bankReferenceNumber) {
        this.bankReferenceNumber = bankReferenceNumber;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public String getRefundTxnSource() {
        return refundTxnSource;
    }

    public void setRefundTxnSource(String refundTxnSource) {
        this.refundTxnSource = refundTxnSource;
    }

    public Date getRefundCreationTime() {
        return refundCreationTime;
    }

    public void setRefundCreationTime(Date refundCreationTime) {
        this.refundCreationTime = refundCreationTime;
    }

    public Date getOrigTxnCreationTime() {
        return origTxnCreationTime;
    }

    public void setOrigTxnCreationTime(Date origTxnCreationTime) {
        this.origTxnCreationTime = origTxnCreationTime;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getUpdatedOn() {
        return updatedOn;
    }

    public void setUpdatedOn(Date updatedOn) {
        this.updatedOn = updatedOn;
    }

    public String getPaymode() {
        return paymode;
    }

    public void setPaymode(String paymode) {
        this.paymode = paymode;
    }

    public String getBankResponseCode() {
        return bankResponseCode;
    }

    public void setBankResponseCode(String bankResponseCode) {
        this.bankResponseCode = bankResponseCode;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((refundExtSerialNum == null) ? 0 : refundExtSerialNum.hashCode());
        return result;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        RefundTxnDetails other = (RefundTxnDetails) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (refundExtSerialNum == null) {
            if (other.refundExtSerialNum != null)
                return false;
        } else if (!refundExtSerialNum.equals(other.refundExtSerialNum))
            return false;
        return true;
    }

    public RefundTxnDetails(RefundTxnDetails refundTxn) {

        this.refundExtSerialNum = refundTxn.getRefundExtSerialNum();
        this.origExtSerialNum = refundTxn.getOrigExtSerialNum();
        this.refundAmount = refundTxn.getRefundAmount();
        this.origTxnAmount = refundTxn.getOrigTxnAmount();
        this.bankCode = refundTxn.getBankCode();
        this.bankReferenceNumber = refundTxn.getBankReferenceNumber();
        this.statusCode = refundTxn.getStatusCode();
        this.statusMessage = refundTxn.getStatusMessage();
        this.refundTxnSource = refundTxn.getRefundTxnSource();
        this.refundCreationTime = refundTxn.getRefundCreationTime();
        this.origTxnCreationTime = refundTxn.getOrigTxnCreationTime();
        this.createdOn = refundTxn.getCreatedOn();
        this.updatedOn = refundTxn.getUpdatedOn();
    }

    public RefundTxnDetails() {
        super();
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("RefundTxnDetails [id=").append(id).append(", refundExtSerialNum=").append(refundExtSerialNum)
                .append(", origExtSerialNum=").append(origExtSerialNum).append(", refundAmount=").append(refundAmount)
                .append(", origTxnAmount=").append(origTxnAmount).append(", bankCode=").append(bankCode)
                .append(", bankReferenceNumber=").append(bankReferenceNumber).append(", statusCode=")
                .append(statusCode).append(", statusMessage=").append(statusMessage).append(", refundTxnSource=")
                .append(refundTxnSource).append(", refundCreationTime=").append(refundCreationTime)
                .append(", origTxnCreationTime=").append(origTxnCreationTime).append(", createdOn=").append(createdOn)
                .append(", updatedOn=").append(updatedOn).append(", sentForRecon=").append(sentForRecon).append("]");
        return builder.toString();
    }
}
