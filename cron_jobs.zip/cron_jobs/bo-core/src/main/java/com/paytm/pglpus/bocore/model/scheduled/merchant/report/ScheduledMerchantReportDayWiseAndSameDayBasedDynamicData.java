package com.paytm.pglpus.bocore.model.scheduled.merchant.report;

import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportConfig;
import com.paytm.pgplus.bocore.entity.jpa.scheduled.merchant.report.ScheduledMerchantReportEvent;
import com.paytm.pgplus.bocore.helper.DateUtil;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Data
public class ScheduledMerchantReportDayWiseAndSameDayBasedDynamicData extends
        ScheduledMerchantReportDayWiseBasedDynamicData {

    private static final Logger LOGGER = LoggerFactory
            .getLogger(ScheduledMerchantReportDayWiseAndSameDayBasedDynamicData.class);

    @Min(0)
    @Max(1440)
    private int endMinute = 1440;

    public ScheduledMerchantReportDayWiseAndSameDayBasedDynamicData() {
        super(ReportGenerationModularityForDynamicData.SAME_DAY);
    }

    @Override
    public List<ScheduledMerchantReportEvent> getScheduledMerchantReportEvents(
            ScheduledMerchantReportConfigEventInfoPayload payload) {

        ScheduledMerchantReportConfig scheduledMerchantReportConfig = payload.getScheduledMerchantReportConfig();
        Date latestEventDataIncludedTo = payload.getLatestEventDataIncludedTo();

        List<ScheduledMerchantReportEvent> scheduledMerchantReportEvents = new ArrayList<>();
        Date currentDateTime = DateUtil.removeTimeFromDate(new Date());
        Date nextDateTime = DateUtil.shiftDateByField(currentDateTime, Calendar.DATE, 1);
        Date reportTriggerTime = getReportTriggerTime(currentDateTime);
        Date currentDate = new Date();

        LOGGER.info(" report trigger time calculate for {} for config id {} ", reportTriggerTime,
                scheduledMerchantReportConfig.getScheduleMerchantReportId());

        if (0 == this.getEndMinute()) {
            /*
             * end minutes cant't be zero for same day report because it will
             * calculate txnIncludedTo as 00:00:00 instead of 23:59:59
             * 
             * set end minute 1440 for same day midnight
             */
            this.setEndMinute(1440);
        } else if (this.getStartMinute() > this.getEndMinute()) {
            /*
             * end minutes are later than start minute? we should swap them
             */
            int startMinute = this.getStartMinute();
            this.setStartMinute(this.getEndMinute());
            this.setEndMinute(startMinute);

        }

        Date txnIncludedFrom = currentDateTime;

        while (true) {

            Date txnIncludedTo = DateUtil.removeTimeFromDate(txnIncludedFrom);

            txnIncludedFrom = DateUtil.setDateField(txnIncludedFrom, Calendar.MINUTE, this.getStartMinute());
            txnIncludedTo = DateUtil.setDateField(txnIncludedTo, Calendar.MINUTE, this.getEndMinute());

            if (latestEventDataIncludedTo == null || !latestEventDataIncludedTo.after(txnIncludedFrom)) {
                if (!txnIncludedTo.after(nextDateTime) && !reportTriggerTime.after(nextDateTime)
                        && !currentDate.before(reportTriggerTime)) {
                    scheduledMerchantReportEvents.add(getScheduledMerchantReportEvent(txnIncludedFrom, txnIncludedTo,
                            scheduledMerchantReportConfig));
                }
                if (latestEventDataIncludedTo == null) {
                    break;
                }

                // move to previous date
                txnIncludedFrom = DateUtil.shiftDateByField(txnIncludedFrom, Calendar.DATE, -1);
            } else {
                break;
            }
        }
        return scheduledMerchantReportEvents;
    }
}
