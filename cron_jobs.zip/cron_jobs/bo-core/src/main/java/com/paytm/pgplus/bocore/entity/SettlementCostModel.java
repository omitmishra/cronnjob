package com.paytm.pgplus.bocore.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "settlement_cost_details")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SettlementCostModel {

    private static final long serialVersionUID = -3898495550004538987L;

    @Id
    @Basic(optional = false)
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "bank_comission_perc")
    private Double bankComissionPerc;

    @Column(name = "bank_comission_amount")
    private Double bankComissionAmount;

    @Column(name = "bank_gst")
    private Double bankGST;

    @Column(name = "bank_vat")
    private Double bankVAT;

    @Column(name = "bank_service_tax")
    private Double bankServiceTax;

    @Column(name = "bank_cess")
    private Double bankCess;

    @Column(name = "bank_total_tax")
    private Double bankTotalTax;

    @Column(name = "onus_indicator")
    private String onusIndicator;

    @Column(name = "bank_card_scheme")
    private String bankCardScheme;

    @Column(name = "bank_card_type")
    private String bankCardType;

    @Column(name = "bank_international")
    private Byte bankInternational;

    @Column(name = "bank_corporate")
    private Byte bankCorporate;

    @Column(name = "mcc_code")
    private String MCCCode;

    @Column(name = "terminal_code")
    private String terminalCode;

    @Column(name = "store_code")
    private String storeCode;

    @Column(name = "store_trading_name")
    private String storeTradingName;

    @Column(name = "mbid")
    private String mbid;

    @Column(name = "udf1")
    private String udf1;

    @Column(name = "udf2")
    private String udf2;

    @Column(name = "udf3")
    private String udf3;

    @Column(name = "udf4")
    private String udf4;

    @Column(name = "udf5")
    private String udf5;

    @Column(name = "udf6")
    private String udf6;

    @ManyToOne
    @JoinColumn(name = "settlement_id")
    private SettlementFileModel settlementFileModel;
}
