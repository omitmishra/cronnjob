package com.paytm.pgplus.bocore.constants;

import org.apache.commons.lang3.StringUtils;

import java.io.File;

/**
 * @author Himanshu Sardana
 * @since 06 Feb 2016
 *
 */
public class OfflineRefundFile {

    // as per doc format is REFUND_NB_REQUEST_<AppId>_<Date>_<Seq>.csv
    // private static final Logger LOGGER =
    // LoggerFactory.getLogger(OfflineRefundFile.class);

    private String fileParent;
    private String fileName;
    private String paymentMode;
    private String bankCode;
    private String fileDate;
    private String fileFormat;
    private String fileSeq;
    private Long fileId;

    public OfflineRefundFile(File filePath) {

        if (filePath != null) {

            this.fileParent = filePath.getParent() != null ? filePath.getParent().toString() : null;

            this.fileName = filePath.getName() != null ? filePath.getName().toString() : null;

            String[] fileNameArray = fileName.split("\\_");
            String[] fileFormat = fileName.split("\\.");

            if (fileNameArray.length >= 6) {
                String bankCode = fileNameArray[3];
                String paymode = fileNameArray[1];
                if (StringUtils.isNotEmpty(bankCode) && bankCode.endsWith(Constants.EDC_CHANNEL_CODE)) {
                    if (StringUtils.isNotEmpty(paymode) && Constants.BANKCARD_PAY_MODE.equals(paymode)) {
                        paymode = Constants.EDC_PAY_MODE;
                    }
                }
                this.paymentMode = paymode;
                this.bankCode = bankCode;
                this.fileDate = fileNameArray[4];
                this.fileSeq = fileNameArray[5].split("\\.")[0];
                this.fileFormat = fileFormat[1];
            } else {
                // LOGGER.error("fileName is splitted and array length is small .. Just saved ArrayIndexOutOfBoundException");
            }
        } else {
            // LOGGER.error("Path coming to make offlineRefundObj is null");
        }
    }

    public String getFileParent() {
        return fileParent;
    }

    public void setFileParent(String fileParent) {
        this.fileParent = fileParent;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getBankCode() {
        return bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    public String getFileDate() {
        return fileDate;
    }

    public void setFileDate(String fileDate) {
        this.fileDate = fileDate;
    }

    public String getFileFormat() {
        return fileFormat;
    }

    public void setFileFormat(String fileFormat) {
        this.fileFormat = fileFormat;
    }

    public String getFileSeq() {
        return fileSeq;
    }

    public void setFileSeq(String fileSeq) {
        this.fileSeq = fileSeq;
    }

    public Long getFileId() {
        return fileId;
    }

    public void setFileId(Long fileId) {
        this.fileId = fileId;
    }

}
