package com.paytm.pgplus.bo.helper;

import com.paytm.pgplus.common.statistics.StatisticsLogger;
import org.springframework.stereotype.Service;

/**
 * Created by ishasinghal on 4/8/17.
 */
public class LogsHelper {

    public static void logResponse(String status, Long startTime, String source, String api, String requestType,
            String destination) {
        StatisticsLogger.logMerchantResponse(source, api, destination, requestType, String.valueOf(startTime), status);
    }
}
