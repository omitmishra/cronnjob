package com.paytm.pgplus.bo.processor;

import com.paytm.pgplus.bo.repository.MySqlDbRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by ritesh on 06/07/17.
 */
public class TransactionalFileProcessor<T> implements IFileProcessingStrategy<T> {
    private IFileProcessingStrategy<T> fileProcessingStrategy;
    private MySqlDbRepository repository;
    private static final Logger log = LoggerFactory.getLogger(TransactionalFileProcessor.class);

    public TransactionalFileProcessor(IFileProcessingStrategy<T> fileProcessingStrategy, MySqlDbRepository repository) {
        this.fileProcessingStrategy = fileProcessingStrategy;
        this.repository = repository;
    }

    @Override
    public void processRecords(FileProcessor<T> fileProcessor) throws Exception {
        repository.withinTransaction(() -> {
            try {
                log.debug("Transactional file processor started");
                fileProcessor.getOnInitialize().run();
                log.debug("Processing file record started");
                fileProcessingStrategy.processRecords(fileProcessor);
                log.debug("Transactional file processor completed");
            } catch (Exception e) {
                throw new FileProcessingException(e);
            }
        });
    }
}
