package com.paytm.pgplus.bo;

/**
 * Created by ritesh on 28/3/17.
 */
public class BoException extends Exception {
    public BoException(Throwable cause) {
        super(cause);
    }
}
