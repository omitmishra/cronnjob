package com.paytm.pgplus.bo.mail;

import com.paytm.pgplus.bo.files.IFileUploader;
import com.paytm.pgplus.rabbitmq.communication.models.EmailInfo;
import com.paytm.pgplus.rabbitmq.enums.EnumRoutingKey;
import com.paytm.pgplus.rabbitmq.service.IRabbitmqProducer;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.NotImplementedException;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.apache.velocity.runtime.RuntimeConstants;
import org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Created by ritesh on 28/3/17.
 */
public class ProxyMailManager implements IMailManager {
    private IFileUploader remoteFileTransfer;
    private IRabbitmqProducer rabbitmqProducer;
    private String REMOTE_BASE_PATH = "downloads/";

    private static final Logger log = LoggerFactory.getLogger(ProxyMailManager.class);

    public ProxyMailManager(IFileUploader remoteFileTransfer, IRabbitmqProducer rabbitmqProducer) {
        this.remoteFileTransfer = remoteFileTransfer;
        this.rabbitmqProducer = rabbitmqProducer;
    }

    @Override
    public void send(EmailInfoBuilder email) throws Exception {
        log.info("Sending mail : {}", email.getSubject());
        for (Map.Entry<String, File> entry : email.getFileVariable().entrySet()) {
            String path = remoteFileTransfer.uploadMultipart(entry.getValue().getAbsolutePath(), REMOTE_BASE_PATH);
            email.param(entry.getKey(), path);
        }
        EmailInfo mail = mail(email);
        modifyMessageToIncludeDownloadableReport(mail);
        rabbitmqProducer.produce(EnumRoutingKey.INTERNAL_EMAIL_CG_NOTIFY, mail);
        log.info("Email data pushed to rabbitmq INTERNAL_EMAIL_CG_NOTIFY queue");
    }

    private void modifyMessageToIncludeDownloadableReport(EmailInfo mail) throws Exception {
        File tempFile = File.createTempFile("report" + UUID.randomUUID().toString(), "html");
        IOUtils.write(mail.getMessage(), new FileOutputStream(tempFile));
        String url = remoteFileTransfer.uploadMultipart(tempFile.getPath(), REMOTE_BASE_PATH);
        mail.setMessage("<div><a href='" + url + "'>View if report not visible</a></div>" + mail.getMessage());
    }

    private EmailInfo mail(EmailInfoBuilder mail) {
        VelocityEngine ve = new VelocityEngine();
        ve.setProperty(RuntimeConstants.RESOURCE_LOADER, "classpath");
        ve.setProperty("classpath.resource.loader.class", ClasspathResourceLoader.class.getName());
        ve.init();
        VelocityContext context = new VelocityContext(mail.getVariables());
        Template t = ve.getTemplate(mail.getMessageTemplate());
        StringWriter writer = new StringWriter();
        t.merge(context, writer);

        EmailInfo emailInfo = new EmailInfo();
        emailInfo.setTo(mail.getTo());
        emailInfo.setSubject(mail.getSubject());
        emailInfo.setMessage(writer.toString());
        return emailInfo;
    }

    @Override
    public <T> Email from(String templateName, T entity) {
        throw new NotImplementedException("");
    }

    @Override
    public <T> Email from(String templateName, List<String> attachments) {
        return null;
    }
}
