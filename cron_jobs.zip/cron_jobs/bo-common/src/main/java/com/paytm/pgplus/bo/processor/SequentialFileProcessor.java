package com.paytm.pgplus.bo.processor;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ritesh on 06/07/17.
 */
public class SequentialFileProcessor<T> implements IFileProcessingStrategy<T> {
    private long batchSize = 100;

    protected SequentialFileProcessor(long batchSize) {
        this.batchSize = batchSize;
    }

    @Override
    public void processRecords(FileProcessor<T> fileProcessor) throws Exception {
        long counter = 0;
        fileProcessor.getOnInitialize().run();
        List<RecordProcessorContext.Record<T>> recordsBatch = new ArrayList<>();
        for (T record : fileProcessor.getRecords()) {
            if (recordsBatch.size() == batchSize) {
                fileProcessor.getRecordProcessor().process(new RecordProcessorContext<>(recordsBatch));
                recordsBatch.clear();
                recordsBatch.add(new RecordProcessorContext.Record<>(record, counter++));
            } else {
                recordsBatch.add(new RecordProcessorContext.Record<>(record, counter++));
            }
        }
        if (!recordsBatch.isEmpty()) {
            fileProcessor.getRecordProcessor().process(new RecordProcessorContext<>(recordsBatch));
        }
    }
}
