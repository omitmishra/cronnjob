package com.paytm.pgplus.bo.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by ritesh on 06/07/17.
 */
@SuppressWarnings("unused")
class ParallelFileProcessor<T> implements IFileProcessingStrategy<T> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ParallelFileProcessor.class);

    private final ExecutorService executorService;
    private Semaphore semaphore;
    private AtomicReference<FileProcessingException> exceptionReference = new AtomicReference<>();

    public ParallelFileProcessor(int parallel, ExecutorService executorService) {
        this.executorService = executorService;
        this.semaphore = new Semaphore(parallel);
    }

    @Override
    public void processRecords(FileProcessor<T> fileProcessor) throws Exception {
        long counter = 0;
        fileProcessor.getOnInitialize().run();

        for (T t : fileProcessor.getRecords()) {
            final Long currentCounter = counter++;
            semaphore.acquire();
            executorService.submit(() -> {
                try {
                    List<RecordProcessorContext.Record<T>> records = new ArrayList<>();
                    records.add(new RecordProcessorContext.Record<>(t, currentCounter));
                    fileProcessor.getRecordProcessor().process(new RecordProcessorContext<>(records));
                } catch (Exception e) {
                    LOGGER.error("Exception : {}", e);
                    FileProcessingException fileProcessingException = new FileProcessingException(e);
                    exceptionReference.set(fileProcessingException);
                } finally {
                    semaphore.release();
                }
            });
            if (exceptionReference.get() != null) {
                throw exceptionReference.get();
            }
        }
        executorService.shutdown();
        executorService.awaitTermination(Long.MAX_VALUE, TimeUnit.DAYS);
        if (exceptionReference.get() != null) {
            throw exceptionReference.get();
        }
    }
}
