package com.paytm.pgplus.bo.config;

/**
 * Created by ritesh on 28/3/17.
 */
public class BootStrapConfig {
    public String dbUrl;
    private String userName;
    private String password;

    public String getDbUrl() {
        return dbUrl;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }
}
