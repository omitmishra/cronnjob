package com.paytm.pgplus.bo.mail;

import com.paytm.pgplus.rabbitmq.communication.models.EmailInfo;

import java.util.List;

/**
 * Created by ritesh on 28/3/17.
 */
public interface IMailManager {
    void send(EmailInfoBuilder email) throws Exception;

    <T> Email from(String templateName, T entity);

    <T> Email from(String templateName, List<String> attachments);
}
