package com.paytm.pgplus.bo.config;

import com.google.gson.GsonBuilder;
import com.paytm.pgplus.bo.job.IJob;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by ritesh on 30/3/17.
 */
public class CachableConfigurationProvider<T> implements IConfigurationProvider<T>, IJob {
    private static Logger log = LoggerFactory.getLogger(CachableConfigurationProvider.class);

    private IConfigurationProvider<T> configurationProvider;
    private AtomicReference<T> cached = new AtomicReference<T>();

    public CachableConfigurationProvider(IConfigurationProvider<T> configurationProvider) {
        this.configurationProvider = configurationProvider;
        reload();
    }

    @Override
    public T config() {
        return cached.get();
    }

    public void reload() {
        log.info("Trying to reload configuration");
        cached.set(configurationProvider.config());
        log.info("Reloaded configuration");
    }

    @Override
    public void execute() throws Exception {
        reload();
    }
}
