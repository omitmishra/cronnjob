package com.paytm.pgplus.bo.repository.entity;

/**
 * Created by ritesh on 13/06/17.
 */
public enum FileType {
    UNSETTLED_TXN_PAYMENT, UNSETTLED_TXN_REFUND, AUTO_REFUND
}
