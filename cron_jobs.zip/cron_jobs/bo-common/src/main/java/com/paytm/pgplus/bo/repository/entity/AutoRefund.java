package com.paytm.pgplus.bo.repository.entity;

import com.paytm.pgplus.bo.util.csv.CsvColumn;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by ishasinghal on 10/7/17.
 */

@Entity
@Table(name = "auto_refund")
public class AutoRefund {

    @CsvColumn("txn_id")
    @Column
    private String txnId;

    @CsvColumn("external_serial_no")
    @Column
    @Id
    private String externalSerialNo;
    @CsvColumn("mid")
    @Column
    private String mid;
    @CsvColumn("merchant_name")
    @Column
    private String merchantName;
    @CsvColumn("txn_date")
    @Column
    private String txnDate;
    @CsvColumn("mbid")
    @Column
    private String mbid;
    @CsvColumn("txn_channel")
    @Column
    private String txnChannel;
    @CsvColumn("txn_amount")
    @Column
    private String txnAmount;
    @CsvColumn("currency_type")
    @Column
    private String currencyType;
    @CsvColumn("order_id")
    @Column
    private String orderId;
    @CsvColumn("response_code")
    @Column
    private String responseCode;
    @CsvColumn("pay_mode")
    @Column
    private String payMode;
    @CsvColumn("bank_txn_id")
    @Column
    private String bankTxnId;
    @CsvColumn("cust_id")
    @Column
    private String customerId;
    @CsvColumn("ccdc_last_4")
    @Column
    private String ccdcLast4;
    @CsvColumn("issuing_bank")
    @Column
    private String issuingBank;
    @CsvColumn("bank_gateway")
    @Column
    private String bankGateway;
    @CsvColumn("status")
    @Column
    private String status;
    @CsvColumn("bank_fees")
    @Column
    private String bankFees;
    @CsvColumn("gateway_paymode")
    @Column
    private String gatewayPaymode;
    @CsvColumn("auto_refund_by_brf")
    @Column
    private String autoRefundBrf;
    @CsvColumn("is_the_same_day")
    @Column
    private String isSameDay;

    @Column
    private Date created;

    @Column
    private Date updated;

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getExternalSerialNo() {
        return externalSerialNo;
    }

    public void setExternalSerialNo(String externalSerialNo) {
        this.externalSerialNo = externalSerialNo;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getTxnDate() {
        return txnDate;
    }

    public void setTxnDate(String txnDate) {
        this.txnDate = txnDate;
    }

    public String getMbid() {
        return mbid;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public String getTxnChannel() {
        return txnChannel;
    }

    public void setTxnChannel(String txnChannel) {
        this.txnChannel = txnChannel;
    }

    public String getTxnAmount() {
        return txnAmount;
    }

    public void setTxnAmount(String txnAmount) {
        this.txnAmount = txnAmount;
    }

    public String getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getPayMode() {
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public String getBankTxnId() {
        return bankTxnId;
    }

    public void setBankTxnId(String bankTxnId) {
        this.bankTxnId = bankTxnId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCcdcLast4() {
        return ccdcLast4;
    }

    public void setCcdcLast4(String ccdcLast4) {
        this.ccdcLast4 = ccdcLast4;
    }

    public String getIssuingBank() {
        return issuingBank;
    }

    public void setIssuingBank(String issuingBank) {
        this.issuingBank = issuingBank;
    }

    public String getBankGateway() {
        return bankGateway;
    }

    public void setBankGateway(String bankGateway) {
        this.bankGateway = bankGateway;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBankFees() {
        return bankFees;
    }

    public void setBankFees(String bankFees) {
        this.bankFees = bankFees;
    }

    public String getGatewayPaymode() {
        return gatewayPaymode;
    }

    public void setGatewayPaymode(String gatewayPaymode) {
        this.gatewayPaymode = gatewayPaymode;
    }

    public String getAutoRefundBrf() {
        return autoRefundBrf;
    }

    public void setAutoRefundBrf(String autoRefundBrf) {
        this.autoRefundBrf = autoRefundBrf;
    }

    public String getIsSameDay() {
        return isSameDay;
    }

    public void setIsSameDay(String isSameDay) {
        this.isSameDay = isSameDay;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    @Override
    public String toString() {
        return "AutoRefund{" + "txnId='" + txnId + '\'' + ", externalSerialNo='" + externalSerialNo + '\'' + ", mid='"
                + mid + '\'' + ", merchantName='" + merchantName + '\'' + ", txnDate='" + txnDate + '\'' + ", mbid='"
                + mbid + '\'' + ", txnChannel='" + txnChannel + '\'' + ", txnAmount='" + txnAmount + '\''
                + ", currencyType='" + currencyType + '\'' + ", orderId='" + orderId + '\'' + ", responseCode='"
                + responseCode + '\'' + ", payMode='" + payMode + '\'' + ", bankTxnId='" + bankTxnId + '\''
                + ", customerId='" + customerId + '\'' + ", ccdcLast4='" + ccdcLast4 + '\'' + ", issuingBank='"
                + issuingBank + '\'' + ", bankGateway='" + bankGateway + '\'' + ", status='" + status + '\''
                + ", bankFees='" + bankFees + '\'' + ", gatewayPaymode='" + gatewayPaymode + '\'' + ", autoRefundBrf='"
                + autoRefundBrf + '\'' + ", isSameDay='" + isSameDay + '\'' + ", created=" + created + ", updated="
                + updated + '}';
    }
}
