package com.paytm.pgplus.bo.processor;

import com.paytm.pgplus.bo.repository.FileInfoRepository;
import com.paytm.pgplus.bo.repository.entity.FileInfo;
import com.paytm.pgplus.bo.repository.entity.FileType;
import com.paytm.pgplus.bo.util.EntityCsvReader;
import com.paytm.pgplus.bo.util.csv.CsvReaderWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Created by ritesh on 13/06/17.
 */
public class FileProcessor<T> implements Closeable {
    private final FileInfoRepository repository;
    private final IRecordProcessorCheckPointer checkPointer;
    private final IRecordProcessor<T> recordProcessor;
    private final EntityCsvReader<T> entityCsvReader;
    private EntityCsvReader.Reader<T> reader;
    private final IFileProcessingStrategy<T> fileProcessingStrategy;
    private final FileType fileType;
    private final Runnable onInitialize;

    private static final Logger LOGGER = LoggerFactory.getLogger(FileProcessor.class);

    protected FileProcessor(Class<T> clazz, FileInfoRepository repository, IRecordProcessorCheckPointer checkPointer,
            IRecordProcessor<T> recordProcessor, IFileProcessingStrategy<T> fileProcessingStrategy,
            CsvReaderWriter.FormattingOptions formattingOptions, FileType fileType, Runnable onInitialize) {
        this.repository = repository;
        this.checkPointer = checkPointer;
        this.recordProcessor = recordProcessor;
        this.fileType = fileType;
        this.onInitialize = onInitialize;
        this.entityCsvReader = new EntityCsvReader<>(clazz, new EntityCsvReader.AnnotationMapper<>(clazz),
                formattingOptions);
        this.fileProcessingStrategy = fileProcessingStrategy;
    }

    public void process() throws Exception {
        FileInfo fileInfo = repository.fetchAndUpdateStatus(fileType, FileInfo.Status.IDENTIFIED,
                FileInfo.Status.INITIATED);
        if (fileInfo == null) {
            LOGGER.info("Could not find any file to process completing process");
            return;
        }
        try {
            LOGGER.debug("File processing initiated");
            checkPointer.checkpoint(FileInfo.Status.INITIATED.name());
            reader = entityCsvReader.read(new FileInputStream(fileInfo.getLocation()));
            fileProcessingStrategy.processRecords(this);
            LOGGER.debug("Processed records successfully");
            fileInfo.setStatus(FileInfo.Status.SUCCESS);
            checkPointer.checkpoint(FileInfo.Status.SUCCESS.name());
            repository.update(fileInfo);
        } catch (Exception e) {
            LOGGER.error("Exception : ", e);
            fileInfo.setStatus(FileInfo.Status.FAILED);
            repository.update(fileInfo);
            checkPointer.checkpoint(FileInfo.Status.FAILED.name());
            throw e;
        }
    }

    protected IRecordProcessor<T> getRecordProcessor() {
        return recordProcessor;
    }

    protected IRecordProcessorCheckPointer getCheckPointer() {
        return checkPointer;
    }

    protected Iterable<T> getRecords() {
        return reader;
    }

    public Runnable getOnInitialize() {
        return onInitialize;
    }

    @Override
    public void close() throws IOException {
        reader.close();
    }

    public static class FileProcessorBuilder<T> {
        private Class<T> clazz;
        private IRecordProcessorCheckPointer checkPointer;
        private IRecordProcessor<T> recordProcessor;
        private IFileProcessingStrategy<T> fileProcessingStrategy;
        private CsvReaderWriter.FormattingOptions formattingOptions;
        private FileInfoRepository repository;
        private FileType fileType;
        private Runnable onInitialize;

        public FileProcessorBuilder<T> setEntityClass(Class<T> clazz) {
            this.clazz = clazz;
            return this;
        }

        public FileProcessorBuilder<T> setCheckPointer(IRecordProcessorCheckPointer checkPointer) {
            this.checkPointer = checkPointer;
            return this;
        }

        public FileProcessorBuilder<T> setFileProcessingStrategy(IFileProcessingStrategy<T> fileProcessingStrategy) {
            this.fileProcessingStrategy = fileProcessingStrategy;
            return this;
        }

        public FileProcessorBuilder<T> setRecordProcessor(IRecordProcessor<T> recordProcessor) {
            this.recordProcessor = recordProcessor;
            return this;
        }

        public FileProcessorBuilder<T> setFormattingOptions(CsvReaderWriter.FormattingOptions formattingOptions) {
            this.formattingOptions = formattingOptions;
            return this;
        }

        public FileProcessorBuilder<T> setFileInfoRepository(FileInfoRepository fileInfoRepository) {
            this.repository = fileInfoRepository;
            return this;
        }

        public FileProcessorBuilder<T> onInitialize(Runnable onInitialize) {
            this.onInitialize = onInitialize;
            return this;
        }

        public FileProcessorBuilder<T> setFileType(FileType fileType) {
            this.fileType = fileType;
            return this;
        }

        public FileProcessor<T> build() {
            onInitialize = (onInitialize == null ? () -> {
            } : onInitialize);
            return new FileProcessor<>(clazz, repository, checkPointer, recordProcessor, fileProcessingStrategy,
                    formattingOptions, fileType, onInitialize);
        }
    }
}
