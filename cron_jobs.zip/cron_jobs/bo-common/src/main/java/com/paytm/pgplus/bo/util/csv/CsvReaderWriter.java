package com.paytm.pgplus.bo.util.csv;

import com.google.common.collect.ImmutableList;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ritesh on 28/3/17.
 */
public class CsvReaderWriter {
    private FormattingOptions formattingOptions;
    private static FormattingOptions DEFAULT = new FormattingOptions();

    public CsvReaderWriter(FormattingOptions formattingOptions) {
        this.formattingOptions = formattingOptions;
    }

    public CsvReaderWriter() {
        this(DEFAULT);
    }

    public CsvWriter write(OutputStream stream, String[] headerNames) throws IOException {
        return new CsvWriter(stream, formattingOptions, headerNames);
    }

    public void writeAll(OutputStream stream, String[] headerNames, List<CsvRow> csvRows) throws IOException {
        try (CsvWriter write = write(stream, headerNames)) {
            for (CsvRow row : csvRows) {
                write.write(row);
            }
        }
    }

    public CsvReader read(InputStream stream, String[] headerNames) throws IOException {
        InputStreamReader streamReader = new InputStreamReader(stream);
        final CSVParser parser = new CSVParser(streamReader, headerNames == null ? CSVFormat.DEFAULT.withHeader()
                : CSVFormat.DEFAULT.withHeader(headerNames));
        CsvReader iterator = new CsvReader(parser, streamReader, headerNames, formattingOptions);
        if (headerNames != null)
            iterator.next();
        return iterator;
    }

    public List<CsvRow> readAll(InputStream stream, String[] headerNames) throws IOException {
        return ImmutableList.copyOf((Iterable<CsvRow>) read(stream, headerNames));
    }

    public static class CsvRow {
        private Map<String, CsvCell> value;

        public CsvRow(Map<String, CsvCell> value) {
            this.value = value;
        }

        public CsvRow() {
            value = new LinkedHashMap<>();
        }

        public Map<String, CsvCell> getValue() {
            return value;
        }

        public void add(String name, Object data) {
            value.put(name, new CsvCell(data));
        }

        public CsvCell get(String name) {
            return value.get(name);
        }

        @Override
        public String toString() {
            return "CsvRow{" + value + '}';
        }
    }

    public static class CsvCell {
        protected String value;
        protected FormattingOptions formattingOptions;
        protected Object object;

        private CsvCell(Object o) {
            object = o;
        }

        private CsvCell(String value) {
            this.value = value;
            this.object = value;
        }

        protected CsvCell(String value, FormattingOptions formattingOptions) {
            this.value = value;
            this.formattingOptions = formattingOptions;
        }

        public CsvCell(Integer value) {
            this.value = (value == null ? null : String.valueOf(value));
        }

        public CsvCell(Double value) {
            this.value = (value == null ? null : String.valueOf(value));
        }

        public CsvCell(Date value) {
            this.value = (value == null ? null : formattingOptions.dateFormatter.format(value));
        }

        public Double toDouble() {
            return Double.parseDouble(value);
        }

        public String getStringValue() {
            return value;
        }

        public Long toLong() {
            return Long.parseLong(value);
        }

        public Integer toInteger() {
            return Integer.parseInt(value);
        }

        public Date toDate() {
            try {
                return this.formattingOptions.dateFormatter.parse(value);
            } catch (ParseException e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public String toString() {
            return "CsvCell{" + value + '\'' + '}';
        }
    }

    public static class FormattingOptions {
        protected SimpleDateFormat dateFormatter;
        protected String newLineSeparator = "\n";

        public FormattingOptions(SimpleDateFormat dateFormatter) {
            this.dateFormatter = dateFormatter;
        }

        public FormattingOptions() {
            this.dateFormatter = new SimpleDateFormat();
        }
    }

}
