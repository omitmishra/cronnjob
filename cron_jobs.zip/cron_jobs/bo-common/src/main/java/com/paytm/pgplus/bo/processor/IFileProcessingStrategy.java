package com.paytm.pgplus.bo.processor;

/**
 * Created by ritesh on 06/07/17.
 */
public interface IFileProcessingStrategy<T> {
    void processRecords(FileProcessor<T> fileProcessor) throws Exception;
}
