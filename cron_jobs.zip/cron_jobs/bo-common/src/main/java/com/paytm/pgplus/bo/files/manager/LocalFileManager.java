package com.paytm.pgplus.bo.files.manager;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by ritesh on 18/07/17.
 */
public class LocalFileManager implements IFileManager {
    public List<String> findFiles(String location, IFileNameFilter filter) {
        List<String> filteredFileNames = new ArrayList<>();
        File[] files = new File(location).listFiles();
        if (files != null && files.length > 0) {
            for (File file : files) {
                if (filter.filter(file.getName())) {
                    filteredFileNames.add(file.getAbsolutePath());
                }
            }
        }
        return filteredFileNames;
    }
}
