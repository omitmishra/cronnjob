package com.paytm.pgplus.bo.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by ritesh on 28/3/17.
 */
public class DateUtils {

    public SimpleDateFormat getDateFormatter() {
        return new SimpleDateFormat("yyyy-MM-dd");
    }

    public Date getDateTimeForDayWindow(Integer dayWindow) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, dayWindow);
        return calendar.getTime();

    }

    public Date getDateFromDDMMYYYY(String date) throws ParseException {
        return new SimpleDateFormat("dd-MM-yyyy").parse(date);
    }

    public String getDateStringForPreviousDayWindow(Integer dayWindow) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
        try {
            Date date = formatter.parse(formatter.format(new Date()));
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, -1 * dayWindow);
            return formatter.format(calendar.getTime());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String getDateStringForDayWindowDDMMYYYY(Integer dayWindow) {
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
        try {
            Date date = formatter.parse(formatter.format(new Date()));
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, -1 * dayWindow);
            return formatter.format(calendar.getTime());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public String todayDateYYYYMMDD() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");

        try {
            Date date = new Date();
            return formatter.format(date);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Date getDateForDayWindow(Integer dayWindow) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");

        try {
            Date date = formatter.parse(formatter.format(new Date()));
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_YEAR, -1 * dayWindow);
            return calendar.getTime();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public Date todayDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date date = new Date();
            return formatter.parse(formatter.format(date));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
