package com.paytm.pgplus.bo.files;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.IOException;

/**
 * Created by raman on 27/6/17.
 */
public class S3FileUploader implements IFileUploader {

    private static final Logger log = LoggerFactory.getLogger(S3FileUploader.class);
    private S3Client client;

    public S3FileUploader(S3Client client) {
        this.client = client;
    }

    @Override
    public String upload(String localPath, String remotePath) throws IOException {
        client.transferFile(remotePath, new File(localPath));
        return String.format("%s/%s/%s%s", client.getUrl(), client.getBucketName(), remotePath,
                FilenameUtils.getName(localPath));
    }

    @Override
    public String uploadMultipart(String localPath, String remotePath) throws Exception {
        return client.transferFileMultipart(remotePath, new File(localPath));
        //return String.format("%s/%s/%s%s", client.getUrl(), client.getBucketName(), remotePath,
          //      FilenameUtils.getName(localPath));
    }

}
