package com.paytm.pgplus.bo.repository;

import com.paytm.pgplus.bo.repository.entity.ApplicationConfiguration;
import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by ritesh on 29/3/17.
 */
@Repository
public class ApplicationConfigurationRepository extends MySqlDbRepository {

    @Autowired
    public ApplicationConfigurationRepository(MySqlDbFactory sqlDbFactory) {
        super(sqlDbFactory);
    }

    @Transactional("slaveTransactionManager")
    public List<ApplicationConfiguration> list(String nodeId) {
        Query query = R().createQuery("SELECT c FROM ApplicationConfiguration c where c.key.node=:node");
        query.setParameter("node", nodeId);
        List<ApplicationConfiguration> list = query.list();
        return list;
    }
}
