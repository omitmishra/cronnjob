package com.paytm.pgplus.bo.repository.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

/**
 * Created by ritesh on 12/06/17.
 */
@Entity
@Table(name = "file_info")
public class FileInfo {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String name;

    @Column
    private Long totalRecords;

    @Column
    private Long successRecords;

    @Column
    private Long failedRecords;

    @Enumerated(EnumType.STRING)
    private Status status;

    @Enumerated(EnumType.STRING)
    private FileType type;

    @Column
    private String location;

    @Column
    private Date created;

    @Column
    private Date updated;

    @Column
    private Date expireOn;

    public enum Status {
        IDENTIFIED, INITIATED, PROCESSED, VALIDATED, SUCCESS, FAILED
    }

    /*
     * @OneToMany(mappedBy = "fileInfo") private List<FileDetails> fileDetails;
     */

    public FileInfo(Status status, String location, FileType type) {
        this.status = status;
        this.location = location;
        this.type = type;
    }

    public FileInfo() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(Long totalRecords) {
        this.totalRecords = totalRecords;
    }

    public Long getSuccessRecords() {
        return successRecords;
    }

    public void setSuccessRecords(Long successRecords) {
        this.successRecords = successRecords;
    }

    public Long getFailedRecords() {
        return failedRecords;
    }

    public void setFailedRecords(Long failedRecords) {
        this.failedRecords = failedRecords;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public Date getExpireOn() {
        return expireOn;
    }

    public void setExpireOn(Date expireOn) {
        this.expireOn = expireOn;
    }

    /*
     * public List<FileDetails> getFileDetails() { return fileDetails; }
     * 
     * public void setFileDetails(List<FileDetails> fileDetails) {
     * this.fileDetails = fileDetails; }
     */

    public FileType getType() {
        return type;
    }

    @Override
    public String toString() {
        return "FileInfo{" + "id=" + id + ", name='" + name + '\'' + ", totalRecords=" + totalRecords
                + ", successRecords=" + successRecords + ", failedRecords=" + failedRecords + ", status=" + status
                + ", type=" + type + ", location='" + location + '\'' + ", created=" + created + ", updated=" + updated
                + ", expireOn=" + expireOn + '}';
    }
}
