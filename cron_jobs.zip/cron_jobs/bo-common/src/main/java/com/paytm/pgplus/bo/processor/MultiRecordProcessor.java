package com.paytm.pgplus.bo.processor;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by ritesh on 06/07/17.
 */
public class MultiRecordProcessor<T> implements IRecordProcessor<T> {
    private LinkedHashMap<String, IRecordProcessor<T>> recordProcessors = new LinkedHashMap<>();

    private MultiRecordProcessor(LinkedHashMap<String, IRecordProcessor<T>> recordProcessors) {
        this.recordProcessors = recordProcessors;
    }

    @Override
    public void process(RecordProcessorContext<T> context) throws Exception {
        for (Map.Entry<String, IRecordProcessor<T>> entry : recordProcessors.entrySet()) {
            entry.getValue().process(context);
        }
    }

    public static class MultiRecordProcessorBuilder<T> {
        private LinkedHashMap<String, IRecordProcessor<T>> recordProcessors = new LinkedHashMap<>();

        public MultiRecordProcessorBuilder<T> add(String name, IRecordProcessor<T> recordProcessor) {
            recordProcessors.put(name, recordProcessor);
            return this;
        }

        public MultiRecordProcessor<T> build() {
            return new MultiRecordProcessor<>(recordProcessors);
        }
    }
}
