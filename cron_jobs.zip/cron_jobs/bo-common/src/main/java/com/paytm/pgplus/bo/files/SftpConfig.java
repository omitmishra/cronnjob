package com.paytm.pgplus.bo.files;

/**
 * Created by ritesh on 28/3/17.
 */
public class SftpConfig {
    public String ipAddress;
    public String username;
    public Integer port;
    public String password;
}
