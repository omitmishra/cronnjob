package com.paytm.pgplus.bo.util.csv;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;

import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by ritesh on 22/05/17.
 */
public class CsvWriter implements Closeable {
    private final CSVPrinter csvPrinter;
    private OutputStreamWriter streamWriter;
    private final CsvReaderWriter.FormattingOptions formattingOptions;
    private String[] headerNames;
    private boolean isHeaderPrinted = false;

    public CsvWriter(OutputStream outputStream, CsvReaderWriter.FormattingOptions formattingOptions,
            String[] headerNames) throws IOException {
        streamWriter = new OutputStreamWriter(outputStream);
        this.formattingOptions = formattingOptions;
        this.headerNames = headerNames;

        CSVFormat csvFormat = CSVFormat.DEFAULT.withRecordSeparator(formattingOptions.newLineSeparator);
        this.csvPrinter = new CSVPrinter(streamWriter, csvFormat);

    }

    public void write(CsvReaderWriter.CsvRow row) throws IOException {
        if (!isHeaderPrinted) {
            if (headerNames == null) {
                headerNames = row.getValue().keySet().toArray(new String[row.getValue().keySet().size()]);
            }
            csvPrinter.printRecord(headerNames);
            isHeaderPrinted = true;
        }

        List<String> data = new ArrayList();
        for (String headerName : headerNames) {
            CsvReaderWriter.CsvCell cell = row.getValue().get(headerName);
            String cellStringValue = null;
            if (cell == null)
                cellStringValue = null;
            else if (cell.object == null)
                cellStringValue = cell.getStringValue();
            else if (cell.object instanceof String)
                cellStringValue = (String) cell.object;
            else if (cell.object instanceof Date)
                cellStringValue = formattingOptions.dateFormatter.format((Date) cell.object);
            else
                cellStringValue = cell.object.toString();
            data.add(cellStringValue);
        }
        csvPrinter.printRecord(data);
    }

    @Override
    public void close() throws IOException {
        streamWriter.flush();
        streamWriter.close();
    }
}
