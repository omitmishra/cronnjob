package com.paytm.pgplus.bo.files;

import java.io.IOException;

/**
 * Created by ritesh on 28/3/17.
 */

/**
 * @deprecated Migrate it to IFileManager
 */
@Deprecated
public interface IFileUploader {
    String upload(String localPath, String remotePath) throws IOException;

    String uploadMultipart(String localPath, String remotePath) throws Exception;
}
