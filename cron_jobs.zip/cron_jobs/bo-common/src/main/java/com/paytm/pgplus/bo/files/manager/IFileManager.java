package com.paytm.pgplus.bo.files.manager;

import java.util.List;

/**
 * Created by ritesh on 18/07/17.
 */
public interface IFileManager {
    List<String> findFiles(String location, IFileNameFilter filter);
}
