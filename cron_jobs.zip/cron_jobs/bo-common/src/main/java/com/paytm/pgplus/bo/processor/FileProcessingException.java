package com.paytm.pgplus.bo.processor;

/**
 * Created by ritesh on 05/07/17.
 */
public class FileProcessingException extends RuntimeException {
    public FileProcessingException(Throwable cause) {
        super(cause);
    }
}
