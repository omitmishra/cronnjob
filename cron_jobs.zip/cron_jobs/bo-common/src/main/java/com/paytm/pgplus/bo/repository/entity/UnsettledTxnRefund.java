package com.paytm.pgplus.bo.repository.entity;

import com.paytm.pgplus.bo.util.csv.CsvColumn;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Created by ritesh on 07/07/17.
 */
@Entity
@Table(name = "unsettled_txn_refund")
public class UnsettledTxnRefund {

    @CsvColumn("refund_id")
    @Column
    private String refundId;

    @CsvColumn("mbid")
    @Column
    private String mbid;

    @CsvColumn("order_id")
    @Column
    private String orderId;

    @CsvColumn("refund_date")
    @Column
    private String refundDate;

    @CsvColumn("refund_amount")
    @Column
    private String refundAmount;

    @CsvColumn("refund_currency")
    @Column
    private String refundCurrency;

    @CsvColumn("response_code")
    @Column
    private String responseCode;

    @CsvColumn("bank_txn_id")
    @Column
    private String bankTxnId;

    @CsvColumn("issuing_bank")
    @Column
    private String issuingBank;

    @CsvColumn("bank_gateway")
    @Column
    private String bankGateway;

    @CsvColumn("sub_refund_type")
    @Column
    private String subRefundType;

    @CsvColumn("status")
    @Column
    private String status;

    @CsvColumn("external_serial_no")
    @Column
    @Id
    private String externalSerialNo;

    @CsvColumn("mid")
    @Column
    private String mid;

    @CsvColumn("txn_id")
    @Column
    private String txnId;

    @CsvColumn("merchant_name")
    @Column
    private String merchantName;

    @CsvColumn("pay_mode")
    @Column
    private String payMode;

    @CsvColumn("txn_date")
    @Column
    private String txnDate;

    @CsvColumn("settled_date")
    @Column
    private String settledDate;

    @CsvColumn("txn_amount")
    @Column
    private String txnAmount;

    @CsvColumn("origin_ext_serial_no")
    @Column
    private String originExtSerialNo;

    public String getRefundId() {
        return refundId;
    }

    public void setRefundId(String refundId) {
        this.refundId = refundId;
    }

    public String getMbid() {
        return mbid;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getRefundDate() {
        return refundDate;
    }

    public void setRefundDate(String refundDate) {
        this.refundDate = refundDate;
    }

    public String getRefundAmount() {
        return refundAmount;
    }

    public void setRefundAmount(String refundAmount) {
        this.refundAmount = refundAmount;
    }

    public String getRefundCurrency() {
        return refundCurrency;
    }

    public void setRefundCurrency(String refundCurrency) {
        this.refundCurrency = refundCurrency;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getBankTxnId() {
        return bankTxnId;
    }

    public void setBankTxnId(String bankTxnId) {
        this.bankTxnId = bankTxnId;
    }

    public String getIssuingBank() {
        return issuingBank;
    }

    public void setIssuingBank(String issuingBank) {
        this.issuingBank = issuingBank;
    }

    public String getBankGateway() {
        return bankGateway;
    }

    public void setBankGateway(String bankGateway) {
        this.bankGateway = bankGateway;
    }

    public String getSubRefundType() {
        return subRefundType;
    }

    public void setSubRefundType(String subRefundType) {
        this.subRefundType = subRefundType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getExternalSerialNo() {
        return externalSerialNo;
    }

    public void setExternalSerialNo(String externalSerialNo) {
        this.externalSerialNo = externalSerialNo;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getPayMode() {
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public String getTxnDate() {
        return txnDate;
    }

    public void setTxnDate(String txnDate) {
        this.txnDate = txnDate;
    }

    public String getSettledDate() {
        return settledDate;
    }

    public void setSettledDate(String settledDate) {
        this.settledDate = settledDate;
    }

    public String getTxnAmount() {
        return txnAmount;
    }

    public void setTxnAmount(String txnAmount) {
        this.txnAmount = txnAmount;
    }

    public String getOriginExtSerialNo() {
        return originExtSerialNo;
    }

    public void setOriginExtSerialNo(String originExtSerialNo) {
        this.originExtSerialNo = originExtSerialNo;
    }

    @Override
    public String toString() {
        return "UnsettledTxnRefund{" + "refundId='" + refundId + '\'' + ", mbid='" + mbid + '\'' + ", orderId='"
                + orderId + '\'' + ", refundDate='" + refundDate + '\'' + ", refundAmount='" + refundAmount + '\''
                + ", refundCurrency='" + refundCurrency + '\'' + ", responseCode='" + responseCode + '\''
                + ", bankTxnId='" + bankTxnId + '\'' + ", issuingBank='" + issuingBank + '\'' + ", bankGateway='"
                + bankGateway + '\'' + ", subRefundType='" + subRefundType + '\'' + ", status='" + status + '\''
                + ", externalSerialNo='" + externalSerialNo + '\'' + ", mid='" + mid + '\'' + ", txnId='" + txnId
                + '\'' + ", merchantName='" + merchantName + '\'' + ", payMode='" + payMode + '\'' + ", txnDate='"
                + txnDate + '\'' + ", settledDate='" + settledDate + '\'' + ", txnAmount='" + txnAmount + '\''
                + ", originExtSerialNo='" + originExtSerialNo + '\'' + '}';
    }
}
