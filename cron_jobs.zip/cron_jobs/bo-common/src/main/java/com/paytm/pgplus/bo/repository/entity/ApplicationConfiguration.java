package com.paytm.pgplus.bo.repository.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by ritesh on 29/3/17.
 */
@Entity
@Table(name = "application_configuration")
public class ApplicationConfiguration {
    @Id
    private ConfigurationId key;

    @Column(name = "value")
    private String value;

    public ConfigurationId getKey() {
        return key;
    }

    public void setKey(ConfigurationId key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Embeddable
    public static class ConfigurationId implements Serializable {
        private String node;
        private String key;

        public String getNode() {
            return node;
        }

        public String getKey() {
            return key;
        }

        public void setNode(String node) {
            this.node = node;
        }

        public void setKey(String key) {
            this.key = key;
        }
    }
}
