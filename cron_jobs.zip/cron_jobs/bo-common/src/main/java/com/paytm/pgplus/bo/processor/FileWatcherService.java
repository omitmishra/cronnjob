package com.paytm.pgplus.bo.processor;

import com.paytm.pgplus.bo.repository.FileInfoRepository;
import com.paytm.pgplus.bo.repository.entity.FileInfo;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by ritesh on 15/06/17.
 */
public class FileWatcherService {
    private List<FileWatcher> fileWatchers;
    private FileInfoRepository repository;
    private static final Logger LOGGER = LoggerFactory.getLogger(FileWatcherService.class);

    public FileWatcherService(FileInfoRepository repository) {
        this.fileWatchers = new ArrayList<>();
        this.repository = repository;
    }

    public void addWatcher(FileWatcher fileWatcher) {
        fileWatchers.add(fileWatcher);
    }

    public void watch() {
        for (FileWatcher fileWatcher : fileWatchers) {
            try {
                List<String> fileLocations = fileWatcher.watch();
                if (!CollectionUtils.isEmpty(fileLocations)) {
                    for (String fileLocation : fileLocations) {
                        FileInfo fileInfo = new FileInfo(FileInfo.Status.IDENTIFIED, fileLocation,
                                fileWatcher.getType());
                        FileInfo existing = repository.createIfNotExist(fileInfo);
                        if (existing != null) {
                            LOGGER.info("Already existing :{} ", existing);
                        }
                    }
                }
            } catch (Exception e) {
                LOGGER.error("Exception : {}", e);
            }
        }
    }

    public List<FileWatcher> getFileWatchers() {
        return fileWatchers;
    }

    public FileInfoRepository getRepository() {
        return repository;
    }
}
