package com.paytm.pgplus.bo.util;

import com.paytm.pgplus.bo.util.csv.CsvColumn;
import com.paytm.pgplus.bo.util.csv.CsvReader;
import com.paytm.pgplus.bo.util.csv.CsvReaderWriter;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import static org.apache.commons.lang3.StringUtils.isEmpty;

/**
 * Created by ritesh on 13/06/17.
 */
public class EntityCsvReader<T> {
    private Mapper<T> mapper;
    private Class<T> clazz;
    private CsvReaderWriter.FormattingOptions formattingOptions;

    public EntityCsvReader(Class<T> clazz, Mapper<T> mapper, CsvReaderWriter.FormattingOptions formattingOptions) {
        this.mapper = mapper;
        this.clazz = clazz;
        this.formattingOptions = formattingOptions;
    }

    public Reader<T> read(InputStream stream) throws IOException {
        CsvReader csvReader = new CsvReaderWriter(formattingOptions).read(stream, null);
        return new Reader<>(csvReader, mapper, clazz);
    }

    public interface Mapper<T> {
        T call(Map<String, CsvReaderWriter.CsvCell> value);
    }

    public static class AnnotationMapper<T> implements Mapper<T> {
        private Class<T> clazz;

        public AnnotationMapper(Class<T> clazz) {
            this.clazz = clazz;
        }

        @Override
        public T call(Map<String, CsvReaderWriter.CsvCell> value) {
            try {
                Field[] fields = clazz.getDeclaredFields();
                T object = clazz.newInstance();
                for (Field field : fields) {
                    CsvColumn annotation = field.getAnnotation(CsvColumn.class);
                    if (annotation == null)
                        continue;
                    String name = annotation.value();
                    if (isEmpty(name))
                        name = field.getName();
                    Method setter = getSetter(field.getName(), clazz);
                    if (setter == null)
                        throw new RuntimeException("setter not found : " + name);
                    if (!value.containsKey(name))
                        continue;
                    if (field.getType().equals(int.class) || field.getType().equals(Integer.class)) {
                        setter.invoke(object, value.get(name).toInteger());
                    } else if (field.getType().equals(String.class)) {
                        setter.invoke(object, value.get(name).getStringValue());
                    } else if (field.getType().equals(long.class) || field.getType().equals(Long.class)) {
                        setter.invoke(object, value.get(name).toLong());
                    } else if (field.getType().equals(double.class) || field.getType().equals(Double.class)) {
                        setter.invoke(object, value.get(name).toDouble());
                    } else if (field.getType().equals(Date.class)) {
                        setter.invoke(object, value.get(name).toDate());
                    }
                }
                return object;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }

        private Method getSetter(String name, Class<T> clazz) {
            for (Method method : clazz.getDeclaredMethods()) {
                if (method.getName().equals("set" + name.substring(0, 1).toUpperCase() + name.substring(1)))
                    return method;
            }
            return null;
        }
    }

    public static class RefectionMapper<T> implements Mapper<T> {

        private final String[] headers;
        private Class<T> clazz;

        public RefectionMapper(Class<T> clazz, String[] headers) {
            this.headers = headers;
            this.clazz = clazz;
        }

        @Override
        public T call(Map<String, CsvReaderWriter.CsvCell> values) {
            try {
                T t = clazz.newInstance();
                Field[] fields = t.getClass().getDeclaredFields();
                for (Field field : fields) {
                    if (field.getType().equals(int.class)) {
                        field.set(t, values.get(field.getName()).toInteger());
                    } else if (field.getType().equals(String.class)) {
                        field.set(t, values.get(field.getName()).getStringValue());
                    } else if (field.getType().equals(long.class)) {
                        field.set(t, values.get(field.getName()).toLong());
                    } else if (field.getType().equals(double.class)) {
                        field.set(t, values.get(field.getName()).toDouble());
                    } else if (field.getType().equals(Date.class)) {
                        field.set(t, values.get(field.getName()).toDate());
                    }
                }
                return t;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        }

    }

    public static class Reader<K> implements Iterator<K>, Iterable<K>, Closeable {
        private CsvReader reader;
        private Mapper<K> mapper;

        public Reader(CsvReader reader, Mapper<K> mapper, Class<K> clazz) {
            this.reader = reader;
            this.mapper = mapper;
        }

        @Override
        public void close() throws IOException {
            reader.close();
        }

        @Override
        public Iterator<K> iterator() {
            return this;
        }

        @Override
        public boolean hasNext() {
            return reader.hasNext();
        }

        @Override
        public K next() {
            CsvReaderWriter.CsvRow row = reader.next();
            return mapper.call(row.getValue());
        }
    }
}
