package com.paytm.pgplus.bo.files;

import org.file.util.RemoteFileUtil;
import org.file.util.exception.FileUtilException;
import org.file.util.model.SftpProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Created by ritesh on 28/3/17.
 */
public class SftpFileTransfer {
    private static final Logger log = LoggerFactory.getLogger(SftpFileTransfer.class);
    private com.paytm.pgplus.bo.files.SftpConfig config;

    public SftpFileTransfer(SftpConfig config) {
        this.config = config;
    }

    public void transfer(String localPath, String remotePath) throws IOException {
        log.info("Transferring file : {}", localPath, remotePath);
        SftpProperty sftpProperty = new SftpProperty(config.ipAddress, config.username, config.port, config.password,
                localPath, remotePath);
        try {
            RemoteFileUtil.upload(sftpProperty, "");
        } catch (FileUtilException e) {
            throw new IOException(e);
        }
    }
}
