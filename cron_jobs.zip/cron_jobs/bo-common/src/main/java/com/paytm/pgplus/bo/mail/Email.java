package com.paytm.pgplus.bo.mail;

/**
 * Created by ritesh on 28/3/17.
 */
public class Email {
    private String to[];
    private String cc[];
    private String bcc[];
    private String from;
    private String subject;
    private String attachments[];

    public Email(String[] to, String[] cc, String[] bcc, String from, String subject, String[] attachments) {
        this.to = to;
        this.cc = cc;
        this.bcc = bcc;
        this.from = from;
        this.subject = subject;
        this.attachments = attachments;
    }

    public String[] getTo() {
        return to;
    }

    public String[] getCc() {
        return cc;
    }

    public String[] getBcc() {
        return bcc;
    }

    public String getFrom() {
        return from;
    }

    public String getSubject() {
        return subject;
    }

    public String[] getAttachments() {
        return attachments;
    }
}
