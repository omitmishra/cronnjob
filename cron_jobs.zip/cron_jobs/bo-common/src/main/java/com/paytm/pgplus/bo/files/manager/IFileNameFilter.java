package com.paytm.pgplus.bo.files.manager;

/**
 * Created by ritesh on 18/07/17.
 */
public interface IFileNameFilter {
    boolean filter(String name);

    class ContainsFileNameFilter implements IFileNameFilter {
        private String keyword;

        public ContainsFileNameFilter(String keyword) {
            this.keyword = keyword;
        }

        @Override
        public boolean filter(String name) {
            return name.toLowerCase().contains(keyword.toLowerCase());
        }
    }
}