package com.paytm.pgplus.bo.files;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Created by ritesh on 28/3/17.
 */
@Deprecated
public class FileManager {

    private static final Logger log = LoggerFactory.getLogger(FileManager.class);

    public File createTempFile(String name, String suffix) throws IOException {
        return File.createTempFile(name, suffix);
    }

    // TODO : Refactor
    public void zipFile(File destination, List<File> files) throws Exception {
        log.debug("Zipping files : {} to destination : {} ", files, destination);

        boolean flag = false;
        FileOutputStream fos = null;
        ZipOutputStream zipOut = null;
        FileInputStream fis = null;
        try {
            fos = new FileOutputStream(destination);
            zipOut = new ZipOutputStream(new BufferedOutputStream(fos));
            for (File fileName : files) {
                File input = new File(fileName.getAbsolutePath());
                fis = new FileInputStream(input);
                ZipEntry zipEntry = new ZipEntry(input.getName());
                log.info("Zipping the file: {}", input.getName());
                zipOut.putNextEntry(zipEntry);

                byte[] tmp = new byte[4 * 1024];
                int size = 0;
                while ((size = fis.read(tmp)) != -1) {
                    zipOut.write(tmp, 0, size);
                }
                // input.delete();
            }
            flag = true;
            zipOut.flush();
            zipOut.close();

        } catch (Exception e) {
            log.error("Exception Occurred..{}", e);
            throw e;
        } finally {
            try {
                if (fos != null)
                    fos.close();
                if (fis != null)
                    fis.close();

            } catch (Exception ex) {
                log.error("Exception Occurred while closing streams..{}", ex);
            }
        }
    }
}
