package com.paytm.pgplus.bo.processor;

/**
 * Created by ritesh on 13/06/17.
 */
public interface IRecordProcessor<T> {
    void process(RecordProcessorContext<T> context) throws Exception;
}
