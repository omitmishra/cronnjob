package com.paytm.pgplus.bo.job;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.quartz.impl.matchers.GroupMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by ritesh on 28/3/17.
 */
public class JobManager {
    private static final Logger log = LoggerFactory.getLogger(JobManager.class);
    private Scheduler scheduler;

    public JobManager() throws Exception {
        this.scheduler = new StdSchedulerFactory().getScheduler();
    }

    public void start() throws SchedulerException {
        scheduler.start();
    }

    public void submit(IJob job, String name, String cron) throws Exception {
        JobDetail jobDetail = JobBuilder.newJob(QuartzJob.class).withIdentity(name + "Job", "defaultGroup").build();

        jobDetail.getJobDataMap().put("job", job);

        Trigger trigger = TriggerBuilder.newTrigger().withIdentity(name + "Trigger", "defaultGroup")
                .withSchedule(CronScheduleBuilder.cronSchedule(cron)).build();
        if (scheduler.checkExists(jobDetail.getKey())) {
            scheduler.deleteJob(jobDetail.getKey());
        }
        scheduler.scheduleJob(jobDetail, trigger);
        log.info("Scheduling new Job with key and trigger {},{}", jobDetail.getKey(), trigger.getNextFireTime());

    }

    public void submit(IJob job, String name, String cron, boolean executeOnce) throws Exception {
        log.info("Submitting job to process {},{}", job + name, cron);
        if (executeOnce)
            job.execute();
        log.info("sucessfully Job is executed");
        // submit(job, name, cron);
    }

    public void stop() throws Exception {
        scheduler.shutdown(true);
    }

    @DisallowConcurrentExecution
    public static class QuartzJob implements Job {

        @Override
        public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
            // TODO : Do via aspect
            long time = System.currentTimeMillis();
            log.info("Starting job : {}", jobExecutionContext.getJobDetail().getKey().getName());
            try {
                IJob job = (IJob) jobExecutionContext.getJobDetail().getJobDataMap().get("job");
                job.execute();
            } catch (Exception e) {
                log.error("JobException : {}", e);
                throw new JobExecutionException(e);
            } finally {
                log.info("Time taken to execute job :{}", System.currentTimeMillis() - time);
            }
        }
    }
}
