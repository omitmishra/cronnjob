package com.paytm.pgplus.bo.config;

/**
 * Created by ritesh on 28/3/17.
 */
public interface IConfigurationProvider<T> {
    T config();
}
