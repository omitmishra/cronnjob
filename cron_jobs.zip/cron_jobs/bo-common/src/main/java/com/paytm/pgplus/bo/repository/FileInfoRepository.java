package com.paytm.pgplus.bo.repository;

import com.paytm.pgplus.bo.repository.entity.FileInfo;
import com.paytm.pgplus.bo.repository.entity.FileType;
import org.hibernate.LockMode;
import org.hibernate.LockOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by ritesh on 13/06/17.
 */
@Repository
public class FileInfoRepository extends MySqlDbRepository {
    @Autowired
    public FileInfoRepository(MySqlDbFactory sqlDbFactory) {
        super(sqlDbFactory);
    }

    @Transactional
    public FileInfo fetchAndUpdateStatus(FileType fileType, FileInfo.Status selectStatus, FileInfo.Status updateStatus) {
        FileInfo fileInfo = (FileInfo) W()
                .createQuery("SELECT f FROM FileInfo f WHERE f.status=:status AND f.type=:fileType ORDER BY f.updated")
                .setParameter("status", selectStatus).setParameter("fileType", fileType)
                .setLockOptions(LockOptions.UPGRADE).setMaxResults(1).uniqueResult();
        if (fileInfo == null)
            return null;
        fileInfo.setStatus(updateStatus);
        W().save(fileInfo);
        return fileInfo;
    }

    @Transactional
    public FileInfo createIfNotExist(FileInfo fileInfo) {
        FileInfo existing = (FileInfo) W().createQuery("SELECT f FROM FileInfo f WHERE f.location = :location")
                .setParameter("location", fileInfo.getLocation()).setLockMode("f", LockMode.PESSIMISTIC_WRITE)
                .uniqueResult();
        if (existing != null)
            return existing;
        else
            W().persist(fileInfo);
        return null;
    }

    @Transactional
    public void update(FileInfo fileInfo) {
        W().update(fileInfo);
    }

    @Transactional
    public FileInfo findFileInfoFromLocation(String location) {
        FileInfo fileInfoFetched = (FileInfo) W().createQuery("SELECT f FROM FileInfo f WHERE f.location = :location")
                .setParameter("location", location).uniqueResult();
        return fileInfoFetched;
    }
}
