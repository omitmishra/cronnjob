package com.paytm.pgplus.bo.files;

import com.amazonaws.HttpMethod;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.internal.StaticCredentialsProvider;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import com.amazonaws.services.s3.transfer.TransferManager;
import com.amazonaws.services.s3.transfer.TransferManagerBuilder;
import com.amazonaws.services.s3.transfer.Upload;
import com.amazonaws.services.s3.transfer.model.UploadResult;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.net.URL;

/**
 * Created by raman on 27/6/17.
 */
@Slf4j
public class S3Client {
    private AmazonS3 amazonS3Client;
    private TransferManager tm;
    private S3Config config;

    private static final long URL_EXPIRY_TIME = 1000 * 60 * 1440 * 7; // 7 days

    public S3Client(S3Config config) {
        this.config = config;

        amazonS3Client = AmazonS3ClientBuilder.standard().withRegion(config.region).withCredentials(
                new StaticCredentialsProvider(new BasicAWSCredentials(config.accessKey, config.secretAccessKey)))
                .build();

        tm = TransferManagerBuilder.standard()
                .withS3Client(amazonS3Client)
                .withMultipartUploadThreshold((long) (5 * 1024 * 1025))// 5MB
                .build();
    }

    public String getUrl() {
        return this.config.url;
    }

    public void transferFile(String remoteBaseFilePath, File file) {
        amazonS3Client.putObject(config.bucketName, remoteBaseFilePath + file.getName(), file);
    }


    public String transferFileMultipart(String remoteBaseFilePath, File file) throws Exception {
        String key = remoteBaseFilePath + file.getName();
        log.info("CRETATED TransferManager with 5MB threshold");
        Upload upload = tm.upload(config.bucketName, key, file);
        log.info("Uploading data");
        log.info("WAITING FOR COMPLETION");
        try {
            UploadResult result = upload.waitForUploadResult();
            log.info("Upload Successful. output:: Etag: {}, Key: {}", result.getETag(), result.getKey());
           return generatePresignedUrl(config.bucketName, key);
        } catch (Exception e) {
            log.error("Error while uploading data to S3:: {}", e.getMessage());
            throw e;
        }
    }

    public void copyObject(String sourceKey, String destinationKey) {
        amazonS3Client.copyObject(config.bucketName, sourceKey, config.bucketName, destinationKey);
    }

    public S3Object getObject(String key) {
        return amazonS3Client.getObject(config.bucketName, key);
    }

    public void renameObject(String sourceKey, String destinationKey) {
        copyObject(sourceKey, destinationKey);
        amazonS3Client.deleteObject(config.bucketName, sourceKey);
    }

    public void setBucketPermission(CannedAccessControlList cannedAccessControlList) {
        amazonS3Client.setBucketAcl(config.bucketName, cannedAccessControlList);
    }

    public void setObjectPermission(String keyName, CannedAccessControlList cannedAccessControlList) {
        amazonS3Client.setObjectAcl(config.bucketName, keyName, cannedAccessControlList);
    }

    public void deleteObjectsInKey(String folderName) {

        ObjectListing objectListing = amazonS3Client.listObjects(new ListObjectsRequest()
                .withBucketName(config.bucketName));

        for (S3ObjectSummary file : objectListing.getObjectSummaries()) {
            amazonS3Client.deleteObject(config.bucketName, file.getKey());
        }
        amazonS3Client.deleteObject(config.bucketName, folderName);
    }

    public String getBucketName() {
        return config.bucketName;
    }

    private String generatePresignedUrl(String bucketName, String objectKey) {
        URL url = null;
        java.util.Date expiration = new java.util.Date();
        long msec = expiration.getTime();
        msec += URL_EXPIRY_TIME;
        expiration.setTime(msec);
        url = amazonS3Client.generatePresignedUrl(bucketName, objectKey, expiration, HttpMethod.GET);
        return url.toString();
    }
}
