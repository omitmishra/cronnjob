package com.paytm.pgplus.bo.repository.entity;

import javax.persistence.*;
import java.util.Date;

/**
 * Created by ritesh on 12/06/17.
 */
/*
 * @Entity
 * 
 * @Table(name = "file_details")
 */
public class FileDetails {

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private FileDetails.Status status;

    @Column
    private Date created;

    @Column
    private Date updated;

    @Column
    private Long recordNumber;

    @Column
    private String comments;

    public enum Status {
        SUCCESS, FAILED
    }

    @ManyToOne
    @JoinColumn(name = "file_info_id", nullable = false)
    private FileInfo fileInfo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    public Long getRecordNumber() {
        return recordNumber;
    }

    public void setRecordNumber(Long recordNumber) {
        this.recordNumber = recordNumber;
    }

    public FileInfo getFileInfo() {
        return fileInfo;
    }

    public void setFileInfo(FileInfo fileInfo) {
        this.fileInfo = fileInfo;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
}
