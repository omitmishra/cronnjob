package com.paytm.pgplus.bo.processor;

import java.util.List;

/**
 * Created by ritesh on 13/06/17.
 */
public class RecordProcessorContext<T> {
    private List<Record<T>> records;

    public RecordProcessorContext(List<Record<T>> records) {
        this.records = records;
    }

    public List<Record<T>> getRecords() {
        return records;
    }

    public static class Record<T> {
        private T record;
        private Long recordNumber;

        public Record(T record, Long recordNumber) {
            this.record = record;
            this.recordNumber = recordNumber;
        }

        public T getRecord() {
            return record;
        }

        public Long getRecordNumber() {
            return recordNumber;
        }

        @Override
        public String toString() {
            return new StringBuilder().append("Record{").append("number=").append(recordNumber).append(" , record=")
                    .append(record).append("}").toString();
        }
    }

    @Override
    public String toString() {
        return new StringBuilder().append("RecordProcessorContext{").append("records=").append(records).append('}')
                .toString();
    }
}
