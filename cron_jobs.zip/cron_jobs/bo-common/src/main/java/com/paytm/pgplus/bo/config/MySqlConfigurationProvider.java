package com.paytm.pgplus.bo.config;

import com.google.gson.Gson;
import com.paytm.pgplus.bo.repository.ApplicationConfigurationRepository;
import com.paytm.pgplus.bo.repository.entity.ApplicationConfiguration;
import pl.jalokim.propertiestojson.util.PropertiesToJsonParser;

import java.util.List;
import java.util.Properties;

/**
 * Created by ritesh on 28/3/17.
 */
public class MySqlConfigurationProvider<T> implements IConfigurationProvider<T> {

    private final ApplicationConfigurationRepository repository;
    private final Class<T> clazz;
    private final String nodeId;

    public MySqlConfigurationProvider(ApplicationConfigurationRepository repository, Class<T> clazz, String nodeId) {
        this.repository = repository;
        this.clazz = clazz;
        this.nodeId = nodeId;
    }

    public T config() {
        List<ApplicationConfiguration> configurations = repository.list(nodeId);
        Properties properties = new Properties();
        for (ApplicationConfiguration configuration : configurations) {
            properties.put(configuration.getKey().getKey(), configuration.getValue());
        }
        return from(properties, clazz);
    }

    // TODO: Fix this
    public static <T> T from(Properties properties, Class<T> clazz) {
        String json = toJson(properties);
        return new Gson().fromJson(json, clazz);
    }

    private static String toJson(Properties properties) {
        synchronized (PropertiesToJsonParser.class) {
            return PropertiesToJsonParser.parseToJson(properties);
        }
    }

}