package com.paytm.pgplus.bo.files;

/**
 * Created by raman on 27/6/17.
 */
public class S3Config {

    public String host;
    public Integer port;
    public String accessKey;
    public String secretAccessKey;
    public String bucketName;
    public String url;
    public String region;

    public S3Config() {
    }

    public S3Config(String host, Integer port, String accessKey, String secretAccessKey, String bucketName, String url,
                    String region) {
        this.host = host;
        this.port = port;
        this.accessKey = accessKey;
        this.secretAccessKey = secretAccessKey;
        this.bucketName = bucketName;
        this.url = url;
        this.region = region;
    }
}
