package com.paytm.pgplus.bo.repository;

import com.paytm.pgplus.bo.processor.FileProcessingException;
import org.hibernate.Session;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by ritesh on 29/3/17.
 */
public class MySqlDbRepository {
    private com.paytm.pgplus.bo.repository.MySqlDbFactory sqlDbFactory;

    public MySqlDbRepository(com.paytm.pgplus.bo.repository.MySqlDbFactory sqlDbFactory) {
        this.sqlDbFactory = sqlDbFactory;
    }

    protected Session W() {
        return sqlDbFactory.getMasterSessionFactory().getCurrentSession();
    }

    protected Session R() {
        return sqlDbFactory.getSlaveSessionFactory().getCurrentSession();
    }

    @Transactional(rollbackFor = Exception.class)
    public void withinTransaction(Runnable runnable) {
        runnable.run();
    }
}
