package com.paytm.pgplus.bo.repository.entity;

import com.paytm.pgplus.bo.util.csv.CsvColumn;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * Created by ritesh on 07/07/17.
 */
@Entity
@Table(name = "unsettled_txn_payment")
public class UnsettledTxnPayment {
    @CsvColumn("txn_id")
    @Column
    private String txnId;

    @CsvColumn("mid")
    @Column
    private String mid;
    @CsvColumn("txn_date")
    @Column
    private String txnDate;
    @CsvColumn("mbid")
    @Column
    private String mbid;
    @CsvColumn("txn_amount")
    @Column
    private String txnAmount;
    @CsvColumn("currency_type")
    @Column
    private String currencyType;
    @CsvColumn("order_id")
    @Column
    private String orderId;
    @CsvColumn("response_code")
    @Column
    private String responseCode;
    @CsvColumn("bank_txn_id")
    @Column
    private String bankTxnId;
    @CsvColumn("bank_gateway")
    @Column
    private String bankGateway;
    @CsvColumn("issuing_bank")
    @Column
    private String issuingBank;
    @CsvColumn("status")
    @Column
    private String status;
    @CsvColumn("fee_amount")
    @Column
    private String feeAmount;
    @CsvColumn("external_serial_no")
    @Column
    @Id
    private String externalSerialNo;
    @CsvColumn("merchant_name")
    @Column
    private String merchantName;
    @CsvColumn("txn_channel")
    @Column
    private String txnChannel;
    @CsvColumn("pay_mode")
    @Column
    private String payMode;
    @CsvColumn("cust_id")
    @Column
    private String customerId;
    @CsvColumn("ccdc_last_4")
    @Column
    private String ccdcLast4;
    @CsvColumn("base_amount")
    @Column
    private String baseAmount;
    @CsvColumn("merchant_commission")
    @Column
    private String merchantCommission;
    @CsvColumn("settled_date")
    @Column
    private String settledDate;
    @CsvColumn("industry")
    @Column
    private String industry;
    @CsvColumn("gatway_paymode")
    @Column
    private String gatwayPaymode;

    @Column
    private Date created;

    @Column
    private Date updated;

    public String getTxnId() {
        return txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getTxnDate() {
        return txnDate;
    }

    public void setTxnDate(String txnDate) {
        this.txnDate = txnDate;
    }

    public String getMbid() {
        return mbid;
    }

    public void setMbid(String mbid) {
        this.mbid = mbid;
    }

    public String getTxnAmount() {
        return txnAmount;
    }

    public void setTxnAmount(String txnAmount) {
        this.txnAmount = txnAmount;
    }

    public String getCurrencyType() {
        return currencyType;
    }

    public void setCurrencyType(String currencyType) {
        this.currencyType = currencyType;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getBankTxnId() {
        return bankTxnId;
    }

    public void setBankTxnId(String bankTxnId) {
        this.bankTxnId = bankTxnId;
    }

    public String getBankGateway() {
        return bankGateway;
    }

    public void setBankGateway(String bankGateway) {
        this.bankGateway = bankGateway;
    }

    public String getIssuingBank() {
        return issuingBank;
    }

    public void setIssuingBank(String issuingBank) {
        this.issuingBank = issuingBank;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFeeAmount() {
        return feeAmount;
    }

    public void setFeeAmount(String feeAmount) {
        this.feeAmount = feeAmount;
    }

    public String getExternalSerialNo() {
        return externalSerialNo;
    }

    public void setExternalSerialNo(String externalSerialNo) {
        this.externalSerialNo = externalSerialNo;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getTxnChannel() {
        return txnChannel;
    }

    public void setTxnChannel(String txnChannel) {
        this.txnChannel = txnChannel;
    }

    public String getPayMode() {
        return payMode;
    }

    public void setPayMode(String payMode) {
        this.payMode = payMode;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCcdcLast4() {
        return ccdcLast4;
    }

    public void setCcdcLast4(String ccdcLast4) {
        this.ccdcLast4 = ccdcLast4;
    }

    public String getBaseAmount() {
        return baseAmount;
    }

    public void setBaseAmount(String baseAmount) {
        this.baseAmount = baseAmount;
    }

    public String getMerchantCommission() {
        return merchantCommission;
    }

    public void setMerchantCommission(String merchantCommission) {
        this.merchantCommission = merchantCommission;
    }

    public String getSettledDate() {
        return settledDate;
    }

    public void setSettledDate(String settledDate) {
        this.settledDate = settledDate;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getGatwayPaymode() {
        return gatwayPaymode;
    }

    public void setGatwayPaymode(String gatwayPaymode) {
        this.gatwayPaymode = gatwayPaymode;
    }

    public Date getCreated() {
        return created;
    }

    public void setCreated(Date created) {
        this.created = created;
    }

    public Date getUpdated() {
        return updated;
    }

    public void setUpdated(Date updated) {
        this.updated = updated;
    }

    @Override
    public String toString() {
        return "UnsettledTxnPayment{" + "txnId='" + txnId + '\'' + ", mid='" + mid + '\'' + ", txnDate='" + txnDate
                + '\'' + ", mbid='" + mbid + '\'' + ", txnAmount='" + txnAmount + '\'' + ", currencyType='"
                + currencyType + '\'' + ", orderId='" + orderId + '\'' + ", responseCode='" + responseCode + '\''
                + ", bankTxnId='" + bankTxnId + '\'' + ", bankGateway='" + bankGateway + '\'' + ", issuingBank='"
                + issuingBank + '\'' + ", status='" + status + '\'' + ", feeAmount='" + feeAmount + '\''
                + ", externalSerialNo='" + externalSerialNo + '\'' + ", merchantName='" + merchantName + '\''
                + ", txnChannel='" + txnChannel + '\'' + ", payMode='" + payMode + '\'' + ", customerId='" + customerId
                + '\'' + ", ccdcLast4='" + ccdcLast4 + '\'' + ", baseAmount='" + baseAmount + '\''
                + ", merchantCommission='" + merchantCommission + '\'' + ", settledDate='" + settledDate + '\''
                + ", industry='" + industry + '\'' + ", gatwayPaymode='" + gatwayPaymode + '\'' + ", created='"
                + created + '\'' + ", updated='" + updated + '\'' + '}';
    }
}
