package com.paytm.pgplus.bo.job;

/**
 * Created by ritesh on 28/3/17.
 */
public interface IJob {
    void execute() throws Exception;
}
