package com.paytm.pgplus.bo.processor;

/**
 * Created by ritesh on 13/06/17.
 */
public interface IRecordProcessorCheckPointer {
    void checkpoint(String state);
}
