package com.paytm.pgplus.bo.util;

import com.paytm.pgplus.bo.util.csv.CsvReaderWriter;
import org.apache.commons.lang3.tuple.Triple;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by ritesh on 28/3/17.
 */
public class EntityCsvWriter<T> {
    private CsvReaderWriter csvReaderWriter;
    private String[] headerNames;
    private Mapper<T> mapper;

    public EntityCsvWriter(String headerNames[], Mapper<T> mapper) {
        this.headerNames = headerNames;
        this.mapper = mapper;
        this.csvReaderWriter = new CsvReaderWriter();
    }

    public void write(File file, List<T> data) throws IOException {
        try (FileOutputStream outputStream = new FileOutputStream(file)) {
            write(outputStream, data);
        }
    }

    public void write(OutputStream stream, List<T> data) throws IOException {
        List<CsvReaderWriter.CsvRow> csvRows = new ArrayList<>();
        for (T datum : data) {
            Map<String, Object> map = new HashMap<>();
            mapper.call(datum, map);
            CsvReaderWriter.CsvRow row = new CsvReaderWriter.CsvRow();
            for (Map.Entry<String, Object> entry : map.entrySet()) {
                row.add(entry.getKey(), entry.getValue());
            }
            csvRows.add(row);
        }
        csvReaderWriter.writeAll(stream, headerNames, csvRows);

    }

    public interface Mapper<T> {
        void call(T object, Map<String, Object> values);
    }

    public static class RefectionMapper<T> implements Mapper<T> {

        private final String[] headers;

        public RefectionMapper(Class<T> clazz, String[] headers) {
            this.headers = headers;
            try {
                for (String s : headers)
                    clazz.getDeclaredField(s);
            } catch (NoSuchFieldException e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public void call(T object, Map<String, Object> values) {
            try {
                for (String s : headers) {
                    Field field = object.getClass().getDeclaredField(s);
                    boolean isAccessible = field.isAccessible();
                    if (!isAccessible)
                        field.setAccessible(true);
                    Object value = field.get(object);
                    field.setAccessible(isAccessible);
                    values.put(s, value);
                }
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static class TripleMapper<L, M, R> implements Mapper<Triple<L, M, R>> {

        private final String[] headers;

        public TripleMapper(String[] headers) {
            this.headers = headers;
        }

        @Override
        public void call(Triple<L, M, R> triple, Map<String, Object> values) {
            try {
                values.put(headers[0], triple.getLeft());
                values.put(headers[1], triple.getMiddle());
                values.put(headers[2], triple.getRight());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
