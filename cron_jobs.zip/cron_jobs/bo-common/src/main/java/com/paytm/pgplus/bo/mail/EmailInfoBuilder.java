package com.paytm.pgplus.bo.mail;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by ritesh on 25/04/17.
 */
public class EmailInfoBuilder {
    private String messageTemplate;
    private String subject;
    private String[] to;
    private Map<String, Object> variables = new HashMap<>();
    private Map<String, File> fileVariable = new HashMap<>();

    public EmailInfoBuilder to(String[] to) {
        this.to = to;
        return this;
    }

    public EmailInfoBuilder param(String key, Object value) {
        variables.put(key, value);
        return this;
    }

    public EmailInfoBuilder file(File path, String variable) {
        fileVariable.put(variable, path);
        return this;
    }

    public EmailInfoBuilder subject(String subject) {
        this.subject = subject;
        return this;
    }

    public EmailInfoBuilder message(String template) {
        this.messageTemplate = template;
        return this;
    }

    public String getMessageTemplate() {
        return messageTemplate;
    }

    public String getSubject() {
        return subject;
    }

    public String[] getTo() {
        return to;
    }

    protected Map<String, Object> getVariables() {
        return variables;
    }

    protected Map<String, File> getFileVariable() {
        return fileVariable;
    }
}
