package com.paytm.pgplus.bo.processor;

import com.paytm.pgplus.bo.files.manager.IFileManager;
import com.paytm.pgplus.bo.files.manager.IFileNameFilter;
import com.paytm.pgplus.bo.repository.entity.FileType;
import com.paytm.pgplus.bo.util.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;

import static org.apache.commons.collections.CollectionUtils.isEmpty;

/**
 * Created by ritesh on 13/06/17.
 */
public class FileWatcher {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileWatcher.class);

    private FileType type;
    private String location;
    private Integer dayFolder;
    private IFileManager fileManager;
    private final IFileNameFilter filter;

    public FileWatcher(FileType type, String location, IFileManager fileManager, IFileNameFilter filter,
            Integer dayFolder) {
        this.type = type;
        this.location = location;
        this.dayFolder = dayFolder;
        this.fileManager = fileManager;
        this.filter = filter;
    }

    public List<String> watch() {
        String searchLocation = (dayFolder == null ? location : location + "/"
                + new DateUtils().getDateStringForPreviousDayWindow(dayFolder));
        LOGGER.info("Looking into location : {}, type: {}", searchLocation, type);
        List<String> files = fileManager.findFiles(searchLocation, filter);
        LOGGER.debug("Found files : {}", files);
        if (isEmpty(files)) {
            return Collections.EMPTY_LIST;
        } else {
            return files;
        }
    }

    public FileType getType() {
        return type;
    }

}
