package com.paytm.pgplus.bo.repository;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by ritesh on 28/3/17.
 */
@Service
public class MySqlDbFactory {
    private SessionFactory masterSessionFactory;
    private SessionFactory slaveSessionFactory;

    @Autowired
    public MySqlDbFactory(SessionFactory masterSessionFactory, SessionFactory slaveSessionFactory) {
        this.masterSessionFactory = masterSessionFactory;
        this.slaveSessionFactory = slaveSessionFactory;
    }

    public SessionFactory getMasterSessionFactory() {
        return masterSessionFactory;
    }

    public SessionFactory getSlaveSessionFactory() {
        return slaveSessionFactory;
    }

}
