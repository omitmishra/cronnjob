package com.paytm.pgplus.bo.util.csv;

import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Created by ritesh on 22/05/17.
 */
public class CsvReader implements Iterator<CsvReaderWriter.CsvRow>, Iterable<CsvReaderWriter.CsvRow>, Closeable {
    private CSVParser parser;
    private Iterator<CSVRecord> iterator;
    private InputStreamReader streamReader;
    private String[] headerNames;
    private CsvReaderWriter.FormattingOptions formattingOptions;

    public CsvReader(CSVParser parser, InputStreamReader streamReader, String[] headerNames,
            CsvReaderWriter.FormattingOptions formattingOptions) {
        this.parser = parser;
        this.iterator = parser.iterator();
        this.streamReader = streamReader;
        this.headerNames = headerNames;
        this.formattingOptions = formattingOptions;
    }

    @Override
    public boolean hasNext() {
        return iterator.hasNext();
    }

    @Override
    public CsvReaderWriter.CsvRow next() {
        return getCsvRow(iterator.next(), headerNames);
    }

    @Override
    public void close() throws IOException {
        parser.close();
        streamReader.close();
    }

    private CsvReaderWriter.CsvRow getCsvRow(CSVRecord record, String[] headerNames) {
        Map<String, CsvReaderWriter.CsvCell> data = new LinkedHashMap<>();
        if (headerNames == null) {
            for (Map.Entry<String, String> entry : record.toMap().entrySet()) {
                data.put(entry.getKey(), new CsvReaderWriter.CsvCell(entry.getValue(), formattingOptions));
            }
        } else {
            for (String headerName : headerNames) {
                String value = record.get(headerName);
                data.put(headerName, new CsvReaderWriter.CsvCell(value, formattingOptions));
            }
        }
        return new CsvReaderWriter.CsvRow(data);
    }

    @Override
    public Iterator<CsvReaderWriter.CsvRow> iterator() {
        return this;
    }
}
