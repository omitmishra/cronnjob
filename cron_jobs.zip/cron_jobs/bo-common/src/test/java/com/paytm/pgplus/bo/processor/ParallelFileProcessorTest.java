package com.paytm.pgplus.bo.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import java.io.InputStream;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by ritesh on 06/07/17.
 */

public class ParallelFileProcessorTest {

    private static final Logger log = LoggerFactory.getLogger(ParallelFileProcessorTest.class);

    @Test(expectedExceptions = FileProcessingException.class)
    public void testWhenExceptionInProcessingThenRaiseException() throws Exception {
        InputStream stream = ParallelFileProcessorTest.class.getClassLoader().getResourceAsStream(
                "parallel-file-processor-test.csv");
        int parallel = 3;
        ExecutorService service = Executors.newFixedThreadPool(parallel);
        ParallelFileProcessor<Integer> parallelFileProcessor = new ParallelFileProcessor<>(parallel, service);
        FileProcessor<Integer> fileProcessor = mock(FileProcessor.class);
        when(fileProcessor.getOnInitialize()).thenReturn(() -> {
        });
        when(fileProcessor.getRecordProcessor()).thenReturn(context -> {
            log.info("Context : {}", context.getRecords());
            Thread.sleep(2000);
            if (context.getRecords().get(0).getRecord() == 6)
                throw new Exception();
        });
        when(fileProcessor.getRecords()).thenReturn(Arrays.asList(1, 2, 3, 4, 5, 6));
        parallelFileProcessor.processRecords(fileProcessor);
    }

    @Test
    public void testSuccessfulProcessing() throws Exception {
        InputStream stream = ParallelFileProcessorTest.class.getClassLoader().getResourceAsStream(
                "parallel-file-processor-test.csv");
        int parallel = 3;
        ExecutorService service = Executors.newFixedThreadPool(parallel);
        ParallelFileProcessor<Integer> parallelFileProcessor = new ParallelFileProcessor<>(parallel, service);
        FileProcessor<Integer> fileProcessor = mock(FileProcessor.class);
        when(fileProcessor.getOnInitialize()).thenReturn(() -> {
        });
        when(fileProcessor.getRecordProcessor()).thenReturn(context -> {
            log.info("Context : {}", context.getRecords());
            Thread.sleep(2000);
        });
        when(fileProcessor.getRecords()).thenReturn(Arrays.asList(1, 2, 3, 4, 5, 6));
        parallelFileProcessor.processRecords(fileProcessor);
    }

}