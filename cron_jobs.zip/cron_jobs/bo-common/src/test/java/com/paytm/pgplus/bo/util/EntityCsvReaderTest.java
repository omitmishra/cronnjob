package com.paytm.pgplus.bo.util;

import com.paytm.pgplus.bo.util.csv.CsvColumn;
import com.paytm.pgplus.bo.util.csv.CsvReader;
import com.paytm.pgplus.bo.util.csv.CsvReaderWriter;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.testng.Assert.assertEquals;

/**
 * Created by ritesh on 06/07/17.
 */
public class EntityCsvReaderTest {
    public static class A {
        @CsvColumn("aa")
        int a;
        @CsvColumn("bb")
        String b;
        @CsvColumn("cc")
        Long c;
        @CsvColumn("dd")
        Date d;

        public int getA() {
            return a;
        }

        public void setA(int a) {
            this.a = a;
        }

        public String getB() {
            return b;
        }

        public void setB(String b) {
            this.b = b;
        }

        public Long getC() {
            return c;
        }

        public void setC(Long c) {
            this.c = c;
        }

        public Date getD() {
            return d;
        }

        public void setD(Date d) {
            this.d = d;
        }
    }

    @Test
    public void testEntityReader() throws IOException {
        InputStream stream = EntityCsvReader.class.getClassLoader().getResourceAsStream(
                "com/paytm/pgplus/bo/util/csv/entity-csv-reader-sample.csv");

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        CsvReaderWriter.FormattingOptions formattingOptions = new CsvReaderWriter.FormattingOptions(dateFormat);

        EntityCsvReader<EntityCsvReaderTest.A> reader = new EntityCsvReader<>(A.class,
                new EntityCsvReader.AnnotationMapper<>(A.class), formattingOptions);

        List<A> list = new ArrayList<>();
        try (EntityCsvReader.Reader<A> read = reader.read(stream)) {
            for (A a : read) {
                list.add(a);
            }
        }
        assertEquals(list.size(), 3);
    }

}