package com.paytm.pgplus.bo.util.s3Client;

import com.paytm.pgplus.bo.files.S3Client;
import com.paytm.pgplus.bo.files.S3Config;
import lombok.extern.slf4j.Slf4j;

import java.io.File;

/**
 * Created by raman on 28/6/17.
 */
@Slf4j
public class S3ClientTest {
    //@Test(enabled = false)

    public static void main(String[] args) {
        try {
            new S3ClientTest().testTransferFile();
        } catch (Exception e) {
            log.error("Error: ", e);
        }
    }
    public void testTransferFile() throws Exception {
        S3Client s3Client = new S3Client(new S3Config("downloads.internal.paytm.local", 8080, "",
                "", "plus-bo-prod",
                "http://downloads.internal.paytm.com", "ap-south-1"));
        String location = "downloads/";
        String url = s3Client.transferFileMultipart(location, new File("/Users/tejindersingh/s3TestInput"));
        log.info("URL: " + url);

    }
}
