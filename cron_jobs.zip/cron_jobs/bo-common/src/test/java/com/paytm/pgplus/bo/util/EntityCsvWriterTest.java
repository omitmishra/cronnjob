package com.paytm.pgplus.bo.util;

import com.paytm.pgplus.bo.util.EntityCsvWriter;
import org.testng.annotations.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Arrays;

/**
 * Created by ritesh on 28/3/17.
 */
public class EntityCsvWriterTest {

    public static class A {
        int a;
        String b;

        public A(int a, String b) {
            this.a = a;
            this.b = b;
        }
    }

    @Test
    public void testEntityWriter() throws IOException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        EntityCsvWriter<A> writer = new EntityCsvWriter<>(new String[] { "a", "b" }, (object, values) -> {
            values.put("a", object.a);
            values.put("b", object.b);

        });
        writer.write(stream, Arrays.asList(new A(1, "2")));
        String result = new String(stream.toByteArray());
        System.out.println(result);

    }

}