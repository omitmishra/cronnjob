package com.paytm.pgplus.bo.util.csv;

import org.testng.annotations.Test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertEquals;

/**
 * Created by ritesh on 28/3/17.
 */
public class CsvReaderTest {

    public static final String SAMPLE_CSV = "com/paytm/pgplus/bo/util/csv/sample.csv";

    @Test
    public void testCsvRead() throws Exception {
        InputStream stream = CsvReaderTest.class.getClassLoader().getResourceAsStream(SAMPLE_CSV);

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        CsvReaderWriter.FormattingOptions formattingOptions = new CsvReaderWriter.FormattingOptions(dateFormat);

        CsvReaderWriter csvReaderWriter = new CsvReaderWriter(formattingOptions);
        List<CsvReaderWriter.CsvRow> read = csvReaderWriter.readAll(stream, new String[] { "string", "integer",
                "double", "date" });
        assertEquals(read.size(), 1);
        CsvReaderWriter.CsvRow row = read.get(0);
        assertEquals(row.get("string").getStringValue(), "abc");
        assertEquals(row.get("integer").toInteger(), (Integer) 123);
        assertEquals(row.get("double").toDouble(), 1.23);
        assertEquals(row.get("date").toDate(), dateFormat.parse("27-03-2017"));
    }

    @Test
    public void testCsvWrite() throws IOException, ParseException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        CsvReaderWriter.FormattingOptions formattingOptions = new CsvReaderWriter.FormattingOptions(dateFormat);

        CsvReaderWriter csvReaderWriter = new CsvReaderWriter(formattingOptions);
        ArrayList<CsvReaderWriter.CsvRow> csvRows = new ArrayList<>();
        CsvReaderWriter.CsvRow row = new CsvReaderWriter.CsvRow();
        row.add("string", "ab,c");
        row.add("integer", 123);
        row.add("double", 1.23);
        row.add("date", dateFormat.parse("27-03-2017"));

        csvRows.add(row);
        csvReaderWriter.writeAll(stream, new String[] { "string", "integer", "double", "date" }, csvRows);
        String data = new String(stream.toByteArray());
        assertEquals(data, "string,integer,double,date\n" + "\"ab,c\",123,1.23,27-03-2017\n");

    }
}