#!/bin/bash

export SCHEDULER_NAME=$2
export COMMAND=$1

export PROPERTIES_BASE="/etc/appconf/project"
export SCHEDULER_BASE="/paytm/scheduler/scheduler/$SCHEDULER_NAME"
export LOGS="/paytm/logs"
export BIN="$SCHEDULER_BASE/bin"
export LIB="$SCHEDULER_BASE/lib"
export RES="$SCHEDULER_BASE/resources"
export CONF="$PROPERTIES_BASE"

export JAVA_OPTS="-DSchedulerName=$SCHEDULER_NAME"

JAVA_OPTS="$JAVA_OPTS -server"
JAVA_OPTS="$JAVA_OPTS -Xms5G -Xmx10G"
JAVA_OPTS="$JAVA_OPTS -XX:+UseParallelGC -XX:+AggressiveOpts -XX:+UseFastAccessorMethods"
JAVA_OPTS="$JAVA_OPTS -XX:+UseCompressedOops -XX:+UseBiasedLocking -XX:+PrintTenuringDistribution"
JAVA_OPTS="$JAVA_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/paytm/logs/oomdump -XX:NewRatio=3 -XX:ParallelGCThreads=20 -XX:ThreadStackSize=256"
JAVA_OPTS="$JAVA_OPTS -XX:+PrintGCDateStamps -Duser.timezone=IST -Dapp.name=$SCHEDULER_NAME -Dlogs.dir=$LOGS -Xloggc:$LOGS/gc-$SCHEDULER_NAME-`date +%Y%m%d-%H%M%S`.log -verbose:gc -XX:+PrintGCDetails -XX:+PrintGCDateStamps -XX:+PrintGCTimeStamps -XX:+UseGCLogFileRotation -XX:NumberOfGCLogFiles=20 -XX:GCLogFileSize=10M"
JAVA_OPTS="$JAVA_OPTS -DLog4jContextSelector=org.apache.logging.log4j.core.async.AsyncLoggerContextSelector"

CLASSPATH="$LIB/*:$CONF/:$CONF/$SCHEDULER_NAME/:$RES/"

case $COMMAND in
    "start")
        echo "Starting service $SCHEDULER_NAME"
        PID=`pgrep "$SCHEDULER_NAME"`
        if [ ! -z "$PID" ]
        then
            echo "Scheduler process with same name exists with pid $PID"
            exit 1
        fi
        java $JAVA_OPTS -cp "$CLASSPATH" com.paytm.pgplus.barfi.ScheduledJob > "$LOGS/$SCHEDULER_NAME.out" 2>&1 &

        sleep 10

        if ps -p $! > /dev/null
        then
            echo "$!" > "$BIN/$SCHEDULER_NAME.pid"
            echo "Scheduler service $SCHEDULER_NAME started successfully"
        else
            echo "Could not start service $SCHEDULER_NAME"
            exit 1
        fi
        ;;

    "stop")
        echo "Stopping service $SCHEDULER_NAME"
        PID=`pgrep -f "$SCHEDULER_NAME"`

        if [ -z "$PID"  ]
        then
            echo "Could not stop service $SCHEDULER_NAME as it doesn't exists"
            exit 1
        fi

        kill $PID
        sleep 5

        if ps -p $PID > /dev/null
        then
            sleep 5
            echo "Killing $PID"
            kill -9 $PID
        fi
        echo "Stopped successfully $SCHEDULER_NAME"
        ;;

    *)
        echo 'Invalid command'
        exit 1;;
esac
