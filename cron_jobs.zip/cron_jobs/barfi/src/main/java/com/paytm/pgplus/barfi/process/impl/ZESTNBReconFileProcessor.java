package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Pawan Kumar
 * @Since 02/04/2020
 */

@Component(value = "ZESTNBReconFileProcessor")
public class ZESTNBReconFileProcessor implements Processable, XLSXProcessor {

    private static final Logger LOGGER = LogManager.getLogger(ZESTNBReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "Loan ID";
    private static final String chargingSheet = "Paytm";
    private static final String refundSheet = "Adjustments";

    private static Map<String, String> txnTypeSet1 = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap1 = new HashMap<>();
    private static Map<String, String> txnTypeSet2 = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap2 = new HashMap<>();

    static {
        txnTypeSet1.put(Constants.PAYTM_CHARGING, Constants.PAYTM_CHARGING);
        reconMap1.put("Loan Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap1.put("OrderId", ReconFileAdapter.Column.TXN_ID);
        reconMap1.put("Paytm Bank Ref Id", ReconFileAdapter.Column.BANK_TXN_ID);

        txnTypeSet2.put(Constants.PAYTM_REFUND, Constants.PAYTM_REFUND);
        reconMap2.put("Order ID", ReconFileAdapter.Column.TXN_ID);
        reconMap2.put("Payment amount ( Net of processing fee for COD orders )", ReconFileAdapter.Column.GROSS_AMT);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        Map<String, List<String>> csvList;
        List<String> csvList1;
        List<String> csvList2;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);

            csvList = extractDataFromAllSheets(adapter.getProcessingFileHandle());
            csvList1 = csvList.get(chargingSheet);
            csvList2 = csvList.get(refundSheet);
            columnMap = columnNameToTxnIdMap(adapter, csvList1, reconMap1, DELIMITER, COLHEAD);
            parseAndWriteAllColumnIntegerMap(adapter, csvList1, columnMap, DELIMITER, null, txnTypeSet1);
            columnMap = columnNameToTxnIdMap(adapter, csvList2, reconMap2, DELIMITER, COLHEAD);
            parseAndWriteAllColumnIntegerMap(adapter, csvList2, columnMap, DELIMITER, null, txnTypeSet2);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }
}
