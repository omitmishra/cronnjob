package com.paytm.pgplus.barfi.process;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import com.paytm.pgplus.barfi.util.XLSXSheetReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.xml.sax.SAXException;

import com.paytm.pgplus.barfi.util.XLSXReader;

/**
 * XLSXReader to extract data from the file. Should only be used when the file
 * is in XLSX format and have multiple sheets. Map will be returned, with number
 * of sheets passed
 *
 * @author Saurabh
 *
 */

public interface XLSXSheetProcessor extends FileProcessor {

    static final Logger LOGGER = LogManager.getLogger(XLSXSheetProcessor.class);

    /**
     * using XLSXSheetReader to extract data sheetwise from the file. Should
     * only be used when the file is in XLSX format and contains multiple sheets
     * which are needed to be seperately processed
     *
     * @param File
     *            Unprocessed file directly from bank
     * @return Map of sheet index and List of Strings extracted data from file
     *         in list form
     * @throws SAXException
     * @throws ParserConfigurationException
     * @throws OpenXML4JException
     */

    public default List<String> extractData(File file) throws IOException {
        return null;
    }

    public default Map<Integer, List<String>> extractDataSheets(File file, int noOfSheets) throws IOException,
            OpenXML4JException, ParserConfigurationException, SAXException {

        Map<Integer, List<String>> csvList = new HashMap<>();
        if (!file.exists()) {
            LOGGER.error("Not found or not a file: {}", file.getPath());
        }

        int minColumns = -1;
        String filePath = file.getPath();
        OPCPackage p = OPCPackage.open(filePath, PackageAccess.READ);
        XLSXSheetReader xlsx2csv = new XLSXSheetReader(p, csvList, minColumns, noOfSheets);
        xlsx2csv.process();
        return csvList;
    }
}
