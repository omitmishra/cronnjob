package com.paytm.pgplus.barfi.scheduler;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimerTask;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.report.DailyReportGenerator;
import com.paytm.pgplus.barfi.util.ApplicationContextProvider;
import com.paytm.pgplus.barfi.util.PropertyContext;
import com.paytm.pgplus.barfi.util.ReloadableProperties;
import com.paytm.pgplus.barfi.worker.EmailWorker;

/**
 * @author Agrim
 *
 */

@Component
@EnableScheduling
@PropertySource("classpath:barfi.properties")
public class DailyReportScheduler extends TimerTask {

    private static final Logger LOGGER = LogManager.getLogger(DailyReportScheduler.class);

    private String HEADER = PropertyContext.getBarfiProxyProperties().getProperty("report.header");
    private String FOOTER = PropertyContext.getBarfiProxyProperties().getProperty("report.footer");
    private String FILE_LOCATION = "/paytm/logs/archive/barfi_statistics/";
    private String FILE_NAME = "barfi_statistics.log.";

    @Autowired
    DailyReportGenerator dailyReportGenerator;

    /*
     * @see java.util.TimerTask#run() scheduler to generate previous day report
     * and to send mail
     */
    @Scheduled(cron = "${report.scheduler.cron.expression}")
    public void run() {

        int reportSchedulerEnable = ReloadableProperties.getInstance().getIntValue("report.scheduler.enable");
        if (reportSchedulerEnable == 1) {
            try {
                LOGGER.info("Generating Report");
                dailyReportGenerator.logBlank();
                Thread.sleep(60000);

                String[] sendTo = ReloadableProperties.getInstance().getStringArray("mail.id.report");

                Calendar cal = Calendar.getInstance();
                DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                cal.add(Calendar.DATE, -1);
                String Date = dateFormat.format(cal.getTime());

                StringBuilder subjectBuilder = new StringBuilder("BARFI REPORT | ");
                subjectBuilder.append(Date);

                StringBuilder fileNameBuilder = new StringBuilder();
                fileNameBuilder.append(FILE_LOCATION).append(FILE_NAME).append(Date);
                StringBuilder mailContent = new StringBuilder();
                mailContent.append(HEADER);
                mailContent.append(FileUtils.readFileToString(new File(fileNameBuilder.toString())));
                mailContent.append(FOOTER);

                EmailWorker emailWorker = (EmailWorker) ApplicationContextProvider.getApplicationContext().getBean(
                        "emailWorker");
                emailWorker.sendMail(sendTo, subjectBuilder.toString(), mailContent.toString());

                LOGGER.info("Daily Report published");
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }
        }
    }

}
