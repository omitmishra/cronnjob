package com.paytm.pgplus.barfi.dao;

import java.io.Serializable;
import java.util.List;

/**
 * @param <T>
 * @param <Id>
 * @author Sakshi Jain Interface class This class is base class and responsible
 *         for define CRUD operation for DAO
 */
public interface IBaseDao<T, Id extends Serializable> {

    void saveBatch(List<T> entity);

    List<T> findByHqlQuery(String queryString, Object... params);

    void updateBatch(List<T> entity);
}
