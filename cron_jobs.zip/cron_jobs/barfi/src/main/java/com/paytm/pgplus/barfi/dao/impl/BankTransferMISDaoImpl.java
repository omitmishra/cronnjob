package com.paytm.pgplus.barfi.dao.impl;

import com.paytm.pgplus.barfi.dao.IBankTransferMISDao;
import com.paytm.pgplus.barfi.model.BankTransferMIS;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author santoshkumar
 */

@Repository("bankTransferMISDao")
public class BankTransferMISDaoImpl extends BaseAbstractDao<BankTransferMIS, Integer> implements IBankTransferMISDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(BankTransferMISDaoImpl.class);

    @Override
    @Transactional(readOnly = false)
    public void saveBankTransferMIS(List<BankTransferMIS> bankTransferMISList) {
        saveBatch(bankTransferMISList);
    }
}