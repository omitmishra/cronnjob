package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSBSheetProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

@Component(value = "AXIAMPGSReconFileProcessor")
public class AXIAMPGSReconFileProcessor implements Processable, XLSBSheetProcessor {

    public static final Logger LOGGER = LogManager.getLogger(AXIAMPGSReconFileProcessor.class);
    private static final Map<String, Enum<ReconFileAdapter.Column>> reconChargingMap = new HashMap<>();
    private static final Map<String, Enum<ReconFileAdapter.Column>> reconRefundMap = new HashMap<>();
    private static Map<Enum<ReconFileAdapter.Column>, Boolean> costParamMap = new HashMap<>();
    public static final String DELIMETER = "\\|";
    private static final String COLHEAD = "MENAME";
    private static final String REFUND = "REFUND";
    private static final String CHARGING = "PURCHASE";

    static {
        reconChargingMap.put("TXN AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        reconChargingMap.put("MERCHANT TRANS REF", ReconFileAdapter.Column.TXN_ID);
        reconChargingMap.put("RRN NO", ReconFileAdapter.Column.BANK_TXN_ID);
        reconRefundMap.put("RRN NO", ReconFileAdapter.Column.BANK_TXN_ID);
        reconRefundMap.put("TXN AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        reconRefundMap.put("MERCHANT TRANS REF", ReconFileAdapter.Column.TXN_ID);
        reconRefundMap.put("ARN", ReconFileAdapter.Column.RRN);

        reconRefundMap.put("COMMISSION", ReconFileAdapter.Column.BANK_COMMISSION);
        reconRefundMap.put("GST", ReconFileAdapter.Column.BANK_CGST);
        reconRefundMap.put("CARD_TYPE", ReconFileAdapter.Column.CARD_TYPE);
        reconRefundMap.put("MID", ReconFileAdapter.Column.MERCHANT_CODE);
        reconRefundMap.put("MENAME", ReconFileAdapter.Column.STORE_TRADINGNAME);

        reconChargingMap.put("COMMISSION", ReconFileAdapter.Column.BANK_COMMISSION);
        reconChargingMap.put("GST", ReconFileAdapter.Column.BANK_CGST);
        reconChargingMap.put("CARD_TYPE", ReconFileAdapter.Column.CARD_TYPE);
        reconChargingMap.put("MID", ReconFileAdapter.Column.MERCHANT_CODE);
        reconChargingMap.put("MENAME", ReconFileAdapter.Column.STORE_TRADINGNAME);

        costParamMap.put(ReconFileAdapter.Column.BANK_COMMISSION, true);
        costParamMap.put(ReconFileAdapter.Column.BANK_CGST, true);
        costParamMap.put(ReconFileAdapter.Column.CARD_TYPE, true);
        costParamMap.put(ReconFileAdapter.Column.MERCHANT_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.STORE_TRADINGNAME, true);
    }

    @Override
    public void process(ReconFileAdapter adapter) {
        LOGGER.info("File Processed..{}", adapter.fileName);

        Map<String, List<String>> csvMap = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = null;
        int noOfSheets = 2;

        try {
            csvMap = extractDataSheets(adapter.getProcessingFileHandle(), noOfSheets);
            columnMap = mapColumns(adapter, csvMap.get(CHARGING), reconChargingMap, DELIMETER, COLHEAD);
            parseAndWriteCharging(adapter, csvMap.get(CHARGING), columnMap, DELIMETER);
            columnMap = mapColumns(adapter, csvMap.get(REFUND), reconRefundMap, DELIMETER, COLHEAD);
            parseAndWriteRefund(adapter, csvMap.get(REFUND), columnMap, DELIMETER);
            LOGGER.info("File {} Processed successfully..", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    public void parseAndWriteCharging(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int highestKey = getHighestKey(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                setChargingValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    public void parseAndWriteRefund(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int highestKey = getHighestKey(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                setRefundValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    public void setRefundValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        DecimalFormat df = new DecimalFormat("#.####");
        String cardType = "";
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();
                    if (columnMap.containsKey(columnIndex)) {
                        switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                        case RRN:
                            entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                                    .checkApostrophe(cell))));
                            break;
                        case GROSS_AMT:
                            Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_COMMISSION:
                            entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            // this field is missing in the file
                            break;
                        case BANK_CGST:
                            entry.setBankGST(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case CARD_TYPE:
                            cardType = AdapterUtil.checkApostrophe(cell);
                            break;
                        case STORE_TRADINGNAME:
                            entry.setStoreTradingName(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }

            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRrn())) {
                entry.setRrn("0");
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getRefundAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            entry.setNeftNo(0.0);
            entry.setStatus(SUCCESS);
            entry.setTxnAmount(0.0);
            if ("D".equalsIgnoreCase(cardType))
                entry.setBankCardType("Debit");
            else
                entry.setBankCardType("Credit");
        } catch (Exception e) {
            LOGGER.error("Exception in setRefundValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForRefund(entry);
        reconAdapter.refundWriteData(entry);
    }

    private void setChargingValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        DecimalFormat df = new DecimalFormat("#.####");
        Double intnlAmount = 0.0;
        String cardType = "";
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();
                    if (columnMap.containsKey(columnIndex)) {
                        switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                        case GROSS_AMT:
                            intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case AUTH_CODE:
                            entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case RRN:
                            entry.setRRN(AdapterUtil.checkApostrophe(cell));
                            break;
                        case BANK_COMMISSION:
                            entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CGST:
                            entry.setBankGST(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case CARD_TYPE:
                            cardType = AdapterUtil.checkApostrophe(cell);
                            break;
                        case STORE_TRADINGNAME:
                            entry.setStoreTradingName(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (StringUtils.isBlank(entry.getAuthCode())) {
                entry.setAuthCode("0");
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRRN())) {
                entry.setRRN("0");
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getGrossAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            entry.setDisc(0.0);
            entry.setNet(0.0);
            entry.setSTax(0.0);
            if ("D".equalsIgnoreCase(cardType))
                entry.setBankCardType("Debit");
            else
                entry.setBankCardType("Credit");
        } catch (Exception e) {
            LOGGER.error("Exception in setChargingValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForCharging(entry);
        reconAdapter.chargingWriteData(entry);
    }
}
