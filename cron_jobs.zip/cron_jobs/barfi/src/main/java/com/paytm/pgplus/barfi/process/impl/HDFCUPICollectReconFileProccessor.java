package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component(value = "HDFCUPICollectReconFileProccessor")
public class HDFCUPICollectReconFileProccessor implements Processable, XLSXProcessor {

    private static final Logger LOGGER = LogManager.getLogger(HDFCUPICollectReconFileProccessor.class);
    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "External MID";
    public static final String REFUND = "DR";// //
    public static final String PAYMENT = "CR";
    private static Map<String, Enum<ReconFileAdapter.Column>> chargingReconMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> refundReconMap = new HashMap<>();
    private static String SUCCESS = "Success";

    static {
        chargingReconMap.put("Order ID", ReconFileAdapter.Column.TXN_ID);
        chargingReconMap.put("Txn ref no. (RRN)", ReconFileAdapter.Column.RRN);
        chargingReconMap.put("Net Amount", ReconFileAdapter.Column.GROSS_AMT);
        chargingReconMap.put("CR / DR", ReconFileAdapter.Column.TXN_TYPE);
        chargingReconMap.put("UPI Trxn ID", ReconFileAdapter.Column.AUTH_CODE);
        refundReconMap.put("Order ID", ReconFileAdapter.Column.TXN_ID);
        refundReconMap.put("Net Amount", ReconFileAdapter.Column.GROSS_AMT);
        refundReconMap.put("Txn ref no. (RRN)", ReconFileAdapter.Column.RRN);
    }

    @Override
    public void process(ReconFileAdapter adapter) {
        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap;
        Map<Integer, Enum<ReconFileAdapter.Column>> refundColumnMap;

        try {
            LOGGER.info("Filename: {}", adapter.fileName);

            csvList = extractData(adapter.getProcessingFileHandle());
            chargingColumnMap = mapColumns(adapter, csvList, chargingReconMap, DELIMITER, COLHEAD);
            refundColumnMap = mapColumns(adapter, csvList, refundReconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, refundColumnMap, chargingColumnMap, DELIMITER);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error("Got Error: {}", e.getMessage(), e);
            adapter.markFail(e.getMessage());

        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    private void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> refundColumnMap,
            Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap, String delimiter) throws Exception {
        int txtTypeColNo = reconAdapter.getColumnNumberDRCR(chargingColumnMap);
        int rowCount = csvList.size();
        if (txtTypeColNo == -1) {
            LOGGER.error("Invalid File " + reconAdapter.fileName);
            throw new Exception("Invalid File " + reconAdapter.fileName);
        }

        int maxColumn = getMaxColumnNumbers(refundColumnMap, chargingColumnMap);
        for (int rowNum = 1; rowNum < rowCount; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);

                if (StringUtils.isBlank(r) || row.length <= maxColumn) {
                    continue;
                }
                String txnType = reconAdapter.getTxnType(txtTypeColNo, row);
                boolean flag = false;
                if (StringUtils.isNotBlank(txnType)) {
                    if (REFUND.equalsIgnoreCase(txnType)) {
                        reconAdapter.setRefundValues(row, refundColumnMap, canBankTxnIdStartWithZero());
                    } else if (PAYMENT.equalsIgnoreCase(txnType)) {
                        reconAdapter.setChargingValues(row, chargingColumnMap, canBankTxnIdStartWithZero());
                    } else {
                        flag = true;
                    }
                } else {
                    flag = true;
                }
                if (flag == true) {
                    LOGGER.error("File " + reconAdapter.fileName + " Invalid record at line " + rowNum);
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }

        }
    }

    private int getMaxColumnNumbers(Map<Integer, Enum<ReconFileAdapter.Column>> refundColumnMap,
            Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap) {
        int refundCount = getMaxFromMap(refundColumnMap);
        int chargingCount = getMaxFromMap(chargingColumnMap);
        return refundCount >= chargingCount ? refundCount : chargingCount;
    }

    private int getMaxFromMap(Map<Integer, Enum<ReconFileAdapter.Column>> columnMap) {
        int maxValue = -1;
        for (int i : columnMap.keySet()) {
            if (maxValue < i) {
                maxValue = i;
            }
        }
        return maxValue;
    }
}
