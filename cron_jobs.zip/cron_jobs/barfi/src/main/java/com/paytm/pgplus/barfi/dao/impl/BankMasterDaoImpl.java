package com.paytm.pgplus.barfi.dao.impl;

import com.paytm.pgplus.barfi.constants.QueriesHelper;
import com.paytm.pgplus.barfi.dao.IBankMasterDao;
import com.paytm.pgplus.barfi.model.BankMaster;
import com.paytm.pgplus.barfi.model.QueryParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

/**
 * @author Sakshi Jain
 */

@Repository("bankMasterDao")
public class BankMasterDaoImpl extends BaseAbstractDao<BankMaster, Integer> implements IBankMasterDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(BankMasterDaoImpl.class);

    /**
     * @param bankCodeSet
     *            Set<String>
     * @return Bank Master list
     */
    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public List<BankMaster> fetchBankMasterList(Set<String> bankCodeSet) {
        List<BankMaster> bankMasterList = null;
        if (null != bankCodeSet && !bankCodeSet.isEmpty()) {
            LOGGER.info("Fetching data from BankMaster based on bank code list");
            QueryParam queryParam = new QueryParam(QueriesHelper.HqlQuery.BANK_DETAILS_BY_BANK_CODE);
            queryParam.getParam().add(bankCodeSet);
            bankMasterList = findByHqlQuery(queryParam.getQuery().toString(), queryParam.getParam().toArray());
        } else {
            LOGGER.info("Bank code list is empty");
        }
        return bankMasterList;
    }
}