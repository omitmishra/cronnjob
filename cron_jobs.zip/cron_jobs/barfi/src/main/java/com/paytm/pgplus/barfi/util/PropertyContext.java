package com.paytm.pgplus.barfi.util;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class PropertyContext {

    private final Properties BARFI_PROPERTIES;
    private static final Logger LOGGER = LogManager.getLogger(PropertyContext.class);

    private PropertyContext() throws Throwable {
        BARFI_PROPERTIES = loadProperties("barfi.properties");
    }

    private static Properties loadProperties(String url) throws IOException {
        InputStream inputStream = null;
        Properties properties = null;
        try {
            properties = new Properties();
            inputStream = PropertyContext.class.getClassLoader().getResourceAsStream(url);

            if (inputStream != null) {
                properties.load(inputStream);

                return properties;
            } else {
                throw new FileNotFoundException("property file '" + url + "' not found in the classpath");
            }
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        } finally {
            if (inputStream != null)
                inputStream.close();
        }
        return properties;
    }

    private static class SingletonHolder {
        private static PropertyContext instance;

        static {
            PropertyContext tmp = null;
            try {
                tmp = new PropertyContext();
            } catch (Throwable t) {
                throw new ExceptionInInitializerError(t);
            }
            instance = tmp;
        }
    }

    public static final PropertyContext getInstance() {
        return SingletonHolder.instance;
    }

    public static final Properties getBarfiProxyProperties() {
        return (Properties) getInstance().BARFI_PROPERTIES;
    }

}