package com.paytm.pgplus.barfi.util;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.ConfigurationBuilderEvent;
import org.apache.commons.configuration2.builder.ReloadingFileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.convert.DefaultListDelimiterHandler;
import org.apache.commons.configuration2.event.EventListener;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.configuration2.reloading.PeriodicReloadingTrigger;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Reloads properties from a specified location
 * 
 * @author Agrim
 *
 */
public class ReloadableProperties {

    private static final Logger LOGGER = LogManager.getLogger(ReloadableProperties.class);
    private static ReloadingFileBasedConfigurationBuilder<PropertiesConfiguration> builder;
    private static Object lock = new Object();
    private static ReloadableProperties _INSTANCE;
    private static String path = "/etc/appconf/project/barfi/barfi-reloadable.properties";

    public static ReloadableProperties getInstance() {
        return _INSTANCE;
    }

    static {
        if (_INSTANCE == null) {
            synchronized (lock) {
                if (_INSTANCE == null) {
                    _INSTANCE = new ReloadableProperties(path);
                }
            }
        }
    }

    private ReloadableProperties(String path) {
        try {
            File propertiesFile = new File(path);
            Parameters parameters = new Parameters();
            builder = new ReloadingFileBasedConfigurationBuilder<>(PropertiesConfiguration.class).configure(parameters
                    .fileBased().setListDelimiterHandler(new DefaultListDelimiterHandler(',')).setFile(propertiesFile)
                    .setReloadingRefreshDelay(600000l));

            PeriodicReloadingTrigger trigger = new PeriodicReloadingTrigger(builder.getReloadingController(), null,
                    120, TimeUnit.SECONDS);
            trigger.start();

            builder.addEventListener(ConfigurationBuilderEvent.CONFIGURATION_REQUEST,
                    new EventListener<ConfigurationBuilderEvent>() {

                        @Override
                        public void onEvent(ConfigurationBuilderEvent event) {
                            builder.getReloadingController().checkForReloading(null);
                        }
                    });
        } catch (Exception e) {
            LOGGER.error("Unable to Reload Properties", e);
        }
    }

    public String getStringValue(String key) {
        String value = null;
        try {
            value = builder.getConfiguration().getString(key);
        } catch (ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return value;
    }

    public Integer getIntValue(String key) {
        Integer value = null;
        try {
            value = builder.getConfiguration().getInt(key);
        } catch (ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return value;
    }

    public Long getLongValue(String key) {
        Long value = null;
        try {
            value = builder.getConfiguration().getLong(key);
        } catch (ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return value;
    }

    public String[] getStringArray(String key) {
        String[] value = null;
        try {
            value = builder.getConfiguration().getStringArray(key);
        } catch (ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return value;
    }

    public List<String> getList(String key) {
        List<String> value = null;
        try {
            value = builder.getConfiguration().getList(String.class, key);
        } catch (ConfigurationException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return value;
    }

}
