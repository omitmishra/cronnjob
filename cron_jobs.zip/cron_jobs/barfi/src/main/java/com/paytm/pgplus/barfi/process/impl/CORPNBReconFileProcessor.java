package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 *
 * @author agrim.bansal
 *
 */

@Component(value = "CORPNBReconFileProcessor")
public class CORPNBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(CORPNBReconFileProcessor.class);

    private static final String DELIMITER = "\\|";

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList;
        Map<Integer, Enum<Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns();
            parseAndWriteCharge(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private Map<Integer, Enum<Column>> mapColumns() {

        Map<Integer, Enum<Column>> columnMap = new HashMap<>();

        columnMap.put(4, Column.GROSS_AMT);
        columnMap.put(3, Column.TXN_ID);
        columnMap.put(2, Column.BANK_TXN_ID);
        return columnMap;
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    private void parseAndWriteCharge(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = getColumnNumberAmount(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                setChargingValues(row, columnMap, canBankTxnIdStartWithZero(), reconAdapter);
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    private void setChargingValues(String[] row, Map<Integer, Enum<Column>> columnMap,
            boolean canBankTxnIdStartWithZero, ReconFileAdapter reconAdapter) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();

            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case GROSS_AMT:
                    entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case BANK_TXN_ID:
                    entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                default:
                    break;
                }
            }
        }
        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRRN())) {
            entry.setRRN("0");
        }
        entry.setDisc(0.0);
        entry.setMerchantCode("0");
        entry.setNet(0.0);
        entry.setSTax(0.0);
        entry.setAuthCode("0");

        reconAdapter.chargingWriteData(entry);
    }

    private int getColumnNumberAmount(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.GROSS_AMT.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }
}