package com.paytm.pgplus.barfi.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.Properties;

@Configuration
public class CustomSystemProperties {
    private static Logger LOGGER = LoggerFactory.getLogger(CustomSystemProperties.class);

    /**
     * Created this bean with @Primary as previous version of spring only
     * created one java.util.Properties bean in the context which was being used
     * by other beans. After spring version upgrade, several other Properties
     * beans became available causing conflict as none was primary.
     *
     * @return java.util.Properties
     */
    @Primary
    @Bean
    public Properties primaryProperties() {
        Properties properties = System.getProperties();
        LOGGER.info("Loaded customProperties");
        return properties;
    }
}