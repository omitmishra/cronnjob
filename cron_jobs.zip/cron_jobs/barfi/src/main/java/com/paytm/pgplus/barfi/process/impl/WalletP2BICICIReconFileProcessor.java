package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;

/* 
 * @author saurabh
 * 
 */

@Component(value = "WalletP2BICICIReconFileProcessor")
public class WalletP2BICICIReconFileProcessor implements Processable, XLSXProcessor {
    private static final Logger LOGGER = LogManager.getLogger(WalletP2BICICIReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "Ben Bank IFSC";
    private static final String CAPTURE_TRANSACTION = "Completed";
    private static final String CAPTURE_TRANSACTION_FOR_FAIL = "Reversed";
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {
        reconMap.put("Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("Transaction Ref", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("Bank RRN", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("Status", ReconFileAdapter.Column.RESULT_CODE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = getColumnNumberResultCode(columnMap);
        int resultCodeColumn = getColumnNumberResultCode(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }

                String resultCode = getResultCode(resultCodeColumn, row);
                if (resultCode.equalsIgnoreCase(CAPTURE_TRANSACTION)) {
                    setChargingValues(reconAdapter, row, columnMap);
                } else if (resultCode.equalsIgnoreCase(CAPTURE_TRANSACTION_FOR_FAIL)) {
                    setChargingValuesForFail(reconAdapter, row, columnMap);
                } else {
                    continue;
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    private void setChargingValues(ReconFileAdapter reconAdapter, String[] row, Map<Integer, Enum<Column>> columnMap) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case GROSS_AMT:
                    entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case BANK_TXN_ID:
                    entry.setBankTxnId(canBankTxnIdStartWithZero() ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    entry.setRRN(canBankTxnIdStartWithZero() ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case INTNL:
                    entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case AUTH_CODE:
                    entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                    break;
                case RRN:
                    entry.setRRN(AdapterUtil.checkApostrophe(cell));
                    break;
                default:
                    break;
                }
            }
        }
        if (StringUtils.isBlank(entry.getAuthCode())) {
            entry.setAuthCode("0");
        }
        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRRN())) {
            entry.setBankTxnId("0");
        }
        entry.setDisc(0.0);
        entry.setMerchantCode("0");
        entry.setNet(0.0);
        entry.setSTax(0.0);

        reconAdapter.chargingWriteData(entry);
    }

    private void setChargingValuesForFail(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<Column>> columnMap) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case GROSS_AMT:
                    entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case BANK_TXN_ID:
                    entry.setBankTxnId(canBankTxnIdStartWithZero() ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    entry.setRRN(canBankTxnIdStartWithZero() ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case INTNL:
                    entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case AUTH_CODE:
                    entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                    break;
                case RRN:
                    entry.setRRN(AdapterUtil.checkApostrophe(cell));
                default:
                    break;
                }
            }
        }
        if (StringUtils.isBlank(entry.getAuthCode())) {
            entry.setAuthCode("0");
        }
        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRRN())) {
            entry.setRRN("0");
        }
        entry.setDisc(0.0);
        entry.setMerchantCode("0");
        entry.setNet(0.0);
        entry.setSTax(0.0);

        reconAdapter.chargingWriteDataForFail(entry);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    private String getResultCode(int colNo, String[] row) {
        return AdapterUtil.removeQuotes(row[colNo]).trim();
    }

    private int getColumnNumberResultCode(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.RESULT_CODE.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

}
