package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author himanshu4.garg
 *
 */

@Component(value = "HDFCIDebitCCDCReconFileProcessor")
public class HDFCIDebitCCDCReconFileProcessor implements Processable, XLSProcessor {

    private static final Logger LOGGER = LogManager.getLogger(HDFCIDebitCCDCReconFileProcessor.class);

    private static final String REFUND = "CVD";
    private static final String CHARGING = "BAT";
    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "MERCHANT CODE";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("DOMESTIC AMT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("MERCHANT_TRACKID", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("TRAN_ID", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("REC FMT", ReconFileAdapter.Column.TXN_TYPE);
        reconMap.put("ARN NO", ReconFileAdapter.Column.RRN);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER, CHARGING, REFUND);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }
}
