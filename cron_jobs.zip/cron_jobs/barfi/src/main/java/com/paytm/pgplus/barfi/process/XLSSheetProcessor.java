package com.paytm.pgplus.barfi.process;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.paytm.pgplus.barfi.util.XLSReader;
import com.paytm.pgplus.barfi.util.XLSSheetReader;

/**
 * @author saurabh malviya
 *
 */

public interface XLSSheetProcessor extends FileProcessor {

    static final Logger LOGGER = LogManager.getLogger(XLSSheetProcessor.class);

    /**
     * using XLSReader to extract data from the file. Should only be used when
     * the file is in XLS format
     * 
     * @param File
     *            Unprocessed file directly from bank
     * @return List of Strings extracted data from file in list form
     */
    public default List<String> extractData(File file) throws IOException {

        List<String> csvList = new ArrayList<String>();
        if (!file.exists()) {
            LOGGER.error("Not found or not a file: {}", file.getPath());
        }

        int minColumns = -1;
        String filePath = file.getPath();
        XLSSheetReader xls2csv = new XLSSheetReader(filePath, csvList, minColumns);
        xls2csv.process();

        return csvList;
    }
}