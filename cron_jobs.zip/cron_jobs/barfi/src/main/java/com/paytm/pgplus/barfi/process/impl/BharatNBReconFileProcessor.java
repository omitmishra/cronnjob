package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 * @author Ashu Vaidwan
 *
 */

@Component(value = "BharatNBReconFileProcessor")
public class BharatNBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(BharatNBReconFileProcessor.class);
    private static final String DELIMITER = ",";
    private static final String COLHEAD = "SrNo";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("paytm_txnid", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("txn_amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("bank_txn_id", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("bank_ac_no", ReconFileAdapter.Column.AUTH_CODE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int rowEnd = csvList.size();
        for (int rowNum = 1; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r)) {
                    continue;
                }
                reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }
}
