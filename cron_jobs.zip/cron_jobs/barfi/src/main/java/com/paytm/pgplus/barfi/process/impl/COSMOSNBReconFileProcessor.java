package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 *
 * @author saurabh malviya
 *
 */

@Component(value = "COSMOSNBReconFileProcessor")
public class COSMOSNBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(COSMOSNBReconFileProcessor.class);

    private static final String DELIMITER = "\\^";

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns();
            parseAndWriteCharging(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private Map<Integer, Enum<Column>> mapColumns() {

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();

        columnMap.put(2, ReconFileAdapter.Column.GROSS_AMT);
        columnMap.put(0, ReconFileAdapter.Column.TXN_ID);
        columnMap.put(1, ReconFileAdapter.Column.BANK_TXN_ID);
        return columnMap;
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    @Override
    public void parseAndWriteCharging(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int recordIdentifier = 3;
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo || row.length <= recordIdentifier) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))
                        || row[recordIdentifier].equalsIgnoreCase("N")) {
                    continue;
                }
                reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

}
