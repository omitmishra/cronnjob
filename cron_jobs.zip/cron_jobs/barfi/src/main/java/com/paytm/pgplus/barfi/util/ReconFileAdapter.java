package com.paytm.pgplus.barfi.util;

import com.paytm.pgplus.barfi.queue.service.IProducer;
import com.paytm.pgplus.barfi.report.DailyReportGenerator;
import com.paytm.pgplus.barfi.service.SlackHelper;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;
import com.paytm.pgplus.barfi.worker.EmailWorker;
import com.paytm.pgplus.rabbitmq.enums.EnumRoutingKey;
import freemarker.template.Template;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.file.util.model.FileMetaData;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.paytm.pgplus.barfi.util.AdapterConstants.*;

/**
 * @author Agrim
 * @author Shubham
 */

public class ReconFileAdapter {

    private static final Logger LOGGER = LogManager.getLogger(ReconFileAdapter.class);
    private static String[] FIS_BANKS = { "FISR", "FISN", "FISB" };
    public String processingDestination;
    private String failDestination;
    private String recordDestination;
    private String successDestination;
    private String recordDestinationForFail;
    private String successDestinationForFail;
    public String fileParentPath;
    public String fileName;
    private String absoluteFileName;
    public String filePath;
    private String bankFolderName;
    private boolean isFIS;
    private PrintWriter refundPrintWriter;
    private PrintWriter chargingPrintWriter;
    private PrintWriter chargebackPrintWriter;
    private PrintWriter refundPrintWriterForFail;
    private PrintWriter chargingPrintWriterForFail;
    private PrintWriter chargebackPrintWriterForFail;
    private StringBuilder unprocessedRefundFilePath;
    private StringBuilder unprocessedChargingFilePath;
    private StringBuilder unprocessedChargebackFilePath;
    private StringBuilder processedRefundFilePath;
    private StringBuilder processedChargingFilePath;
    private StringBuilder processedChargebackFilePath;

    private StringBuilder unprocessedRefundFilePathForFail;
    private StringBuilder unprocessedChargingFilePathForFail;
    private StringBuilder unprocessedChargebackFilePathForFail;
    private StringBuilder processedRefundFilePathForFail;
    private StringBuilder processedChargingFilePathForFail;
    private StringBuilder processedChargebackFilePathForFail;

    private Template template;
    private int refundCount;
    private int chargingCount;
    private int refundCountForFail;
    private int chargingCountForFail;
    private String extension;

    private int noOfRecordInResponse;
    private boolean isPartitionAllowed;

    private boolean isCostReconBank = false;
    private boolean isDynamicCurrency = false;
    private static final FastDateFormat DATE_FORMAT = FastDateFormat.getInstance("yyyy/MM/dd HH:mm:ss");

    public ReconFileAdapter(File file, Template template) throws FileNotFoundException {
        this.template = template;
        this.fileParentPath = file.getParent();
        this.fileName = file.getName();
        this.bankFolderName = file.getParentFile().getName();
        this.isFIS = checkFIS(bankFolderName, FIS_BANKS);
        String bankfolder = ProcessorBean.valueOf(getBeanName()).getDestinationFolder();
        if (BANK_PAYMODE_ICICIPAY_CC_DC.equalsIgnoreCase(bankfolder)) {
            isDynamicCurrency = true;
        }
        this.extension = FilenameUtils.getExtension(fileName);
        if (extension.equals(FILEPART)) {
            throw new IllegalFileFormatException(fileName + " Not moved completely yet, extension is filepart ");
        }
        this.absoluteFileName = FilenameUtils.removeExtension(fileName) + "_" + getBeanName();
        this.filePath = file.getPath();
        this.processingDestination = fileParentPath + SLASH + PROCESSING_TEMP + SLASH + fileName;

        this.failDestination = ReloadableProperties.getInstance().getStringValue("location.fail.unprocessed.dir")
                + bankfolder;
        this.recordDestination = ReloadableProperties.getInstance().getStringValue("location.success.unprocessed.dir")
                + bankfolder;
        this.successDestination = ReloadableProperties.getInstance().getStringValue("location.success.processed.dir")
                + bankfolder + SLASH + absoluteFileName;

        this.recordDestinationForFail = ReloadableProperties.getInstance().getStringValue(
                "location.success.unprocessed.dir.forfail")
                + bankfolder;
        this.successDestinationForFail = ReloadableProperties.getInstance().getStringValue(
                "location.success.processed.dir.forfail")
                + bankfolder + SLASH + absoluteFileName;

        if (this.bankFolderName.equals("WALLET-P2B_ICICI"))
            this.noOfRecordInResponse = ReloadableProperties.getInstance().getIntValue(
                    "response.record.count.old.pg.file");
        else
            this.noOfRecordInResponse = ReloadableProperties.getInstance().getIntValue("response.record.count");

        this.isPartitionAllowed = this.bankFolderName.equals("WALLET-P2B_ICICI")
                || this.bankFolderName.equals("PPBL-UPI");

        this.setStringBuilders();
        this.markProcessing();

        /*
         * PGP-23942 commented below line because if data not found for file
         * then empty file is being create with header so when recon consume
         * then they cann't move into respective folder so they scan such file
         * unneccessarly result degrade's performance this.refundPrintWriter =
         * new PrintWriter(unprocessedRefundFilePath.toString());
         * this.chargingPrintWriter = new
         * PrintWriter(unprocessedChargingFilePath.toString());
         * this.chargebackPrintWriter = new
         * PrintWriter(unprocessedChargebackFilePath.toString()); //For fail
         * this.refundPrintWriterForFail = new
         * PrintWriter(unprocessedRefundFilePathForFail.toString());
         * this.chargingPrintWriterForFail = new
         * PrintWriter(unprocessedChargingFilePathForFail.toString());
         * this.chargebackPrintWriterForFail = new
         * PrintWriter(unprocessedChargebackFilePathForFail.toString());
         * 
         * this.refundWriteHead(); this.chargingWriteHead();
         * this.chargebackWriteHead(); // for fail
         * this.refundWriteHeadForFail(); this.chargingWriteHeadForFail();
         * this.chargebackWriteHeadForFail();
         */

        String bankName = getBeanName();
        String costReconBankList = ReloadableProperties.getInstance().getStringValue("cost.recon.bank.list");
        if (Strings.isNotEmpty(costReconBankList) && costReconBankList.indexOf(bankName) >= 0)
            this.isCostReconBank = true;
        this.refundCount = 0;
        this.chargingCount = 0;

        this.refundCountForFail = 0;
        this.chargingCountForFail = 0;
        this.verifyFileExtension();
    }

    private boolean checkFIS(String bankName, String[] bankFolderNames) {
        LOGGER.info("Bank folder currently is {} , Bank folder names {}", bankFolderName,
                Arrays.toString(bankFolderNames));
        for (String bank : bankFolderNames) {
            if (bankName.contains(bank))
                return true;
        }
        return false;
    }

    /**
     * verifies file extension, and no further processing is thrown in case of
     * failure
     */
    private void verifyFileExtension() {
        if (!extension.equalsIgnoreCase(ProcessorBean.valueOf(getBeanName()).getExtension())) {
            markFail("Extension Mismatch");
            throw new IllegalFileFormatException(fileName + " Extension Mismatch ");
        }
    }

    public ProcessedRefundRow resetCostParametersForRefund(ProcessedRefundRow entry) {
        LOGGER.error("Resetting Cost Parameters for Refund : filePath {} | fileName {} | txnId {}", this.filePath,
                this.fileName, entry.getTxnId());
        entry.setBankComissionPerc(0.0);
        entry.setBankComissionAmount(0.0);
        entry.setBankGST(0.0);
        entry.setBankVAT(0.0);
        entry.setBankServiceTax(0.0);
        entry.setBankCess(0.0);
        entry.setBankTotalTax(0.0);
        entry.setOnusIndicator(Strings.EMPTY);
        entry.setBankCardScheme(Strings.EMPTY);
        entry.setBankCardType(Strings.EMPTY);
        entry.setBankInternational((byte) 0);
        entry.setBankCorporate((byte) 0);
        entry.setMCCCode(Strings.EMPTY);
        entry.setTerminalCode(Strings.EMPTY);
        entry.setStoreCode(Strings.EMPTY);
        entry.setStoreTradingName(Strings.EMPTY);
        entry.setUdf1(Strings.EMPTY);
        entry.setUdf2(Strings.EMPTY);
        entry.setUdf3(Strings.EMPTY);
        entry.setUdf4(Strings.EMPTY);
        entry.setUdf5(Strings.EMPTY);
        entry.setUdf6(Strings.EMPTY);
        return entry;
    }

    public ProcessedChargingRow resetCostParametersForCharging(ProcessedChargingRow entry) {
        LOGGER.error("Resetting Cost Parameters for Charging : filePath {} | fileName {} | txnId {}", this.filePath,
                this.fileName, entry.getTxnId());
        entry.setBankComissionPerc(0.0);
        entry.setBankComissionAmount(0.0);
        entry.setBankGST(0.0);
        entry.setBankVAT(0.0);
        entry.setBankServiceTax(0.0);
        entry.setBankCess(0.0);
        entry.setBankTotalTax(0.0);
        entry.setOnusIndicator(Strings.EMPTY);
        entry.setBankCardScheme(Strings.EMPTY);
        entry.setBankCardType(Strings.EMPTY);
        entry.setBankInternational((byte) 0);
        entry.setBankCorporate((byte) 0);
        entry.setMCCCode(Strings.EMPTY);
        entry.setTerminalCode(Strings.EMPTY);
        entry.setStoreCode(Strings.EMPTY);
        entry.setStoreTradingName(Strings.EMPTY);
        entry.setUdf1(Strings.EMPTY);
        entry.setUdf2(Strings.EMPTY);
        entry.setUdf3(Strings.EMPTY);
        entry.setUdf4(Strings.EMPTY);
        entry.setUdf5(Strings.EMPTY);
        entry.setUdf6(Strings.EMPTY);
        return entry;
    }

    public enum Column {

        TXN_DATE, GROSS_AMT, TXN_ID, BANK_TXN_ID, TXN_TYPE, RRN, INTNL, AUTH_CODE, RESULT_CODE, BANK_CGST, BANK_SGST, BANK_IGST, BANK_UGST, BANK_COMMISSION, BANK_SERVICETAX, DEBITCREDIT_TYPE, CARD_TYPE, MERCHANT_CODE, TERMINAL_CODE, BANK_TID, BANK_CARDSCHEME, TXN_CURR, ONUS_INDC, CARD_CATEGORY, MCC, STORE_CODE, STORE_TRADINGNAME, NET_AMT, TRANSACTION_STATUS, TXN_AMT, TXN_CURRENCY, ARN;
    }

    public enum FileType {
        PAYMENT, REFUND;
    }

    /**
     * in case of refund, this method is called to set values in the processed
     * file
     *
     * @param canBankTxnIdStartWithZero
     * @param File
     *            row to be parsed and written in the processed file
     * @param Map
     *            columnMap required for indices
     */
    // instead use setRefundValuesColumnIntegerMap method
    public void setRefundValues(String[] row, Map<Integer, Enum<Column>> columnMap, boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();

            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case RRN:
                    entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                            .checkApostrophe(cell))));
                    break;
                case GROSS_AMT:
                    Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                    entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case BANK_TXN_ID:
                    // If bankTxnId can start with zero in processed, then do
                    // not strip leading zeroes
                    entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case INTNL:
                    entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                default:
                    break;
                }
            }
        }

        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRrn())) {
            entry.setRrn("0");
        }
        entry.setNeftNo(0.0);
        entry.setMerchantCode("0");
        entry.setStatus(SUCCESS);
        entry.setTxnAmount(0.0);

        this.refundWriteData(entry);
    }

    /**
     * in case of refund, this method is called to set values in the processed
     * file
     *
     * @param canBankTxnIdStartWithZero
     * @param File
     *            row to be parsed and written in the processed file
     * @param Map
     *            columnMap required for indices
     */
    public void setRefundValuesColumnIntegerMap(String[] row, Map<Enum<Column>, Integer> columnMap,
            boolean canBankTxnIdStartWithZero) {
        ProcessedRefundRow entry = new ProcessedRefundRow();
        for (Map.Entry<Enum<ReconFileAdapter.Column>, Integer> mapEntry : columnMap.entrySet()) {
            int columnIndex = mapEntry.getValue();
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            switch ((Column) mapEntry.getKey()) {
            case RRN:
                entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                        .checkApostrophe(cell))));
                break;
            case GROSS_AMT:
                Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                break;
            case TXN_ID:
                entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                break;
            case BANK_TXN_ID:
                // If bankTxnId can start with zero in processed, then do
                // not strip leading zeroes
                entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                        .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                break;
            case INTNL:
                entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                break;
            default:
                break;
            }
        }

        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRrn())) {
            entry.setRrn("0");
        }
        entry.setNeftNo(0.0);
        entry.setMerchantCode("0");
        entry.setStatus(SUCCESS);
        entry.setTxnAmount(0.0);

        this.refundWriteData(entry);
    }

    public void setRefundValuesForFail(String[] row, Map<Integer, Enum<Column>> columnMap,
            boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();

            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case RRN:
                    entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                            .checkApostrophe(cell))));
                    break;
                case GROSS_AMT:
                    Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                    entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case BANK_TXN_ID:
                    // If bankTxnId can start with zero in processed, then do
                    // not strip leading zeroes
                    entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case INTNL:
                    entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                default:
                    break;
                }
            }
        }

        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRrn())) {
            entry.setRrn("0");
        }
        entry.setNeftNo(0.0);
        entry.setMerchantCode("0");
        entry.setStatus(SUCCESS);
        entry.setTxnAmount(0.0);

        this.refundWriteDataForFail(entry);
    }

    /**
     * in case of charging, this method is called to set values in the processed
     * file
     *
     * @param canBankTxnIdStartWithZero
     * @param File
     *            row to be parsed and written in the processed file
     * @param Map
     *            columnMap required for indices
     */
    // instead use setChargingValuesColumnIntegerMap method
    public void setChargingValues(String[] row, Map<Integer, Enum<Column>> columnMap, boolean canBankTxnIdStartWithZero) {
        // LOGGER.info("canBankTxnIdStartWithZero value -- {}",
        // canBankTxnIdStartWithZero);
        ProcessedChargingRow entry = new ProcessedChargingRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case GROSS_AMT:
                    Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                    entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case BANK_TXN_ID:
                    // If bankTxnId can start with zero in processed, then do
                    // not strip leading zeroes
                    entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    LOGGER.info("Bank txn id is -- {}", entry.getBankTxnId());
                    break;
                case INTNL:
                    entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case AUTH_CODE:
                    entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                    break;
                case RRN:
                    entry.setRRN(AdapterUtil.checkApostrophe(cell));
                    break;
                default:
                    break;
                }
            }
        }
        if (StringUtils.isBlank(entry.getAuthCode())) {
            entry.setAuthCode("0");
        }
        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRRN())) {
            entry.setRRN("0");
        }
        entry.setDisc(0.0);
        entry.setMerchantCode("0");
        entry.setNet(0.0);
        entry.setSTax(0.0);

        this.chargingWriteData(entry);
    }

    /**
     * in case of charging, this method is called to set values in the processed
     * file
     *
     * @param canBankTxnIdStartWithZero
     * @param File
     *            row to be parsed and written in the processed file
     * @param Map
     *            columnMap required for indices
     */
    public void setChargingValuesColumnIntegerMap(String[] row, Map<Enum<Column>, Integer> columnMap,
            boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        for (Map.Entry<Enum<ReconFileAdapter.Column>, Integer> mapEntry : columnMap.entrySet()) {
            int columnIndex = mapEntry.getValue();
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            switch ((Column) mapEntry.getKey()) {
            case GROSS_AMT:
                Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                break;
            case TXN_ID:
                entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                break;
            case BANK_TXN_ID:
                // If bankTxnId can start with zero in processed, then do not
                // strip leading zeroes
                entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                        .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                break;
            case INTNL:
                entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                break;
            case AUTH_CODE:
                entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                break;
            case RRN:
                entry.setRRN(AdapterUtil.checkApostrophe(cell));
                break;
            default:
                break;
            }
        }
        if (StringUtils.isBlank(entry.getAuthCode())) {
            entry.setAuthCode("0");
        }
        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRRN())) {
            entry.setRRN("0");
        }
        entry.setDisc(0.0);
        entry.setMerchantCode("0");
        entry.setNet(0.0);
        entry.setSTax(0.0);

        this.chargingWriteData(entry);
    }

    public void setChargingValuesForFail(String[] row, Map<Integer, Enum<Column>> columnMap,
            boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case GROSS_AMT:
                    Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                    entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case BANK_TXN_ID:
                    // If bankTxnId can start with zero in processed, then do
                    // not strip leading zeroes
                    entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case INTNL:
                    entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case AUTH_CODE:
                    entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                    break;
                case RRN:
                    entry.setRRN(AdapterUtil.checkApostrophe(cell));
                    break;
                default:
                    break;
                }
            }
        }
        if (StringUtils.isBlank(entry.getAuthCode())) {
            entry.setAuthCode("0");
        }
        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        if (StringUtils.isBlank(entry.getRRN())) {
            entry.setRRN("0");
        }
        entry.setDisc(0.0);
        entry.setMerchantCode("0");
        entry.setNet(0.0);
        entry.setSTax(0.0);

        this.chargingWriteDataForFail(entry);
    }

    /**
     * return the index number of RESULT CODE
     *
     * @param map
     *            of columnhead
     * @return int
     */
    public int getResultCodeColumnNumber(Map<Integer, Enum<Column>> columnMap) {

        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.RESULT_CODE.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    /**
     * return the index number of txn Type
     *
     * @param map
     *            of columnhead
     * @return int
     */
    public int getColumnNumberDRCR(Map<Integer, Enum<Column>> columnMap) {

        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.TXN_TYPE.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    /*
     * 
     * returns the column no. of txn type if exists otherwise returns -1
     */
    public int getColumnNumberWRTTxnType(Map<Enum<Column>, Integer> columnMap) {
        for (Enum<Column> key : columnMap.keySet()) {
            if (Column.TXN_TYPE.equals(key)) {
                return columnMap.get(key);
            }
        }
        return -1;
    }

    /**
     * return the index number of amount column
     *
     * @param map
     *            of columnhead
     * @return int
     */
    public int getColumnNumberAmount(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.GROSS_AMT.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    /**
     * return the index number of transId column
     *
     * @param map
     *            of columnhead
     * @return int
     */
    public int getColumnNumberTransId(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.TXN_ID.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    /**
     * return the index number of RRN column
     *
     * @param map
     *            of columnhead
     * @return int
     */
    public int getColumnNumberRRN(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.RRN.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    /**
     * return the Txn Type given the column number
     *
     * @param int Column number
     * @param String
     *            [] Array of the row data
     * @return String
     */
    public String getTxnType(int columnNumber, String[] row) {
        String txnType = row[columnNumber];
        return AdapterUtil.removeQuotes(txnType).trim();
    }

    /**
     * return the Message Type given the column number
     *
     * @param int Column number
     * @param String
     *            [] Array of the row data
     * @return String
     */
    public String getMessageType(int columnNumber, String[] row) {
        String messageType = row[columnNumber];
        return AdapterUtil.removeQuotes(messageType).trim();
    }

    /**
     * An entry is entered in the processed refund file
     *
     * @param Processed
     *            row
     */
    public void refundWriteData(ProcessedRefundRow row) {
        if (refundCount == 0) {
            try {
                this.refundPrintWriter = new PrintWriter(unprocessedRefundFilePath.toString());
            } catch (FileNotFoundException e) {
                LOGGER.error(e.getMessage(), e);
            }
            this.refundWriteHead();
        }
        refundPrintWriter.append(row.toCSVString(isCostReconBank));
        refundCount++;
    }

    public void refundWriteDataForFail(ProcessedRefundRow row) {
        if (refundCountForFail == 0) {
            try {
                this.refundPrintWriterForFail = new PrintWriter(unprocessedRefundFilePathForFail.toString());
            } catch (FileNotFoundException e) {
                LOGGER.error(e.getMessage(), e);
            }
            this.refundWriteHeadForFail();
        }
        refundPrintWriterForFail.append(row.toCSVString(isCostReconBank));
        refundCountForFail++;
    }

    /**
     * An entry is entered in the processed charging file
     *
     * @param Processed
     *            row
     */
    public void chargingWriteData(ProcessedChargingRow row) {
        if (chargingCount == 0) {
            try {
                this.chargingPrintWriter = new PrintWriter(unprocessedChargingFilePath.toString());
            } catch (FileNotFoundException e) {
                LOGGER.error(e.getMessage(), e);
            }
            this.chargingWriteHead();
        }
        chargingPrintWriter.append(row.toCSVString(isFIS, isCostReconBank, isDynamicCurrency));
        chargingCount++;
    }

    public void chargingWriteDataForFail(ProcessedChargingRow row) {
        if (chargingCountForFail == 0) {
            try {
                this.chargingPrintWriterForFail = new PrintWriter(unprocessedChargingFilePathForFail.toString());
            } catch (FileNotFoundException e) {
                LOGGER.error(e.getMessage(), e);
            }
            this.chargingWriteHeadForFail();
        }
        chargingPrintWriterForFail.append(row.toCSVString(isFIS, isCostReconBank, isDynamicCurrency));
        chargingCountForFail++;
    }

    /**
     * Column titles are written in the processed refund file
     */
    private void refundWriteHead() {
        refundPrintWriter.append("Merchant Code").append(",").append("Txn Date").append(",").append("Txn Amount")
                .append(",").append("Refund Date").append(",").append("Refund Amount").append(",").append("Order ID")
                .append(",").append("Bank Txn ID").append(",").append("NEFT No.").append(",").append("RRN").append(",")
                .append("Status");
        if (isCostReconBank) {
            refundPrintWriter.append(",").append("Bank Commission perc").append(",").append("Bank Commission Amount")
                    .append(",").append("Bank GST").append(",").append("Bank VAT").append(",")
                    .append("Bank Service Tax").append(",").append("Bank CESS").append(",").append("Bank Total Tax")
                    .append(",").append("Onus Indicator").append(",").append("Bank Card Scheme").append(",")
                    .append("Bank Card Type").append(",").append("Bank International").append(",")
                    .append("Bank Corporate").append(",").append("MCC Code").append(",").append("Merchant Id")
                    .append(",").append("Terminal Code").append(",").append("Store Code").append(",")
                    .append("STORETRADINGNAME").append(",").append("MBID").append(",").append("UDF1").append(",")
                    .append("UDF2").append(",").append("UDF3").append(",").append("UDF4").append(",").append("UDF5")
                    .append(",").append("UDF6");
        }
        refundPrintWriter.append("\n");
    }

    private void refundWriteHeadForFail() {
        refundPrintWriterForFail.append("Merchant Code").append(",").append("Txn Date").append(",")
                .append("Txn Amount").append(",").append("Refund Date").append(",").append("Refund Amount").append(",")
                .append("Order ID").append(",").append("Bank Txn ID").append(",").append("NEFT No.").append(",")
                .append("RRN").append(",").append("Status");
        if (isCostReconBank) {
            refundPrintWriterForFail.append(",").append("Bank Commission perc").append(",")
                    .append("Bank Commission Amount").append(",").append("Bank GST").append(",").append("Bank VAT")
                    .append(",").append("Bank Service Tax").append(",").append("Bank CESS").append(",")
                    .append("Bank Total Tax").append(",").append("Onus Indicator").append(",")
                    .append("Bank Card Scheme").append(",").append("Bank Card Type").append(",")
                    .append("Bank International").append(",").append("Bank Corporate").append(",").append("MCC Code")
                    .append(",").append("Merchant Id").append(",").append("Terminal Code").append(",")
                    .append("Store Code").append(",").append("STORETRADINGNAME").append(",").append("MBID").append(",")
                    .append("UDF1").append(",").append("UDF2").append(",").append("UDF3").append(",").append("UDF4")
                    .append(",").append("UDF5").append(",").append("UDF6");
        }
        refundPrintWriterForFail.append("\n");
    }

    /**
     * Column titles are written in the processed charging file
     */

    private void chargingWriteHead() {
        chargingPrintWriter.append("Merchant Code").append(",").append("Txn Date").append(",").append("Gross")
                .append(",").append("Disc").append(",").append("S Tax").append(",").append("Net").append(",")
                .append("Order ID").append(",").append("Bank Txn ID").append(",").append("Auth Code/Trace No.")
                .append(",").append("RRN");
        if (isDynamicCurrency) {
            chargingPrintWriter.append(",").append("Txn Currency").append(",").append("Txn Amount");
        }
        if (isCostReconBank) {
            chargingPrintWriter.append(",").append("Bank Commission perc").append(",").append("Bank Commission Amount")
                    .append(",").append("Bank GST").append(",").append("Bank VAT").append(",")
                    .append("Bank Service Tax").append(",").append("Bank CESS").append(",").append("Bank Total Tax")
                    .append(",").append("Onus Indicator").append(",").append("Bank Card Scheme").append(",")
                    .append("Bank Card Type").append(",").append("Bank International").append(",")
                    .append("Bank Corporate").append(",").append("MCC Code").append(",").append("Merchant Id")
                    .append(",").append("Terminal Code").append(",").append("Store Code").append(",")
                    .append("STORETRADINGNAME").append(",").append("MBID").append(",").append("UDF1").append(",")
                    .append("UDF2").append(",").append("UDF3").append(",").append("UDF4").append(",").append("UDF5")
                    .append(",").append("UDF6");
        }
        chargingPrintWriter.append("\n");
    }

    private void chargingWriteHeadForFail() {
        chargingPrintWriterForFail.append("Merchant Code").append(",").append("Txn Date").append(",").append("Gross")
                .append(",").append("Disc").append(",").append("S Tax").append(",").append("Net").append(",")
                .append("Order ID").append(",").append("Bank Txn ID").append(",").append("Auth Code/Trace No.")
                .append(",").append("RRN");
        if (isCostReconBank) {
            chargingPrintWriterForFail.append(",").append("Bank Commission perc").append(",")
                    .append("Bank Commission Amount").append(",").append("Bank GST").append(",").append("Bank VAT")
                    .append(",").append("Bank Service Tax").append(",").append("Bank CESS").append(",")
                    .append("Bank Total Tax").append(",").append("Onus Indicator").append(",")
                    .append("Bank Card Scheme").append(",").append("Bank Card Type").append(",")
                    .append("Bank International").append(",").append("Bank Corporate").append(",").append("MCC Code")
                    .append(",").append("Merchant Id").append(",").append("Terminal Code").append(",")
                    .append("Store Code").append(",").append("STORETRADINGNAME").append(",").append("MBID").append(",")
                    .append("UDF1").append(",").append("UDF2").append(",").append("UDF3").append(",").append("UDF4")
                    .append(",").append("UDF5").append(",").append("UDF6");
        }
        chargingPrintWriterForFail.append("\n");
    }

    /**
     * Column titles are written in the processed chargeback file
     */
    private void chargebackWriteHead() {
        chargebackPrintWriter.append("Merchant Code").append(",").append("Txn Date").append(",").append("Amount")
                .append(",").append("Order ID").append(",").append("Bank Txn ID").append(",").append("Debit Date")
                .append(",").append("Auth Code/ Trace No.").append(",").append("Neft No.").append(",")
                .append("Neft Date").append(",").append("Reson Code");
        if (isCostReconBank) {
            chargebackPrintWriter.append(",").append("Bank Commission perc").append(",")
                    .append("Bank Commission Amount").append(",").append("Bank GST").append(",").append("Bank VAT")
                    .append(",").append("Bank Service Tax").append(",").append("Bank CESS").append(",")
                    .append("Bank Total Tax").append(",").append("Onus Indicator").append(",")
                    .append("Bank Card Scheme").append(",").append("Bank Card Type").append(",")
                    .append("Bank International").append(",").append("Bank Corporate").append(",").append("MCC Code")
                    .append(",").append("Merchant Id").append(",").append("Terminal Code").append(",")
                    .append("Store Code").append(",").append("STORETRADINGNAME").append(",").append("MBID").append(",")
                    .append("UDF1").append(",").append("UDF2").append(",").append("UDF3").append(",").append("UDF4")
                    .append(",").append("UDF5").append(",").append("UDF6");
        }
        chargebackPrintWriter.append("\n");
    }

    private void chargebackWriteHeadForFail() {
        chargebackPrintWriterForFail.append("Merchant Code").append(",").append("Txn Date").append(",")
                .append("Amount").append(",").append("Order ID").append(",").append("Bank Txn ID").append(",")
                .append("Debit Date").append(",").append("Auth Code/ Trace No.").append(",").append("Neft No.")
                .append(",").append("Neft Date").append(",").append("Reson Code");
        if (isCostReconBank) {
            chargebackPrintWriterForFail.append(",").append("Bank Commission perc").append(",")
                    .append("Bank Commission Amount").append(",").append("Bank GST").append(",").append("Bank VAT")
                    .append(",").append("Bank Service Tax").append(",").append("Bank CESS").append(",")
                    .append("Bank Total Tax").append(",").append("Onus Indicator").append(",")
                    .append("Bank Card Scheme").append(",").append("Bank Card Type").append(",")
                    .append("Bank International").append(",").append("Bank Corporate").append(",").append("MCC Code")
                    .append(",").append("Merchant Id").append(",").append("Terminal Code").append(",")
                    .append("Store Code").append(",").append("STORETRADINGNAME").append(",").append("MBID").append(",")
                    .append("UDF1").append(",").append("UDF2").append(",").append("UDF3").append(",").append("UDF4")
                    .append(",").append("UDF5").append(",").append("UDF6");
        }
        chargebackPrintWriterForFail.append("\n");
    }

    private void closePrintWriter() {

        if (chargingPrintWriter != null) {
            chargingPrintWriter.close();
        }
        if (refundPrintWriter != null) {
            refundPrintWriter.close();
        }
        if (chargingPrintWriterForFail != null) {
            chargingPrintWriterForFail.close();
        }
        if (refundPrintWriterForFail != null) {
            refundPrintWriterForFail.close();
        }
    }

    public File getProcessingFileHandle() {
        return new File(processingDestination);
    }

    public void markSuccess() {
        DailyReportGenerator dailyReportGenerator = (DailyReportGenerator) ApplicationContextProvider
                .getApplicationContext().getBean("dailyReportGenerator");
        closePrintWriter();
        FileUtil.createDirs(successDestination);
        FileUtil.createDirs(recordDestination);
        try {
            if (isPartitionAllowed) {
                moveCSVToSuccessAndMakePartition();
            } else {
                moveCSVToSuccess();
            }
            LOGGER.info(
                    "file: {}, bank: {} processed completely and moved to BO scheduler. refundCount:{} , chargingCount:{}",
                    fileName, bankFolderName, refundCount, chargingCount);
            dailyReportGenerator.logSuccessEntry(bankFolderName, fileName, DATE_FORMAT.format(new Date()),
                    String.valueOf(chargingCount), String.valueOf(refundCount));
            if (chargingCountForFail != 0 || refundCountForFail != 0) {
                FileUtil.createDirs(successDestinationForFail);
                FileUtil.createDirs(recordDestinationForFail);
                if (isPartitionAllowed) {
                    moveCSVToSuccessForFailAndMakePartition();
                } else {
                    moveCSVToSuccessForFail();
                }
                LOGGER.info(
                        "file: {}, bank: {} processed completely and moved to BO scheduler for fail. refundCount:{} , chargingCount:{}",
                        fileName, bankFolderName, refundCountForFail, chargingCountForFail);
                dailyReportGenerator.logSuccessEntry(bankFolderName, fileName + "_FORFAIL",
                        DATE_FORMAT.format(new Date()), String.valueOf(chargingCountForFail),
                        String.valueOf(refundCountForFail));

            } else {
                deleteCSVforFail();
                LOGGER.info(
                        "file: {}, bank: {} processed completely and ignored for fail. refundCount:{} , chargingCount:{}",
                        fileName, bankFolderName, refundCountForFail, chargingCountForFail);
            }

            FileUtil.moveFile(processingDestination,
                    (new StringBuilder(recordDestination).append(SLASH).append(fileName)).toString());
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            markFail("File movement to BOScheduler disrupted, marking failed");
        }

    }

    public void pushFileMetaData(String fileName, String fileParentPath) {
        IProducer queueService = (IProducer) ApplicationContextProvider.getApplicationContext().getBean(
                "queueServiceImpl");
        LOGGER.info("Received filename fileParentPath:{} {}", fileName, fileParentPath);
        if (!FileUtil.isFileExist(fileName + "/" + fileParentPath)) {
            return;
        }
        FileMetaData fileMetaDataInfo = new FileMetaData(fileName, fileParentPath);
        queueService.push(ReloadableProperties.getInstance().getStringValue("barfi.file.status.queue"),
                fileMetaDataInfo);
        LOGGER.info("Push bank recon notification:{} {}", fileName, fileMetaDataInfo.toString());
        LOGGER.info("FileMetaData filename: {}", fileMetaDataInfo.getFileName());
        LOGGER.info("FileMetaData parentDirectory: {}", fileMetaDataInfo.getParentDirectory());
    }

    public void markFail(String reason) {
        DailyReportGenerator dailyReportGenerator = (DailyReportGenerator) ApplicationContextProvider
                .getApplicationContext().getBean("dailyReportGenerator");
        String[] sendTo = ReloadableProperties.getInstance().getStringArray("mail.id.failure");
        StringBuilder subjectBuilder = new StringBuilder().append(bankFolderName).append(" , ").append(fileName)
                .append(" marked FAIL. ").append(reason).append(".");
        Map<String, String> map = populateEmailMap(reason);
        closePrintWriter();
        FileUtil.createDirs(failDestination);
        try {
            EmailWorker emailWorker = (EmailWorker) ApplicationContextProvider.getApplicationContext().getBean(
                    "emailWorker");
            emailWorker.sendMail(sendTo, subjectBuilder.toString(), map, template);
            deleteCSV();
            FileUtil.moveFile(processingDestination,
                    (new StringBuilder(failDestination).append(SLASH).append(fileName)).toString());
            LOGGER.info("File: '{}', Bank: '{}' marked fail | error message: [{}]", fileName, bankFolderName, reason);
            dailyReportGenerator.logFailEntry(bankFolderName, fileName, DATE_FORMAT.format(new Date()));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    private Map<String, String> populateEmailMap(String reason) {
        Map<String, String> map = new HashMap<>();
        map.put("BANKCODE", bankFolderName);
        map.put("FILENAME", fileName);
        map.put("REASON", (StringUtils.isBlank(reason)) ? "Parsing error" : reason);
        map.put("TIMESTAMP", DATE_FORMAT.format(new Date()));
        return map;
    }

    private void markProcessing() {
        this.makeProcessingDirectory();
        try {
            FileUtil.moveFile(filePath, processingDestination);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    private void makeProcessingDirectory() {
        FileUtil.createDir((new StringBuilder(fileParentPath).append(SLASH).append(PROCESSING_TEMP)).toString());
    }

    private void deleteCSV() throws Exception {

        Path deletePath = FileSystems.getDefault().getPath(unprocessedRefundFilePath.toString());
        Files.deleteIfExists(deletePath);
        deletePath = FileSystems.getDefault().getPath(unprocessedChargingFilePath.toString());
        Files.deleteIfExists(deletePath);
        /*
         * deletePath =
         * FileSystems.getDefault().getPath(unprocessedChargebackFilePath
         * .toString()); Files.deleteIfExists(deletePath);
         */
        deletePath = FileSystems.getDefault().getPath(unprocessedRefundFilePathForFail.toString());
        Files.deleteIfExists(deletePath);
        deletePath = FileSystems.getDefault().getPath(unprocessedChargingFilePathForFail.toString());
        Files.deleteIfExists(deletePath);
        /*
         * deletePath =
         * FileSystems.getDefault().getPath(unprocessedChargebackFilePathForFail
         * .toString()); Files.deleteIfExists(deletePath);
         */

    }

    private void deleteCSVforFail() throws Exception {

        Path deletePath = FileSystems.getDefault().getPath(unprocessedRefundFilePathForFail.toString());
        Files.deleteIfExists(deletePath);
        deletePath = FileSystems.getDefault().getPath(unprocessedChargingFilePathForFail.toString());
        Files.deleteIfExists(deletePath);
        // PGP-23942 currently chargeback MIS is not comming hence commented
        /*
         * deletePath =
         * FileSystems.getDefault().getPath(unprocessedChargebackFilePathForFail
         * .toString()); Files.deleteIfExists(deletePath);
         */

    }

    private void moveCSVAndMakePartition(String to, String from, String type, String pushDestination) throws Exception {
        // FileUtil.moveFile(to, from);
        /**
         * Reason for doing this because there is different service running
         * fileNotifier which picks file from PushDestination. If file is too
         * large we split the file into small parts that file move to push
         * destination and file notifier service check the file but it should
         * not pick parent file. If file notifier starts and we have not deleted
         * parent file yet.
         *
         * Then chances of OFM(out of memory) will be there, to avoid this we
         * have split the file into to folder and then move one by one. At the
         * end we delete the file from to folder
         */
        int fileCount = FileUtil.splitFile(to, noOfRecordInResponse);
        int indexFrom = from.lastIndexOf(".");
        int indexTo = to.lastIndexOf(".");
        String prefixTo = to.substring(0, indexTo);
        String suffixTo = to.substring(indexTo);
        String prefixFrom = from.substring(0, indexFrom);
        String suffixFrom = from.substring(indexFrom);
        for (int fileIndex = 1; fileIndex <= fileCount; fileIndex++) {
            // move here one by one
            String filePathTo = prefixTo + fileIndex + suffixTo;
            String filePathFrom = prefixFrom + fileIndex + suffixFrom;
            try {

                LOGGER.info("File moving from {} to {}", filePathTo, filePathFrom);
                if (FileUtil.isFileExist(filePathTo)) {
                    FileUtil.moveFile(filePathTo, filePathFrom);
                }
            } catch (Exception exception) {
                SlackHelper.sendAlertToBoStatic("Following error occurred while moving file. " + "\n"
                        + "File moving from {} to {} " + filePathTo + "," + filePathFrom + "\n"
                        + "Exception occurred is {}" + exception.getMessage());
            }

            /**
             * This is unnecessary push no use of this push as per now
             */
            pushFileMetaData(pushDestination,
                    (new StringBuilder(type).append(absoluteFileName).append(fileIndex).append(CSV)).toString());
        }
        FileUtil.deleteFile(new File(to));
    }

    private void moveCSVToSuccessAndMakePartition() throws Exception {

        if (FileUtil.isFileExist(unprocessedRefundFilePath.toString())) {
            moveCSVAndMakePartition(unprocessedRefundFilePath.toString(), processedRefundFilePath.toString(), REFUND,
                    successDestination);
        }
        if (FileUtil.isFileExist(unprocessedChargingFilePath.toString())) {
            moveCSVAndMakePartition(unprocessedChargingFilePath.toString(), processedChargingFilePath.toString(),
                    CHARGING, successDestination);
        }
        // PGP-23942 currently chargeback MIS is not comming hence commented
        /*
         * moveCSVAndMakePartition(unprocessedChargebackFilePath.toString(),
         * processedChargebackFilePath.toString(), CHARGEBACK,
         * successDestination);
         */

        pushFileMetaData(
                (new StringBuilder(ReloadableProperties.getInstance().getStringValue("location.success.processed.dir")).append(ProcessorBean
                        .valueOf(getBeanName()).getDestinationFolder())).toString(), absoluteFileName);

    }

    private void moveCSVToSuccess() throws Exception {

        FileUtil.moveFile(unprocessedRefundFilePath.toString(), processedRefundFilePath.toString());
        pushFileMetaData(successDestination,
                (new StringBuilder(REFUND).append(absoluteFileName).append(CSV)).toString());

        FileUtil.moveFile(unprocessedChargingFilePath.toString(), processedChargingFilePath.toString());
        pushFileMetaData(successDestination,
                (new StringBuilder(CHARGING).append(absoluteFileName).append(CSV)).toString());

        // PGP-23942 currently chargeback MIS is not comming hence commented
        /*
         * FileUtil.moveFile(unprocessedChargebackFilePath.toString(),
         * processedChargebackFilePath.toString());
         * pushFileMetaData(successDestination, (new
         * StringBuilder(CHARGEBACK).append
         * (absoluteFileName).append(CSV)).toString());
         */

        pushFileMetaData(
                (new StringBuilder(ReloadableProperties.getInstance().getStringValue("location.success.processed.dir")).append(ProcessorBean
                        .valueOf(getBeanName()).getDestinationFolder())).toString(), absoluteFileName);

    }

    private void moveCSVToSuccessForFailAndMakePartition() throws Exception {

        if (FileUtil.isFileExist(unprocessedRefundFilePathForFail.toString())) {
            moveCSVAndMakePartition(unprocessedRefundFilePathForFail.toString(),
                    processedRefundFilePathForFail.toString(), REFUND, successDestinationForFail);
        }
        if (FileUtil.isFileExist(unprocessedChargingFilePathForFail.toString())) {
            moveCSVAndMakePartition(unprocessedChargingFilePathForFail.toString(),
                    processedChargingFilePathForFail.toString(), CHARGING, successDestinationForFail);
        }

        // PGP-23942 currently chargeback MIS is not comming hence commented
        /*
         * moveCSVAndMakePartition(unprocessedChargebackFilePathForFail.toString(
         * ), processedChargebackFilePathForFail.toString(), CHARGEBACK,
         * successDestinationForFail);
         */

        pushFileMetaData(
                (new StringBuilder(ReloadableProperties.getInstance().getStringValue(
                        "location.success.processed.dir.forfail")).append(ProcessorBean.valueOf(getBeanName())
                        .getDestinationFolder())).toString(), absoluteFileName);

    }

    private void moveCSVToSuccessForFail() throws Exception {
        FileUtil.moveFile(unprocessedRefundFilePathForFail.toString(), processedRefundFilePathForFail.toString());

        FileUtil.moveFile(unprocessedChargingFilePathForFail.toString(), processedChargingFilePathForFail.toString());

        // PGP-23942 currently chargeback MIS is not comming hence commented
        /*
         * FileUtil.moveFile(unprocessedChargebackFilePathForFail.toString(),
         * processedChargebackFilePathForFail.toString());
         */

        try {
            pushFileMetaData(successDestinationForFail,
                    (new StringBuilder(REFUND).append(absoluteFileName).append(CSV)).toString());
            pushFileMetaData(successDestinationForFail,
                    (new StringBuilder(CHARGING).append(absoluteFileName).append(CSV)).toString());
            // PGP-23942 currently chargeback MIS is not comming hence commented
            /*
             * pushFileMetaData(successDestinationForFail, (new
             * StringBuilder(CHARGEBACK
             * ).append(absoluteFileName).append(CSV)).toString());
             */
            pushFileMetaData(
                    (new StringBuilder(ReloadableProperties.getInstance().getStringValue(
                            "location.success.processed.dir.forfail")).append(ProcessorBean.valueOf(getBeanName())
                            .getDestinationFolder())).toString(), absoluteFileName);
        } catch (Exception e) {
            LOGGER.error("Failed to push data to RabbitMQ", e.getMessage());
        }

    }

    public String getBeanName() {
        String beanName = null;
        String[] str = bankFolderName.split("-");
        if (str.length == 1) {
            beanName = StringUtils.upperCase(str[0]);
        } else if (str[1].equals(BANKCARD_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + BANKCARD);
        } else if (str[1].equals(NB_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + NB);
        } else if (str[1].equals(DIGITAL_CREDIT_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + DIGITAL_CREDIT);
        } else if (str[1].equals(UPI_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + UPI);
        } else if (str[1].equals(P2B_ICICI_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + P2B_ICICI);
        } else if (str[1].equals(P2B_FIS_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + P2B_FIS);
        } else if (str[1].equals(EDC_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + EDC);
        } else if (str[1].equals(EMI)) {
            beanName = StringUtils.upperCase(str[0] + EMI);
        } else if (str[1].equals(P2B)) {
            beanName = StringUtils.upperCase(str[0] + P2B);
        } else if (str[1].equals(BANK_MANDATE_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + BANK_MANDATE);
        } else if (str[1].equals(EMIDC_PAYMODE)) {
            beanName = StringUtils.upperCase(str[0] + EMIDC_PAYMODE);
        } else if (str[1].equals(BANK_TRANSFER)) {
            beanName = StringUtils.upperCase(str[0] + BANK_TRANSFER);
        } else {
            LOGGER.error("INVALID FOLDER NAME");
        }

        return beanName;

    }

    public void setStringBuilders() {
        unprocessedRefundFilePath = new StringBuilder(fileParentPath).append(SLASH).append(PROCESSING_TEMP)
                .append(SLASH).append(REFUND).append(absoluteFileName).append(CSV);
        unprocessedChargingFilePath = new StringBuilder(fileParentPath).append(SLASH).append(PROCESSING_TEMP)
                .append(SLASH).append(CHARGING).append(absoluteFileName).append(CSV);
        unprocessedChargebackFilePath = new StringBuilder(fileParentPath).append(SLASH).append(PROCESSING_TEMP)
                .append(SLASH).append(CHARGEBACK).append(absoluteFileName).append(CSV);
        processedRefundFilePath = new StringBuilder(successDestination).append(SLASH).append(REFUND)
                .append(absoluteFileName).append(CSV);
        processedChargingFilePath = new StringBuilder(successDestination).append(SLASH).append(CHARGING)
                .append(absoluteFileName).append(CSV);
        processedChargebackFilePath = new StringBuilder(successDestination).append(SLASH).append(CHARGEBACK)
                .append(absoluteFileName).append(CSV);

        unprocessedRefundFilePathForFail = new StringBuilder(fileParentPath).append(SLASH).append(PROCESSING_TEMP)
                .append(SLASH).append(REFUND).append(RET).append(absoluteFileName).append(CSV);
        unprocessedChargingFilePathForFail = new StringBuilder(fileParentPath).append(SLASH).append(PROCESSING_TEMP)
                .append(SLASH).append(CHARGING).append(RET).append(absoluteFileName).append(CSV);
        unprocessedChargebackFilePathForFail = new StringBuilder(fileParentPath).append(SLASH).append(PROCESSING_TEMP)
                .append(SLASH).append(CHARGEBACK).append(RET).append(absoluteFileName).append(CSV);
        processedRefundFilePathForFail = new StringBuilder(successDestinationForFail).append(SLASH).append(REFUND)
                .append(RET).append(absoluteFileName).append(CSV);
        processedChargingFilePathForFail = new StringBuilder(successDestinationForFail).append(SLASH).append(CHARGING)
                .append(RET).append(absoluteFileName).append(CSV);
        processedChargebackFilePathForFail = new StringBuilder(successDestinationForFail).append(SLASH)
                .append(CHARGEBACK).append(RET).append(absoluteFileName).append(CSV);

    }

}
