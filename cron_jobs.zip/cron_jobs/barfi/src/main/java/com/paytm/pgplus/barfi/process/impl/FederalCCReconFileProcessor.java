package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class FederalCCReconFileProcessor implements Processable, XLSXProcessor {

    public static final Logger LOGGER = LogManager.getLogger(FederalCCReconFileProcessor.class);
    private static final Map<String, Enum<ReconFileAdapter.Column>> reconChargingMap = new HashMap<>();
    private static final Map<String, Enum<ReconFileAdapter.Column>> reconRefundMap = new HashMap<>();
    public static final String DELIMETER = "\\|";
    private static final String COLHEAD = "EMI ID";
    private static final String REFUND = "Refund_Amount";

    static {
        reconChargingMap.put("EMI ID", ReconFileAdapter.Column.TXN_ID);
        reconChargingMap.put("Transaction Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconChargingMap.put("Authorisation Id", ReconFileAdapter.Column.AUTH_CODE);

        reconRefundMap.put("EMI ID", ReconFileAdapter.Column.TXN_ID);
        reconRefundMap.put(REFUND, ReconFileAdapter.Column.GROSS_AMT);

    }

    @Override
    public void process(ReconFileAdapter adapter) {

        LOGGER.info("File Processed..{}", adapter.fileName);
        try {
            List<String> csvList = extractData(adapter.getProcessingFileHandle());
            if (csvList == null || csvList.size() == 0) {
                LOGGER.error("No data found");
                adapter.markFail("No data found");
            }
            Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap = mapColumns(adapter, csvList,
                    reconChargingMap, DELIMETER, COLHEAD);
            Map<Integer, Enum<ReconFileAdapter.Column>> refundColumnMap = mapColumns(adapter, csvList, reconRefundMap,
                    DELIMETER, COLHEAD);
            boolean forRefund = foRefund(csvList.get(0));
            parseAndWrite(adapter, csvList, forRefund ? refundColumnMap : chargingColumnMap, forRefund);

            LOGGER.info("File {} Processed successfully..", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }

    }

    private void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean forRefund) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);

        for (int rowNum = 0; rowNum < csvList.size(); rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(DELIMETER);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }

                if (forRefund) {
                    reconAdapter.setRefundValues(row, columnMap, canBankTxnIdStartWithZero());
                } else {
                    reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    private boolean foRefund(String headers) {
        String colHead[] = headers.split(DELIMETER);
        for (int i = 0; i < colHead.length; i++) {
            if (REFUND.equalsIgnoreCase(AdapterUtil.removeQuotes(colHead[i]))) {
                return true;
            }
        }
        return false;
    }
}
