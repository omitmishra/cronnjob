package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 * @author utkarsh gupta
 **/

@Component(value = "AXISUPIReconFileProcessor")
public class AXISUPIReconFileprocessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(AXISUPIReconFileprocessor.class);
    private static final String DELIMITER = "\\,";
    private static final String REFUND = "refund";
    private static final String SUCCESS = "success";
    private static final String DEEMED = "deemed";

    private static Map<Integer, Enum<ReconFileAdapter.Column>> reconMapCharging = new HashMap<>();
    private static Map<Integer, Enum<ReconFileAdapter.Column>> reconMapRefund = new HashMap<>();

    static {
        reconMapCharging.put(1, ReconFileAdapter.Column.BANK_TXN_ID);
        reconMapCharging.put(2, ReconFileAdapter.Column.TXN_ID);
        reconMapCharging.put(3, ReconFileAdapter.Column.GROSS_AMT);
        reconMapCharging.put(11, ReconFileAdapter.Column.RESULT_CODE);

        reconMapRefund.put(2, ReconFileAdapter.Column.BANK_TXN_ID);
        reconMapRefund.put(3, ReconFileAdapter.Column.TXN_ID);
        reconMapRefund.put(15, ReconFileAdapter.Column.GROSS_AMT);
        reconMapRefund.put(13, ReconFileAdapter.Column.RESULT_CODE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {
        List<String> csvList = null;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            parseAndWrite(adapter, csvList, adapter.fileName.toLowerCase().contains(REFUND) ? reconMapRefund
                    : reconMapCharging, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        boolean isRefundFile = reconAdapter.fileName.toLowerCase().contains(REFUND);
        int highestKey = getHighestKey(columnMap);
        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int colNoResultCode = reconAdapter.getResultCodeColumnNumber(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);

                if (StringUtils.isBlank(row) || cellArr.length <= highestKey
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNo, cellArr))) {
                    continue;
                }

                String resultCode = reconAdapter.getTxnType(colNoResultCode, cellArr);
                if (isRefundFile) {
                    if (!resultCode.equalsIgnoreCase(SUCCESS)) {
                        continue;
                    }
                    reconAdapter.setRefundValues(cellArr, columnMap, canBankTxnIdStartWithZero());
                } else {
                    if (!(resultCode.equalsIgnoreCase(SUCCESS) || resultCode.equalsIgnoreCase(DEEMED))) {
                        continue;
                    }
                    reconAdapter.setChargingValues(cellArr, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }
}
