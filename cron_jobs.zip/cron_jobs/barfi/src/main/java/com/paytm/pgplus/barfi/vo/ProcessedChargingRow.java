package com.paytm.pgplus.barfi.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;

/**
 * Represents each row in the Processed Charging File
 * 
 * @author Agrim
 * @author Shubham
 *
 */

@Getter
@Setter
public class ProcessedChargingRow {

    private Date txnDate;

    private Double grossAmount;

    private Double intnlAmount;

    private String bankTxnId;

    private String txnId;

    private Double disc;

    private Double sTax;

    private Double net;

    private String authCode;

    private String RRN;

    private Double bankComissionPerc = 0.0;

    private Double bankComissionAmount = 0.0;

    private Double bankGST = 0.0;

    private Double bankVAT = 0.0;

    private Double bankServiceTax = 0.0;

    private Double bankCess = 0.0;

    private Double bankTotalTax = 0.0;

    private String onusIndicator;

    private String bankCardScheme;

    private String bankCardType;

    private Byte bankInternational;

    private Byte bankCorporate;

    private String MCCCode;

    private String merchantCode;

    private String terminalCode;

    private String storeCode;

    private String storeTradingName;

    private String mbid = Strings.EMPTY;

    private String udf1;

    private String udf2;

    private String udf3;

    private String udf4;

    private String udf5;

    private String udf6;
    private Double transactionAmount;
    private String transactionCurrency;

    // public CharSequence toCSVString() {
    //
    // StringBuilder sb = new StringBuilder();
    // sb.append(merchantCode).append(",").append("0").append(",").append(grossAmount).append(",").append(disc)
    // .append(",").append(sTax).append(",").append(net).append(",").append(txnId).append(",")
    // .append(bankTxnId).append(",").append(authCode).append(",").append(RRN).append("\n");
    // return sb.toString();
    // }

    public CharSequence toCSVString(boolean hasRRN, boolean isCostReconBank, boolean isDynamicCurrency) {

        StringBuilder sb = new StringBuilder();
        sb.append(merchantCode).append(",").append("0").append(",").append(grossAmount).append(",").append(disc)
                .append(",").append(sTax).append(",").append(net).append(",").append(txnId).append(",")
                .append(bankTxnId).append(",").append(authCode).append(",").append(RRN);
        // .append(StringUtils.isBlank(RRN) ? "0" : RRN);
        if (isDynamicCurrency) {
            sb.append(",").append(transactionCurrency).append(",").append(transactionAmount);
        }
        if (isCostReconBank) {
            sb.append(",").append(bankComissionPerc).append(",").append(bankComissionAmount).append(",")
                    .append(bankGST).append(",").append(bankVAT).append(",").append(bankServiceTax).append(",")
                    .append(bankCess).append(",").append(bankTotalTax).append(",")
                    .append(StringUtils.isBlank(onusIndicator) ? "" : onusIndicator).append(",")
                    .append(StringUtils.isBlank(bankCardScheme) ? "" : bankCardScheme).append(",")
                    .append(StringUtils.isBlank(bankCardType) ? "" : bankCardType).append(",")
                    .append(bankInternational == null ? (byte) 0 : bankInternational).append(",")
                    .append(bankCorporate == null ? (byte) 0 : bankCorporate).append(",")
                    .append(StringUtils.isBlank(MCCCode) ? "" : MCCCode).append(",")
                    .append(StringUtils.isBlank(merchantCode) ? "" : merchantCode).append(",")
                    .append(StringUtils.isBlank(terminalCode) ? "" : terminalCode).append(",")
                    .append(StringUtils.isBlank(storeCode) ? "" : storeCode).append(",")
                    .append(StringUtils.isBlank(storeTradingName) ? "" : storeTradingName).append(",")
                    .append(StringUtils.isBlank(mbid) ? " " : mbid).append(",")
                    .append(StringUtils.isBlank(udf1) ? " " : udf1).append(",")
                    .append(StringUtils.isBlank(udf2) ? " " : udf2).append(",")
                    .append(StringUtils.isBlank(udf3) ? " " : udf3).append(",")
                    .append(StringUtils.isBlank(udf4) ? " " : udf4).append(",")
                    .append(StringUtils.isBlank(udf5) ? " " : udf5).append(",")
                    .append(StringUtils.isBlank(udf6) ? " " : udf6);
        }
        sb.append("\n");
        return sb.toString();
    }

}
