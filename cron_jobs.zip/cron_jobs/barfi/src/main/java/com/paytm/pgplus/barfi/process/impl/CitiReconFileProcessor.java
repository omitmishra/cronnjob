package com.paytm.pgplus.barfi.process.impl;

import static com.paytm.pgplus.barfi.util.AdapterConstants.PROCESSING_TEMP;
import static com.paytm.pgplus.barfi.util.AdapterConstants.SLASH;
import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.FileUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import com.paytm.pgplus.barfi.util.ZipUtil;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;

/**
 * @author Agrim
 * @author Shubham
 *
 */

@Component(value = "CITIReconFileProcessor")
public class CitiReconFileProcessor implements Processable, XLSProcessor {

    private static final Logger LOGGER = LogManager.getLogger(CitiReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "MECODE";
    private static final String DELIMITERRRN = "\\|";
    private static final String COLHEADRRN = "ME CODE";
    private static final String RRN = "RRN";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMapRRN = new HashMap<>();

    static {

        reconMap.put("GROSSAMT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("ORDERNUM", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("AUTHNO", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMapRRN.put("ACQREF NUM", ReconFileAdapter.Column.RRN);
        reconMapRRN.put("ORDER NUMBER", ReconFileAdapter.Column.TXN_ID);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        List<String> csvListRRN = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMapRRN;
        String filePath = null;
        String filePathRRN = null;
        File folder = null;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            ZipUtil.extractZip(adapter.processingDestination, adapter.fileParentPath + SLASH + PROCESSING_TEMP);
            folder = new File(FilenameUtils.removeExtension(adapter.processingDestination));
            File[] listOfFiles = folder.listFiles();
            for (int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].isFile() && listOfFiles[i].getName().split("_")[0].equals(RRN)) {
                    filePathRRN = listOfFiles[i].getPath();
                    LOGGER.info(filePathRRN);
                }
                if (listOfFiles[i].isFile() && !listOfFiles[i].getName().split("_")[0].equals(RRN)) {
                    filePath = listOfFiles[i].getPath();
                    LOGGER.info(filePath);
                }
            }
            csvList = extractData(new File(filePath));
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            csvListRRN = extractData(new File(filePathRRN));
            columnMapRRN = mapColumns(adapter, csvListRRN, reconMapRRN, DELIMITERRRN, COLHEADRRN);
            parseAndWrite(adapter, csvList, csvListRRN, columnMap, columnMapRRN, DELIMITER, DELIMITERRRN);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        } finally {
            FileUtil.deleteFolder(folder);
        }
    }

    /**
     * Parses and writes to the csv files
     * 
     * @param reconAdapter
     * @param csvList
     * @param csvListRRN
     * @param columnMap
     * @param columnMapRRN
     * @param delimiter
     * @param delimiterRRN
     * @throws Exception
     */
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList, List<String> csvListRRN,
            Map<Integer, Enum<Column>> columnMap, Map<Integer, Enum<Column>> columnMapRRN, String delimiter,
            String delimiterRRN) throws Exception {

        int rowNum = 0;
        int rowEnd = csvList.size();
        try {
            HashMap<String, ProcessedRefundRow> myMap = new HashMap<>();
            int colNo = reconAdapter.getColumnNumberAmount(columnMap);
            int colNoTxnId = reconAdapter.getColumnNumberTransId(columnMap);
            for (rowNum = 0; rowNum < rowEnd; rowNum++) {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= Math.max(colNo, colNoTxnId)
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNoTxnId, row))) {
                    continue;
                }
                if (reconAdapter.getTxnType(colNo, row).startsWith("-")) {
                    ProcessedRefundRow entry = getRowEntry(row, columnMap);
                    myMap.put(entry.getTxnId(), entry);
                } else {
                    reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
                }
            }

            colNo = getColumnNumberRRN(columnMapRRN);
            colNoTxnId = reconAdapter.getColumnNumberTransId(columnMap);
            rowEnd = csvListRRN.size();
            for (rowNum = 0; rowNum < rowEnd; rowNum++) {
                String r = csvListRRN.get(rowNum);
                String[] row = r.split(delimiterRRN);
                if (StringUtils.isBlank(r) || row.length <= Math.max(colNo, colNoTxnId)
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNoTxnId, row))) {
                    continue;
                }
                String[] entryRrn = getRowEntryRRN(row, columnMapRRN);

                if (myMap.get(entryRrn[0]) != null) {
                    myMap.get(entryRrn[0]).setRrn(entryRrn[1]);
                }
            }

            for (Map.Entry<String, ProcessedRefundRow> entry : myMap.entrySet()) {
                reconAdapter.refundWriteData(entry.getValue());
            }
        } catch (Exception e) {
            throw new Exception("File " + reconAdapter.fileName + " parsing error at " + rowNum, e);
        }
    }

    /**
     * generates entry from main file
     * 
     * @param reconAdapter
     * @param row
     * @param columnMap
     * @return
     */
    private ProcessedRefundRow getRowEntry(String[] row, Map<Integer, Enum<Column>> columnMap) {
        ProcessedRefundRow entry = new ProcessedRefundRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case GROSS_AMT:
                    entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case BANK_TXN_ID:
                    entry.setBankTxnId(canBankTxnIdStartWithZero() ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                default:
                    break;
                }
            }
        }

        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        entry.setRrn("0");
        entry.setNeftNo(0.0);
        entry.setMerchantCode("0");
        entry.setStatus(SUCCESS);
        entry.setTxnAmount(0.0);
        return entry;
    }

    /**
     * Gets RRN from secondary file
     * 
     * @param reconAdapter
     * @param row
     * @param columnMapRRN
     * @return
     */
    private String[] getRowEntryRRN(String[] row, Map<Integer, Enum<Column>> columnMapRRN) {
        String[] entry = new String[2];
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            if (columnMapRRN.containsKey(columnIndex)) {
                switch ((Column) columnMapRRN.get(columnIndex)) {
                case TXN_ID:
                    entry[0] = AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell));
                    break;
                case RRN:
                    entry[1] = AdapterUtil.setZeroIfBlank(AdapterUtil.checkApostrophe(cell));
                    break;
                default:
                    break;
                }
            }
        }
        return entry;
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    public void logMap(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            LOGGER.info("key " + entry.getKey() + " = value " + entry.getValue());
        }
    }

    public int getColumnNumberRRN(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.RRN.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }
}
