package com.paytm.pgplus.barfi.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.hibernate.validator.constraints.NotBlank;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "edc_banks_batch_upload")
public class EdcHdfcBatchUpload {
    @Column(name = "processing_code")
    @NotBlank(message = "processing code should not be blank")
    private String processingCode;

    @Column(name = "transaction_amount")
    @NotBlank(message = "Amount must not be blank")
    private String transactionAmount;

    @Column(name = "stan")
    @NotBlank(message = "stan should not be blank")
    private String stan;

    @Column(name = "transaction_time")
    @NotBlank(message = "transactionTime must not be blank")
    private String transactionTime;

    @Column(name = "transaction_date")
    @NotBlank(message = "transactionDate must not be blank")
    private String transactionDate;

    @Column(name = "pos_entry_mode")
    @NotBlank(message = "pos entry mode must not be blank")
    private String posEntryMode;

    @Column(name = "pos_condition_code")
    @NotBlank(message = "pos condition code must not be blank")
    private String posConditionCode;

    @Column(name = "rrn_code")
    @NotBlank(message = "rrnCode code must not be blank")
    private String rrnCode;

    @Column(name = "auth_code")
    @NotBlank(message = "authorizationCode code must not be blank")
    private String authCode;

    @Column(name = "result_code")
    private String resultCode;

    @Column(name = "result_code_id")
    private String resultCodeId;

    @Column(name = "result_msg")
    private String resultMsg;

    @Column(name = "bank_tid")
    @NotBlank(message = "terminal id must not be blank")
    private String bankTid;

    @Column(name = "mbid")
    @NotBlank(message = "bank merchant id must not be blank")
    private String mbid;

    @Column(name = "icc_data")
    private String iccData;

    @Column(name = "invoice_number")
    @NotBlank(message = "Invoice Number must not be blank")
    private String invoiceNumber;

    @Column(name = "pay_method")
    private String payMethod;

    @Column(name = "external_serial_no")
    @NotBlank(message = "external_serial_no id must not be blank")
    private String externalSerialNo;

    @Column(name = "service_inst_id")
    @NotBlank(message = "service_inst_id id must not be blank")
    private String serviceInstId;

    @Column(name = "bank_abbr")
    private String bankAbbr;

    @Id
    @Column(name = "merchant_trans_id")
    @NotBlank(message = "merchant_trans_id id must not be blank")
    private String merchantTransId;

    @Column(name = "transaction_type")
    @NotBlank(message = "transaction_type must not be blank")
    private String TransactionType;

    @Column(name = "bank_code")
    @NotBlank(message = "bank_code must not be blank")
    private String bankcode;

    @Column(name = "txn_time")
    @NotBlank(message = "txn_time must not be blank")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Kolkata")
    private String txnTime;

    @Column(name = "txn_upload_status")
    private String txnUploadStatus;

}
