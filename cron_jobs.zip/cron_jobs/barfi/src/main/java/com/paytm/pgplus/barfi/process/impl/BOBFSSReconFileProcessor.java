package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.exception.PaytmBarfiException;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

@Component(value = "BOBFSSBankCardReconFileProcessor")
public class BOBFSSReconFileProcessor implements Processable, XLSProcessor {

    private static final Logger LOGGER = LogManager.getLogger(BOBFSSReconFileProcessor.class);

    private static final String DELIMITER = "\\|+";
    private static final String COLHEAD = "Transaction Date";
    private static final String CHARGING = "Purchase";
    private static final String REFUND = "Credit";
    private static final String CAPTURE_TRANSACTION = "CAPTURED";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("Transaction Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("Merchant Track ID", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("Reference Transaction ID", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("Transaction Type", ReconFileAdapter.Column.TXN_TYPE);
        reconMap.put("Result Code", ReconFileAdapter.Column.RESULT_CODE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = getColumnNumberResultCode(columnMap);
        int resultCodeColumn = getColumnNumberResultCode(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }

                String resultCode = getResultCode(resultCodeColumn, row);
                if (!resultCode.equals(CAPTURE_TRANSACTION)) {
                    continue;
                }
                if (reconAdapter.getTxnType(getColumnNumberTxnType(columnMap), row).equals(REFUND)) {
                    reconAdapter.setRefundValues(row, columnMap, canBankTxnIdStartWithZero());
                } else if (reconAdapter.getTxnType(getColumnNumberTxnType(columnMap), row).equals(CHARGING)) {
                    reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    private String getResultCode(int colNo, String[] row) {
        return AdapterUtil.removeQuotes(row[colNo]).trim();
    }

    private int getColumnNumberResultCode(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.RESULT_CODE.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    private int getColumnNumberTxnType(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.TXN_TYPE.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    @Override
    public Map<Integer, Enum<ReconFileAdapter.Column>> mapColumns(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<String, Enum<ReconFileAdapter.Column>> reconMap, String delimiter, String colHead) throws IOException,
            PaytmBarfiException {

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
        for (String r : csvList) {
            if (StringUtils.isBlank(r)) {
                continue;
            }
            String[] row = r.split(delimiter);
            if (row.length == 0) {
                continue;
            }
            if (row.length < 2) {
                continue;
            }
            row[0] = AdapterUtil.removeQuotes(row[0]).trim();
            row[1] = AdapterUtil.removeQuotes(row[1]).trim();
            if (!(row[0].equals(colHead) || row[1].equals(colHead))) {
                continue;
            }
            for (int columnNo = 0; columnNo < row.length; columnNo++) {
                if (StringUtils.isBlank(row[columnNo])) {
                    continue;
                }
                row[columnNo] = AdapterUtil.removeQuotes(row[columnNo]);
                if (reconMap.containsKey(row[columnNo].trim())) {
                    columnMap.put(columnNo, reconMap.get(row[columnNo].trim()));
                }
            }
            break;
        }
        if (MapUtils.isEmpty(columnMap)) {
            throw new PaytmBarfiException(" Exception   " + " File '{}' - Process Failed due to missing column heads  ");
        }
        return columnMap;
    }

}
