/**
 *
 */
package com.paytm.pgplus.barfi.queue.service;

public interface IProducer {

    void push(String key, Object payload);

}
