package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.FileUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ZipUtil;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.util.*;

import static com.paytm.pgplus.barfi.util.AdapterConstants.*;

@Component(value = "CITIReconFileProcessorV2")
public class CitiReconFileProcessorV2 implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(CitiReconFileProcessorV2.class);

    private static final String DELIMITER = ",";
    private static final String COLHEAD = "ME_CODE";
    private static final String DELIMITERRRN = ",";
    private static final String COLHEADRRN = "ME_CODE";
    private static final String ARN = "ARN";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMapRRN = new HashMap<>();

    static {
        reconMap.put("GROSS_AMT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("ORDER_NO", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("AUTH_CODE", ReconFileAdapter.Column.BANK_TXN_ID);

        reconMapRRN.put("ACQREF_NUM", ReconFileAdapter.Column.RRN);
        reconMapRRN.put("ORDER_NO", ReconFileAdapter.Column.TXN_ID);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        File folder = null;
        List<String> misList;
        List<String> arnList;

        List<File> misFileList = new ArrayList<File>();
        List<File> arnFileList = new ArrayList<File>();

        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMapRRN;

        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            ZipUtil.extractZip(adapter.processingDestination, adapter.fileParentPath + SLASH + PROCESSING_TEMP);
            folder = new File(FilenameUtils.removeExtension(adapter.processingDestination));
            File[] listOfFiles = folder.listFiles();
            for (int i = 0; i < listOfFiles.length; i++) {
                if (listOfFiles[i].isFile() && listOfFiles[i].getName().split("_")[0].equals(ARN)) {
                    arnFileList.add(listOfFiles[i]);
                } else {
                    misFileList.add(listOfFiles[i]);
                }
            }
            misList = prepareMisList(misFileList);
            arnList = prepareArnList(arnFileList);
            LOGGER.info("Number of records received : MIS file - {} ARN file - {}", misList.size(), arnList.size());

            columnMap = columnNameToTxnIdMap(adapter, misList, reconMap, DELIMITER, COLHEAD);
            columnMapRRN = columnNameToTxnIdMap(adapter, arnList, reconMapRRN, DELIMITERRRN, COLHEADRRN);
            parseAndWrite(adapter, misList, arnList, columnMap, columnMapRRN, DELIMITER, DELIMITERRRN);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        } finally {
            FileUtil.deleteFolder(folder);
        }
    }

    private List<String> prepareArnList(List<File> arnFileList) throws IOException {
        List<String> arnList = new ArrayList<String>();
        int i = 0;
        try {
            for (i = 0; i < arnFileList.size(); i++) {
                arnList.addAll(extractData(arnFileList.get(i)));
            }
        } catch (IOException ex) {
            throw new IOException("Error occurred while extracting data from " + arnFileList.get(i) + " File", ex);
        }

        return arnList;
    }

    private List<String> prepareMisList(List<File> misFileList) throws IOException {
        List<String> misList = new ArrayList<String>();
        int i = 0;
        try {
            for (i = 0; i < misFileList.size(); i++) {
                misList.addAll(extractData(misFileList.get(i)));
            }
        } catch (IOException ex) {
            throw new IOException("Error occurred while extracting data from " + misFileList.get(i) + " File", ex);
        }
        return misList;
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList, List<String> csvListRRN,
            Map<Enum<ReconFileAdapter.Column>, Integer> columnMap,
            Map<Enum<ReconFileAdapter.Column>, Integer> columnMapRRN, String delimiter, String delimiterRRN)
            throws Exception {
        int rowNum = 0;
        try {
            HashMap<String, List<ProcessedRefundRow>> refundMap = new HashMap<>();

            int highestKey = getHighestValue(columnMap);
            int colNo = columnMap.get(ReconFileAdapter.Column.GROSS_AMT);
            int colNoTxnId = columnMap.get(ReconFileAdapter.Column.TXN_ID);
            int rowEnd = csvList.size();

            for (rowNum = 0; rowNum < rowEnd; rowNum++) {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                String amount = reconAdapter.getTxnType(colNo, row);
                String txnId = reconAdapter.getTxnType(colNoTxnId, row);

                if (StringUtils.isBlank(r) || row.length <= highestKey
                        || !NumberUtils.isParsable(amount.startsWith("+") ? amount.substring(1) : amount)
                        || !NumberUtils.isParsable(txnId)) {
                    continue;
                }

                if (amount.startsWith("-")) {
                    ProcessedRefundRow entry = getRowEntry(row, columnMap);

                    List<ProcessedRefundRow> entryList = refundMap.get(entry.getTxnId());
                    if (entryList == null) {
                        entryList = new LinkedList<>();
                        refundMap.put(entry.getTxnId(), entryList);
                    }
                    entryList.add(entry);

                } else if (amount.startsWith("+")) {
                    reconAdapter.setChargingValuesColumnIntegerMap(row, columnMap, canBankTxnIdStartWithZero());
                }
            }

            highestKey = getHighestValue(columnMapRRN);
            colNo = columnMapRRN.get(ReconFileAdapter.Column.RRN);
            colNoTxnId = columnMapRRN.get(ReconFileAdapter.Column.TXN_ID);
            rowEnd = csvListRRN.size();

            for (rowNum = 0; rowNum < rowEnd; rowNum++) {
                String r = csvListRRN.get(rowNum);
                String[] row = r.split(delimiterRRN);

                if (StringUtils.isBlank(r) || row.length <= highestKey
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNoTxnId, row))) {
                    continue;
                }

                String transactionId = AdapterUtil.stripLeadingZeros(filter(row[colNoTxnId]));
                String rrn = AdapterUtil.setZeroIfBlank(filter(row[colNo]));

                if (refundMap.get(transactionId) != null) {
                    List<ProcessedRefundRow> entryList = refundMap.get(transactionId);
                    for (ProcessedRefundRow element : entryList) {
                        if ("0".equalsIgnoreCase(element.getRrn())) {
                            element.setRrn(rrn);
                        }
                    }
                }
            }

            for (Map.Entry<String, List<ProcessedRefundRow>> entry : refundMap.entrySet()) {
                for (ProcessedRefundRow element : entry.getValue()) {
                    reconAdapter.refundWriteData(element);
                }
            }
        } catch (Exception e) {
            throw new Exception("File " + reconAdapter.fileName + " parsing error at " + rowNum, e);
        }
    }

    private String filter(String value) {
        return AdapterUtil.checkApostrophe(AdapterUtil.removeQuotes(value).trim());
    }

    private ProcessedRefundRow getRowEntry(String[] row, Map<Enum<ReconFileAdapter.Column>, Integer> columnMap) {
        ProcessedRefundRow entry = new ProcessedRefundRow();
        for (Map.Entry<Enum<ReconFileAdapter.Column>, Integer> mapEntry : columnMap.entrySet()) {
            int columnIndex = mapEntry.getValue();
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            switch ((ReconFileAdapter.Column) mapEntry.getKey()) {
            case GROSS_AMT:
                entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                break;
            case TXN_ID:
                entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                break;
            case BANK_TXN_ID:
                entry.setBankTxnId(canBankTxnIdStartWithZero() ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                        .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                break;
            default:
                break;
            }
        }
        if (StringUtils.isBlank(entry.getBankTxnId())) {
            entry.setBankTxnId("0");
        }
        entry.setRrn("0");
        entry.setNeftNo(0.0);
        entry.setMerchantCode("0");
        entry.setStatus(SUCCESS);
        entry.setTxnAmount(0.0);
        return entry;
    }

}