package com.paytm.pgplus.barfi.dao;

import com.paytm.pgplus.barfi.model.BankMaster;

import java.util.List;
import java.util.Set;

/**
 * @author Sakshi Jain
 */

public interface IBankMasterDao extends IBaseDao<BankMaster, Integer> {

    List<BankMaster> fetchBankMasterList(Set<String> bankCode);
}
