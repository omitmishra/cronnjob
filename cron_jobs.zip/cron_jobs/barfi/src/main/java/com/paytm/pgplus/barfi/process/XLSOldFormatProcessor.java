package com.paytm.pgplus.barfi.process;

import com.paytm.pgplus.barfi.model.*;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public interface XLSOldFormatProcessor extends FileProcessor {

    static final Logger LOGGER = LogManager.getLogger(XLSOldFormatProcessor.class);

    /**
     * using XLSReader to extract data from the file. Should only be used when
     * the file is in XLS format before 2003
     * 
     * @param File
     *            Unprocessed file directly from bank
     * @return List of Strings extracted data from file in list form
     */
    public default List<String> extractData(File file) throws IOException {

        List<String> csvList = new ArrayList<String>();
        if (!file.exists()) {
            LOGGER.error("Not found or not a file: {}", file.getPath());
        }

        String str = FileUtils.readFileToString(file);
        Workbook workbook = ParseXML.parseXML(str, Workbook.class);
        List<Row> rows = workbook.getWorksheet().getTable().getRows();
        for (Row r : rows) {
            List<Cell> columns = r.getCells();
            StringBuilder sb = new StringBuilder();
            for (Cell c : columns) {

                sb.append(c.getData().get()).append(",");
            }
            csvList.add(sb.substring(0, sb.length() - 1).toString());
        }
        return csvList;
    }
}