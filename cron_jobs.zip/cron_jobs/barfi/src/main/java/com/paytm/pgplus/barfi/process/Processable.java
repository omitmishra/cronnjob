package com.paytm.pgplus.barfi.process;

import com.paytm.pgplus.barfi.util.ReconFileAdapter;

/**
 * @author Lalit Mehra
 * @since October 3, 2016
 *
 */

public interface Processable {

    /**
     * Parses the file received from the Bank. <br>
     * Parsing algorithm can be distinct and specific to a single bank only. In
     * such cases it is advisable to setup a different implementation specific
     * to that Bank only.
     * 
     * @param adapter
     *            Information Processed from the File received from the Bank
     */

    public void process(ReconFileAdapter adapter);

}
