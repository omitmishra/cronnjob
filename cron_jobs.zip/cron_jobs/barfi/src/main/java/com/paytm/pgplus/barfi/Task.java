package com.paytm.pgplus.barfi;

import java.io.File;
import java.io.FileNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ApplicationContextProvider;
import com.paytm.pgplus.barfi.util.ProcessorBean;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

import freemarker.template.Template;

/**
 * Executable Task for Bank Reconciliation File Automation
 * 
 * @author Lalit Mehra
 *
 */
public class Task implements Runnable {

    private static final Logger LOGGER = LogManager.getLogger(Task.class);
    private ReconFileAdapter adapter;
    private String bankCode;

    public Task(File file, Template template) throws FileNotFoundException {

        this.adapter = new ReconFileAdapter(file, template);
        this.bankCode = adapter.getBeanName();
    }

    @Override
    public void run() {

        LOGGER.info("Task Submitted for Bank: {}", bankCode);
        try {
            Processable worker = (Processable) ApplicationContextProvider.getApplicationContext().getBean(
                    ProcessorBean.valueOf(bankCode).getBean());
            worker.process(adapter);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Bank not supported");
        }
    }

}
