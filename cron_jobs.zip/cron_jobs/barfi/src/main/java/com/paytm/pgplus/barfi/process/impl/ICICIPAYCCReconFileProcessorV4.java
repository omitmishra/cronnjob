package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import com.paytm.pgplus.barfi.util.ReloadableProperties;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * @author Ashu Vaidwan
 *
 */
@Component(value = "ICICIPAYBankCardReconFileProcessorV4")
public class ICICIPAYCCReconFileProcessorV4 extends ICICICCReconFileProcessorV4 {

    private static final List NET_AMOUNT_TERMINAL_IDS = ReloadableProperties.getInstance().getList(
            "icici.net.amount.terminal.ids");

    /**
     * Remove unmatched records in given list in the form of {@link List
     * <String>}
     * 
     * @param csvList
     * @param columnMap
     * @return matching records in the form of {@link List}
     */
    @Override
    protected List<String> removeUnmatched(List<String> csvList, Map<Integer, Enum<Column>> columnMap) {

        int idenfierColIndex = -1;
        for (Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.BANK_TXN_ID.equals(entry.getValue())) {
                idenfierColIndex = entry.getKey();
                break;
            }
        }

        List<String> matchingRecordList = new ArrayList<>();
        for (int i = 0; i < csvList.size(); i++) {

            matchingRecordList.add(csvList.get(i));
            String rowData = csvList.get(i);

            if (StringUtils.isBlank(rowData)) {
                continue;
            }
            String[] row = rowData.split(DELIMITER);
            if (row.length == 0) {
                continue;
            }
            row[0] = AdapterUtil.removeQuotes(row[0]);
            if (!row[0].equals(COLHEAD)) {
                continue;
            }

            for (int j = i + 1; j < csvList.size(); j++) {
                rowData = csvList.get(j);
                row = rowData.split(DELIMITER);

                if (row.length > idenfierColIndex && !StringUtils.isBlank(row[idenfierColIndex])) {
                    String val = AdapterUtil.removeQuotes(row[idenfierColIndex]).trim();
                    val = StringUtils.stripStart(val, "0");
                    if (RECORD_IDENTIFIER_LENGTH.equals(val.length())) {
                        matchingRecordList.add(csvList.get(j));
                    }
                }
            }
            break;
        }
        return matchingRecordList;
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter, String charging, String refund) throws Exception {

        int colNo = reconAdapter.getColumnNumberDRCR(columnMap);
        int colNoGrossAmount = reconAdapter.getColumnNumberAmount(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }

                /*
                 * JIRA: PGP-25735 hack to use Net Amount for specific terminal
                 * ids provided in properties
                 */

                if (CollectionUtils.isNotEmpty(NET_AMOUNT_TERMINAL_IDS)) {
                    int columnNumberForTerminalId = getColumnNumberTerminalId(columnMap);
                    if (columnNumberForTerminalId >= 0 && columnNumberForTerminalId < row.length) {
                        String rowTerminalId = row[columnNumberForTerminalId];

                        if (NET_AMOUNT_TERMINAL_IDS.contains(AdapterUtil.removeQuotes(rowTerminalId))) {
                            int columnNumberForNetAmount = getColumnNumberNetAmount(columnMap);

                            if (columnNumberForNetAmount >= 0 && columnNumberForNetAmount < row.length) {
                                // use an alternative map, as changing existing
                                // map will go for all rows
                                Map<Integer, Enum<Column>> alternativeColumnMap = new HashMap<>(columnMap);

                                // remove existing entry for GROSS_AMT column
                                alternativeColumnMap.remove(colNoGrossAmount);

                                // update GROSS_AMT column key, use NET_AMT
                                // column for this row
                                alternativeColumnMap.put(columnNumberForNetAmount, Column.GROSS_AMT);

                                if (refund.equalsIgnoreCase(reconAdapter.getTxnType(colNo, row))) {
                                    setRefundValues(reconAdapter, row, alternativeColumnMap,
                                            canBankTxnIdStartWithZero());
                                }
                                if (charging.equalsIgnoreCase(reconAdapter.getTxnType(colNo, row))) {
                                    setChargingValues(reconAdapter, row, alternativeColumnMap,
                                            canBankTxnIdStartWithZero());
                                }

                                // continue loop over for other rows
                                continue;
                            }
                        }
                    }
                }

                if (refund.equalsIgnoreCase(reconAdapter.getTxnType(colNo, row))) {
                    setRefundValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
                }
                if (charging.equalsIgnoreCase(reconAdapter.getTxnType(colNo, row))) {
                    setChargingValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
                }

            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    private int getColumnNumberTerminalId(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.TERMINAL_CODE.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    private int getColumnNumberNetAmount(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.NET_AMT.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }
}