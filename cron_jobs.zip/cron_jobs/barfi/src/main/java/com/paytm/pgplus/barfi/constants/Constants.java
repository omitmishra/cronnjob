package com.paytm.pgplus.barfi.constants;

public class Constants {
    public static final String PAYTM_CHARGING = "PAYTM_CHARGING";
    public static final String PAYTM_REFUND = "PAYTM_REFUND";
    public static final String PAYTM_CHARGEBACK = "PAYTM_CHARGEBACK";
    public static final String PIPE = "|";
    public static final String EXT_SERIAL_NO = "extSerialNo";
}
