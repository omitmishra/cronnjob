package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.exception.PaytmBarfiException;
import com.paytm.pgplus.barfi.process.RupayProcessable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.service.RupayBinFileProcessorHelper;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.RupayFileAdapter;
import com.paytm.pgplus.barfi.vo.ProcessedRupayRow;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author Sakshi Jain
 */

@Component(value = "RupayBinFileProcessor")
public class RupayBinFileProcessor implements RupayProcessable, XLSXProcessor {
    private static final Logger LOGGER = LogManager.getLogger(RupayBinFileProcessor.class);

    @Autowired
    private RupayBinFileProcessorHelper rupayBinFileProcessorHelper;

    private static final String DELIMITER = "\\|";
    private static final String SKIPPED_ROWS_DELIMETER = ",";
    private static final String COLHEAD = "Participant ID";
    private static final String CAPTURE_SCHEME_CODE_01 = "01";
    private static final String CAPTURE_SCHEME_CODE_1 = "1";
    private static Map<String, Enum<RupayFileAdapter.Column>> rupayMap = new HashMap<>();

    static {
        rupayMap.put(COLHEAD, RupayFileAdapter.Column.PARTICIPANT_INITIALS);
        rupayMap.put("BIN Low value", RupayFileAdapter.Column.BIN_LOW);
        rupayMap.put("BIN High Value", RupayFileAdapter.Column.BIN_HIGH);
        rupayMap.put("Card Type", RupayFileAdapter.Column.CARD_TYPE);
        rupayMap.put("BIN Country Code", RupayFileAdapter.Column.IS_INDIAN);
        rupayMap.put("Scheme Code", RupayFileAdapter.Column.SCHEME_CODE);
        rupayMap.put("Status Flag", RupayFileAdapter.Column.IS_ACTIVE);
    }

    /**
     * @param adapter
     *            RupayFileAdapter
     */
    @Override
    public void process(RupayFileAdapter adapter) {

        List<String> csvList;
        Map<Integer, Enum<RupayFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {} is ready to be processed", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, rupayMap);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("Data extraction from file '{}' is successful", adapter.fileName);

            LOGGER.info("Initiating database updation operations");
            updateBinDetails(adapter);
            if (adapter.failureList.isEmpty()) {
                adapter.markSuccess();
            } else {
                adapter.markFail("Some records failed to process");
            }
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    /**
     * @param rupayAdapter
     *            RupayFileAdapter
     * @param csvList
     *            List<String>
     * @param columnMap
     *            Map<Integer, Enum<RupayFileAdapter.Column>>
     * @param delimiter
     *            String
     * @throws PaytmBarfiException
     *             if parsing error is encountered
     */
    public void parseAndWrite(RupayFileAdapter rupayAdapter, List<String> csvList,
            Map<Integer, Enum<RupayFileAdapter.Column>> columnMap, String delimiter) throws PaytmBarfiException {

        int schemeCodeColNo = getColumnNumberSchemeCode(columnMap);
        for (int rowNum = 0; rowNum < csvList.size(); rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (rowNum == 0) {
                    skipRupayRow(rupayAdapter, rowNum, row, null);
                    continue;
                }
                if (StringUtils.isBlank(r) || row.length <= rupayMap.size() || row.length <= schemeCodeColNo) {
                    skipRupayRow(rupayAdapter, rowNum, row, "Blank row");
                    continue;
                }
                String resultCode = getSchemeCode(schemeCodeColNo, row);
                if (resultCode.equals(CAPTURE_SCHEME_CODE_01) || resultCode.equals(CAPTURE_SCHEME_CODE_1)) {
                    setRupayRowListData(rupayAdapter, row, columnMap, rowNum);
                } else {
                    skipRupayRow(rupayAdapter, rowNum, row, "Invalid SCHEME_CODE");
                }
            } catch (Exception e) {
                LOGGER.error("File " + rupayAdapter.fileName + " parsing error at line " + rowNum, e);
                throw new PaytmBarfiException("File " + rupayAdapter.fileName + " parsing error at line " + rowNum);
            }
        }
    }

    public void skipRupayRow(RupayFileAdapter rupayAdapter, int rowNum, String[] row, String error) {
        if (rowNum == 0) {
            LOGGER.info("Header rownum: {} row : {}", rowNum, row);
            rupayAdapter.rupayRowListHeader = String.join(SKIPPED_ROWS_DELIMETER, row);
            return;
        }
        LOGGER.error("Failed to parse rownum: {} row : {} Error : {}", rowNum, row, error);
        error = Objects.isNull(error) ? "" : error;
        rupayAdapter.skippedRupayRows.add(String.join(SKIPPED_ROWS_DELIMETER, row).concat("," + error));
    }

    /**
     * @param rupayAdapter
     *            RupayFileAdapter
     * @param row
     *            String[]
     * @param columnMap
     *            Map<Integer, Enum<RupayFileAdapter.Column>>
     */
    private void setRupayRowListData(RupayFileAdapter rupayAdapter, String[] row,
            Map<Integer, Enum<RupayFileAdapter.Column>> columnMap, int rowNum) {
        ProcessedRupayRow entry = new ProcessedRupayRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (!StringUtils.isBlank(cell)) {
                cell = cell.trim();
            }
            if (columnMap.containsKey(columnIndex)) {
                // Ignore the row if it has blank value in required/mandatory
                // column
                RupayFileAdapter.Column colVal = (RupayFileAdapter.Column) columnMap.get(columnIndex);
                if (StringUtils.isBlank(cell)) {
                    skipRupayRow(rupayAdapter, rowNum, row, "Blank mandatory column " + colVal.toString());
                    return;
                }

                setResolvedRowValues(entry, colVal, cell);
            }
        }
        entry.setBinLength(validateBINLength(entry.getBinLow(), entry.getBinHigh()));
        if (entry.getBinLength() != -1 && !entry.getCardType().equalsIgnoreCase("INVALID CARD TYPE")) {
            entry.setBin(findBin(entry.getBinLength(), entry.getBinLow()));
            rupayAdapter.rupayRowList.add(entry);
        } else if (entry.getBinLength() == -1) {
            skipRupayRow(rupayAdapter, rowNum, row, "Invalid Bin");
        } else {
            skipRupayRow(rupayAdapter, rowNum, row, "INVALID CARD TYPE");
        }
    }

    /**
     * @param binLength
     *            int
     * @param binLow
     *            String
     * @return Bin
     */
    private int findBin(int binLength, String binLow) {
        if (binLength == 6)
            return Integer.parseInt(binLow.substring(0, 6));
        else
            return Integer.parseInt(binLow.substring(0, 8));
    }

    /**
     * @param binLow
     *            String
     * @param binHigh
     *            String
     * @return Bin length if valid; otherwise -1
     */
    private int validateBINLength(String binLow, String binHigh) {
        if (binLow.length() == 9 && binHigh.length() == 9) {
            String binLowInitial8 = binLow.substring(0, 8);
            String binHighInitial8 = binHigh.substring(0, 8);
            if (binLowInitial8.equalsIgnoreCase(binHighInitial8))
                return 8;
            else {
                String binLowInitial6 = binLow.substring(0, 6);
                String binHighInitial6 = binHigh.substring(0, 6);
                if (binLowInitial6.equalsIgnoreCase(binHighInitial6))
                    return 6;
            }
        }
        return -1;
    }

    /**
     * @param participantId
     *            String
     * @return IFSC code
     */
    private String getIFSCCode(String participantId) {
        return participantId.substring(0, 4);
    }

    /**
     * @param type
     *            String
     * @return Card type
     */
    private static String getCardType(String type) {
        switch (Integer.parseInt(type)) {
        case 1:
            return "DEBIT_CARD";
        case 2:
            return "CREDIT_CARD";
        case 3:
            return "PREPAID_CARD";
        default:
            return "INVALID CARD TYPE";
        }
    }

    /**
     * @param countryCode
     *            String
     * @return IsIndian flag as 1 or 0
     */
    private static Integer getIsIndian(String countryCode) {
        return countryCode.equalsIgnoreCase("IN") ? 1 : 0;
    }

    /**
     * @param statusCode
     *            String
     * @return IsActive flag as 1 or 0
     */
    private static Integer getIsActive(String statusCode) {
        return statusCode.equalsIgnoreCase("D") ? 0 : 1;
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    /**
     * @param colNo
     *            int
     * @param row
     *            String[]
     * @return Scheme code
     */
    private String getSchemeCode(int colNo, String[] row) {
        return AdapterUtil.removeQuotes(row[colNo]).trim();
    }

    /**
     * @param columnMap
     *            Map<Integer, Enum<RupayFileAdapter.Column>>
     * @return Column number of Scheme code if found; otherwise -1
     */
    private int getColumnNumberSchemeCode(Map<Integer, Enum<RupayFileAdapter.Column>> columnMap) {
        for (Map.Entry<Integer, Enum<RupayFileAdapter.Column>> entry : columnMap.entrySet()) {
            if (RupayFileAdapter.Column.SCHEME_CODE.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

    /**
     * @param adapter
     *            RupayFileAdapter
     * @throws PaytmBarfiException
     *             if database operation fails
     */
    private void updateBinDetails(RupayFileAdapter adapter) throws PaytmBarfiException {
        try {
            if (!adapter.rupayRowList.isEmpty()) {
                rupayBinFileProcessorHelper.updateBinDetails(adapter);
            } else {
                LOGGER.info("No data found for updation");
            }
        } catch (Exception e) {
            LOGGER.error("Error in database operation" + e.getMessage());
            throw new PaytmBarfiException("Error in database operation" + e.getMessage());
        }
    }

    /**
     * @param entry
     *            ProcessedRupayRow
     * @param colVal
     *            RupayFileAdapter.Column
     * @param cell
     *            String
     */
    private void setResolvedRowValues(ProcessedRupayRow entry, RupayFileAdapter.Column colVal, String cell) {
        switch (colVal) {
        case PARTICIPANT_INITIALS:
            entry.setParticipantIdInitials(getIFSCCode(AdapterUtil.checkApostrophe(cell)));
            break;
        case BIN_LOW:
            entry.setBinLow(AdapterUtil.checkApostrophe(cell));
            break;
        case BIN_HIGH:
            entry.setBinHigh(AdapterUtil.checkApostrophe(cell));
            break;
        case CARD_TYPE:
            entry.setCardType(getCardType(AdapterUtil.checkApostrophe(cell)));
            break;
        case SCHEME_CODE:
            entry.setSchemeCode(AdapterUtil.checkApostrophe(cell));
            break;
        case IS_INDIAN:
            entry.setIsIndian(getIsIndian(AdapterUtil.checkApostrophe(cell)));
            break;
        case IS_ACTIVE:
            entry.setIsActive(getIsActive(AdapterUtil.checkApostrophe(cell)));
            break;
        default:
            break;
        }
    }

    /**
     * Maps the column titles to their respective indices in the processed row.
     *
     * @param rupayFileAdapter
     *            RupayFileAdapter
     * @param csvList
     *            List<String>
     * @param rupayMap
     *            Map<String, Enum<RupayFileAdapter.Column>>
     * @return Map of column titles
     * @throws PaytmBarfiException
     *             thrown in case column heads don't match
     */
    private Map<Integer, Enum<RupayFileAdapter.Column>> mapColumns(RupayFileAdapter rupayFileAdapter,
            List<String> csvList, Map<String, Enum<RupayFileAdapter.Column>> rupayMap) throws PaytmBarfiException {

        Map<Integer, Enum<RupayFileAdapter.Column>> columnMap = new HashMap<>();
        for (String r : csvList) {
            if (StringUtils.isBlank(r)) {
                continue;
            }
            String[] row = r.split(DELIMITER);
            if (row.length == 0) {
                continue;
            }
            row[0] = AdapterUtil.removeQuotes(row[0]).trim();
            if (!row[0].equals(COLHEAD)) {
                continue;
            }
            for (int columnNo = 0; columnNo < row.length; columnNo++) {
                if (StringUtils.isBlank(row[columnNo])) {
                    continue;
                }
                row[columnNo] = AdapterUtil.removeQuotes(row[columnNo]);
                if (rupayMap.containsKey(row[columnNo].trim())) {
                    columnMap.put(columnNo, rupayMap.get(row[columnNo].trim()));
                }
            }
            break;
        }
        if (MapUtils.isEmpty(columnMap)) {
            throw new PaytmBarfiException(" Exception - Process Failed due to missing column heads,  File- "
                    + rupayFileAdapter.fileName);
        }
        return columnMap;
    }
}