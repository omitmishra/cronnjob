package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

/**
 * @author Agrim
 * @author Shubham
 *
 */

@Component(value = "SBIBankCardReconFileProcessor")
public class SBICCReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(SBICCReconFileProcessor.class);

    private static final String DELIMITER = ",";
    private static final String COLHEAD = "SUPERMERCHANT_ID";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();
    private static Map<Enum<ReconFileAdapter.Column>, Boolean> costParamMap = new HashMap<>();

    static {

        reconMap.put("GROSS_AMT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("MERCHANT_TXNNO", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("EPG_TXN_REFNO", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("ARN", ReconFileAdapter.Column.RRN);

        reconMap.put("MDR", ReconFileAdapter.Column.BANK_COMMISSION);
        reconMap.put("MGI_ITCH_NAME", ReconFileAdapter.Column.BANK_CARDSCHEME);
        reconMap.put("MAP_PAYM_NAME", ReconFileAdapter.Column.CARD_TYPE);
        reconMap.put("MERCHANT_ID", ReconFileAdapter.Column.MERCHANT_CODE);
        reconMap.put("TERMINAL_ID", ReconFileAdapter.Column.TERMINAL_CODE);
        reconMap.put("TXN_CURR", ReconFileAdapter.Column.TXN_CURR);
        reconMap.put("ONUS_INDC", ReconFileAdapter.Column.ONUS_INDC);

        costParamMap.put(ReconFileAdapter.Column.BANK_COMMISSION, true);
        costParamMap.put(ReconFileAdapter.Column.BANK_CARDSCHEME, true);
        costParamMap.put(ReconFileAdapter.Column.CARD_TYPE, true);
        costParamMap.put(ReconFileAdapter.Column.MERCHANT_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.TERMINAL_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.TXN_CURR, true);
        costParamMap.put(ReconFileAdapter.Column.ONUS_INDC, true);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                if (reconAdapter.getTxnType(colNo, row).startsWith("-")) {
                    setRefundValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
                } else {
                    setChargingValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    public void setRefundValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        DecimalFormat df = new DecimalFormat("#.####");
        DecimalFormat df1 = new DecimalFormat("#.##");
        boolean costFieldError = false;
        Double MDR = 0.0;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();

                    if (columnMap.containsKey(columnIndex)) {
                        switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                        case RRN:
                            entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                                    .checkApostrophe(cell))));
                            break;
                        case GROSS_AMT:
                            Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_COMMISSION:
                            MDR = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                            break;
                        case BANK_CARDSCHEME:
                            entry.setBankCardScheme(AdapterUtil.checkApostrophe(cell));
                            break;
                        case CARD_TYPE:
                            entry.setBankCardType(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TERMINAL_CODE:
                            entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TXN_CURR:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;
                        case ONUS_INDC:
                            entry.setOnusIndicator(AdapterUtil.checkApostrophe(cell));
                            break;

                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }

            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRrn())) {
                entry.setRrn("0");
            }
            if (entry.getRefundAmount() < 2000.0)
                entry.setBankComissionAmount(MDR);
            else
                entry.setBankComissionAmount(new Double(df1.format(MDR / (1.18))));

            if (entry.getRefundAmount() < 2000.0)
                entry.setBankGST(0.0);
            else
                entry.setBankGST(new Double(df1.format((MDR) - (MDR / (1.18)))));
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getRefundAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            entry.setNeftNo(0.0);
            entry.setStatus(SUCCESS);
            entry.setTxnAmount(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setRefundValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForRefund(entry);
        reconAdapter.refundWriteData(entry);
    }

    private void setChargingValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        DecimalFormat df = new DecimalFormat("#.####");
        DecimalFormat df1 = new DecimalFormat("#.##");
        Double intnlAmount = 0.0;
        Double MDR = 0.0;
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();
                    if (columnMap.containsKey(columnIndex)) {
                        switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                        case GROSS_AMT:
                            intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case AUTH_CODE:
                            entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case RRN:
                            entry.setRRN(AdapterUtil.checkApostrophe(cell));
                            break;
                        case BANK_COMMISSION:
                            MDR = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                            break;
                        case BANK_CARDSCHEME:
                            entry.setBankCardScheme(AdapterUtil.checkApostrophe(cell));
                            break;
                        case CARD_TYPE:
                            entry.setBankCardType(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TERMINAL_CODE:
                            entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TXN_CURR:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;
                        case ONUS_INDC:
                            entry.setOnusIndicator(AdapterUtil.checkApostrophe(cell));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (StringUtils.isBlank(entry.getAuthCode())) {
                entry.setAuthCode("0");
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRRN())) {
                entry.setRRN("0");
            }
            if (entry.getGrossAmount() < 2000.0)
                entry.setBankComissionAmount(MDR);
            else
                entry.setBankComissionAmount(new Double(df1.format(MDR / (1.18))));

            if (entry.getGrossAmount() < 2000.0)
                entry.setBankGST(0.0);
            else
                entry.setBankGST(new Double(df1.format((MDR) - (MDR / (1.18)))));
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getGrossAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            entry.setDisc(0.0);
            entry.setNet(0.0);
            entry.setSTax(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setChargingValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForCharging(entry);
        reconAdapter.chargingWriteData(entry);
    }
}
