package com.paytm.pgplus.barfi.util;

import com.paytm.pgplus.barfi.model.BankMaster;
import com.paytm.pgplus.barfi.model.BinMaster;
import com.paytm.pgplus.barfi.vo.ProcessedRupayRow;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.time.FastDateFormat;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.paytm.pgplus.barfi.util.AdapterConstants.*;

/**
 * @author Sakshi Jain
 */

public class RupayFileAdapter {

    private static final Logger LOGGER = LogManager.getLogger(RupayFileAdapter.class);

    public List<ProcessedRupayRow> rupayRowList = new ArrayList<>();
    public String rupayRowListHeader;
    public List<String> skippedRupayRows = new ArrayList<>();
    public List<BinMaster> successList = new ArrayList<>();
    public List<BinMaster> failureList = new ArrayList<>();
    public String beanName;
    public String fileName;
    private String processingDestination;
    private String failDestination;
    private String recordDestination;
    private String fileParentPath;
    private String filePath;
    private String rupayFolderName;
    private String extension;

    private String CSV_DELIMETER = ",";

    private static final FastDateFormat DATE_FORMAT = FastDateFormat.getInstance("yyyy/MM/dd HH:mm:ss");

    /**
     * @param file
     *            File
     */
    public RupayFileAdapter(File file) {
        this.beanName = "RUPAYBIN";
        this.fileParentPath = file.getParent();
        this.fileName = file.getName();
        this.rupayFolderName = file.getParentFile().getName();
        String bankfolder = ProcessorBean.valueOf(beanName).getDestinationFolder();
        this.extension = FilenameUtils.getExtension(fileName);
        if (extension.equals(FILEPART)) {
            throw new IllegalFileFormatException(fileName + " Not moved completely yet, extension is filepart ");
        }
        this.filePath = file.getPath();
        this.processingDestination = fileParentPath + SLASH + PROCESSING_TEMP + SLASH + fileName;

        this.failDestination = ReloadableProperties.getInstance().getStringValue("location.fail.unprocessed.dir")
                + bankfolder;
        this.recordDestination = ReloadableProperties.getInstance().getStringValue("location.success.unprocessed.dir")
                + bankfolder;
        this.markProcessing();

        this.verifyFileExtension();
    }

    /**
     * verifies file extension, and no further processing is thrown in case of
     * failure
     */
    private void verifyFileExtension() {
        if (!extension.equalsIgnoreCase(ProcessorBean.valueOf(beanName).getExtension())) {
            markFail("Extension Mismatch");
            throw new IllegalFileFormatException(fileName + " Extension Mismatch ");
        }
    }

    public enum Column {
        PARTICIPANT_INITIALS, BIN_LOW, BIN_HIGH, CARD_TYPE, SCHEME_CODE, IS_INDIAN, IS_ACTIVE
    }

    /**
     * @return File
     */
    public File getProcessingFileHandle() {
        return new File(processingDestination);
    }

    /**
     * moves file from processing folder to success-record folder
     */
    public void markSuccess() {

        LOGGER.info("File: {}, NPCI: {} RupayRowList data has been moved to paytmpgplusdb at time: {}.", fileName,
                rupayFolderName, DATE_FORMAT.format(new Date()));

        FileUtil.createDirs(recordDestination);
        try {
            moveSuccessAndFailedRecords();
            FileUtil.moveFile(processingDestination,
                    (new StringBuilder(recordDestination).append(SLASH).append(fileName)).toString());
            LOGGER.info(
                    "File: {}, NPCI: {} data has been successfully captured in RupayRowList and file has been moved to recordDestination at time: {}.",
                    fileName, rupayFolderName, DATE_FORMAT.format(new Date()));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            markFail("File movement is disrupted, marking failed");
        }
    }

    /**
     * moves file from processing folder to fail-record folder
     *
     * @param reason
     *            String
     */
    public void markFail(String reason) {
        FileUtil.createDirs(failDestination);
        try {
            moveSuccessAndFailedRecords();
            FileUtil.moveFile(processingDestination,
                    (new StringBuilder(failDestination).append(SLASH).append(fileName)).toString());
            LOGGER.info("File: '{}', NPCI: '{}' marked fail | error message: [{}] at time: {}", fileName,
                    rupayFolderName, reason, DATE_FORMAT.format(new Date()));
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    /**
     * moves file from input location to processing folder
     */
    private void markProcessing() {
        this.makeProcessingDirectory();
        try {
            FileUtil.moveFile(filePath, processingDestination);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    /**
     * creates processing directory used for storing files in process
     */
    private void makeProcessingDirectory() {
        FileUtil.createDir((new StringBuilder(fileParentPath).append(SLASH).append(PROCESSING_TEMP)).toString());
    }

    private void moveSuccessAndFailedRecords() {
        String pattern = "yyyyMMdd_HHmmss.SSS";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        String date = simpleDateFormat.format(new Date());
        String successFileName = "/" + date + "_success.csv";
        String failureFileName = "/" + date + "_fail.csv";
        String skippedFileName = "/" + date + "_skipped.csv";
        try {
            if (!this.failureList.isEmpty()) {
                FileUtil.createDirs(failDestination);
                FileWriter writer = new FileWriter(failDestination + failureFileName);
                writeRecords(writer, this.failureList, false);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to move failure records {}", e.getMessage(), e);
        }
        try {
            if (!this.skippedRupayRows.isEmpty()) {
                FileUtil.createDirs(failDestination);
                FileWriter writer = new FileWriter(failDestination + skippedFileName);
                writeSkippedRecords(writer, this.rupayRowListHeader, this.skippedRupayRows);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to move failure records {}", e.getMessage(), e);
        }
        try {
            if (!this.successList.isEmpty()) {
                FileUtil.createDirs(recordDestination);
                FileWriter writer = new FileWriter(recordDestination + successFileName);
                writeRecords(writer, this.successList, true);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to move success records {}", e.getMessage(), e);
        }
    }

    private void writeRecords(FileWriter writer, List<BinMaster> binMasterList, boolean isSuccess) throws IOException {
        String header = "BIN,BANK_ID,BANK_CODE,CARD_NAME,CARD_TYPE,IS_ACTIVE,IS_INDIAN,BIN_LENGTH";
        if (!isSuccess) {
            header = header.concat(",ERROR");
        }
        writer.write(header);
        for (BinMaster binMaster : binMasterList) {
            StringBuilder builder = new StringBuilder().append("\n").append(binMaster.getBin()).append(CSV_DELIMETER)
                    .append(binMaster.getBankId()).append(CSV_DELIMETER).append(binMaster.getBankCode())
                    .append(CSV_DELIMETER).append(binMaster.getCardName()).append(CSV_DELIMETER)
                    .append(binMaster.getCardType()).append(CSV_DELIMETER).append(binMaster.getIsActive())
                    .append(CSV_DELIMETER).append(binMaster.getIsIndian()).append(CSV_DELIMETER)
                    .append(binMaster.getBinLength());
            if (!isSuccess) {
                builder.append(CSV_DELIMETER).append(binMaster.getErrorMessage());
            }
            writer.write(builder.toString());
        }
        writer.flush();
        writer.close();
    }

    private void writeSkippedRecords(FileWriter writer, String header, List<String> rows) throws IOException {
        header = header.concat(",ERROR");
        writer.write(header);
        for (String row : rows) {
            StringBuilder builder = new StringBuilder().append("\n").append(row);
            writer.write(builder.toString());
        }
        writer.flush();
        writer.close();
    }
}
