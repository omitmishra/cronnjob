package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 * @author manojpal
 */
@Service("ICICINBReconFileProcessor")
public class ICICINBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(ICICINBReconFileProcessor.class);
    // Using all white space as delimiter; \\s is equivalent to [
    // \\t\\n\\x0B\\f\\r]
    private static final String DELIMITER = "\\s+";
    private static final String COLHEAD = "ITC";

    @Override
    public void process(ReconFileAdapter adapter) {
        List<String> csvList = null;
        Map<Integer, Enum<Column>> columnMap = null;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns();
            csvList = removeUnMatched(csvList);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private Map<Integer, Enum<Column>> mapColumns() {
        Map<Integer, Enum<Column>> columnMap = new HashMap<>();
        columnMap.put(0, Column.TXN_ID);
        columnMap.put(2, Column.BANK_TXN_ID);
        columnMap.put(3, Column.GROSS_AMT);
        return columnMap;
    }

    private List<String> removeUnMatched(List<String> csvList) {
        List<String> requiredRecords = new ArrayList<>();

        for (int i = 0; i < csvList.size(); i++) {
            if (StringUtils.isBlank(csvList.get(i))) {
                continue;
            }
            String[] data = csvList.get(i).split(DELIMITER);
            if (data.length == 0) {
                continue;
            }
            if (!data[0].equals(COLHEAD)) {
                continue;
            }
            for (int j = i + 1; j < csvList.size(); j++) {
                String row = csvList.get(j);
                if (row.startsWith("----------", 0)) {
                    continue;
                }
                requiredRecords.add(row);
            }
        }
        return requiredRecords;
    }

    @Override
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {
        LOGGER.info("ICICINB recon parse & write getting called");
        for (int rowNum = 0; rowNum < csvList.size(); rowNum++) {
            try {
                String record = csvList.get(rowNum);
                if (StringUtils.isBlank(record)) {
                    continue;
                }
                String[] row = record.split(delimiter);
                // fetch data before "_" in first value/txnId in record, ex.
                // 123456_SCWPAYTM
                row[0] = row[0].split(Pattern.compile("_").pattern())[0];
                if (!(row.length > 3 && NumberUtils.isParsable(row[3]))) { // amount_index_in_column
                    continue;
                }
                reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception ex) {
                LOGGER.error(ex.getMessage(), ex);
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, ex);
            }
        }

    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

}
