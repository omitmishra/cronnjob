package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.exception.PaytmBarfiException;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;

/**
 * @author agrim.bansal
 */

@Component(value = "PEDCBankcardReconFileProcessor")
public class PEDCReconFileProcessor implements Processable, CSVProcessor {

    public enum Column {
        GROSS_AMT, TXN_ID, BANK_TXN_ID, RESPCODE, MESSAGE_TYPE, TRAN_REVERSED, TXN_TYPE, BANK_COMMISSION, BANK_CARDSCHEME, CARD_TYPE, CARD_CATEGORY, MERCHANT_CODE, TERMINAL_CODE, INCENTIVE_PERCENTAGE;
    }

    private static final Logger LOGGER = LogManager.getLogger(PEDCReconFileProcessor.class);
    private static final String DELIMITER = ",";
    private static final String COLHEAD = "Merchant ID";
    private static final String SETTLE = "SETTLE";

    private static Map<String, Enum<Column>> reconMapCharging = new HashMap<>();
    private static Map<Enum<Column>, Boolean> costParamMap = new HashMap<>();

    static {
        reconMapCharging.put("PayTM_ID", Column.TXN_ID);
        reconMapCharging.put("Retr Ref Nr", Column.BANK_TXN_ID);
        reconMapCharging.put("Amount", Column.GROSS_AMT);
        reconMapCharging.put("Response Code", Column.RESPCODE);
        reconMapCharging.put("Message type", Column.MESSAGE_TYPE);
        reconMapCharging.put("Transaction type", Column.TXN_TYPE);

        reconMapCharging.put("FEE_AMOUNT", Column.BANK_COMMISSION);
        reconMapCharging.put("Interchange Type", Column.BANK_CARDSCHEME);
        reconMapCharging.put("Credit_debit", Column.CARD_TYPE);
        reconMapCharging.put("CardCountry", Column.CARD_CATEGORY);
        reconMapCharging.put("Merchant ID", Column.MERCHANT_CODE);
        reconMapCharging.put("Terminal ID", Column.TERMINAL_CODE);
        reconMapCharging.put("0.75% IncentiveAmount", Column.INCENTIVE_PERCENTAGE);

        costParamMap.put(Column.BANK_COMMISSION, true);
        costParamMap.put(Column.BANK_CARDSCHEME, true);
        costParamMap.put(Column.CARD_TYPE, true);
        costParamMap.put(Column.MERCHANT_CODE, true);
        costParamMap.put(Column.TERMINAL_CODE, true);
        costParamMap.put(Column.CARD_CATEGORY, true);
        costParamMap.put(Column.INCENTIVE_PERCENTAGE, true);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        if (StringUtils.containsIgnoreCase(adapter.fileName, SETTLE)) {
            processCharging(adapter);
            // } else {
            // LOGGER.info("unrecognized filename {}", adapter.fileName);
            // adapter.markFail("unrecognized filename");
        }
    }

    private void processCharging(ReconFileAdapter adapter) {
        List<String> csvList = null;
        Map<Integer, Enum<Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumnsEDC(adapter, csvList, reconMapCharging);
            parseAndWriteChargingEDC(adapter, csvList, columnMap);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private void parseAndWriteChargingEDC(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap) throws Exception {

        int AmountColNo = getColNumEDC(columnMap, Column.GROSS_AMT);
        int ExtColNo = getColNumEDC(columnMap, Column.TXN_ID);
        int respCodeColNo = getColNumEDC(columnMap, Column.RESPCODE);
        int txnTypColNo = getColNumEDC(columnMap, Column.TXN_TYPE);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(DELIMITER);
                if (StringUtils.isBlank(r) || row.length <= ExtColNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(AmountColNo, row))) {
                    continue;
                }
                if (!"00".equalsIgnoreCase(reconAdapter.getTxnType(respCodeColNo, row))) {
                    continue;
                }
                if ("00".equalsIgnoreCase(reconAdapter.getTxnType(txnTypColNo, row))
                        || "09".equalsIgnoreCase(reconAdapter.getTxnType(txnTypColNo, row))
                        || "84".equalsIgnoreCase(reconAdapter.getTxnType(txnTypColNo, row))) {
                    setChargingValues(row, columnMap, reconAdapter);
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    private void setChargingValues(String[] row, Map<Integer, Enum<Column>> columnMap, ReconFileAdapter reconAdapter) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        DecimalFormat df = new DecimalFormat("#.####");
        String cardType = "";
        String cardCategory = "";
        boolean costFieldError = false;
        int messageTypeColNo = getColNumEDC(columnMap, Column.MESSAGE_TYPE);
        int txnTypeColNo = getColNumEDC(columnMap, Column.TXN_TYPE);
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();
                    if (columnMap.containsKey(columnIndex)) {
                        switch ((Column) columnMap.get(columnIndex)) {
                        case GROSS_AMT:
                            // please check JIRA PGP-25785 for amount set 0.01
                            // for hitachi
                            String messageType = reconAdapter.getMessageType(messageTypeColNo, row);
                            String txnType = reconAdapter.getTxnType(txnTypeColNo, row);
                            if (("0200".equalsIgnoreCase(messageType) || ("200".equalsIgnoreCase(messageType)))
                                    && "84".equalsIgnoreCase(txnType)) {
                                entry.setGrossAmount(0.01);
                            } else {
                                entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            }
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            entry.setBankTxnId(canBankTxnIdStartWithZero() ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_COMMISSION:
                            entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CARDSCHEME:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;
                        case CARD_TYPE:
                            cardType = AdapterUtil.checkApostrophe(cell);
                            break;
                        case CARD_CATEGORY:
                            cardCategory = AdapterUtil.checkApostrophe(cell);
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TERMINAL_CODE:
                            entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case INCENTIVE_PERCENTAGE:
                            entry.setUdf2(AdapterUtil.checkApostrophe(cell));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ", (Column) columnMap.get(columnIndex),
                            ex.getMessage());
                    if (costParamMap.containsKey((Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (StringUtils.isBlank(entry.getAuthCode())) {
                entry.setAuthCode("0");
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRRN())) {
                entry.setRRN("0");
            }
            entry.setDisc(0.0);
            entry.setNet(0.0);
            entry.setSTax(0.0);
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getGrossAmount())));
            if (entry.getGrossAmount() < 2000)
                entry.setBankGST(0.0);
            else
                entry.setBankGST(entry.getBankComissionAmount() * 0.18);
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            if (entry.getUdf1() != null) {
                if (entry.getUdf1().toLowerCase().startsWith("visa"))
                    entry.setBankCardScheme("Visa");
                else if (entry.getUdf1().toLowerCase().startsWith("rupay"))
                    entry.setBankCardScheme("Rupay");
                else
                    entry.setBankCardScheme("Mastercard");
            }
            if (cardType != null) {
                if ("C".equalsIgnoreCase(cardType))
                    entry.setBankCardType("Credit");
                else
                    entry.setBankCardType("Debit");
            }
            if (cardCategory != null) {
                if (cardCategory.toLowerCase().startsWith("in"))
                    entry.setBankInternational((byte) 0);
                else
                    entry.setBankInternational((byte) 1);
            }
        } catch (Exception e) {
            LOGGER.error("Exception in setChargingValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForCharging(entry);
        reconAdapter.chargingWriteData(entry);
    }

    private Map<Integer, Enum<Column>> mapColumnsEDC(ReconFileAdapter adapter, List<String> csvList,
            Map<String, Enum<Column>> reconMap) throws PaytmBarfiException {

        Map<Integer, Enum<Column>> columnMap = new HashMap<>();
        for (String r : csvList) {
            if (StringUtils.isBlank(r)) {
                continue;
            }
            String[] row = r.split(DELIMITER);
            if (row.length == 0) {
                continue;
            }
            row[0] = AdapterUtil.removeQuotes(row[0]).trim();
            if (!row[0].equals(COLHEAD)) {
                continue;
            }
            for (int columnNo = 0; columnNo < row.length; columnNo++) {
                if (StringUtils.isBlank(row[columnNo])) {
                    continue;
                }
                row[columnNo] = AdapterUtil.removeQuotes(row[columnNo]);
                if (reconMap.containsKey(row[columnNo].trim())) {
                    columnMap.put(columnNo, reconMap.get(row[columnNo].trim()));
                }
            }
            break;
        }
        if (MapUtils.isEmpty(columnMap)) {
            throw new PaytmBarfiException(" Exception - Process Failed due to missing column heads,  File- "
                    + adapter.fileName);
        }
        return columnMap;
    }

    private int getColNumEDC(Map<Integer, Enum<Column>> columnMap, Enum<Column> colEnum) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (colEnum.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

}
