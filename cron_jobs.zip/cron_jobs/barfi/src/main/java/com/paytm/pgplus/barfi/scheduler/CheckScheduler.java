package com.paytm.pgplus.barfi.scheduler;

import static com.paytm.pgplus.barfi.util.AdapterConstants.CSV;
import static com.paytm.pgplus.barfi.util.AdapterConstants.PROCESSING_TEMP;
import static com.paytm.pgplus.barfi.util.AdapterConstants.SLASH;
import static com.paytm.pgplus.barfi.util.AdapterConstants.UNDERSCORE;

import java.io.File;
import java.io.FilenameFilter;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.util.ReloadableProperties;

/**
 * @author Agrim
 * @author Shubham
 *
 */

@Component
@EnableScheduling
@PropertySource("classpath:barfi.properties")
public class CheckScheduler extends TimerTask {

    private static final Logger LOGGER = LogManager.getLogger(CheckScheduler.class);

    private static final String REFUND = "Refund";
    private static final String CHARGEBACK = "Chargeback";
    private static final String CHARGING = "Charging";

    @Scheduled(cron = "${check.scheduler.cron.expression}")
    public void run() {

        int checkSchedulerEnable = ReloadableProperties.getInstance().getIntValue("check.scheduler.enable");
        String unprocessedDir = ReloadableProperties.getInstance().getStringValue("location.raw.unprocessed.dir");
        long threshold = ReloadableProperties.getInstance().getLongValue("check.scheduler.threshold.time");

        if (checkSchedulerEnable == 1) {
            LOGGER.info("CHECK Scheduler start");
            File file = new File(unprocessedDir);
            String[] directories = file.list(new FilenameFilter() {
                @Override
                public boolean accept(File current, String name) {
                    return new File(current, name).isDirectory();
                }
            });

            for (String dir : directories) {
                File folder = new File(unprocessedDir + SLASH + dir + SLASH + PROCESSING_TEMP);
                File[] listOfFiles = folder.listFiles();
                int numberOfFiles = (listOfFiles == null) ? 0 : listOfFiles.length;
                for (int i = 0; i < numberOfFiles; i++) {
                    if (listOfFiles[i].isFile()) {

                        String fileName = listOfFiles[i].getName();
                        String fileType = fileName.split(UNDERSCORE)[0];
                        if (!(fileType.equals(REFUND) || fileType.equals(CHARGEBACK) || fileType.equals(CHARGING))) {
                            if ((System.currentTimeMillis() - listOfFiles[i].lastModified()) > TimeUnit.MINUTES
                                    .toMillis(threshold)) {
                                LOGGER.info("Moving Unprocessed File: {}. Bank: {}", fileName, dir);
                                markRedo(listOfFiles[i]);
                            }
                        }

                    }
                }
            }
            LOGGER.info("CHECK Scheduler end");
        }
    }

    private void markRedo(File file) {
        try {
            Path deletePath = FileSystems.getDefault().getPath(
                    file.getParent() + SLASH + REFUND + UNDERSCORE + file.getName().split("\\.")[0] + CSV);
            Files.deleteIfExists(deletePath);
            deletePath = FileSystems.getDefault().getPath(
                    file.getParent() + SLASH + CHARGEBACK + UNDERSCORE + file.getName().split("\\.")[0] + CSV);
            Files.deleteIfExists(deletePath);
            deletePath = FileSystems.getDefault().getPath(
                    file.getParent() + SLASH + CHARGING + UNDERSCORE + file.getName().split("\\.")[0] + CSV);
            Files.deleteIfExists(deletePath);
            Path from = FileSystems.getDefault().getPath(file.getAbsolutePath());
            Path target = FileSystems.getDefault().getPath(file.getParentFile().getParent() + SLASH + file.getName());
            Files.move(from, target, StandardCopyOption.REPLACE_EXISTING);
            LOGGER.info("File '{}' Moved", file.getName());
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

    }
}
