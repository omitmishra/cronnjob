package com.paytm.pgplus.barfi.process;

import com.paytm.pgplus.barfi.util.XLSBSheetReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * XLSBSheetReader to extract data from the file. Should only be used when the
 * file is in XLSB format and have multiple sheets. Map will be returned, with
 * number of sheets passed
 *
 * @author Nitin Kumar Bhola
 *
 */

public interface XLSBSheetProcessor extends FileProcessor {

    static final Logger LOGGER = LogManager.getLogger(XLSBSheetProcessor.class);

    /**
     * using XLSBSheetReader to extract data sheetwise from the file. Should
     * only be used when the file is in XLSB format and contains multiple sheets
     * which are needed to be seperately processed
     *
     * @param File
     *            Unprocessed file directly from bank
     * @return Map of sheet index and List of Strings extracted data from file
     *         in list form
     * @throws SAXException
     * @throws ParserConfigurationException
     * @throws OpenXML4JException
     * @throws IOException
     */

    public default List<String> extractData(File file) throws IOException {
        return null;
    }

    public default Map<String, List<String>> extractDataSheets(File file, int noOfSheets) throws IOException,
            OpenXML4JException, ParserConfigurationException, SAXException {

        Map<String, List<String>> csvMap = new HashMap<>();
        if (!file.exists()) {
            LOGGER.error("Not found or not a file: {}", file.getPath());
        }

        int minColumns = -1;
        String filePath = file.getPath();
        OPCPackage p = OPCPackage.open(filePath, PackageAccess.READ);
        XLSBSheetReader xlsb2csv = new XLSBSheetReader(p, csvMap, minColumns, noOfSheets);
        xlsb2csv.process();
        return csvMap;
    }
}