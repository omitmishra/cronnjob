package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.dao.impl.BankTransferMISDaoImpl;
import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ApplicationContextProvider;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.model.BankTransferMIS;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author santosh kumar
 * @Since 25/08/2020
 */

@Component(value = "BankTransferReconFileProcessor")
public class BankTransferReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(BankTransferReconFileProcessor.class);

    private static final String DELIMITER = ",";
    private static final String COLHEAD = "VAN Number";

    private static Map<String, String> txnTypeSet = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMapDB = new HashMap<>();

    static {

        // Mandatory
        reconMap.put("Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("banktransactionRequestId", ReconFileAdapter.Column.BANK_TXN_ID);

        // Optional
        reconMap.put("Transaction Type", ReconFileAdapter.Column.TXN_TYPE);

        // This is for insert data in DB
        reconMapDB.put("Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMapDB.put("banktransactionRequestId", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMapDB.put("Transaction Type", ReconFileAdapter.Column.TXN_TYPE);
        reconMapDB.put("Transaction status", ReconFileAdapter.Column.TRANSACTION_STATUS);

    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = columnNameToTxnIdMap(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWriteAllColumnIntegerMapForBankTransfer(adapter, csvList, columnMap, DELIMITER, null);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
            columnMap = columnNameToTxnIdMap(adapter, csvList, reconMapDB, DELIMITER, COLHEAD);
            saveBankTransferMISInDB(adapter, csvList, columnMap, DELIMITER, null, txnTypeSet);
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    public void saveBankTransferMISInDB(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Enum<ReconFileAdapter.Column>, Integer> columnMap, String delimiter, String cleared,
            Map<String, String> txnTypeSet) throws Exception {

        ApplicationContext context = ApplicationContextProvider.getApplicationContext();
        BankTransferMISDaoImpl bankTransferMISDao = (BankTransferMISDaoImpl) context.getBean("bankTransferMISDao");
        int highestKey = getHighestValue(columnMap);
        int grossAmtColNo = columnMap.get(ReconFileAdapter.Column.GROSS_AMT);
        int txnStatusColNo = 0;
        int rowEnd = csvList.size();
        if (cleared != null) {
            txnStatusColNo = columnMap.get(ReconFileAdapter.Column.RESULT_CODE);
        }

        List<BankTransferMIS> misList = new ArrayList<>();

        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);
                if (StringUtils.isBlank(row) || cellArr.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(grossAmtColNo, cellArr))) {
                    continue;
                }
                if (cleared != null && !cleared.equalsIgnoreCase(reconAdapter.getTxnType(txnStatusColNo, cellArr))) {
                    continue;
                }
                BankTransferMIS bankTransferMIS = populateBankTransferMIS(cellArr, columnMap,
                        canBankTxnIdStartWithZero());
                misList.add(bankTransferMIS);

            } catch (Exception e) {
                LOGGER.error("File " + reconAdapter.fileName + " parsing error at line " + rowNum);
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
        if (CollectionUtils.isNotEmpty(misList)) {
            bankTransferMISDao.saveBankTransferMIS(misList);
        }
    }

    public BankTransferMIS populateBankTransferMIS(String[] row, Map<Enum<ReconFileAdapter.Column>, Integer> columnMap,
            boolean canBankTxnIdStartWithZero) {
        BankTransferMIS entry = new BankTransferMIS();
        for (Map.Entry<Enum<ReconFileAdapter.Column>, Integer> mapEntry : columnMap.entrySet()) {
            int columnIndex = mapEntry.getValue();
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            switch ((ReconFileAdapter.Column) mapEntry.getKey()) {

            case BANK_TXN_ID:
                // If bankTxnId can start with zero in processed, then do not
                // strip leading zeroes
                entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                        .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                break;
            case TRANSACTION_STATUS:
                entry.setTransactionStatus(AdapterUtil.checkApostrophe(cell));
                break;
            case TXN_TYPE:
                entry.setTransactionType(AdapterUtil.checkApostrophe(cell));
                break;
            default:
                break;
            }
        }
        return entry;

    }
}