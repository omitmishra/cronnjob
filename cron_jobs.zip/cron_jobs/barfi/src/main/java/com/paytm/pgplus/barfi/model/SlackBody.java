package com.paytm.pgplus.barfi.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class SlackBody {

    private String channel;
    private String username;
    private String text;
    private String icon_emoji;

}