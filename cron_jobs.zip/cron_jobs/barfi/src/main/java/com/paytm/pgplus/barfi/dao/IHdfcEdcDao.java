package com.paytm.pgplus.barfi.dao;

import com.paytm.pgplus.barfi.model.EdcHdfcBatchUpload;

import java.util.List;

public interface IHdfcEdcDao {

    List<EdcHdfcBatchUpload> fetchTransactionId(final List<String> authCodeList, final List<String> bankTidList);

}
