package com.paytm.pgplus.barfi.process;

import com.paytm.pgplus.barfi.util.RupayFileAdapter;

/**
 * @author Sakshi Jain
 */

public interface RupayProcessable {

    /**
     * Parses the file received from NPCI
     *
     * @param adapter
     *            Information Processed from the File received from NPCI
     */
    void process(RupayFileAdapter adapter);

}
