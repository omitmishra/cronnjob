package com.paytm.pgplus.barfi.dao;

import com.paytm.pgplus.barfi.model.BankTransferMIS;

import java.util.List;

/**
 * @author santoshkumar
 */

public interface IBankTransferMISDao {

    void saveBankTransferMIS(List<BankTransferMIS> bankTransferMISList);
}
