package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXSheetProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author shubham.singh
 */

@Component(value = "AXISMPGSReconFileProcessor")
public class AXISMPGSReconFileProcessor implements Processable, XLSXSheetProcessor {

    private static final Logger LOGGER = LogManager.getLogger(AXISMPGSReconFileProcessor.class);
    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "SETTLEMENT DATE";

    Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {
        reconMap.put("TXN AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("ORDER INFO", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("RRN NO", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("ARN", ReconFileAdapter.Column.RRN);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        Map<Integer, List<String>> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        Map<Integer, Enum<ReconFileAdapter.Column>> refundColMap = new HashMap<>();
        Map<Integer, Enum<ReconFileAdapter.Column>> chargingColMap = new HashMap<>();
        int noOfSheets = 6;

        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractDataSheets(adapter.getProcessingFileHandle(), noOfSheets);
            chargingColMap = mapColumns(adapter, csvList.get(0), reconMap, DELIMITER, COLHEAD);
            refundColMap = mapColumns(adapter, csvList.get(1), reconMap, DELIMITER, COLHEAD);
            parseAndWriteCharging(adapter, removeUnmatched(csvList.get(0), chargingColMap), chargingColMap, DELIMITER);
            parseAndWriteRefund(adapter, removeUnmatched(csvList.get(1), refundColMap), refundColMap, DELIMITER);
            parseAndWriteCharging(adapter, removeUnmatched(csvList.get(2), chargingColMap), chargingColMap, DELIMITER);
            parseAndWriteRefund(adapter, removeUnmatched(csvList.get(3), refundColMap), refundColMap, DELIMITER);
            parseAndWriteCharging(adapter, removeUnmatched(csvList.get(4), chargingColMap), chargingColMap, DELIMITER);
            parseAndWriteRefund(adapter, removeUnmatched(csvList.get(5), refundColMap), refundColMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }

    }

    /**
     * Remove unmatched records in given list in the form of {@link List
     * <String>}
     *
     * @param csvList
     * @param columnMap
     * @return matching records in the form of {@link List}
     */
    protected List<String> removeUnmatched(List<String> csvList, Map<Integer, Enum<ReconFileAdapter.Column>> columnMap) {

        int idenfierColIndex = -1;
        for (Map.Entry<Integer, Enum<ReconFileAdapter.Column>> entry : columnMap.entrySet()) {
            if (ReconFileAdapter.Column.BANK_TXN_ID.equals(entry.getValue())) {
                idenfierColIndex = entry.getKey();
                break;
            }
        }

        List<String> matchingRecordList = new ArrayList<>();
        for (int i = 0; i < csvList.size(); i++) {

            String rowData = csvList.get(i);

            if (StringUtils.isBlank(rowData)) {
                continue;
            }
            String[] row = rowData.split(DELIMITER);
            if (row.length == 0) {
                continue;
            }
            row[0] = AdapterUtil.removeQuotes(row[0]);
            if (!row[0].equals(COLHEAD)) {
                continue;
            }

            for (int j = i + 1; j < csvList.size(); j++) {
                rowData = csvList.get(j);
                row = rowData.split(DELIMITER);
                if (row.length > idenfierColIndex && !row[0].contains("count")) {
                    matchingRecordList.add(csvList.get(j));
                }
            }
            break;
        }
        return matchingRecordList;
    }

}
