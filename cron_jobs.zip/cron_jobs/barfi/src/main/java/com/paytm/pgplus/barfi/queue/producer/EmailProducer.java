package com.paytm.pgplus.barfi.queue.producer;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.queue.service.IProducer;
import com.paytm.pgplus.rabbitmq.communication.models.EmailInfo;
import com.paytm.pgplus.rabbitmq.enums.EnumRoutingKey;

@Component
public class EmailProducer {

    @Autowired
    IProducer queueService;

    private static final Logger LOGGER = LogManager.getLogger(EmailProducer.class);

    public void publish(EmailInfo object) {
        LOGGER.info("Publishing Email. {}", object.getSubject());
        queueService.push(EnumRoutingKey.EMAIL_CG_NOTIFY.getValue(), object);
    }

}
