package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Nitin Kumar Bhola
 *
 */

@Component(value = "ICICIDebitBankCardReconFileProcessor")
public class ICICIDebitBankCardReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(ICICIDebitBankCardReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "S.No";
    private static final String SALE = "Sale";
    private static final String REFUND = "Refund";
    private static final String SUCCESS = "Successful";

    private static Map<String, Enum<Column>> reconMap = new HashMap<>();

    static {
        reconMap.put("Transaction Amount", Column.GROSS_AMT);
        reconMap.put("Merchant Track ID", Column.TXN_ID);
        reconMap.put("Transaction ID", Column.BANK_TXN_ID);
        reconMap.put("Transaction Action", Column.TXN_TYPE);
        reconMap.put("Transaction Status", Column.RESULT_CODE);
        reconMap.put("Retrieval Reference Number", Column.RRN);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    /**
     * Parses and writes to the csv files
     * 
     * @param reconAdapter
     * @param csvList
     * @param columnMap
     * @param delimiter
     * @throws Exception
     */
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int rowNum = 0;
        try {
            int colNo = reconAdapter.getColumnNumberAmount(columnMap); // GrossAmount
            int colNoTxnId = reconAdapter.getColumnNumberTransId(columnMap);
            int colNoTxnType = reconAdapter.getColumnNumberDRCR(columnMap);
            int colNoResultCode = reconAdapter.getResultCodeColumnNumber(columnMap);
            int highestKey = getHighestKey(columnMap);
            int rowEnd = csvList.size();
            for (rowNum = 0; rowNum < rowEnd; rowNum++) {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);
                if (StringUtils.isBlank(row) || cellArr.length <= highestKey
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNo, cellArr))
                        || !NumberUtils.isParsable(reconAdapter.getTxnType(colNoTxnId, cellArr))) {
                    continue;
                }
                String resultCode = reconAdapter.getTxnType(colNoResultCode, cellArr);
                if (!resultCode.equalsIgnoreCase(SUCCESS)) {
                    continue;
                }
                String txnType = reconAdapter.getTxnType(colNoTxnType, cellArr);
                if (txnType.equalsIgnoreCase(REFUND)) {
                    reconAdapter.setRefundValues(cellArr, columnMap, canBankTxnIdStartWithZero());
                } else if (txnType.equalsIgnoreCase(SALE)) {
                    reconAdapter.setChargingValues(cellArr, columnMap, canBankTxnIdStartWithZero());
                }
            }

        } catch (Exception e) {
            throw new Exception("File " + reconAdapter.fileName + " parsing error at " + rowNum, e);
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }
}