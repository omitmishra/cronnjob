package com.paytm.pgplus.barfi.scheduler;

import com.paytm.pgplus.barfi.RupayTask;
import com.paytm.pgplus.barfi.TaskExecutor;
import com.paytm.pgplus.barfi.util.ReloadableProperties;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.TimerTask;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SLASH;

/**
 * @author Sakshi Jain
 */

@Component
@EnableScheduling
@PropertySource("classpath:barfi.properties")
public class RupayBinScheduler extends TimerTask {

    private static final Logger LOGGER = LogManager.getLogger(RupayBinScheduler.class);

    @Autowired
    private TaskExecutor taskExecutor;

    /*
     * @see java.util.TimerTask#run() scheduler
     */
    @Scheduled(cron = "${rupay.scheduler.cron.expression}")
    public void run() {
        int rupaySchedulerEnable = ReloadableProperties.getInstance().getIntValue("rupay.scheduler.enable");
        String unprocessedDirPath = ReloadableProperties.getInstance().getStringValue("location.raw.rupay.dir");
        if (rupaySchedulerEnable == 1) {
            LOGGER.info("Rupay Scheduler start");
            File fileFolderPath = new File(unprocessedDirPath + SLASH + "RUPAY-BIN");
            if (fileFolderPath.isDirectory()) {
                processFilesInPath(fileFolderPath.getPath());
            }
            LOGGER.info("Rupay Scheduler end");
        }
    }

    /**
     * @param path
     *            String
     */
    private void processFilesInPath(String path) {

        String filePath;
        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();
        if (null != listOfFiles) {
            for (File file : listOfFiles) {
                if (file.isFile()) {
                    try {
                        filePath = file.getCanonicalPath();
                        taskExecutor.submit(new RupayTask(new File(filePath)));
                    } catch (Exception e) {
                        LOGGER.error("raw file not found at location ");
                        LOGGER.error(e.getMessage(), e);
                    }
                }
            }
        }
    }
}
