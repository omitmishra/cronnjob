package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 * @author Agrim
 */

@Component(value = "AMEXBankCardReconFileProcessor")
public class AMEXCCReconFileProcessor implements Processable, XLSProcessor {

    private static final Logger LOGGER = LogManager.getLogger(AMEXCCReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "Reference (ROC,TKT,CPC)";
    private static final String ADJUSTMENT = "Adjustment";
    private static final String CHARGEBACK = "chargeback";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("Transaction Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("Reference (ROC,TKT,CPC)", ReconFileAdapter.Column.TXN_ID);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public Map<Integer, Enum<ReconFileAdapter.Column>> mapColumns(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<String, Enum<ReconFileAdapter.Column>> reconMap, String delimiter, String colHead) throws IOException {

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
        for (String r : csvList) {
            if (StringUtils.isBlank(r)) {
                continue;
            }
            String[] row = r.split(delimiter);
            if (row.length <= 1) {
                continue;
            }
            row[1] = AdapterUtil.removeQuotes(row[1]).trim();
            if (!row[1].equals(colHead)) {
                continue;
            }
            for (int columnNo = 0; columnNo < row.length; columnNo++) {
                if (StringUtils.isBlank(row[columnNo])) {
                    continue;
                }
                row[columnNo] = AdapterUtil.removeQuotes(row[columnNo]);
                if (reconMap.containsKey(row[columnNo].trim())) {
                    columnMap.put(columnNo, reconMap.get(row[columnNo].trim()));
                }
            }
            break;
        }
        return columnMap;
    }

    @Override
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                if (AdapterUtil.removeQuotes(row[4]).equalsIgnoreCase(ADJUSTMENT)
                        || AdapterUtil.removeQuotes(row[4]).equalsIgnoreCase(CHARGEBACK)) {
                    continue;
                }
                if (reconAdapter.getTxnType(colNo, row).startsWith("-")) {
                    reconAdapter.setRefundValues(row, columnMap, canBankTxnIdStartWithZero());
                } else {
                    reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }
}
