/**
 *
 */
package com.paytm.pgplus.barfi.queue.service.impl;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.queue.service.IProducer;
import com.paytm.pgplus.rabbitmq.enums.EnumRoutingKey;
import com.paytm.pgplus.rabbitmq.service.IRabbitmqProducer;

@Component(value = "queueServiceImpl")
public class QueueServiceImpl implements IProducer {

    // private static final Logger LOGGER =
    // LoggerFactory.getLogger(QueueServiceImpl.class);

    @Autowired
    IRabbitmqProducer rabbitmqProducer;

    @Override
    public void push(String key, Object requestBody) {
        // LOGGER.info("Request received for pushing data in queue at key {}",
        // key);

        EnumRoutingKey node = EnumRoutingKey.getNode(key);

        if (null != node) {
            // LOGGER.debug("Sending : {} ", requestBody);
            rabbitmqProducer.produce(node, requestBody);
            // LOGGER.debug("Data Sent to queue successfully");
        }
    }
}