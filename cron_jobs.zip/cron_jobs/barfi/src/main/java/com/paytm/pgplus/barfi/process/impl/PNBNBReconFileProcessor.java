package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Jay Tiwari
 *
 */

@Component(value = "PNBNBReconFileProcessor")
public class PNBNBReconFileProcessor implements Processable, XLSXProcessor {

    private static final Logger LOGGER = LogManager.getLogger(PNBNBReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "Bank_Refernce_No";

    private static Map<String, String> txnTypeSet = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {
        txnTypeSet.put(Constants.PAYTM_CHARGING, Constants.PAYTM_CHARGING);

        reconMap.put("Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("Bank_Refernce_No", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("Aggregator Refernce No", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("Account_No", ReconFileAdapter.Column.AUTH_CODE);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = columnNameToTxnIdMap(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWriteAllColumnIntegerMap(adapter, csvList, columnMap, DELIMITER, null, txnTypeSet);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }
}