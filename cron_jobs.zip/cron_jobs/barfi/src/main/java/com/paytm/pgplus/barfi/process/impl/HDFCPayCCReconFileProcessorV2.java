package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

/**
 * @author Agrim
 *
 */

@Component(value = "HDFCPayBankCardReconFileProcessorV2")
public class HDFCPayCCReconFileProcessorV2 implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(HDFCPayCCReconFileProcessorV2.class);

    private static final String REFUND = "CVD";
    private static final String CHARGING = "BAT";
    private static final String DELIMITER = ",";
    private static final String COLHEAD = "MERCHANT CODE";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("DOMESTIC AMT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("INTNL AMT", ReconFileAdapter.Column.INTNL);
        reconMap.put("MERCHANT TRACKID", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("REC FMT", ReconFileAdapter.Column.TXN_TYPE);
        reconMap.put("ARN NO", ReconFileAdapter.Column.RRN);
        reconMap.put("RRN", ReconFileAdapter.Column.BANK_TXN_ID);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER, CHARGING, REFUND);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }
}
