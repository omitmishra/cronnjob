package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

/**
 * @author saurabh.malviya
 */

@Component(value = "CCAvenueBankCardReconFileProcessor")
public class CCAvenueBankCardReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(CCAvenueBankCardReconFileProcessor.class);
    private static final String DELIMITER = ",";
    private static final String CHARGING = "capture";
    private static final String REFUND = "refund";
    private static final String COLHEAD = "Order #";

    @Override
    public void process(ReconFileAdapter adapter) {
        LOGGER.info("File Processed..{}", adapter.fileName);
        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnRefundMap;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnCharingMap;
        try {
            csvList = extractData(adapter.getProcessingFileHandle());
            csvList = removeUnMatched(csvList);
            columnRefundMap = mapRefundColumns();
            columnCharingMap = mapChargingColumns();
            parseAndWrite(adapter, csvList, columnRefundMap, columnCharingMap, DELIMITER, CHARGING, REFUND);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    private Map<Integer, Enum<ReconFileAdapter.Column>> mapRefundColumns() {

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
        columnMap.put(0, ReconFileAdapter.Column.TXN_ID);
        columnMap.put(10, ReconFileAdapter.Column.GROSS_AMT);
        columnMap.put(7, ReconFileAdapter.Column.TXN_TYPE);
        return columnMap;
    }

    private Map<Integer, Enum<ReconFileAdapter.Column>> mapChargingColumns() {

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
        columnMap.put(0, ReconFileAdapter.Column.TXN_ID);
        columnMap.put(1, ReconFileAdapter.Column.BANK_TXN_ID);
        columnMap.put(10, ReconFileAdapter.Column.GROSS_AMT);
        columnMap.put(7, ReconFileAdapter.Column.TXN_TYPE);
        return columnMap;
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnRefundMap,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnChargingMap, String delimiter, String charging,
            String refund) throws Exception {

        int colNo = reconAdapter.getColumnNumberDRCR(columnChargingMap);
        int rowEnd = csvList.size();
        String payMode = "CRDC";
        int payModeCol = 23;
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (!payMode.equals(row[payModeCol])) {
                    continue;
                }
                if (refund.equals(reconAdapter.getTxnType(colNo, row))) {
                    reconAdapter.setRefundValues(row, columnRefundMap, canBankTxnIdStartWithZero());
                }
                if (charging.equals(reconAdapter.getTxnType(colNo, row))) {
                    reconAdapter.setChargingValues(row, columnChargingMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    private List<String> removeUnMatched(List<String> csvList) {
        List<String> requiredRecords = new ArrayList<>();

        for (int i = 0; i < csvList.size(); i++) {
            if (StringUtils.isBlank(csvList.get(i))) {
                continue;
            }
            String[] data = csvList.get(i).split(DELIMITER);
            if (data.length < 25) {
                continue;
            }
            if (data[0].equals(COLHEAD)) {
                continue;
            }

            String row = csvList.get(i);
            if (row.startsWith("----------", 0)) {
                continue;
            }
            requiredRecords.add(row);
        }
        if (requiredRecords.size() == 0) {
            LOGGER.error("File changed {}");
            throw new UnsupportedOperationException();
        }
        return requiredRecords;
    }

}
