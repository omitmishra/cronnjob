package com.paytm.pgplus.barfi.process.impl;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;

/**
 * @author Prachi Jain
 **/

@Component(value = "KOTAKCCReconFileProcessor")
public class KOTAKReconFileProcessor implements Processable, XLSXProcessor {

    private static final Logger LOGGER = LogManager.getLogger(KOTAKReconFileProcessor.class);
    private static final Map<String, Enum<ReconFileAdapter.Column>> reconChargingMap = new HashMap<>();
    private static final Map<String, Enum<ReconFileAdapter.Column>> reconRefundMap = new HashMap<>();
    private static Map<Enum<ReconFileAdapter.Column>, Boolean> costParamMap = new HashMap<>();
    private static final String DELIMETER = "\\|";
    private static final String COLHEAD = "MERCHANT_ID";
    private static final String REFUND = "Refund";
    private static final String CHARGING = "Purchase";

    static {

        reconChargingMap.put("FINAL_AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        reconChargingMap.put("ORDER_ID", ReconFileAdapter.Column.TXN_ID);
        reconChargingMap.put("RRN", ReconFileAdapter.Column.BANK_TXN_ID);
        reconRefundMap.put("REFUND_CANCEL_ID", ReconFileAdapter.Column.TXN_ID);
        reconRefundMap.put("AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        reconRefundMap.put("RRN", ReconFileAdapter.Column.RRN);// Same Column
                                                               // for bankTxnId

        reconChargingMap.put("MDR", ReconFileAdapter.Column.BANK_COMMISSION);
        reconChargingMap.put("GST", ReconFileAdapter.Column.BANK_CGST);
        reconChargingMap.put("NETWORK", Column.BANK_CARDSCHEME);
        reconChargingMap.put("CARD_PROGRAM", ReconFileAdapter.Column.CARD_TYPE);
        reconChargingMap.put("CARD_CATEGORY", Column.CARD_CATEGORY);
        reconChargingMap.put("MCC", Column.MCC);
        reconChargingMap.put("MERCHANT_ID", ReconFileAdapter.Column.MERCHANT_CODE);
        reconChargingMap.put("TERMINAL_ID", ReconFileAdapter.Column.TERMINAL_CODE);
        reconChargingMap.put("CURRENCY_CODE", ReconFileAdapter.Column.TXN_CURR);

        reconRefundMap.put("NETWORK", Column.BANK_CARDSCHEME);
        reconRefundMap.put("CARD_PROGRAM", ReconFileAdapter.Column.CARD_TYPE);
        reconRefundMap.put("CARD_CATEGORY", Column.CARD_CATEGORY);
        reconRefundMap.put("MCC", Column.MCC);
        reconRefundMap.put("MERCHANT_ID", ReconFileAdapter.Column.MERCHANT_CODE);
        reconRefundMap.put("TERMINAL_ID", ReconFileAdapter.Column.TERMINAL_CODE);
        reconRefundMap.put("CURRENCY_CODE", ReconFileAdapter.Column.TXN_CURR);

        costParamMap.put(ReconFileAdapter.Column.BANK_COMMISSION, true);
        costParamMap.put(ReconFileAdapter.Column.BANK_CGST, true);
        costParamMap.put(ReconFileAdapter.Column.CARD_TYPE, true);
        costParamMap.put(ReconFileAdapter.Column.BANK_CARDSCHEME, true);
        costParamMap.put(ReconFileAdapter.Column.CARD_CATEGORY, true);
        costParamMap.put(ReconFileAdapter.Column.MERCHANT_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.TERMINAL_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.TXN_CURR, true);
        costParamMap.put(ReconFileAdapter.Column.MCC, true);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        LOGGER.info("File Processed..{}", adapter.fileName);

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnChargingMap = new HashMap<>();
        Map<Integer, Enum<ReconFileAdapter.Column>> columnRefundMap = new HashMap<>();

        try {
            csvList = extractData(adapter.getProcessingFileHandle());
            if (adapter.fileName.contains(REFUND)) {
                columnRefundMap = mapColumns(adapter, csvList, reconRefundMap, DELIMETER, COLHEAD);
                parseAndWriteRefund(adapter, csvList, columnRefundMap, DELIMETER);
            } else if (adapter.fileName.contains(CHARGING)) {
                columnChargingMap = mapColumns(adapter, csvList, reconChargingMap, DELIMETER, COLHEAD);
                parseAndWriteCharging(adapter, csvList, columnChargingMap, DELIMETER);
            } else {
                adapter.markFail("File name format not as specified");
            }

            LOGGER.info("File {} Processed successfully..", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }

    }

    public void parseAndWriteRefund(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {
        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                setRefundValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    private void setRefundValues(ReconFileAdapter reconAdapter, String[] row, Map<Integer, Enum<Column>> columnMap,
            boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        DecimalFormat df = new DecimalFormat("#.####");
        String cardCategory = "";
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();

                    if (columnMap.containsKey(columnIndex)) {
                        switch ((Column) columnMap.get(columnIndex)) {
                        case RRN:
                            entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                                    .checkApostrophe(cell))));
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case GROSS_AMT:
                            Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case CARD_CATEGORY:
                            cardCategory = AdapterUtil.checkApostrophe(cell);
                            break;
                        case BANK_CARDSCHEME:
                            entry.setBankCardScheme(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MCC:
                            entry.setMCCCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case CARD_TYPE:
                            entry.setBankCardType(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TERMINAL_CODE:
                            entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TXN_CURR:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;

                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            entry.setBankComissionAmount(0.0);
            entry.setBankGST(0.0);
            entry.setBankComissionPerc(0.0);
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRrn())) {
                entry.setRrn("0");
            }
            entry.setNeftNo(0.0);
            entry.setStatus(SUCCESS);
            entry.setTxnAmount(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setRefundValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForRefund(entry);
        reconAdapter.refundWriteData(entry);
    }

    public void parseAndWriteCharging(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int highestKey = getHighestKey(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                setChargingValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    private void setChargingValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        DecimalFormat df = new DecimalFormat("#.####");
        String cardCategory = "";
        Double intnlAmount = 0.0;
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();
                    if (columnMap.containsKey(columnIndex)) {
                        switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                        case GROSS_AMT:
                            intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case AUTH_CODE:
                            entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case RRN:
                            entry.setRRN(AdapterUtil.checkApostrophe(cell));
                            break;
                        case BANK_CGST:
                            entry.setBankGST(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case CARD_CATEGORY:
                            cardCategory = AdapterUtil.checkApostrophe(cell);
                            break;
                        case BANK_COMMISSION:
                            entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CARDSCHEME:
                            entry.setBankCardScheme(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MCC:
                            entry.setMCCCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case CARD_TYPE:
                            entry.setBankCardType(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TERMINAL_CODE:
                            entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TXN_CURR:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (StringUtils.isBlank(entry.getAuthCode())) {
                entry.setAuthCode("0");
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRRN())) {
                entry.setRRN("0");
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getGrossAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            entry.setDisc(0.0);
            entry.setNet(0.0);
            entry.setSTax(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setChargingValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForCharging(entry);
        reconAdapter.chargingWriteData(entry);
    }
}
