package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

/**
 * @author saurabh.malviya
 */

@Component(value = "CCAvenueNBReconFileProcessor")
public class CCAvenueNBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(CCAvenueNBReconFileProcessor.class);

    private static final String DELIMITER = ",";
    private static final String COLHEAD = "Serial No.";

    private static Map<String, String> txnTypeSetCharging = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMapCharging = new HashMap<>();

    private static Map<String, String> txnTypeSetRefund = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMapRefund = new HashMap<>();

    static {
        txnTypeSetCharging.put(Constants.PAYTM_CHARGING, "CAPTURE");
        reconMapCharging.put("Order No.", ReconFileAdapter.Column.TXN_ID);
        reconMapCharging.put("CCAvenue Reference No.", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMapCharging.put("Transaction Type", ReconFileAdapter.Column.TXN_TYPE);
        reconMapCharging.put("Order Amt", ReconFileAdapter.Column.GROSS_AMT);

        txnTypeSetRefund.put(Constants.PAYTM_REFUND, "REFUND");
        reconMapRefund.put("Order No.", ReconFileAdapter.Column.TXN_ID);
        reconMapRefund.put("CCAvenue Reference No.", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMapRefund.put("Transaction Type", ReconFileAdapter.Column.TXN_TYPE);
        reconMapRefund.put("Refund Amt", ReconFileAdapter.Column.GROSS_AMT);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            // process for charging
            columnMap = columnNameToTxnIdMap(adapter, csvList, reconMapCharging, DELIMITER, COLHEAD);
            parseAndWriteAllColumnIntegerMap(adapter, csvList, columnMap, DELIMITER, null, txnTypeSetCharging);
            // process for refund
            columnMap = columnNameToTxnIdMap(adapter, csvList, reconMapRefund, DELIMITER, COLHEAD);
            parseAndWriteAllColumnIntegerMap(adapter, csvList, columnMap, DELIMITER, null, txnTypeSetRefund);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }
}