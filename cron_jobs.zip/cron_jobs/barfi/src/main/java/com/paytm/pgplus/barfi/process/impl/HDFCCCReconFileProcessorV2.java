package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

/**
 * @author Vivek.Lata
 *
 */

@Component(value = "HDFCBankCardReconFileProcessorV2")
public class HDFCCCReconFileProcessorV2 implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(HDFCCCReconFileProcessorV2.class);

    private static final String REFUND = "CVD";
    private static final String CHARGING = "BAT";
    private static final String DELIMITER = ",";
    private static final String COLHEAD = "MERCHANT CODE";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("DOMESTIC AMT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("INTNL AMT", ReconFileAdapter.Column.INTNL);
        reconMap.put("MERCHANT_TRACKID", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("TRAN_ID", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("REC FMT", ReconFileAdapter.Column.TXN_TYPE);
        reconMap.put("ARN NO", ReconFileAdapter.Column.RRN);
        reconMap.put("CGST AMT", ReconFileAdapter.Column.BANK_CGST);
        reconMap.put("IGST AMT", ReconFileAdapter.Column.BANK_IGST);
        reconMap.put("SGST AMT", ReconFileAdapter.Column.BANK_SGST);
        reconMap.put("UTGST AMT", ReconFileAdapter.Column.BANK_UGST);
        reconMap.put("SERV TAX", ReconFileAdapter.Column.BANK_SERVICETAX);
        reconMap.put("MSF", ReconFileAdapter.Column.BANK_COMMISSION);
        reconMap.put("DEBITCREDIT_TYPE", ReconFileAdapter.Column.DEBITCREDIT_TYPE);
        reconMap.put("CARD TYPE", ReconFileAdapter.Column.CARD_TYPE);
        reconMap.put("TERMINAL NUMBER", ReconFileAdapter.Column.TERMINAL_CODE);
        reconMap.put("MERCHANT CODE", ReconFileAdapter.Column.MERCHANT_CODE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER, CHARGING, REFUND);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, String delimiter, String charging, String refund)
            throws Exception {
        int colNo = reconAdapter.getColumnNumberDRCR(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (refund.equals(reconAdapter.getTxnType(colNo, row))) {
                    setRefundValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
                }
                if (charging.equals(reconAdapter.getTxnType(colNo, row))) {
                    setChargingValues(reconAdapter, row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    private void setChargingValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        DecimalFormat df = new DecimalFormat("#.####");
        Double intnlAmount = 0.0;
        Double bankCGST = 0.0;
        Double bankSGST = 0.0;
        Double bankIGST = 0.0;
        Double bankUGST = 0.0;
        String debitCredinType = "";
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                if (StringUtils.isBlank(cell)) {
                    continue;
                }
                cell = cell.trim();
                if (columnMap.containsKey(columnIndex)) {
                    switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                    case GROSS_AMT:
                        intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                        entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                        break;
                    case TXN_ID:
                        entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        break;
                    case BANK_TXN_ID:
                        // If bankTxnId can start with zero in processed, then
                        // do
                        // not strip leading zeroes
                        entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                                .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        break;
                    case INTNL:
                        entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                        break;
                    case AUTH_CODE:
                        entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                        break;
                    case RRN:
                        entry.setRRN(AdapterUtil.checkApostrophe(cell));
                        break;
                    case BANK_CGST:
                        bankCGST = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                        break;
                    case BANK_SGST:
                        bankSGST = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                        break;
                    case BANK_IGST:
                        bankIGST = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                        break;
                    case BANK_UGST:
                        bankUGST = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                        break;
                    case BANK_COMMISSION:
                        entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                        break;
                    case BANK_SERVICETAX:
                        entry.setBankServiceTax(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                        break;
                    case DEBITCREDIT_TYPE:
                        debitCredinType = AdapterUtil.checkApostrophe(cell);
                        break;
                    case CARD_TYPE:
                        entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                        break;
                    case MERCHANT_CODE:
                        entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                        break;
                    case TERMINAL_CODE:
                        entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                        entry.setMbid(AdapterUtil.checkApostrophe(cell));
                        break;
                    default:
                        break;
                    }
                }
            }
            if (StringUtils.isBlank(entry.getAuthCode())) {
                entry.setAuthCode("0");
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRRN())) {
                entry.setRRN("0");
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getGrossAmount())));
            entry.setBankGST(bankCGST + bankSGST + bankIGST + bankUGST);
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            if ("DC".equalsIgnoreCase(debitCredinType) || "FC".equalsIgnoreCase(debitCredinType))
                entry.setBankCardType("Credit Card");
            else
                entry.setBankCardType("Debit Card");

            if (intnlAmount > 0 || "FC".equalsIgnoreCase(debitCredinType) || "FD".equalsIgnoreCase(debitCredinType))
                entry.setBankInternational((byte) 1);
            else
                entry.setBankInternational((byte) 0);

            if (entry.getUdf1() != null) {
                if (entry.getUdf1().toLowerCase().indexOf("corporate") >= 0)
                    entry.setBankCorporate((byte) 1);
                else
                    entry.setBankCorporate((byte) 0);

                if (entry.getUdf1().toLowerCase().indexOf("visa") >= 0)
                    entry.setBankCardScheme("Visa");
                if (entry.getUdf1().toLowerCase().indexOf("rupay") >= 0)
                    entry.setBankCardScheme("Rapay");
                if (entry.getUdf1().toLowerCase().indexOf("master") >= 0)
                    entry.setBankCardScheme("Mastercard");
                else
                    entry.setBankCardScheme("Diner");
            }
            entry.setUdf2(bankCGST.toString());
            entry.setUdf3(bankSGST.toString());
            entry.setUdf4(bankIGST.toString());
            entry.setUdf5(bankUGST.toString());
            entry.setDisc(0.0);
            entry.setNet(0.0);
            entry.setSTax(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setChargingValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage(), e);
        }
        reconAdapter.chargingWriteData(entry);
    }

    public void setRefundValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        DecimalFormat df = new DecimalFormat("#.####");
        Double intnlAmount = 0.0;
        Double bankCGST = 0.0;
        Double bankSGST = 0.0;
        Double bankIGST = 0.0;
        Double bankUGST = 0.0;
        String debitCredinType = "";
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                if (StringUtils.isBlank(cell)) {
                    continue;
                }
                cell = cell.trim();

                if (columnMap.containsKey(columnIndex)) {
                    switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                    case RRN:
                        entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                                .checkApostrophe(cell))));
                        break;
                    case GROSS_AMT:
                        intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                        entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                        break;
                    case TXN_ID:
                        entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        break;
                    case BANK_TXN_ID:
                        // If bankTxnId can start with zero in processed, then
                        // do
                        // not strip leading zeroes
                        entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell) : AdapterUtil
                                .stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        break;
                    case INTNL:
                        entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                        break;
                    case BANK_CGST:
                        bankCGST = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                        break;
                    case BANK_SGST:
                        bankSGST = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                        break;
                    case BANK_IGST:
                        bankIGST = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                        break;
                    case BANK_UGST:
                        bankUGST = Math.abs(Double.parseDouble(cell.replaceAll(",", "")));
                        break;
                    case BANK_COMMISSION:
                        entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                        break;
                    case BANK_SERVICETAX:
                        entry.setBankServiceTax(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                        break;
                    case DEBITCREDIT_TYPE:
                        debitCredinType = AdapterUtil.checkApostrophe(cell);
                        break;
                    case CARD_TYPE:
                        entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                        break;
                    case MERCHANT_CODE:
                        entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                        break;
                    case TERMINAL_CODE:
                        entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                        entry.setMbid(AdapterUtil.checkApostrophe(cell));
                        break;
                    default:
                        break;
                    }
                }
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getRefundAmount())));
            entry.setBankGST(bankCGST + bankSGST + bankIGST + bankUGST);
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            if ("DC".equalsIgnoreCase(debitCredinType) || "FC".equalsIgnoreCase(debitCredinType))
                entry.setBankCardType("Credit Card");
            else
                entry.setBankCardType("Debit Card");

            if (intnlAmount > 0 || "FC".equalsIgnoreCase(debitCredinType) || "FD".equalsIgnoreCase(debitCredinType))
                entry.setBankInternational((byte) 1);
            else
                entry.setBankInternational((byte) 0);

            if (entry.getUdf1() != null) {
                if (entry.getUdf1().toLowerCase().indexOf("corporate") >= 0)
                    entry.setBankCorporate((byte) 1);
                else
                    entry.setBankCorporate((byte) 0);
                if (entry.getUdf1().toLowerCase().indexOf("visa") >= 0)
                    entry.setBankCardScheme("Visa");
                if (entry.getUdf1().toLowerCase().indexOf("rupay") >= 0)
                    entry.setBankCardScheme("Rapay");
                if (entry.getUdf1().toLowerCase().indexOf("master") >= 0)
                    entry.setBankCardScheme("Mastercard");
                else
                    entry.setBankCardScheme("Diner");
            }
            entry.setUdf2(bankCGST.toString());
            entry.setUdf3(bankSGST.toString());
            entry.setUdf4(bankIGST.toString());
            entry.setUdf5(bankUGST.toString());
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRrn())) {
                entry.setRrn("0");
            }
            entry.setNeftNo(0.0);
            entry.setStatus(SUCCESS);
            entry.setTxnAmount(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setRefundValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage(), e);
        }
        reconAdapter.refundWriteData(entry);
    }
}
