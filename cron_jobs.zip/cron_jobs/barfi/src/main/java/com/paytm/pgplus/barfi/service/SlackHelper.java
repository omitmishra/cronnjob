package com.paytm.pgplus.barfi.service;

import com.paytm.pgplus.barfi.model.SlackBody;
import com.paytm.pgplus.barfi.util.ReloadableProperties;
import com.paytm.pgplus.facade.exception.FacadeCheckedException;
import com.paytm.pgplus.facade.utils.JsonMapper;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component(value = "slackHelper")
public class SlackHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(SlackHelper.class);

    private static final String HASH = "#";

    private static final String WEBHOOK_URL = ReloadableProperties.getInstance().getStringValue("slack.bo.alert.url");
    private static final String CHANNEL = StringUtils.isNotBlank(ReloadableProperties.getInstance().getStringValue(
            "slack.bo.alert.channel")) ? ReloadableProperties.getInstance().getStringValue("slack.bo.alert.channel")
            : "bo-alerts";
    private static final String USER_NAME = StringUtils.isNotBlank(ReloadableProperties.getInstance().getStringValue(
            "slack.bo.alert.user.name")) ? ReloadableProperties.getInstance()
            .getStringValue("slack.bo.alert.user.name") : "webhookbot";
    private static final String EMOJI = StringUtils.isNotBlank(ReloadableProperties.getInstance().getStringValue(
            "slack.bo.alert.emoji")) ? ReloadableProperties.getInstance().getStringValue("slack.bo.alert.emoji")
            : ":ghost:";

    public void sendAlertToBo(String alertMessage) {
        sendSlackNotification(alertMessage, CHANNEL, USER_NAME, EMOJI, WEBHOOK_URL);
    }

    public static void sendAlertToBoStatic(String alertMessage) {
        sendSlackNotification(alertMessage, CHANNEL, USER_NAME, EMOJI, WEBHOOK_URL);
    }

    public static void sendSlackNotification(String message, String channel, String username, String emoji,
            String slackWebhookUrl) {
        try {
            CloseableHttpClient httpClient = HttpClients.createDefault();
            HttpPost httpPost = new HttpPost(slackWebhookUrl);
            String jsonString = JsonMapper.mapObjectToJson(getSlackRequestBody(message, channel, username, emoji));
            httpPost.setEntity(new StringEntity(jsonString));
            httpClient.execute(httpPost);
        } catch (IOException | FacadeCheckedException e) {
            LOGGER.error("Exception while sending message to slack : ", e);
        }
    }

    private static SlackBody getSlackRequestBody(String message, String channel, String username, String emoji) {
        String text = "<!channel> Alert !!!!! " + "\n" + message;
        SlackBody slackBody = new SlackBody(HASH + channel, username, text, emoji);
        return slackBody;
    }
}
