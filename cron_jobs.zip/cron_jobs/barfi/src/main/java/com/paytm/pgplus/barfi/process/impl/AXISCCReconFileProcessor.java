package com.paytm.pgplus.barfi.process.impl;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.exception.PaytmBarfiException;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSProcessor;
import com.paytm.pgplus.barfi.process.XLSSheetProcessor;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;

/**
 * 
 * @author saurabh malviya
 *
 */

@Component(value = "AXISCCReconFileProcessor")
public class AXISCCReconFileProcessor implements Processable, XLSSheetProcessor {

    public static final Logger LOGGER = LogManager.getLogger(AXISCCReconFileProcessor.class);
    private static final Map<String, Enum<ReconFileAdapter.Column>> reconChargingMap = new HashMap<>();
    private static final Map<String, Enum<ReconFileAdapter.Column>> reconRefundMap = new HashMap<>();
    public static final String DELIMETER = "\\|";
    private static final String COLHEAD = "MENAME";

    static {
        reconChargingMap.put("TXN AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        reconChargingMap.put("MERCHANT TRANS REF", ReconFileAdapter.Column.TXN_ID);
        reconChargingMap.put("ORDER ID", ReconFileAdapter.Column.BANK_TXN_ID);
        reconRefundMap.put("ORDER ID", ReconFileAdapter.Column.BANK_TXN_ID);
        reconRefundMap.put("TXN AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        reconRefundMap.put("MERCHANT TRANS REF", ReconFileAdapter.Column.TXN_ID); // for
                                                                                  // bankTxnId
        reconRefundMap.put("ARN", ReconFileAdapter.Column.RRN);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    @Override
    public void process(ReconFileAdapter adapter) {
        LOGGER.info("File Processed..{}", adapter.fileName);

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();

        try {
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconRefundMap, DELIMETER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMETER);
            adapter.markFail("File name format not as specified");
            LOGGER.info("File {} Processed successfully..", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }

    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {
        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int rowEnd = csvList.size();

        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                if (row[row.length - 1].equals("\"REFUND\"")) {
                    reconAdapter.setRefundValues(row, columnMap, canBankTxnIdStartWithZero());
                } else {
                    reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

}
