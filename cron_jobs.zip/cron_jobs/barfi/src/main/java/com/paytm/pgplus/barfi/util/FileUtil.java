package com.paytm.pgplus.barfi.util;

import static com.paytm.pgplus.barfi.util.AdapterConstants.RETRY_COUNT;
import static com.paytm.pgplus.barfi.util.AdapterConstants.SLASH;

import java.io.*;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Agrim
 */

public class FileUtil {

    private static final Logger LOGGER = LogManager.getLogger(FileUtil.class);

    public static void moveFile(String moveFrom, String moveTo) throws Exception {

        /*
         * PGP-23942 Add check for file exist becuase earlier all file created
         * by default when ReconAdaptor.java initialize but as per above JIRA we
         * are restricting to create empty file with header, file will be create
         * when data will be available other file will not be create as in case
         * of earlier behaviour.Actually earlier all file will be created by
         * default.
         */
        if (!isFileExist(moveFrom)) {
            return;
        }

        Path from = FileSystems.getDefault().getPath(moveFrom);
        Path target = FileSystems.getDefault().getPath(moveTo);
        int retry = RETRY_COUNT;
        int counter = 100000;
        while (!move(from, target) && (retry > 0)) {
            retry--;
            while (--counter > 0) {
            }
        }
        if (retry == 0) {
            throw new Exception("File Movement Failed");
        }
        LOGGER.info("File moved from {} to {} successfully", moveFrom, moveTo);
    }

    public static boolean move(Path from, Path target) {
        try {
            Files.move(from, target, StandardCopyOption.REPLACE_EXISTING);
            return true;
        } catch (Exception e) {
            LOGGER.info("File Movement Failed. Retrying", e);
            return false;
        }
    }

    public static void createDir(String dir) {
        File theDir = new File(dir);
        if (!theDir.exists()) {
            theDir.mkdir();
        }
    }

    public static void createDirs(String dir) {
        File theDir = new File(dir);
        theDir.mkdirs();
    }

    /**
     * deletes the given folder
     *
     * @param index
     */
    public static void deleteFolder(File index) {
        try {
            FileUtils.deleteDirectory(index);
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    /**
     * deletes the given folder
     *
     * @param index
     */
    public static void deleteFile(File index) {
        try {
            FileUtils.forceDelete(index);
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    public static String[] getAllSubDirectories(String path) {
        File file = new File(path);
        return file.list(new FilenameFilter() {
            // List only sub-directories from a directory, not files
            @Override
            public boolean accept(File current, String name) {
                return new File(current, name).isDirectory();
            }
        });

    }

    public static int splitFile(String inputfile, double noOfRecord) throws Exception {
        FileInputStream file = new FileInputStream(inputfile);
        Scanner scanner = new Scanner(file);
        String strHeadingS = scanner.nextLine();
        String strLineS;
        int j = 1;
        boolean flag = false;
        while (scanner.hasNextLine()) {
            flag = true;
            FileWriter fstream1 = new FileWriter(inputfile.substring(0, inputfile.lastIndexOf('.')) + j
                    + inputfile.substring(inputfile.lastIndexOf('.')));
            BufferedWriter out = new BufferedWriter(fstream1);
            out.write(strHeadingS);
            out.newLine();
            for (int i = 1; scanner.hasNextLine() && i <= noOfRecord; i++) {
                strLineS = scanner.nextLine();
                if (strLineS != null) {
                    out.write(strLineS);
                    if (i != noOfRecord) {
                        out.newLine();
                    }
                }
            }
            if (scanner.hasNextLine()) {
                j++;
            }
            out.close();
        }
        if (!flag) {
            FileWriter fstream1 = new FileWriter(inputfile.substring(0, inputfile.lastIndexOf('.')) + j
                    + inputfile.substring(inputfile.lastIndexOf('.')));
            BufferedWriter out = new BufferedWriter(fstream1);
            out.write(strHeadingS);
            out.newLine();
            out.close();
        }
        return j;
    }

    public static boolean isFileExist(String filePath) {

        File file = new File(filePath);
        if (!file.exists()) {
            LOGGER.info("file doesn't exist {}", file.getAbsoluteFile());
            return false;
        }
        return true;
    }

    public static void unzip(String zipFilePath, String destDir) {
        File dir = new File(destDir);
        if (!dir.exists())
            dir.mkdirs();
        FileInputStream fis;
        byte[] buffer = new byte[1024];
        try {
            fis = new FileInputStream(zipFilePath);
            ZipInputStream zis = new ZipInputStream(fis);
            ZipEntry ze = zis.getNextEntry();
            while (ze != null) {
                String fileName = ze.getName();
                File newFile = new File(destDir + File.separator + fileName);
                System.out.println("Unzipping to " + newFile.getAbsolutePath());
                new File(newFile.getParent()).mkdirs();
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
                zis.closeEntry();
                ze = zis.getNextEntry();
            }
            zis.closeEntry();
            zis.close();
            fis.close();
        } catch (IOException e) {
            LOGGER.info("Exception while unzipping the file ", e);
        }

    }
}
