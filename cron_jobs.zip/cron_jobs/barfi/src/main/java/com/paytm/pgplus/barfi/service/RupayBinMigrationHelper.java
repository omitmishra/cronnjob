package com.paytm.pgplus.barfi.service;

import com.paytm.pgplus.barfi.util.ReloadableProperties;
import com.paytm.pgplus.facade.bins.models.request.BinConfigAttributes;
import com.paytm.pgplus.facade.bins.models.request.CreateBinRequest;
import com.paytm.pgplus.barfi.dao.impl.BinMasterDaoImpl;
import com.paytm.pgplus.barfi.model.BinMaster;
import com.paytm.pgplus.barfi.util.RupayFileAdapter;
import com.paytm.pgplus.facade.bins.models.request.ModifyBinRequest;
import com.paytm.pgplus.facade.bins.models.response.CreateBinResponse;
import com.paytm.pgplus.facade.bins.models.response.ModifyBinResponse;
import com.paytm.pgplus.facade.bins.services.impl.AlipayBinsServiceImpl;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Component
public class RupayBinMigrationHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(RupayBinMigrationHelper.class);

    private static Map<String, String> allowedCardTypes = new HashMap<>();
    static {
        allowedCardTypes.put("CREDIT_CARD", "CC");
        allowedCardTypes.put("DEBIT_CARD", "DC");
        allowedCardTypes.put("PREPAID_CARD", "CC");
    }

    @Autowired
    private BinMasterDaoImpl binMasterDao;

    @Autowired
    AlipayBinsServiceImpl alipayBinsService;

    public void updateBinMasterList(BinMaster binMaster, RupayFileAdapter adapter) {
        Session session = binMasterDao.getMasterSessionExt();
        Transaction tx = session.beginTransaction();
        try {
            session.update(binMaster);
        } catch (Exception e) {
            LOGGER.error("Failed to update bin: {},  {}", binMaster.getBin(), e.getMessage(), e);
            binMaster.setErrorMessage(e.getMessage());
            adapter.failureList.add(binMaster);
            tx.rollback();
            binMasterDao.closeSessionExt(session);
            return;
        }
        try {
            saveBinMasterInPplus(binMaster);
            tx.commit();
            adapter.successList.add(binMaster);
        } catch (Exception e) {
            tx.rollback();
            binMaster.setErrorMessage(e.getMessage());
            adapter.failureList.add(binMaster);
            LOGGER.error("Failed to update bin: {},  {}", binMaster.getBin(), e.getMessage(), e);
        } finally {
            session.flush();
            binMasterDao.closeSessionExt(session);
        }
    }

    public void saveBinMasterList(BinMaster binMaster, RupayFileAdapter adapter) {
        Session session = binMasterDao.getMasterSessionExt();
        Transaction tx = session.beginTransaction();
        try {
            session.save(binMaster);
        } catch (Exception e) {
            LOGGER.error("Failed to save bin: {},  {}", binMaster.getBin(), e.getMessage(), e);
            binMaster.setErrorMessage(e.getMessage());
            adapter.failureList.add(binMaster);
            tx.rollback();
            binMasterDao.closeSessionExt(session);
            return;
        }
        try {
            saveBinMasterInPplus(binMaster);
            tx.commit();
            adapter.successList.add(binMaster);
        } catch (Exception e) {
            tx.rollback();
            binMaster.setErrorMessage(e.getMessage());
            adapter.failureList.add(binMaster);
            LOGGER.error("Failed to save bin: {},  {}", binMaster.getBin(), e.getMessage(), e);
        } finally {
            session.flush();
            binMasterDao.closeSessionExt(session);
        }
    }

    private static boolean isBinMigrationEnabled() {
        String binMigrationEnabledString = ReloadableProperties.getInstance().getStringValue(
                "rupay.bins.pplus.api.enabled");
        return Boolean.parseBoolean(binMigrationEnabledString);
    }

    private void saveBinMasterInPplus(BinMaster binMaster) throws Exception {

        if (!isBinMigrationEnabled()) {
            return;
        }

        if (!allowedCardTypes.containsKey(binMaster.getCardType())) {
            throw new Exception("Invalid card type");
        }

        BinConfigAttributes binConfigAttributes = BinConfigAttributes.builder().INDIAN("true")
                .ONE_CLICK_SUPPORTED("false").ZERO_SUCCESS_RATE("false").build();

        CreateBinRequest request = CreateBinRequest.builder().bin(binMaster.getBin().toString())
                .blocked(binMaster.getIsActive() == 1 ? "false" : "true").cardScheme(binMaster.getCardName())
                .cardType(allowedCardTypes.get(binMaster.getCardType())).countryCode("IN")
                .institutionId(binMaster.getBankCode()).binConfigAttributes(binConfigAttributes).source("ADMIN")
                .build();
        CreateBinResponse response = alipayBinsService.createBin(request);

        // if duplicate code, call modify bin
        if (response.getResponseCode().equals("027") && Objects.nonNull(response)) {
            ModifyBinRequest modifyBinRequest = ModifyBinRequest.builder().bin(binMaster.getBin().toString())
                    .blocked(binMaster.getIsActive() == 1 ? "false" : "true").cardScheme(binMaster.getCardName())
                    .cardType(allowedCardTypes.get(binMaster.getCardType())).countryCode("IN")
                    .institutionId(binMaster.getBankCode()).binConfigAttributes(binConfigAttributes).source("ADMIN")
                    .build();
            ModifyBinResponse modifyBinResponse = alipayBinsService.modifyBin(modifyBinRequest);
            if (Objects.isNull(modifyBinResponse) || !modifyBinResponse.getResponseCode().equals("01")) {
                throw new Exception("Failed to modify Bin");
            }
        } else if (Objects.isNull(response) || !response.getResponseCode().equals("01")) {
            throw new Exception("Failed to create Bin");
        }
    }

}
