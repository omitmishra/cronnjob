package com.paytm.pgplus.barfi.model;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Sakshi Jain
 */

@Setter
@Getter
public class QueryParam {
    StringBuilder query;
    List<Object> param;
    Integer maxResults;
    Integer firstResult;

    public QueryParam() {
        super();
        this.query = new StringBuilder();
        this.param = new ArrayList<Object>();
        this.maxResults = 100;
        this.firstResult = 0;
    }

    public QueryParam(String query) {
        super();
        this.query = new StringBuilder(query);
        this.param = new ArrayList<Object>();
        this.maxResults = 100;
        this.firstResult = 0;
    }

    public QueryParam(StringBuilder query, List<Object> param) {
        super();
        this.query = query;
        this.param = param;
        this.maxResults = 100;
        this.firstResult = 0;
    }

    public QueryParam(StringBuilder query, List<Object> param, int maxResult) {
        super();
        this.query = query;
        this.param = param;
        this.maxResults = maxResult;
        this.firstResult = 0;
    }
}
