package com.paytm.pgplus.barfi.util;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Agrim
 *
 */

public class AdapterUtil {

    /**
     * A String without surrounded by double-quotes is returned if present
     * 
     * @param String
     * @return String without double-quotes
     * 
     */
    public static String removeQuotes(String str) {
        return str.replaceAll("^\"|\"$", "");
    }

    /**
     * An apostrophe is removed from front if present
     * 
     * @param String
     * @return String with apostrophe
     * 
     */
    public static String checkApostrophe(String str) {
        if (str.charAt(0) == '\'') {
            return str.substring(1);
        }
        return str;
    }

    /**
     * Removes leading zeros in given string
     * 
     * @param str
     * @return
     */
    public static String stripLeadingZeros(String str) {
        return StringUtils.stripStart(str.trim(), "0");
    }

    /**
     * sets zero if blank
     * 
     * @param str
     * @return
     */
    public static String setZeroIfBlank(String str) {

        if (StringUtils.isBlank(str)) {
            return "0";
        }
        return str;
    }

    public static String setZeroIfNotNumeric(String str) {

        if (!StringUtils.isNumeric(str)) {
            return "0";
        }
        return str;
    }

    public static String replaceNoneValueWithEmptyStr(String str) {
        if ("None".equalsIgnoreCase(str)) {
            return "";
        }
        return str;
    }

}
