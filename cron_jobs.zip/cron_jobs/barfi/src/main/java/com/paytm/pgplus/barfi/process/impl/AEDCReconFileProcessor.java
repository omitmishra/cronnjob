package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Sakshi Jain
 */

@Component(value = "AEDCReconFileProcessor")
public class AEDCReconFileProcessor implements Processable, XLSXProcessor {

    private static final Logger LOGGER = LogManager.getLogger(PEDCReconFileProcessor.class);
    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "Merchant ID";
    private static final String SETTLE = "SETTLE";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMapCharging = new HashMap<>();

    static {
        reconMapCharging.put("PayTM_ID", ReconFileAdapter.Column.TXN_ID);
        reconMapCharging.put("Retr Ref Nr", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMapCharging.put("Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMapCharging.put("Response Code", ReconFileAdapter.Column.RESULT_CODE);
        reconMapCharging.put("Transaction type", ReconFileAdapter.Column.TXN_TYPE);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    /**
     *
     * @param adapter
     *            ReconFileAdapter
     */
    @Override
    public void process(ReconFileAdapter adapter) {

        if (StringUtils.containsIgnoreCase(adapter.fileName, SETTLE)) {
            List<String> csvList;
            Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
            try {
                LOGGER.info("Filename: {}", adapter.fileName);
                csvList = extractData(adapter.getProcessingFileHandle());
                columnMap = columnNameToTxnIdMap(adapter, csvList, reconMapCharging, DELIMITER, COLHEAD);
                parseAndWriteCharging(adapter, csvList, columnMap);
                LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
                adapter.markSuccess();
            } catch (IOException e) {
                LOGGER.error(e.getMessage(), e);
                adapter.markFail("Error in reading file " + adapter.fileName);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
                adapter.markFail(e.getMessage());
            }
        } else {
            adapter.markFail("File name format not as specified");
        }
    }

    /**
     *
     * @param reconAdapter
     *            ReconFileAdapter
     * @param csvList
     *            List<String>
     * @param columnMap
     *            Map<Enum<ReconFileAdapter.Column>, Integer>
     * @throws Exception
     *             in case there is parsing error
     */
    private void parseAndWriteCharging(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Enum<ReconFileAdapter.Column>, Integer> columnMap) throws Exception {

        int AmountColNo = getColNum(columnMap, ReconFileAdapter.Column.GROSS_AMT);
        int ExtColNo = getColNum(columnMap, ReconFileAdapter.Column.TXN_ID);
        int respCodeColNo = getColNum(columnMap, ReconFileAdapter.Column.RESULT_CODE);
        int txnTypColNo = getColNum(columnMap, ReconFileAdapter.Column.TXN_TYPE);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(DELIMITER);
                if (StringUtils.isBlank(r) || row.length <= ExtColNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(AmountColNo, row))) {
                    continue;
                }
                if (!"00".equalsIgnoreCase(reconAdapter.getTxnType(respCodeColNo, row))) {
                    continue;
                }
                if ("00".equalsIgnoreCase(reconAdapter.getTxnType(txnTypColNo, row))) {
                    reconAdapter.setChargingValuesColumnIntegerMap(row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }
}