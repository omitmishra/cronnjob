package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component(value = "KotakDcEmiReconFileProcessor")
public class KotakDcEmiReconFileProcessor implements Processable, XLSXProcessor {

    private static final Logger LOGGER = LogManager.getLogger(KotakDcEmiReconFileProcessor.class);
    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "APPL";

    private static final Map<String, Enum<ReconFileAdapter.Column>> reconChargingMap = new HashMap<>();

    static {
        reconChargingMap.put("APAC", ReconFileAdapter.Column.BANK_TXN_ID);
        reconChargingMap.put("Contract No", ReconFileAdapter.Column.TXN_ID);
        reconChargingMap.put("Pay Transid", ReconFileAdapter.Column.RRN);
        reconChargingMap.put("Apac Amount", ReconFileAdapter.Column.GROSS_AMT);
    }

    @Override
    public void process(ReconFileAdapter adapter) {
        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconChargingMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File: {} processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }

    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

}