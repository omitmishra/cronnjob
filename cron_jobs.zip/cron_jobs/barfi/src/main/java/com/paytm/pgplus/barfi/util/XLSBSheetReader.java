package com.paytm.pgplus.barfi.util;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.CellAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.binary.XSSFBSharedStringsTable;
import org.apache.poi.xssf.binary.XSSFBSheetHandler;
import org.apache.poi.xssf.binary.XSSFBStylesTable;
import org.apache.poi.xssf.eventusermodel.XSSFBReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class XLSBSheetReader {

    /**
     * Uses the XSSF Event SAX helpers to do most of the work of parsing the
     * Sheet XML, and outputs the contents as a (basic) CSV.
     */
    private class SheetToCSV implements XSSFSheetXMLHandler.SheetContentsHandler {
        private boolean firstCellOfRow = false;
        private int currentRow = -1;
        private int currentCol = -1;
        private List<String> csvListTemp = new ArrayList<String>();
        private StringBuilder sb = new StringBuilder();

        private void outputMissingRows(int number) {
            for (int i = 0; i < number; i++) {
                for (int j = 0; j < minColumns; j++) {
                    sb.append("|");
                }
                csvListTemp.add(sb.toString());
                sb.setLength(0);
            }
        }

        @Override
        public void startRow(int rowNum) {
            // If there were gaps, output the missing rows
            outputMissingRows(rowNum - currentRow - 1);
            // Prepare for this row
            firstCellOfRow = true;
            currentRow = rowNum;
            currentCol = -1;
        }

        @Override
        public void endRow(int rowNum) {
            // Ensure the minimum number of columns
            for (int i = currentCol; i < minColumns; i++) {
                sb.append("|");
            }
            csvListTemp.add(sb.toString());
            sb.setLength(0);
        }

        @Override
        public void cell(String cellReference, String formattedValue, XSSFComment comment) {
            if (firstCellOfRow) {
                firstCellOfRow = false;
            } else {
                sb.append("|");
            }

            // gracefully handle missing CellRef here in a similar way as
            // XSSFCell does
            if (cellReference == null) {
                cellReference = new CellAddress(currentRow, currentCol).formatAsString();
            }

            // Did we miss any cells?
            int thisCol = (new CellReference(cellReference)).getCol();
            int missedCols = thisCol - currentCol - 1;
            for (int i = 0; i < missedCols; i++) {
                sb.append("|");
            }
            currentCol = thisCol;

            // Number or string?
            try {
                Double.parseDouble(formattedValue);
                sb.append(formattedValue);
            } catch (NumberFormatException e) {
                sb.append("\"");
                sb.append(formattedValue);
                sb.append("\"");
            }
        }

        @Override
        public void headerFooter(String text, boolean isHeader, String tagName) {
            // Skip, no headers or footers in CSV
        }

        public List<String> getCsvListTemp() {
            return csvListTemp;
        }

    }

    // /////////////////////////////////////

    private final OPCPackage xlsbPackage;

    /**
     * Number of columns to read starting with leftmost
     */
    private final int minColumns;

    /**
     * Destination for data
     */
    private Map<String, List<String>> csvMap;

    private int sheetNumber = 0;

    public Map<String, List<String>> getCsvMap() {
        return csvMap;
    }

    /**
     * Creates a new XLSB -> CSV converter
     *
     * @param pkg
     *            The XLSB package to process
     * @param output
     *            The PrintStream to output the CSV to
     * @param minColumns
     *            The minimum number of columns to output, or -1 for no minimum
     */
    public XLSBSheetReader(OPCPackage pkg, Map<String, List<String>> csvMap, int minColumns, int sheetNumber) {
        this.xlsbPackage = pkg;
        this.minColumns = minColumns;
        this.csvMap = csvMap;
        this.sheetNumber = sheetNumber;
    }

    /**
     * Parses and shows the content of one sheet using the specified styles and
     * shared-strings tables.
     *
     * @param styles
     * @param strings
     * @param sheetInputStream
     */
    public void processSheet(XSSFBStylesTable styles, XSSFBSharedStringsTable strings,
            XSSFSheetXMLHandler.SheetContentsHandler sheetHandler, InputStream sheetInputStream) throws IOException {
        DataFormatter formatter = new DataFormatter();
        XSSFBSheetHandler handler = new XSSFBSheetHandler(sheetInputStream, styles, null, strings, sheetHandler,
                formatter, false);
        handler.parse();
    }

    /**
     * Initiates the processing of the XLS workbook file to CSV.
     *
     * @throws IOException
     * @throws OpenXML4JException
     * @throws ParserConfigurationException
     * @throws SAXException
     */
    public void process() throws IOException, OpenXML4JException, ParserConfigurationException, SAXException {
        XSSFBSharedStringsTable strings = new XSSFBSharedStringsTable(this.xlsbPackage);
        XSSFBReader xssfbReader = new XSSFBReader(this.xlsbPackage);
        XSSFBStylesTable styles = xssfbReader.getXSSFBStylesTable();
        XSSFBReader.SheetIterator iter = (XSSFBReader.SheetIterator) xssfbReader.getSheetsData();
        int sheetIndex = 0;

        while (iter.hasNext() && sheetIndex < sheetNumber) {
            InputStream stream = iter.next();
            String sheetName = iter.getSheetName().toUpperCase();
            XLSBSheetReader.SheetToCSV converter = new XLSBSheetReader.SheetToCSV();
            processSheet(styles, strings, converter, stream);
            stream.close();
            csvMap.put(sheetName, converter.getCsvListTemp());
            sheetIndex++;
        }
    }

}
