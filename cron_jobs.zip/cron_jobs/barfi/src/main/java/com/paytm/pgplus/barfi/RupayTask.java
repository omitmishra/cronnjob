package com.paytm.pgplus.barfi;

import com.paytm.pgplus.barfi.process.RupayProcessable;
import com.paytm.pgplus.barfi.util.ApplicationContextProvider;
import com.paytm.pgplus.barfi.util.ProcessorBean;
import com.paytm.pgplus.barfi.util.RupayFileAdapter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;

/**
 * @author Sakshi Jain Executable Task for NPCI Rupay file
 */

public class RupayTask implements Runnable {

    private static final Logger LOGGER = LogManager.getLogger(RupayTask.class);
    private RupayFileAdapter adapter;
    private String rupayCode;

    public RupayTask(File file) {
        this.adapter = new RupayFileAdapter(file);
        this.rupayCode = adapter.beanName;
    }

    /**
     * Rupay Task which runs every fortnight
     */
    @Override
    public void run() {

        LOGGER.info("RupayTask Submitted for updating BIN details");
        try {
            RupayProcessable worker = (RupayProcessable) ApplicationContextProvider.getApplicationContext().getBean(
                    ProcessorBean.valueOf(rupayCode).getBean());
            worker.process(adapter);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Rupay processor not supported");
        }
    }
}