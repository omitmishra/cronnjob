package com.paytm.pgplus.barfi;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.stereotype.Component;

/**
 * Task Executor that performs a {@link Task} in concurrent manner<br/>
 * Fixed Thread Pool with 10 Threads is used to perform multiple {@link Task} in
 * parallel
 * 
 * @author Lalit Mehra
 *
 */
@Component
public class TaskExecutor {

    private static final ExecutorService executor = Executors.newFixedThreadPool(2);

    public void submit(Runnable task) {
        executor.execute(task);
    }

}
