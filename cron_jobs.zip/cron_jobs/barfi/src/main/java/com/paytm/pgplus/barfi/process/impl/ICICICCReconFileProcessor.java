package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 * @author Agrim
 * @author Shubham
 *
 */

@Component(value = "ICICIBankCardReconFileProcessor")
public class ICICICCReconFileProcessor implements Processable, XLSProcessor {

    private static final Logger LOGGER = LogManager.getLogger(ICICICCReconFileProcessor.class);

    private static final String REFUND = "DEBIT";
    private static final String CHARGING = "CREDIT";
    protected static final String DELIMITER = "\\|";
    protected static final String COLHEAD = "Trxn Date";
    protected static final Integer RECORD_IDENTIFIER_LENGTH = 11;
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("Gross Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("Session ID", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("FT Number", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("DR_CR", ReconFileAdapter.Column.TXN_TYPE);
        reconMap.put("ARN", ReconFileAdapter.Column.RRN);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;

        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            csvList = removeUnmatched(csvList, columnMap);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER, CHARGING, REFUND);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    /**
     * Remove unmatched records in given list in the form of {@link List
     * <String>}
     * 
     * @param csvList
     * @param columnMap
     * @return matching records in the form of {@link List}
     */
    protected List<String> removeUnmatched(List<String> csvList, Map<Integer, Enum<ReconFileAdapter.Column>> columnMap) {

        int idenfierColIndex = -1;
        for (Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (ReconFileAdapter.Column.BANK_TXN_ID.equals(entry.getValue())) {
                idenfierColIndex = entry.getKey();
                break;
            }
        }

        List<String> matchingRecordList = new ArrayList<>();
        for (int i = 0; i < csvList.size(); i++) {

            matchingRecordList.add(csvList.get(i));
            String rowData = csvList.get(i);

            if (StringUtils.isBlank(rowData)) {
                continue;
            }
            String[] row = rowData.split(DELIMITER);
            if (row.length == 0) {
                continue;
            }
            row[0] = AdapterUtil.removeQuotes(row[0]);
            if (!row[0].equals(COLHEAD)) {
                continue;
            }

            for (int j = i + 1; j < csvList.size(); j++) {
                rowData = csvList.get(j);
                row = rowData.split(DELIMITER);

                if (row.length > idenfierColIndex && !StringUtils.isBlank(row[idenfierColIndex])) {
                    String val = AdapterUtil.removeQuotes(row[idenfierColIndex]).trim();
                    val = StringUtils.stripStart(val, "0");
                    if (!RECORD_IDENTIFIER_LENGTH.equals(val.length())) {
                        matchingRecordList.add(csvList.get(j));
                    }
                }
            }
            break;
        }
        return matchingRecordList;
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }
}
