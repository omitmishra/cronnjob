package com.paytm.pgplus.barfi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Worksheet {

    @Override
    public String toString() {
        return "Worksheet [table=" + table + "]";
    }

    @JacksonXmlProperty(localName = "Table")
    private TableXML table;

    public TableXML getTable() {
        return table;
    }

    public void setTable(TableXML table) {
        this.table = table;
    }

}
