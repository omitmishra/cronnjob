package com.paytm.pgplus.barfi.dao.impl;

import com.paytm.pgplus.barfi.dao.IBaseDao;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.util.Assert;

import java.io.Serializable;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @param <T>
 * @param <Id>
 *            Abstract class This class is base class and responsible for CRUD
 *            operation for Dao
 * @author Sakshi Jain
 */
@Repository
public abstract class BaseAbstractDao<T, Id extends Serializable> implements IBaseDao<T, Id> {

    private static final Logger LOGGER = LoggerFactory.getLogger(BaseAbstractDao.class);
    private static Pattern queryPattern = Pattern.compile(":(.*?)(\\s|$|,)");
    private static String EMPTY = "";

    @Autowired
    @Qualifier("sessionFactory")
    private SessionFactory sessionFactoryMaster;

    @Autowired
    @Qualifier("slaveSessionFactory")
    private SessionFactory sessionFactorySlave;

    /**
     * @return Session object
     */
    private Session getMasterSession() {
        return sessionFactoryMaster.openSession();
    }

    /**
     * @return Session object
     */
    private Session getSlaveSession() {
        return sessionFactorySlave.openSession();
    }

    /**
     * @param session
     *            Session
     */
    private void closeSession(Session session) {
        if (session != null)
            session.close();
    }

    /**
     * @param entity
     *            List<T>
     */
    @Override
    public void saveBatch(List<T> entity) {
        Assert.notNull(entity, "Batch list can not be null");
        Session session = getMasterSession();
        for (T t : entity) {
            session.save(t);
        }
        LOGGER.debug("Batch Data saved successfully! data : {}", entity);
        session.flush();
        closeSession(session);
    }

    public Session getMasterSessionExt() {
        return getMasterSession();
    }

    public void closeSessionExt(Session session) {
        closeSession(session);
    }

    /**
     * @param entity
     *            List<T>
     */
    @Override
    public void updateBatch(List<T> entity) {
        Assert.notNull(entity, "Batch list can not be null");
        Session session = getMasterSession();
        for (T t : entity) {
            session.merge(t);
        }
        LOGGER.debug("Batch Data updated successfully! data : {}", entity);
        session.flush();
        closeSession(session);
    }

    /**
     * @param queryString
     *            String
     * @param params
     *            Object...
     * @return List<T>
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<T> findByHqlQuery(String queryString, Object... params) {
        LOGGER.debug("Query being fired in hql is : " + queryString);
        Assert.notNull(queryString, "queryString can not be null");
        Session session = getSlaveSession();
        Query query = session.createQuery(queryString);
        addQueryParameters(query, params);
        List<T> entityList = query.list();
        closeSession(session);
        LOGGER.debug("Total Found {} entries for Query : {}", entityList.size(), queryString);
        return entityList;
    }

    /**
     * @param query
     *            Query
     * @param params
     *            Object...
     */
    @SuppressWarnings("unchecked")
    private void addQueryParameters(Query query, Object... params) {
        LOGGER.debug("Params are {} ", params);
        if (params != null && params.length > 0) {
            Matcher matcher = queryPattern.matcher(query.getQueryString());
            for (int i = 0; matcher.find(); i++) {
                if (params[i] instanceof List) {
                    query.setParameterList(matcher.group(1).replace(")", EMPTY), (List<T>) params[i]);
                } else if (params[i] instanceof Set) {
                    query.setParameterList(matcher.group(1).replace(")", EMPTY), (Set<T>) params[i]);
                } else {
                    query.setParameter(matcher.group(1).replace(")", EMPTY), params[i]);
                }
            }
        }
    }
}
