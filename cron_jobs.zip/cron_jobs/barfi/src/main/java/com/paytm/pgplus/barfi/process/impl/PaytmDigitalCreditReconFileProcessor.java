package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

/**
 * @author Karan Kapoor
 *
 */
@Component(value = "PaytmDigitalCreditReconFileProcessor")
public class PaytmDigitalCreditReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(PaytmDigitalCreditReconFileProcessor.class);

    private static final String DELIMITER = ",";
    private static final String COLHEAD = "transaction_id";
    private static final String REFUND = "refund";
    private static final String CHARGING = "pay";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("pg_transaction_id", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("transaction_id", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("lender_transaction_id", ReconFileAdapter.Column.RRN);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            if (adapter.fileName.toLowerCase().contains(REFUND)) {
                parseAndWriteRefund(adapter, csvList, columnMap, DELIMITER);
            } else if (adapter.fileName.toLowerCase().contains(CHARGING)) {
                parseAndWriteCharging(adapter, csvList, columnMap, DELIMITER);
            } else {
                adapter.markFail("File name format not as specified");
            }
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }
}
