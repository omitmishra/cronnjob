package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.dao.IHdfcEdcDao;
import com.paytm.pgplus.barfi.dao.IOfflineRefundTxnDao;
import com.paytm.pgplus.barfi.exception.PaytmBarfiException;
import com.paytm.pgplus.barfi.model.EdcHdfcBatchUpload;
import com.paytm.pgplus.barfi.model.OfflineRefundTxn;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.*;
import com.paytm.pgplus.barfi.worker.EmailWorker;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.lang3.StringUtils;
import org.file.util.CSVFileUtil;
import org.file.util.FileUtil;
import org.file.util.exception.FileUtilException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Component(value = "HDFCEDCReconFileProcessor")
public class HDFCEDCReconFileProcessor implements Processable, XLSXProcessor {

    @Autowired
    private IHdfcEdcDao hdfcEdcDao;
    @Autowired
    private IOfflineRefundTxnDao iOfflineRefundTxnDao;

    private String HEADER = PropertyContext.getBarfiProxyProperties().getProperty("report.header");
    private String FOOTER = PropertyContext.getBarfiProxyProperties().getProperty("report.footer");
    private static List<String> sendTo = ReloadableProperties.getInstance().getList("mail.id.report");

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "MERCHANT CODE";
    private static final int HDFC_EDC_BATCH_SIZE = 500;
    private static final String EXT_SERIAL_NO = "extSerialNo";
    private static final String PIPE = "|";
    private static final String SEQUENCE_NUMBER = "SEQUENCE NUMBER";

    private static final String REFUND = "CVD";
    private static final String CHARGING = "BAT";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new LinkedHashMap<>();

    static {
        sendTo.add("edc.techops@paytm.com");
        reconMap.put("DOMESTIC AMT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("SEQUENCE NUMBER", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("APPROV CODE", ReconFileAdapter.Column.AUTH_CODE);
        reconMap.put("INTNL AMT", ReconFileAdapter.Column.NET_AMT);
        reconMap.put("TERMINAL NUMBER", ReconFileAdapter.Column.BANK_TID);
        reconMap.put("REC FMT", ReconFileAdapter.Column.TXN_TYPE);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        try {
            log.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = columnNameToTxnIdMap(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            final Integer indexOfBankTid = columnMap.get(ReconFileAdapter.Column.BANK_TID);
            final Integer indexOfAuthCode = columnMap.get(ReconFileAdapter.Column.AUTH_CODE);
            final Integer indexOfTxnType = columnMap.get(ReconFileAdapter.Column.TXN_TYPE);
            final Integer indexOfRrnCode = columnMap.get(ReconFileAdapter.Column.RRN);

            log.info("Index of auth: " + indexOfAuthCode);
            log.info("Index of tid: " + indexOfBankTid);

            final Map<String, String> authTidMapCharging = new HashMap<>();
            final Map<String, String> authTidMapRefund = new HashMap<>();
            String csvListHeader = csvList.get(0);
            String csvNewHeader = csvListHeader + PIPE + EXT_SERIAL_NO;
            csvList.set(0, csvNewHeader);

            int batch = HDFC_EDC_BATCH_SIZE;
            boolean isNextBatch = true;
            int startIndex = 1;
            int endIndex = csvList.size();
            log.info("Initially run for startIndex : {} , isNextBatch : {}", startIndex, isNextBatch);
            List<String> csvBaseList = new ArrayList<String>();
            // List<String> listOfRRNs = new ArrayList<String>();
            List<String> chargingListOfAuthCode = new ArrayList<String>();
            List<String> chargingListOfBankTid = new ArrayList<String>();
            List<String> refundListOfAuthCode = new ArrayList<String>();
            List<String> refundListOfBankTid = new ArrayList<String>();
            List<String> corruptedList = new ArrayList<String>();
            List<String> extraRecords = new ArrayList<String>();

            Boolean ignore = false;
            while (isNextBatch) {
                List<EdcHdfcBatchUpload> edcHdfcBatchUploadList = null;
                List<OfflineRefundTxn> offlineRefundTxnList = null;
                if (startIndex >= endIndex) {
                    isNextBatch = false;
                } else if (batch > (endIndex - startIndex)) {
                    batch = endIndex - startIndex;
                }
                if (isNextBatch) {
                    List<String> csvSubList = csvList.subList(startIndex, startIndex + batch);
                    for (String csvRecord : csvSubList) {
                        if (ignore && StringUtils.isEmpty(removeAllQuotes(csvRecord).replace(DELIMITER, "").trim())) {
                            ignore = true;
                            extraRecords.add(csvRecord);
                        }
                        String[] rowData = removeAllQuotes(csvRecord).split(DELIMITER);
                        if (rowData.length >= indexOfAuthCode && !StringUtils.isEmpty(rowData[indexOfAuthCode].trim())
                                && rowData.length >= indexOfBankTid
                                && !StringUtils.isEmpty(rowData[indexOfBankTid].trim())) {
                            if (REFUND.equals(adapter.getTxnType(indexOfTxnType, rowData))) {
                                refundListOfBankTid.add(rowData[indexOfBankTid].trim());
                                refundListOfAuthCode.add(rowData[indexOfAuthCode].trim());
                            } else if (CHARGING.equals(adapter.getTxnType(indexOfTxnType, rowData))) {
                                chargingListOfBankTid.add(rowData[indexOfBankTid].trim());
                                chargingListOfAuthCode.add(rowData[indexOfAuthCode].trim());
                            }
                        } else {
                            LOGGER.error("AUTH_CODE or BANK_TID not found" + rowData);
                        }
                    }
                    if (CollectionUtils.isNotEmpty(extraRecords)) {
                        csvSubList.removeAll(extraRecords);
                        extraRecords.clear();
                    }
                    LOGGER.info("File read successfully");
                    if ((!CollectionUtils.isEmpty(chargingListOfAuthCode))
                            && (!CollectionUtils.isEmpty(chargingListOfBankTid))) {
                        edcHdfcBatchUploadList = hdfcEdcDao.fetchTransactionId(chargingListOfAuthCode,
                                chargingListOfBankTid);
                        edcHdfcBatchUploadList.stream().forEach(
                                x -> authTidMapCharging.put(x.getAuthCode() + '_' + x.getBankTid(),
                                        x.getExternalSerialNo()+ '_' +x.getRrnCode()));
                    }

                    if ((!CollectionUtils.isEmpty(refundListOfAuthCode))
                            && (!CollectionUtils.isEmpty(refundListOfBankTid))) {
                        offlineRefundTxnList = iOfflineRefundTxnDao.fetchTransactionId(refundListOfAuthCode,
                                refundListOfBankTid);
                        offlineRefundTxnList.stream().forEach(
                                x -> authTidMapRefund.put(x.getAuthCode() + '_' + x.getTid(), x.getExtSerialNum()+ '_' +x.getRrnCode()));
                    }

                    if ((!CollectionUtils.isEmpty(edcHdfcBatchUploadList))
                            || (!CollectionUtils.isEmpty(offlineRefundTxnList))) {

                        csvSubList = csvSubList
                                .stream()
                                .filter(x -> {
                                    String valArgs[] = removeAllQuotes(x).split(DELIMITER);
                                    if (valArgs != null && valArgs.length >= indexOfAuthCode
                                            && valArgs.length >= indexOfBankTid) {
                                        return true;
                                    }
                                    return false;
                                })
                                .map(x -> {
                                    String txnId = "";
                                    String rrnCode = "";
                                    String txnRrnVal = "";
                                    if (REFUND.equals(removeAllQuotes(x).split(DELIMITER)[indexOfTxnType].trim())) {
                                        txnRrnVal = authTidMapRefund
                                                .get(removeAllQuotes(x).split(DELIMITER)[indexOfAuthCode].trim() + '_'
                                                        + removeAllQuotes(x).split(DELIMITER)[indexOfBankTid].trim());
                                        if(StringUtils.isNotEmpty(txnRrnVal)){
                                            txnId = txnRrnVal.split("_")[0];
                                            rrnCode = txnRrnVal.split("_")[1];
                                        }
                                    } else if (CHARGING.equals(removeAllQuotes(x).split(DELIMITER)[indexOfTxnType]
                                            .trim())) {
                                        txnRrnVal = authTidMapCharging
                                                .get(removeAllQuotes(x).split(DELIMITER)[indexOfAuthCode].trim() + '_'
                                                        + removeAllQuotes(x).split(DELIMITER)[indexOfBankTid].trim());
                                        if(StringUtils.isNotEmpty(txnRrnVal)){
                                            txnId = txnRrnVal.split("_")[0];
                                            rrnCode = txnRrnVal.split("_")[1];
                                        }
                                    }

                                    if (StringUtils.isEmpty(txnId)) {
                                        LOGGER.info("TXN_ID not found in database for HDFCEDC" + x);
                                        LOGGER.info("key {} ",
                                                removeAllQuotes(x).split(DELIMITER)[indexOfAuthCode].trim() + '_'
                                                        + removeAllQuotes(x).split(DELIMITER)[indexOfBankTid].trim());
                                    }
                                    if (StringUtils.isEmpty(txnId))
                                        corruptedList.add(x);
                                    else{
                                        String[] rowDataFinal = removeAllQuotes(x).split(DELIMITER);
                                        if(rowDataFinal.length - 1 >= indexOfRrnCode) {
                                            rowDataFinal[indexOfRrnCode] = rrnCode;
                                            x = convertStringArrayToString(rowDataFinal, PIPE);
                                        }else{
                                            x = x.substring(0, x.length() - 1)+rrnCode+"\"";
                                        }
                                    }
                                    return (StringUtils.isEmpty(txnId) ? "" : x + PIPE + txnId);
                                }).filter(x -> StringUtils.isNotEmpty(x)).collect(Collectors.toList());

                    }
                    csvBaseList.addAll(csvSubList);
                    if (CollectionUtils.isNotEmpty(edcHdfcBatchUploadList))
                        edcHdfcBatchUploadList.clear();
                    if (CollectionUtils.isNotEmpty(offlineRefundTxnList))
                        offlineRefundTxnList.clear();
                    chargingListOfAuthCode.clear();
                    chargingListOfBankTid.clear();
                    refundListOfAuthCode.clear();
                    refundListOfBankTid.clear();
                    authTidMapCharging.clear();
                    authTidMapRefund.clear();
                    startIndex += batch;
                }
            }
            reconMap.put(EXT_SERIAL_NO, ReconFileAdapter.Column.TXN_ID);
            csvBaseList.add(0, csvList.get(0));
            columnMap.clear();
            Map<Enum<ReconFileAdapter.Column>, Integer> newColumnMap = columnNameToTxnIdMap(adapter, csvBaseList,
                    reconMap, DELIMITER, COLHEAD);
            LOGGER.info("Corrupted size for HDFC-EDC {} ", corruptedList.size());
            if (CollectionUtils.isNotEmpty(corruptedList)) {
                corruptedList.add(0, csvList.get(0));
                StringBuilder body = csvToHtmlTable(listToString(corruptedList));
                sendEmail(body, "Corrupted records of HDFC EDC:" + adapter.fileName);

            }

            parseAndWrite(adapter, csvBaseList, DELIMITER, newColumnMap, CHARGING, REFUND);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();

        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private static String convertStringArrayToString(String[] strArr, String delimiter) {
        StringBuilder sb = new StringBuilder();
        for (String str : strArr)
            sb.append(str).append(delimiter);
        return sb.substring(0, sb.length() - 1);
    }

    private void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList, String delimiter,
            Map<Enum<ReconFileAdapter.Column>, Integer> columnMap, String charging, String refund) throws Exception {
        int colNo = reconAdapter.getColumnNumberWRTTxnType(columnMap);
        int colNoGrossAmount = getColumnNumberAmount(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 1; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r)) {
                    continue;
                }

                if (colNoGrossAmount >= 0 && colNoGrossAmount < row.length
                        && StringUtils.isNotEmpty(row[colNoGrossAmount]) && row[colNoGrossAmount].trim().equals("0")) {
                    {
                        int columnNumberIntlAmount = getColumnNumberIntlAmount(columnMap);
                        if (columnNumberIntlAmount >= 0 && columnNumberIntlAmount < row.length) {

                            // use an alternative map, as changing existing
                            // map will go for all rows
                            Map<Enum<ReconFileAdapter.Column>, Integer> alternativeColumnMap = new HashMap<>(columnMap);

                            // remove existing entry for GROSS_AMT column
                            alternativeColumnMap.remove(ReconFileAdapter.Column.GROSS_AMT);
                            alternativeColumnMap.put(ReconFileAdapter.Column.GROSS_AMT, columnNumberIntlAmount);
                            reconAdapter.setChargingValuesColumnIntegerMap(row, alternativeColumnMap,
                                    canBankTxnIdStartWithZero());

                            // continue loop over for other rows
                            continue;
                        }
                    }
                }

                if (refund.equals(reconAdapter.getTxnType(colNo, row))) {
                    reconAdapter.setRefundValuesColumnIntegerMap(row, columnMap, canBankTxnIdStartWithZero());
                }
                if (charging.equals(reconAdapter.getTxnType(colNo, row))) {
                    reconAdapter.setChargingValuesColumnIntegerMap(row, columnMap, canBankTxnIdStartWithZero());
                }

            } catch (Exception e) {
                if (rowNum > 0) {
                    LOGGER.error("Previous at line " + rowNum + " data:" + csvList.get(rowNum - 1), e);
                }
                for (Map.Entry<Enum<ReconFileAdapter.Column>, Integer> mapEntry : columnMap.entrySet()) {
                    LOGGER.info("Key{}  and value{} ", mapEntry.getKey(), mapEntry.getValue());
                }
                LOGGER.error("Error at line " + rowNum + " data:" + csvList.get(rowNum), e);
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    public static String removeAllQuotes(String str) {
        return str.replaceAll("[\"*\'*]", "");
    }

    public static String removeQuotes(String str) {
        return str.replaceAll("^\"|\"$", "");
    }

    public Map<Enum<ReconFileAdapter.Column>, Integer> columnNameToTxnIdMap(ReconFileAdapter reconAdapter,
            List<String> csvList, Map<String, Enum<ReconFileAdapter.Column>> reconMap, String delimiter, String colHead)
            throws IOException, PaytmBarfiException {
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap = new HashMap<>();
        for (String r : csvList) {
            if (StringUtils.isBlank(r)) {
                continue;
            }
            String[] row = r.split(delimiter);
            if (row.length == 0) {
                continue;
            }
            row[0] = removeQuotes(row[0]).trim();
            if (!row[0].equals(colHead)) {
                continue;
            }
            for (int columnNo = 0; columnNo < row.length; columnNo++) {
                if (StringUtils.isBlank(row[columnNo])) {
                    continue;
                }
                row[columnNo] = removeQuotes(row[columnNo]);
                if (reconMap.containsKey(row[columnNo].trim())) {
                    columnMap.put(reconMap.get(row[columnNo].trim()), columnNo);
                    if (SEQUENCE_NUMBER.equals(row[columnNo].trim())) {
                        columnMap.put(ReconFileAdapter.Column.RRN, columnNo);
                    }
                }
            }
            break;
        }
        if (MapUtils.isEmpty(columnMap)) {
            throw new PaytmBarfiException(" Exception - Process Failed due to missing column heads,  File- "
                    + reconAdapter.fileName);
        }
        return columnMap;
    }

    public int getColumnNumberAmount(Map<Enum<ReconFileAdapter.Column>, Integer> columnMap) {
        for (Map.Entry<Enum<ReconFileAdapter.Column>, Integer> entry : columnMap.entrySet()) {
            if (ReconFileAdapter.Column.GROSS_AMT.equals(entry.getKey())) {
                return entry.getValue();
            }
        }
        return -1;
    }

    public int getColumnNumberIntlAmount(Map<Enum<ReconFileAdapter.Column>, Integer> columnMap) {
        for (Map.Entry<Enum<ReconFileAdapter.Column>, Integer> entry : columnMap.entrySet()) {
            if (ReconFileAdapter.Column.NET_AMT.equals(entry.getKey())) {
                return entry.getValue();
            }
        }
        return -1;
    }

    public void sendEmail(StringBuilder body, String mailSubject) {

        EmailWorker emailWorker = (EmailWorker) ApplicationContextProvider.getApplicationContext().getBean(
                "emailWorker");
        emailWorker.sendMail(sendTo.toArray(new String[0]), mailSubject, body.toString());
    }

    public StringBuilder listToString(List<String> list) {

        StringBuilder builder = new StringBuilder();
        for (String data : list) {
            builder.append(data).append("\n");
        }
        return builder;
    }

    private StringBuilder csvToHtmlTable(StringBuilder strb) {
        String str = strb.toString();
        str = handleNewLine(str);
        String[] lines = str.split("\n");

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < lines.length; i++) {

            List<String> rowData = getTableData(lines[i]);

            if (checkIfEmptyRow(rowData)) {
                continue;
            }

            result.append("<tr>");
            for (String td : rowData) {
                if (i == 0)
                    result.append(String.format("<th style=\"background-color:#808080\">%s</th>\n", td));
                else
                    result.append(String.format("<td>%s</td>\n", td));
            }
            result.append("</tr>");
        }

        return new StringBuilder(
                String.format(
                        "<html><head><style>table, th, td { border: 1px solid black;}</style></head><body><table>\n%s</table></body></html>",
                        result.toString()));
    }

    private static String handleNewLine(String str) {

        StringBuilder buffer = new StringBuilder();
        char[] chars = str.toCharArray();

        boolean inquote = false;

        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == '"') {
                inquote = !inquote;
            }

            if (chars[i] == '\n' && inquote) {
                buffer.append("<br>");
            } else {
                buffer.append(chars[i]);
            }
        }

        return buffer.toString();
    }

    private List<String> getTableData(String str) {
        List<String> data = new ArrayList<String>();

        boolean inquote = false;
        StringBuilder buffer = new StringBuilder();
        char[] chars = str.toCharArray();

        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == '"') {
                inquote = !inquote;
                continue;
            }

            if (chars[i] == '|') {
                if (inquote) {
                    buffer.append(chars[i]);
                } else {
                    data.add(buffer.toString());
                    buffer.delete(0, buffer.length());
                }
            } else {
                buffer.append(chars[i]);
            }

        }

        data.add(buffer.toString().trim());

        return data;
    }

    private boolean checkIfEmptyRow(List<String> rowData) {

        for (String td : rowData) {
            if (!td.isEmpty()) {
                return false;
            }
        }

        return true;
    }

}