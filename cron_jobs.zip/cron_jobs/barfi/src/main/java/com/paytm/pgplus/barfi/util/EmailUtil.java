package com.paytm.pgplus.barfi.util;

import com.paytm.pgplus.barfi.queue.service.IProducer;
import com.paytm.pgplus.rabbitmq.communication.models.EmailInfo;
import com.paytm.pgplus.rabbitmq.enums.EnumRoutingKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class EmailUtil {

    private static final Logger LOGGER = LoggerFactory.getLogger(EmailUtil.class);

    public static EmailInfo getEmailInfo(String[] to, String[] cC, String[] bCC, String from, String replyTo,
            String subject, String message) {

        EmailInfo emailInfo = new EmailInfo();
        emailInfo.setTo(to);
        emailInfo.setBcc(bCC);
        emailInfo.setCc(cC);
        emailInfo.setFrom(from);
        emailInfo.setMessage(message);
        emailInfo.setReplyTo(replyTo);
        emailInfo.setSubject(subject);

        return emailInfo;
    }

    private static EmailInfo createEmailInfo(String msg, String emailSubject) {
        LOGGER.info("Creating Email Info Object..");

        String[] to = { "santosh11.kumar@paytm.com", "neeraj.aggarwal@paytm.com" };
        String[] cC = {};
        String[] bCC = {};
        String from = "alerts@paytm.com";
        String replyTo = "santosh11.kumar@paytm.com";
        return getEmailInfo(to, cC, bCC, from, replyTo, emailSubject, msg);
    }

    public static boolean sendEmailWithAttachment(String msg, String subject, List<String> fileList) {
        boolean flag = false;
        try {
            IProducer queueService = (IProducer) ApplicationContextProvider.getApplicationContext().getBean(
                    "queueServiceImpl");
            EmailInfo emailInfo = createEmailInfo(msg, subject);

            if (emailInfo == null) {
                return flag;
            }
            emailInfo.setFileList(fileList);
            queueService.push("email_cg_notify", emailInfo);
            flag = true;
            LOGGER.info("Email Payload pushed to Queue..");

        } catch (Throwable e) {
            LOGGER.error("Exception while doing Email  ", e);
        }

        return flag;
    }

}
