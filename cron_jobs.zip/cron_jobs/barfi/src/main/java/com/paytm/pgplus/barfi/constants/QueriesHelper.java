package com.paytm.pgplus.barfi.constants;

public class QueriesHelper {

    private QueriesHelper() {
        throw new IllegalStateException("QueriesHelper class");
    }

    public static class HqlQuery {

        private HqlQuery() {
            throw new IllegalStateException("HqlQuery class");
        }

        public static final String BANK_DETAILS_BY_BANK_CODE = "from BankMaster bm where bm.standardBankCode IN (:bankCodeList)";

        public static final String BIN_DETAILS_BY_BIN_NUMBER = "from BinMaster bm where bm.bin IN (:binList)";

        public static final String HDFC_EDC_TXN_ID_BY_AUTH_CODE_AND_BANK_TID = "from EdcHdfcBatchUpload where authCode in (:authCodeList) AND bankTid in (:bankTidList)";

        public static final String OFFLINE_REFUND_TXN_ID_BY_AUTH_CODE_AND_BANK_TID = "from OfflineRefundTxn where authCode in (:authCodeList) AND tid in (:bankTidList)";

    }
}