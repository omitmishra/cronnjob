package com.paytm.pgplus.barfi.service;

import com.paytm.pgplus.barfi.dao.impl.BankMasterDaoImpl;
import com.paytm.pgplus.barfi.dao.impl.BinMasterDaoImpl;
import com.paytm.pgplus.barfi.exception.PaytmBarfiException;
import com.paytm.pgplus.barfi.model.BankMaster;
import com.paytm.pgplus.barfi.model.BinMaster;
import com.paytm.pgplus.barfi.util.ApplicationContextProvider;
import com.paytm.pgplus.barfi.util.PropertyContext;
import com.paytm.pgplus.barfi.util.RupayFileAdapter;
import com.paytm.pgplus.barfi.vo.ProcessedRupayRow;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * @author Sakshi Jain
 */

@Component
public class RupayBinFileProcessorHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(RupayBinFileProcessorHelper.class);

    @Autowired
    RupayBinMigrationHelper rupayBinMigrationHelper;

    /**
     * @param adapter
     *            List<ProcessedRupayRow>
     * @throws PaytmBarfiException
     *             in case Dao operation fails
     */
    public void updateBinDetails(RupayFileAdapter adapter) throws PaytmBarfiException {
        List<ProcessedRupayRow> rupayRowList = adapter.rupayRowList;
        Set<String> bankCodeSet;
        List<BankMaster> bankMasterList;
        Set<Integer> binSet = new HashSet<>();
        List<BinMaster> binFileList;
        Map<String, BankMaster> bankIdByBankCode = null;

        try {
            String defaultBankCode = PropertyContext.getBarfiProxyProperties().getProperty("rupay.default.bank.code");

            ApplicationContext context = ApplicationContextProvider.getApplicationContext();
            BankMasterDaoImpl bankMasterDao = (BankMasterDaoImpl) context.getBean("bankMasterDao");

            bankCodeSet = createBankCodeList(rupayRowList);

            bankCodeSet.add(defaultBankCode);
            bankMasterList = bankMasterDao.fetchBankMasterList(bankCodeSet);

            if (null != bankMasterList)
                bankIdByBankCode = createBankIdByBankCodeMap(bankMasterList);

            binFileList = transformBinMasterList(rupayRowList, bankIdByBankCode);
            if (!binFileList.isEmpty()) {
                List<BinMaster> uniqBinList = getUniqueBins(binFileList, binSet, adapter);
                saveOrUpdateBinMaster(binSet, uniqBinList, adapter);
            } else {
                LOGGER.info("Bin master list to be updated is empty");
            }

        } catch (Exception e) {
            LOGGER.error("Exception from DAO", e.getMessage(), e);
            throw new PaytmBarfiException("Exception from DAO");
        }
    }

    private List<BinMaster> getUniqueBins(List<BinMaster> bins, Set<Integer> binSet, RupayFileAdapter adapter) {
        Map<Integer, BinMaster> uniqueMap = new HashMap<>();
        for (BinMaster bin : bins) {
            if (uniqueMap.containsKey(bin.getBin())) {
                BinMaster skippedBin = uniqueMap.get(bin.getBin());
                skippedBin.setErrorMessage("Skipped duplicate Bin");
                adapter.failureList.add(skippedBin);
            }
            binSet.add(bin.getBin());
            uniqueMap.put(bin.getBin(), bin);
        }
        return new ArrayList<>(uniqueMap.values());
    }

    /**
     * @param rupayRowList
     *            List<ProcessedRupayRow>
     * @return Bank code list
     */
    private Set<String> createBankCodeList(List<ProcessedRupayRow> rupayRowList) {
        LOGGER.info("Creating bank code list from rupay row list data");
        Set<String> bankCodeSet = new HashSet<>();
        for (ProcessedRupayRow row : rupayRowList)
            bankCodeSet.add(row.getParticipantIdInitials());
        return bankCodeSet;
    }

    /**
     * @param processedRupayRowList
     *            List<ProcessedRupayRow>
     * @param bankMap
     *            Map<String, Integer>
     * @return List<BinMaster>
     */
    private List<BinMaster> transformBinMasterList(List<ProcessedRupayRow> processedRupayRowList,
            Map<String, BankMaster> bankMap) {

        String defaultBankCode = PropertyContext.getBarfiProxyProperties().getProperty("rupay.default.bank.code");
        BankMaster defaultBank = bankMap.get(defaultBankCode);
        List<BinMaster> binFileList = new ArrayList<>();
        for (ProcessedRupayRow row : processedRupayRowList) {
            BinMaster aBinRow = new BinMaster();

            aBinRow.setBin(row.getBin());
            aBinRow.setBinLength(row.getBinLength());
            aBinRow.setCardType(row.getCardType());
            aBinRow.setIsIndian(row.getIsIndian());
            aBinRow.setIsActive(row.getIsActive());
            aBinRow.setCardName("RUPAY");
            aBinRow.setBankCode(bankMap.getOrDefault(row.getParticipantIdInitials(), defaultBank).getBankCode());
            if (null != bankMap && !bankMap.isEmpty())
                aBinRow.setBankId(bankMap.getOrDefault(row.getParticipantIdInitials(), defaultBank).getBankId());
            else
                aBinRow.setBankId(defaultBank.getBankId());

            binFileList.add(aBinRow);
        }
        return binFileList;
    }

    /**
     * @param binMasterList
     *            List<BinMaster>
     * @param binsFound
     *            List<BinMaster>
     * @return list of bins to be updated
     */
    private List<BinMaster> fetchBinsToBeUpdated(List<BinMaster> binMasterList, List<BinMaster> binsFound) {
        List<BinMaster> binsToBeUpdated = new ArrayList<>();

        for (BinMaster aBin : binMasterList) {
            for (BinMaster foundBin : binsFound) {
                if (aBin.getBin().equals(foundBin.getBin())) {
                    aBin.setId(foundBin.getId());
                    binsToBeUpdated.add(aBin);
                    break;
                }
            }
        }
        return binsToBeUpdated;
    }

    /**
     * @param binSet
     *            Set<Integer>
     * @param binFileUniqList
     *            List<BinMaster>
     */
    private void saveOrUpdateBinMaster(Set<Integer> binSet, List<BinMaster> binFileUniqList, RupayFileAdapter adapter) {

        List<BinMaster> binsToBeUpdated = null;
        List<BinMaster> binMasterList;
        List<BinMaster> binsToBeSaved = new ArrayList<>(binFileUniqList);
        ApplicationContext context = ApplicationContextProvider.getApplicationContext();
        BinMasterDaoImpl binMasterDao = (BinMasterDaoImpl) context.getBean("binMasterDao");

        LOGGER.debug("Creating bin model list for records already present in BIN_MASTER table");
        // find list of bins which are already present in BIN_MASTER and needs
        // to be updated
        binMasterList = binMasterDao.fetchBinDetails(binSet);
        if (null != binMasterList && !binMasterList.isEmpty()) {
            binsToBeUpdated = fetchBinsToBeUpdated(binFileUniqList, binMasterList);
        }

        // if bins found, call update in BIN_MASTER
        if (null != binsToBeUpdated && !binsToBeUpdated.isEmpty()) {
            LOGGER.debug("Initiating batch data updation");
            for (BinMaster binMaster : binsToBeUpdated) {
                rupayBinMigrationHelper.updateBinMasterList(binMaster, adapter);
            }
            binsToBeSaved.removeAll(binsToBeUpdated);
        } else {
            LOGGER.debug("No record in bin model list exist in BIN_MASTER table");
        }

        // call save in BIN_MASTER for remaining bins
        if (!binsToBeSaved.isEmpty())
            for (BinMaster binMaster : binsToBeSaved) {
                rupayBinMigrationHelper.saveBinMasterList(binMaster, adapter);
            }
    }

    /**
     * @param bankMasterList
     *            List<BankMaster>
     * @return map of key, value pairs where key is bank code and value is bank
     *         id
     */
    private Map<String, BankMaster> createBankIdByBankCodeMap(List<BankMaster> bankMasterList) {
        Map<String, BankMaster> bankIdByBankCodeMap = new HashMap<>();
        for (BankMaster bankMaster : bankMasterList) {
            bankIdByBankCodeMap.putIfAbsent(bankMaster.getStandardBankCode(), bankMaster);
        }
        return bankIdByBankCodeMap;
    }
}