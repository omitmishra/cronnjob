package com.paytm.pgplus.barfi.util;

public enum ProcessorBean {

    HDFCBANKCARD("HDFCBankCardReconFileProcessor", "xls", "HDFC-CC+DC"), HDFCV2BANKCARD(
            "HDFCBankCardReconFileProcessorV2", "csv", "HDFC-CC+DC"), HDFCPAYBANKCARD(
            "HDFCPayBankCardReconFileProcessor", "xls", "HDFCPAY-CC+DC"), HDFCPAYV2BANKCARD(
            "HDFCPayBankCardReconFileProcessorV2", "csv", "HDFCPAY-CC+DC"), HDFCEMI("HDFCEMIReconFileProcessor", "xls",
            "HDFE-EMI"), ICICIBANKCARD("ICICIBankCardReconFileProcessor", "xls", "ICICI-CC+DC"), ICICIPAYBANKCARD(
            "ICICIPAYBankCardReconFileProcessor", "xls", "ICICIPAY-CC+DC"), SBIBANKCARD(
            "SBIBankCardReconFileProcessor", "csv", "SBI-CC+DC"), VJYANB("VIJAYANBReconFileProcessor", "txt", "VJYA-NB"), PNBNB(
            "PNBNBReconFileProcessor", "xlsx", "PNB-NB"), ICICINB("ICICINBReconFileProcessor", "rpt", "ICICI-NB"), IOBNB(
            "IOBNBReconFileProcessor", "csv", "IOB-NB"), BHARATNB("BharatNBReconFileProcessor", "csv", "BHARAT-NB"), YESNB(
            "YESNBReconFileProcessor", "csv", "YES-NB"), AMEXBANKCARD("AMEXBankCardReconFileProcessor", "xls",
            "AMEX-CC+DC"), AXISNB("AXISNBReconFileProcessor", "txt", "AXIS-NB"), KOTAKNB("KotakNBReconFileProcessor",
            "txt", "KOTAK-NB"), HDFCNB("HDFCNBReconFIleProcessor", "txt", "HDFC-NB"), SBIFSSBANKCARD(
            "SBIBankCardReconFileProcessor", "csv", "SBIFSS-CC+DC"), CITI("CITIReconFileProcessor", "zip", "CITI-CC+DC"), CITIV2(
            "CITIReconFileProcessorV2", "zip", "CITI-CC+DC"), PPBNB("PPBNBReconFileProcessor", "csv", "PPBL-NB"), PAYTMCCPAYTM_DIGITAL_CREDIT(
            "PaytmDigitalCreditReconFileProcessor", "csv", "PAYTMCC-PAYTM_DIGITAL_CREDIT"), CSBNB(
            "CSBNBReconFileProcessor", "txt", "CSB-NB"), PSBNB("PSBNBReconFileProcessor", "rpt", "PSB-NB"), PPBLBANKMANDATE(
            "PPBLBankMandateReconFileProcessor", "xls", "PPBL-BANK_MANDATE"), SBINB("SBINBReconFileProcessor", "txt",
            "SBI-NB"), RATNNB("RBLNBReconFileProcessor", "txt", "RATN-NB"), SIBNB("SIBNBReconFileProcessor", "txt",
            "SIB-NB"), IDFCNB("IDFCNBReconFileProcessor", "txt", "IDFC-NB"), DCBNB("DCBNBReconFileProcessor", "txt",
            "DCB-NB"), BOBNB("BOBNBReconFileProcessor", "txt", "BOB-NB"), OBCNB("OBCNBReconFileProcessor", "dat",
            "OBPRF-NB"), ICICIV2BANKCARD("ICICIBankCardReconFileProcessorV3", "xls", "ICICI-CC+DC"), ICICIPAYV2BANKCARD(
            "ICICIPAYBankCardReconFileProcessorV3", "xls", "ICICIPAY-CC+DC"), ICICIV3BANKCARD(
            "ICICIBankCardReconFileProcessorV4", "csv", "ICICI-CC+DC"), ICICIPAYV3BANKCARD(
            "ICICIPAYBankCardReconFileProcessorV4", "csv", "ICICIPAY-CC+DC"), ICICIDEBITBANKCARD(
            "ICICIDebitBankCardReconFileProcessor", "csv", "ICICIIDEBIT-CC+DC"), SBIFSSV2BANKCARD(
            "SBIFSSBankCardReconFileProcessorV2", "csv", "SBIFSS-CC+DC"), ICICIUPI("ICICIUpiReconFileProcessor",
            "xlsx", "ICICI-UPI"), BOBFSSBANKCARD("BOBFSSBankCardReconFileProcessor", "xls", "BOBFSS-CC+DC"), BOBFSSBANKCARDV2(
            "BOBFSSBankCardReconFileProcessorV2", "xlsb", "BOBFSS-CC+DC"), WALLETP2B_FIS(
            "WalletP2BFISReconFileProcessor", "csv", "WALLET-P2B_FIS"), PPBLUPI("PPBUPIReconFileProcessor", "csv",
            "PPBL-UPI"), HDFCADVBANKCARD("HDFCAdvBankCardReconFileProcessor", "xls", "HDFCADV-CC+DC"), CBINB(
            "CBINBReconFileProcessor", "txt", "CBI-NB"), UCONB("UCONBReconFileProcessor", "txt", "UCO-NB"), CORPNB(
            "CORPNBReconFileProcessor", "txt", "CORP-NB"), KOTAKBANKCARD("KOTAKCCReconFileProcessor", "xlsx",
            "KOTAK-CC+DC"), DENANB("DENANBReconFileProcessor", "txt", "DENA-NB"), CANARANB(
            "CANARANBReconFileProcessor", "xls", "CANARA-NB"), ANDBNB("ANDBNBReconFileProcessor", "txt", "ANDB-NB"), AXISBANKCARD(
            "AXISCCReconFileProcessor", "xls", "AXIS-CC+DC"), AXISV2BANKCARD("AXISCCReconFileProcessorV2", "xlsb",
            "AXIS-CC+DC"), UNINB("UNINBReconFileProcessor", "txt", "UNI-NB"), WALLETP2B_ICICI(
            "WalletP2BICICIReconFileProcessor", "xlsx", "WALLET-P2B_ICICI"), PEDCEDC("PEDCBankcardReconFileProcessor",
            "csv", "PEDC-EDC"), AEDCEDC("AEDCReconFileProcessor", "xlsx", "AEDC-EDC"), CITIUBNB(
            "CITIUBNBReconFileProcessor", "txt", "CITIUB-NB"), STBNB("STBNBReconFileProcessor", "txt", "STB-NB"), BOMNB(
            "BOMNBReconFileProcessor", "txt", "BOM-NB"), INDBNB("INDBNBReconFileProcessor", "txt", "INDB-NB"), JKBNB(
            "JKBNBReconFileProcessor", "txt", "JKB-NB"), KVBNB("KVBNBReconFileProcessor", "txt", "KVB-NB"), LVBNB(
            "LVBNBReconFileProcessor", "txt", "LVB-NB"), GPPBNB("GPPBNBReconFileProcessor", "txt", "GPPB-NB"), UBINB(
            "UBINBReconFileProcessor", "rpt", "UBI-NB"), INDSNB("INDSNBReconFileProcessor", "txt", "INDS-NB"), COSMOSNB(
            "COSMOSNBReconFileProcessor", "txt", "COSMOS-NB"), JSBNB("JSBNBReconFileProcessor", "txt", "JSB-NB"), KTKBNB(
            "KTKBNBReconFileProcessor", "dat", "KTKB-NB"), PMCBNB("PMCBNBReconFileProcessor", "txt", "PMCB-NB"), TNMBNB(
            "TNMBNBReconFileProcessor", "txt", "TNMB-NB"), BAJAJEMI("BAJAJEMIReconFileProcessor", "xlsx", "BAJAJFN-EMI"), AXISUPI(
            "AXISUPIReconFileProcessor", "csv", "AXIS-UPI"), CCAVENUEADVNB("CCAvenueNBReconFileProcessor", "csv",
            "CCAVENUEADV-NB"), CCAVENUEBANKCARD("CCAvenueBankCardReconFileProcessor", "csv", "CCAVENUE-CC+DC"), ICIEEMI(
            "ICIEEMIReconFileProcessor", "xlsx", "ICIE-EMI"), SSFBNB("SSFBNBReconFileProcessor", "txt", "SSFB-NB"), FISNP2B(
            "FISNP2BReconFileProcessor", "csv", "WALLET-P2B_FISN"), FISRP2B("FISRP2BReconFileProcessor", "csv",
            "WALLET-P2B_FISR"), FISBP2B("FISBP2BReconFileProcessor", "csv", "WALLET-P2B_FISB"), PPBLNB(
            "PPBLNBReconFileProcessor", "csv", "PPBL-NB"), PYTMNB("PYTMNBReconFileProcessor", "csv", "PYTM-NB"), PYTMV2NB(
            "PYTMV2NBReconFileProcessor", "xlsx", "PYTM-NB"), RUPAYBIN("RupayBinFileProcessor", "xlsx", "RUPAY-BIN"), AMEXV2BANKCARD(
            "AMEXBankCardReconFileProcessorV2", "txt", "AMEX-CC+DC"), HDFCIDEBITBANKCARD(
            "HDFCIDebitCCDCReconFileProcessor", "xls", "HDFCIDEBIT-CC+DC"), PAGGBANKCARD("PAGGCCReconFileProcessor",
            "xls", "PAGG-CC+DC"), IEDCEDC("ICICIEDCReconFileProcessor", "csv", "IEDC-EDC"), PPBLBANKCARD(
            "PPBLRupayCCDCFileProcessor", "csv", "PPBL-CC+DC"), AXISCORPNB("AXISCORPNBReconFileProcessor", "txt",
            "AXISCORP-NB"), ALHNB("ALHNBReconFileProcessor", "txt", "ALH-NB"), DHANNB("DHANNBReconFileProcessor",
            "txt", "DHAN-NB"), SVCNB("SVCNBReconFileProcessor", "txt", "SVC-NB"), NKGSNB("NKGSBNBReconFileProcessor",
            "txt", "NKGS-NB"), ZESTNB("ZESTNBReconFileProcessor", "xlsx", "ZEST-NB"), HDFCUPI(
            "HDFCUPICollectReconFileProccessor", "xlsx", "HDFC-UPI"), IDBINB("IDBINBReconFileProcessor", "rpt",

    "IDBI-NB"), HDDCEMI_DC("HdfcEdcDcEmiReconFileProcessor", "xlsx", "HDDC-EMI_DC"), SCBNB("SCBLReconFileProcessor",
            "txt", "SCB-NB"), ESFBNB("EQUINBReconFileProcessor", "csv", "ESFB-NB"), AXIABANKCARD(
            "AXISMPGSReconFileProcessor", "xlsx", "AXIA-CC+DC"), FDEBEMI_DC("federalCCReconFileProcessor", "xlsx",
            "FDEB-EMI_DC"), STANNB("SCBLReconFileProcessor", "txt", "STAN-NB"), PPBLBANK_TRANSFER(
            "BankTransferReconFileProcessor", "csv", "PPBL-BANK_TRANSFER"), HDFCEDC("HDFCEDCReconFileProcessor",
            "xlsx", "HEDC-EDC"), FDEBNB("FederalNBReconFileProcessor", "txt", "FDEB-NB"), PPBLBANKMANDATEV2(
            "PPBLMandateMISReconFileProcessor", "csv", "PPBL-BANK_MANDATE"), AUBLNB("AUSmallNBReconFileProccessor",
            "csv", "AUBL-NB"), KTEDCEMI_DC("KotakDcEmiReconFileProcessor", "xlsx", "KTEDC-EMI_DC"), AXIAMPGSBANKCARD(
            "AXIAMPGSReconFileProcessor", "xlsb", "AXIS-CC+DC"), PPSL("BankTransferReconFileProcessor", "csv",
            "PPBL-BANK_TRANSFER/PPSL"), SBIEDC("SBEDReconFileProcessor", "xlsx", "SBI-EDC"), AXIARUPAYBANKCARD(
            "AXIARupayReconFileProcessor", "xlsb", "AXIS-CC+DC");

    private String beanName;
    private String extension;
    private String destinationFolder;

    private ProcessorBean(String beanName, String extension, String destinationFolder) {
        this.beanName = beanName;
        this.extension = extension;
        this.destinationFolder = destinationFolder;
    }

    public String getBean() {
        return this.beanName;
    }

    public String getExtension() {
        return this.extension;
    }

    public String getDestinationFolder() {
        return this.destinationFolder;
    }

}
