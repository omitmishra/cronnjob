package com.paytm.pgplus.barfi.dao.impl;

import com.paytm.pgplus.barfi.dao.IHdfcEdcDao;
import com.paytm.pgplus.barfi.model.EdcHdfcBatchUpload;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static com.paytm.pgplus.barfi.constants.QueriesHelper.HqlQuery.HDFC_EDC_TXN_ID_BY_AUTH_CODE_AND_BANK_TID;

@Repository("hdfcEdcDaoImpl")
public class HdfcEdcDaoImpl extends BaseAbstractDao<EdcHdfcBatchUpload, Integer> implements IHdfcEdcDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(HdfcEdcDaoImpl.class);;

    @Transactional(readOnly = true)
    @Override
    public List<EdcHdfcBatchUpload> fetchTransactionId(final List<String> authCodeList, final List<String> bankTidList) {
        HdfcEdcDaoImpl.LOGGER.info("Fetching data from EDC batch");

        final List<EdcHdfcBatchUpload> txnList = this.findByHqlQuery(HDFC_EDC_TXN_ID_BY_AUTH_CODE_AND_BANK_TID,
                new Object[] { authCodeList, bankTidList });
        if (txnList != null) {
            HdfcEdcDaoImpl.LOGGER.info("Size of data from DB: " + txnList.size());
            return txnList;
        }
        return null;
    }
}