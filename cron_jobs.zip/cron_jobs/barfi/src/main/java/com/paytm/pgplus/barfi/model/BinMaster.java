package com.paytm.pgplus.barfi.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Sakshi Jain
 */

@Setter
@Getter
@ToString
@Entity
@Table(name = "BIN_MASTER")
public class BinMaster {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "BIN")
    private Integer bin;

    @Column(name = "IS_INDIAN")
    private Integer isIndian;

    @Column(name = "CARD_TYPE")
    private String cardType;

    @Column(name = "CARD_NAME")
    private String cardName;

    @Column(name = "IS_ACTIVE")
    private Integer isActive;

    @Column(name = "BIN_LENGTH")
    private Integer binLength;

    @Column(name = "BANK_ID")
    private Integer bankId;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_ON", nullable = false, updatable = false)
    private Date createdOn = new Date();

    @Column(name = "CREATED_BY")
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATED_ON", nullable = false)
    @UpdateTimestamp
    private Date updatedOn = new Date();

    @Column(name = "UPDATED_BY")
    private Long updatedBy;

    @JsonIgnore
    @Transient
    private String bankCode;

    @JsonIgnore
    @Transient
    private String errorMessage;
}