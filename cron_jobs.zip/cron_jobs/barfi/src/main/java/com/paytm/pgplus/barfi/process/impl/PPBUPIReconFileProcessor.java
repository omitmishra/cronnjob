package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 * @author Sonu
 *
 */

@Component(value = "PPBUPIReconFileProcessor")
public class PPBUPIReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(PPBUPIReconFileProcessor.class);
    private static final String DELIMITER = ",";
    private static final String COLHEAD = "merchanttxnid";
    private static final String REFUND_COLHEAD = "PG REFUND ID";
    private static final String REFUND = "refund";
    private static final String PAYMENT = "paid";

    private static Map<String, Enum<Column>> chargingReconMap = new HashMap<>();
    private static Map<String, Enum<Column>> refundReconMap = new HashMap<>();

    static {

        chargingReconMap.put("merchanttxnid", Column.TXN_ID);
        chargingReconMap.put("rrn", Column.BANK_TXN_ID);
        chargingReconMap.put("txnamount", Column.GROSS_AMT);

        refundReconMap.put("PG REFUND ID", Column.TXN_ID);
        refundReconMap.put("REFUND AMOUNT", Column.GROSS_AMT);
        refundReconMap.put("BANK RRN", Column.BANK_TXN_ID);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;

        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            if (adapter.fileName.toLowerCase().contains(REFUND)) {
                columnMap = mapColumns(adapter, csvList, refundReconMap, DELIMITER, REFUND_COLHEAD);
                parseAndWriteRefund(adapter, csvList, columnMap, DELIMITER);
            } else if (adapter.fileName.toLowerCase().contains(PAYMENT)) {
                columnMap = mapColumns(adapter, csvList, chargingReconMap, DELIMITER, COLHEAD);
                parseAndWriteCharging(adapter, csvList, columnMap, DELIMITER);
            } else {
                adapter.markFail("File name format not as specified for PPBL-UPI FileName : " + adapter.fileName);
            }

            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            csvList = null;
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

}
