package com.paytm.pgplus.barfi.model;

import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.IOException;

public class ParseXML {

    private static XmlMapper mapper;
    private static DocumentBuilderFactory builderFactory;

    static {
        JacksonXmlModule module = new JacksonXmlModule();
        module.setDefaultUseWrapper(false);
        mapper = new XmlMapper(module);
        builderFactory = DocumentBuilderFactory.newInstance();
    }

    public static <T> T parseXML(String xml, Class<T> obj) throws IOException {
        return mapper.readValue(xml, obj);
    }

}
