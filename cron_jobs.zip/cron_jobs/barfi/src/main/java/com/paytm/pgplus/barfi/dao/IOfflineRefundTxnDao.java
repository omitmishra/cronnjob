package com.paytm.pgplus.barfi.dao;

import com.paytm.pgplus.barfi.model.OfflineRefundTxn;

import java.util.List;

public interface IOfflineRefundTxnDao {

    List<OfflineRefundTxn> fetchTransactionId(final List<String> authCodeList, final List<String> bankTidList);

}
