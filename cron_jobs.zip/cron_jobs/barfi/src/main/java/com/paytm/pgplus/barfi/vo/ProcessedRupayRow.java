package com.paytm.pgplus.barfi.vo;

import lombok.Getter;
import lombok.Setter;

/**
 * @author Sakshi Jain Represents each row under process which further needs to
 *         be updated in Bin Master table
 */

@Getter
@Setter
public class ProcessedRupayRow {

    private String participantIdInitials;

    private String binLow;

    private String binHigh;

    private String cardType;

    private String schemeCode;

    private Integer isIndian;

    private Integer isActive;

    private Integer binLength;

    private Integer bin;
}