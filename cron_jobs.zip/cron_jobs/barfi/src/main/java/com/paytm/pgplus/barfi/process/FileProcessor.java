package com.paytm.pgplus.barfi.process;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.exception.PaytmBarfiException;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.*;

import static java.util.Collections.*;

/**
 * @author Agrim
 * @author Shubham
 */

public interface FileProcessor {

    /**
     * Maps the column titles to their respective indices in the processed row.
     */
    public default Map<Integer, Enum<ReconFileAdapter.Column>> mapColumns(ReconFileAdapter reconAdapter,
            List<String> csvList, Map<String, Enum<ReconFileAdapter.Column>> reconMap, String delimiter, String colHead)
            throws IOException, PaytmBarfiException {

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
        for (String r : csvList) {
            if (StringUtils.isBlank(r)) {
                continue;
            }
            String[] row = r.split(delimiter);
            if (row.length == 0) {
                continue;
            }
            row[0] = AdapterUtil.removeQuotes(row[0]).trim();
            if (!row[0].equals(colHead)) {
                continue;
            }
            for (int columnNo = 0; columnNo < row.length; columnNo++) {
                if (StringUtils.isBlank(row[columnNo])) {
                    continue;
                }
                row[columnNo] = AdapterUtil.removeQuotes(row[columnNo]);
                if (reconMap.containsKey(row[columnNo].trim())) {
                    columnMap.put(columnNo, reconMap.get(row[columnNo].trim()));
                }
            }
            break;
        }
        if (MapUtils.isEmpty(columnMap)) {
            throw new PaytmBarfiException(" Exception - Process Failed due to missing column heads,  File- "
                    + reconAdapter.fileName);
        }
        return columnMap;
    }

    /**
     * Maps the column titles to their respective indices in the processed row.
     */
    public default Map<Enum<ReconFileAdapter.Column>, Integer> columnNameToTxnIdMap(ReconFileAdapter reconAdapter,
            List<String> csvList, Map<String, Enum<ReconFileAdapter.Column>> reconMap, String delimiter, String colHead)
            throws IOException, PaytmBarfiException {
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap = new HashMap<>();
        for (String r : csvList) {
            if (StringUtils.isBlank(r)) {
                continue;
            }
            String[] row = r.split(delimiter);
            if (row.length == 0) {
                continue;
            }
            row[0] = AdapterUtil.removeQuotes(row[0]).trim();
            if (!row[0].equals(colHead)) {
                continue;
            }
            for (int columnNo = 0; columnNo < row.length; columnNo++) {
                if (StringUtils.isBlank(row[columnNo])) {
                    continue;
                }
                row[columnNo] = AdapterUtil.removeQuotes(row[columnNo]);
                if (reconMap.containsKey(row[columnNo].trim())) {
                    columnMap.put(reconMap.get(row[columnNo].trim()), columnNo);
                }
            }
            break;
        }
        if (MapUtils.isEmpty(columnMap)) {
            throw new PaytmBarfiException(" Exception - Process Failed due to missing column heads,  File- "
                    + reconAdapter.fileName);
        }
        return columnMap;
    }

    /*
     * This method is used to write charging file, refund file altogether
     */
    // this method should be used in all the cases;
    public default void parseAndWriteAllColumnIntegerMap(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Enum<ReconFileAdapter.Column>, Integer> columnMap, String delimiter, String cleared,
            Map<String, String> txnTypeSet) throws Exception {
        int highestKey = getHighestValue(columnMap);
        int grossAmtColNo = columnMap.get(ReconFileAdapter.Column.GROSS_AMT);
        int colNoOfTxnType = reconAdapter.getColumnNumberWRTTxnType(columnMap);
        int txnStatusColNo = 0;
        int rowEnd = csvList.size();
        if (cleared != null) {
            txnStatusColNo = columnMap.get(ReconFileAdapter.Column.RESULT_CODE);
        }

        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);
                if (StringUtils.isBlank(row) || cellArr.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(grossAmtColNo, cellArr))) {
                    continue;
                }
                if (cleared != null && !cleared.equalsIgnoreCase(reconAdapter.getTxnType(txnStatusColNo, cellArr))) {
                    continue;
                }
                String charging = txnTypeSet.get(Constants.PAYTM_CHARGING);
                String refund = txnTypeSet.get(Constants.PAYTM_REFUND);
                if (charging != null) {
                    if (charging.equals(Constants.PAYTM_CHARGING)
                            || (colNoOfTxnType != -1 && charging.equals(reconAdapter
                                    .getTxnType(colNoOfTxnType, cellArr)))) {
                        reconAdapter.setChargingValuesColumnIntegerMap(cellArr, columnMap, canBankTxnIdStartWithZero());
                    }
                }
                if (refund != null) {
                    if (refund.equals(Constants.PAYTM_REFUND)
                            || (colNoOfTxnType != -1 && refund.equals(reconAdapter.getTxnType(colNoOfTxnType, cellArr)))) {
                        reconAdapter.setRefundValuesColumnIntegerMap(cellArr, columnMap, canBankTxnIdStartWithZero());
                    }
                }

                // TO-DO for chargeback

            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    /*
     * This method is used to write charging file for bank transfer paymode
     */
    // this method should be used in all the cases;
    public default void parseAndWriteAllColumnIntegerMapForBankTransfer(ReconFileAdapter reconAdapter,
            List<String> csvList, Map<Enum<ReconFileAdapter.Column>, Integer> columnMap, String delimiter,
            String cleared) throws Exception {
        int highestKey = getHighestValue(columnMap);
        int grossAmtColNo = columnMap.get(ReconFileAdapter.Column.GROSS_AMT);
        int txnStatusColNo = 0;
        int rowEnd = csvList.size();
        if (cleared != null) {
            txnStatusColNo = columnMap.get(ReconFileAdapter.Column.RESULT_CODE);
        }

        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);
                if (StringUtils.isBlank(row) || cellArr.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(grossAmtColNo, cellArr))) {
                    continue;
                }
                if (cleared != null && !cleared.equalsIgnoreCase(reconAdapter.getTxnType(txnStatusColNo, cellArr))) {
                    continue;
                }
                reconAdapter.setChargingValuesColumnIntegerMap(cellArr, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    /**
     * Extracts the required fields for the processed row and writes the
     * processed file
     **/

    public default void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter, String charging, String refund, String resultCode)
            throws Exception {

        int txnTypeColNo = reconAdapter.getColumnNumberDRCR(columnMap);
        int resultCodeColNo = reconAdapter.getResultCodeColumnNumber(columnMap);

        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= txnTypeColNo || row.length <= resultCodeColNo) {
                    continue;
                }
                if (resultCode.equals(reconAdapter.getTxnType(resultCodeColNo, row))) {
                    if (refund.equals(reconAdapter.getTxnType(txnTypeColNo, row))) {
                        reconAdapter.setRefundValues(row, columnMap, canBankTxnIdStartWithZero());
                    }
                    if (charging.equals(reconAdapter.getTxnType(txnTypeColNo, row))) {
                        reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
                    }
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    /**
     * Extracts the required fields for the processed row and writes the
     * processed file
     */
    @Deprecated
    public default void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter, String charging, String refund) throws Exception {

        int colNo = reconAdapter.getColumnNumberDRCR(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (refund.equals(reconAdapter.getTxnType(colNo, row))) {
                    reconAdapter.setRefundValues(row, columnMap, canBankTxnIdStartWithZero());
                }
                if (charging.equals(reconAdapter.getTxnType(colNo, row))) {
                    reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    /**
     * Extracts the required fields for the processed row and writes the
     * processed file
     */
    public default void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                if (reconAdapter.getTxnType(colNo, row).startsWith("-")) {
                    reconAdapter.setRefundValues(row, columnMap, canBankTxnIdStartWithZero());
                } else {
                    reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    /**
     * Extracts the required fields for the processed row and writes the
     * processed Refund file : For banks that send different files for charging
     * and refund
     */
    @Deprecated
    public default void parseAndWriteRefund(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int highestKey = getHighestKey(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                reconAdapter.setRefundValues(row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    /**
     * Extracts the required fields for the processed row and writes the
     * processed Charging file : For banks that send different files for
     * charging and refund
     */
    @Deprecated
    public default void parseAndWriteCharging(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int highestKey = getHighestKey(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, row))) {
                    continue;
                }
                reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    /**
     * Extracts highest value from hashmap
     */
    public default <K, V extends Comparable<V>> V getHighestValue(Map<K, V> map) {
        Map.Entry<K, V> maxEntry = Collections.max(map.entrySet(), Comparator.comparing(Map.Entry::getValue));
        return maxEntry.getValue();
    }

    /**
     * Extracts highest key from hashmap
     */
    public default int getHighestKey(Map<Integer, Enum<Column>> columnMap) {
        int highestKey = -1;
        for (Map.Entry<Integer, Enum<ReconFileAdapter.Column>> map : columnMap.entrySet()) {
            int key = map.getKey();
            if (key > highestKey) {
                highestKey = key;
            }
        }
        return highestKey;
    }

    /**
     * Extracts all the data from the unprocessed file and converts into a list
     * of strings
     */
    public List<String> extractData(File file) throws IOException, OpenXML4JException, ParserConfigurationException,
            SAXException;

    /**
     * If bankTxnId can start with zero in processed, then do not strip leading
     * zeroes
     *
     * @return
     */
    public default boolean canBankTxnIdStartWithZero() {
        return false;
    }

    /**
     *
     */
    default int getColNum(Map<Enum<ReconFileAdapter.Column>, Integer> columnMap, Enum<ReconFileAdapter.Column> colEnum) {
        if (columnMap.containsKey(colEnum))
            return columnMap.get(colEnum);
        return -1;
    }

}
