package com.paytm.pgplus.barfi.util;

import java.io.File;

public final class AdapterConstants {

    public static final String REFUND = "Refund_";
    public static final String CHARGING = "Charging_";
    public static final String CHARGEBACK = "Chargeback_";
    public static final String CSV = ".csv";
    public static final String SUCCESS = "SUCCESS";
    public static final String PROCESSING_TEMP = "processing_temp";
    public static final String SLASH = File.separator;
    public static final String UNDERSCORE = "_";
    public static final String FILEPART = "filepart";
    public static final String FORFAIL = "forfail";
    public static final String FAIL = "Fail_";

    public static final String BANKCARD_PAYMODE = "CC+DC";
    public static final String BANKCARD = "BANKCARD";
    public static final String NB_PAYMODE = "NB";
    public static final String NB = "NB";
    public static final String UPI_PAYMODE = "UPI";
    public static final String UPI = "UPI";
    public static final String DIGITAL_CREDIT_PAYMODE = "PAYTM_DIGITAL_CREDIT";
    public static final String DIGITAL_CREDIT = "PAYTM_DIGITAL_CREDIT";
    public static final String P2B_ICICI = "P2B_ICICI";
    public static final String P2B_ICICI_PAYMODE = "P2B_ICICI";
    public static final String P2B_FIS = "P2B_FIS";
    public static final String P2B_FIS_PAYMODE = "P2B_FIS";
    public static final String EDC = "EDC";
    public static final String EDC_PAYMODE = "EDC";
    public static final String RET = "RET_";
    public static final String EMI = "EMI";
    public static final String P2B = "P2B";
    public static final String BANK_MANDATE_PAYMODE = "BANK_MANDATE";
    public static final String BANK_MANDATE = "BANKMANDATE";
    public static final String EMIDC_PAYMODE = "EMI_DC";
    public static final String BANK_TRANSFER = "BANK_TRANSFER";
    public static final String BANK_PAYMODE_ICICIPAY_CC_DC = "ICICIPAY-CC+DC";
    public static final int RETRY_COUNT = 3;

}