package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXSheetProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author saurabh.malviya
 */

@Component(value = "ICIEEMIReconFileProcessor")
public class ICICIEMIDCReconFileProcessor implements Processable, XLSXSheetProcessor {

    private static final Logger LOGGER = LogManager.getLogger(ICICIEMIDCReconFileProcessor.class);
    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "S.NO";

    Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> refundMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> chargingMap = new HashMap<>();

    static {
        chargingMap.put("Sale Amt", ReconFileAdapter.Column.GROSS_AMT);
        chargingMap.put("Track_Id", ReconFileAdapter.Column.TXN_ID);
        chargingMap.put("Loan Ref Id", ReconFileAdapter.Column.BANK_TXN_ID);
        refundMap.put("Amount", ReconFileAdapter.Column.GROSS_AMT);
        refundMap.put("Track id", ReconFileAdapter.Column.TXN_ID);
        refundMap.put("Loan Ref No.", ReconFileAdapter.Column.RRN);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        Map<Integer, List<String>> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        Map<Integer, Enum<ReconFileAdapter.Column>> refundColMap = new HashMap<>();
        Map<Integer, Enum<ReconFileAdapter.Column>> chargingColMap = new HashMap<>();
        int noOfSheets = 2;

        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractDataSheets(adapter.getProcessingFileHandle(), noOfSheets);
            chargingColMap = mapColumns(adapter, csvList.get(0), chargingMap, DELIMITER, COLHEAD);
            refundColMap = mapColumns(adapter, csvList.get(1), refundMap, DELIMITER, COLHEAD);
            parseAndWriteCharging(adapter, csvList.get(0), chargingColMap, DELIMITER);
            parseAndWriteRefund(adapter, csvList.get(1), refundColMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }

    }

}
