package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.*;

/**
 * @author Pawan Kumar
 * @Since 19/12/2019
 */

@Component(value = "PYTMV2NBReconFileProcessor")
public class PYTMV2NBReconFileProcessor implements Processable, XLSXProcessor {

    private static final Logger LOGGER = LogManager.getLogger(PYTMV2NBReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "Merchant_Name";
    private static final String CLEARED = "success";

    private static Map<String, String> txnTypeSet = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {
        txnTypeSet.put(Constants.PAYTM_CHARGING, Constants.PAYTM_CHARGING);
    }

    static {
        reconMap.put("amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("request_transaction_id", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("Bank_Reference_Number", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("status", ReconFileAdapter.Column.RESULT_CODE);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = columnNameToTxnIdMap(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWriteAllColumnIntegerMap(adapter, csvList, columnMap, DELIMITER, CLEARED, txnTypeSet);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }
}
