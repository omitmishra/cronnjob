package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component(value = "AUSmallNBReconFileProccessor")
public class AUSmallNBReconFileProccessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(AUSmallNBReconFileProccessor.class);
    private static final String DELIMITER = ",";
    private static final String COLHEAD = "TRANSACTION TYPE";
    public static final String REFUND = "REFUND";
    public static final String PAYMENT = "PAYMENT";
    private static Map<String, Enum<ReconFileAdapter.Column>> chargingReconMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> refundReconMap = new HashMap<>();
    private static String SUCCESS = "S";

    static {
        chargingReconMap.put("PAYMENT_AMT", ReconFileAdapter.Column.GROSS_AMT);
        chargingReconMap.put("HOST_REF_NO", ReconFileAdapter.Column.BANK_TXN_ID);
        chargingReconMap.put("USERREFERENCENO", ReconFileAdapter.Column.TXN_ID);
        chargingReconMap.put("STATUS", ReconFileAdapter.Column.RESULT_CODE);
        chargingReconMap.put("TRANSACTION TYPE", ReconFileAdapter.Column.TXN_TYPE);
        refundReconMap.put("HOST_REF_NO", ReconFileAdapter.Column.RRN);
        refundReconMap.put("REFUND_AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        // refundReconMap.put("BANK_TXN_ID",
        // ReconFileAdapter.Column.BANK_TXN_ID);
        refundReconMap.put("PAYMENT_ID_EXT", ReconFileAdapter.Column.TXN_ID); // ?
        refundReconMap.put("TRANSACTION TYPE", ReconFileAdapter.Column.TXN_TYPE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {
        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap;
        Map<Integer, Enum<ReconFileAdapter.Column>> refundColumnMap;

        try {
            LOGGER.info("Filename: {}", adapter.fileName);

            csvList = extractData(adapter.getProcessingFileHandle());
            chargingColumnMap = mapColumns(adapter, csvList, chargingReconMap, DELIMITER, COLHEAD);
            refundColumnMap = mapColumns(adapter, csvList, refundReconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, refundColumnMap, chargingColumnMap, DELIMITER);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error("Got Error: {}", e.getMessage(), e);
            adapter.markFail(e.getMessage());

        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    private void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> refundColumnMap,
            Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap, String delimiter) throws Exception {
        int colNoStatus = reconAdapter.getResultCodeColumnNumber(chargingColumnMap);
        int txtTypeColNo = reconAdapter.getColumnNumberDRCR(chargingColumnMap);
        int refundEsnColNo = reconAdapter.getColumnNumberTransId(refundColumnMap);
        int txnEsnColNo = reconAdapter.getColumnNumberTransId(chargingColumnMap);
        int rowCount = csvList.size();
        if (colNoStatus == -1 || txtTypeColNo == -1) {
            LOGGER.error("Invalid File " + reconAdapter.fileName);
            throw new Exception("Invalid File " + reconAdapter.fileName);
        }

        int maxColumn = getMaxColumnNumbers(refundColumnMap, chargingColumnMap);
        for (int rowNum = 1; rowNum < rowCount; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);

                if (StringUtils.isBlank(r) || row.length <= maxColumn) {
                    continue;
                }
                String status = reconAdapter.getTxnType(colNoStatus, row);
                String txnType = reconAdapter.getTxnType(txtTypeColNo, row);

                if (StringUtils.isNotBlank(status) && SUCCESS.equalsIgnoreCase(status)) {
                    boolean flag = false;
                    if (StringUtils.isNotBlank(txnType)) {
                        if (REFUND.equalsIgnoreCase(txnType)) {
                            String refundEsn = reconAdapter.getTxnType(refundEsnColNo, row);
                            if (refundEsn.startsWith("'")) {
                                refundEsn = refundEsn.replace("'", "");
                                row[refundEsnColNo] = refundEsn;
                            }
                            reconAdapter.setRefundValues(row, refundColumnMap, canBankTxnIdStartWithZero());
                        } else if (PAYMENT.equalsIgnoreCase(txnType)) {
                            String chargingEsn = reconAdapter.getTxnType(txnEsnColNo, row);
                            if (chargingEsn.startsWith("'")) {
                                chargingEsn = chargingEsn.replace("'", "");
                                row[txnEsnColNo] = chargingEsn;
                            }
                            reconAdapter.setChargingValues(row, chargingColumnMap, canBankTxnIdStartWithZero());
                        } else {
                            flag = true;
                        }
                    } else {
                        flag = true;
                    }
                    if (flag == true) {
                        LOGGER.error("File " + reconAdapter.fileName + " Invalid record at line " + rowNum);
                    }

                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }

        }
    }

    private int getMaxColumnNumbers(Map<Integer, Enum<ReconFileAdapter.Column>> refundColumnMap,
            Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap) {
        int refundCount = getMaxFromMap(refundColumnMap);
        int chargingCount = getMaxFromMap(chargingColumnMap);
        return refundCount >= chargingCount ? refundCount : chargingCount;
    }

    private int getMaxFromMap(Map<Integer, Enum<ReconFileAdapter.Column>> columnMap) {
        int maxValue = -1;
        for (int i : columnMap.keySet()) {
            if (maxValue < i) {
                maxValue = i;
            }
        }
        return maxValue;
    }

}
