package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Pawan Kumar
 * @Since 10/04/2020
 */

@Component(value = "IDBINBReconFileProcessor")
public class IDBINBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(IDBINBReconFileProcessor.class);

    private static final String DELIMITER = "\\ ";
    private static final String CLEARED = "Y";

    private static Map<String, String> txnTypeSet = new HashMap<>();

    static {
        txnTypeSet.put(Constants.PAYTM_CHARGING, Constants.PAYTM_CHARGING);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            csvList = processCsvList(csvList);
            columnMap = mapColumns();
            parseAndWriteAllColumnIntegerMap(adapter, csvList, columnMap, DELIMITER, CLEARED, txnTypeSet);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private List<String> processCsvList(List<String> csvList) {
        if (csvList.size() > 0) {
            csvList.remove(0);
        }
        if (csvList.size() > 0) {
            csvList = csvList.stream().map(csv -> csv.replaceAll(" +", " ")).collect(Collectors.toList());
            csvList = csvList.stream().map(csv -> setElements(Arrays.asList(csv.split(DELIMITER))))
                    .collect(Collectors.toList());
        }
        return csvList;
    }

    private String setElements(List<String> cs) {
        if (!StringUtils.isEmpty(cs.get(0))) {
            cs.set(0, StringUtils.substring(cs.get(0), 10, 20));
        }
        if (!StringUtils.isEmpty(cs.get(2))) {
            int iend = cs.get(2).indexOf("I");
            Double amt = 0.0;
            if (iend != -1) {
                amt = Double.parseDouble(cs.get(2).substring(0, iend)) / 100;
            }
            cs.set(2, Double.toString(amt));
        }
        return cs.stream().collect(Collectors.joining(" "));
    }

    private Map<Enum<ReconFileAdapter.Column>, Integer> mapColumns() {

        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap = new HashMap<>();

        columnMap.put(ReconFileAdapter.Column.TXN_ID, 1);
        columnMap.put(ReconFileAdapter.Column.GROSS_AMT, 2);
        columnMap.put(ReconFileAdapter.Column.BANK_TXN_ID, 0);
        columnMap.put(ReconFileAdapter.Column.RESULT_CODE, 11);

        return columnMap;
    }
}
