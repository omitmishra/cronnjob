package com.paytm.pgplus.barfi.util;

public class IllegalFileFormatException extends RuntimeException {

    /**
	 * 
	 */
    private static final long serialVersionUID = 3878670040972846492L;

    IllegalFileFormatException(String s) {
        super(s);
    }

    IllegalFileFormatException() {
        super();
    }

}
