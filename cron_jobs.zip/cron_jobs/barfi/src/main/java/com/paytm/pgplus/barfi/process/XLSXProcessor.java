package com.paytm.pgplus.barfi.process;

import com.paytm.pgplus.barfi.util.XLSXReader;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * XLSXReader to extract data from the file. Should only be used when the file
 * is in XLSX format
 * 
 * @author Agrim
 * @author Shubham
 *
 */

public interface XLSXProcessor extends FileProcessor {

    static final Logger LOGGER = LogManager.getLogger(XLSXProcessor.class);

    /**
     * using XLSXReader to extract data from the file. Should only be used when
     * the file is in XLSX format
     * 
     * @param File
     *            Unprocessed file directly from bank
     * @return List of Strings extracted data from file in list form
     * @throws SAXException
     * @throws ParserConfigurationException
     * @throws OpenXML4JException
     */
    public default List<String> extractData(File file) throws IOException, OpenXML4JException,
            ParserConfigurationException, SAXException {

        List<String> csvList = new ArrayList<String>();
        if (!file.exists()) {
            LOGGER.error("Not found or not a file: {}", file.getPath());
        }

        int minColumns = -1;
        String filePath = file.getPath();
        OPCPackage p = OPCPackage.open(filePath, PackageAccess.READ);
        XLSXReader xlsx2csv = new XLSXReader(p, csvList, minColumns);
        xlsx2csv.process();

        return csvList;
    }

    public default Map<String, List<String>> extractDataFromAllSheets(File file) throws OpenXML4JException,
            IOException, ParserConfigurationException, SAXException {
        if (!file.exists()) {
            LOGGER.error("Not found or not a file: {}", file.getPath());
        }

        int minColumns = -1;
        String filePath = file.getPath();
        OPCPackage p = OPCPackage.open(filePath, PackageAccess.READ);
        XLSXReader xlsx2csv = new XLSXReader(p, null, minColumns);
        return xlsx2csv.processMapSheetsToCSV();
    }
}
