package com.paytm.pgplus.barfi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Cell {

    @JacksonXmlProperty(localName = "Data")
    private Data Data;

    public Data getData() {
        return Data;
    }

    public void setData(Data data) {
        Data = data;
    }

    @Override
    public String toString() {
        return "ClassPojo [Data = " + Data + "]";
    }

}
