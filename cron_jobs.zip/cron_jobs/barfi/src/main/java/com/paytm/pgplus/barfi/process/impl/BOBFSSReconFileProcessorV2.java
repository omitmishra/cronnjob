package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSBSheetProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

@Component(value = "BOBFSSBankCardReconFileProcessorV2")
public class BOBFSSReconFileProcessorV2 implements Processable, XLSBSheetProcessor {

    private static final Logger LOGGER = LogManager.getLogger(BOBFSSReconFileProcessorV2.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "TRANSACTIONID";
    private static final String CHARGING = "Purchase";
    private static final String REFUND = "Refund";
    private static final String CAPTURE_TRANSACTION = "APPROVED";
    private static final String SHEETNAME = "SHEET1";

    private static Map<String, Enum<Column>> reconMap = new HashMap<>();
    private static Map<Enum<ReconFileAdapter.Column>, Boolean> costParamMap = new HashMap<>();

    static {
        reconMap.put("TRANSACTIONAMOUNT", Column.GROSS_AMT);
        reconMap.put("MERCHANTTRACKID", Column.TXN_ID);
        reconMap.put("PAYMENTGATEWAYTRANID", Column.BANK_TXN_ID);
        reconMap.put("TRANSACTIONTYPE", Column.TXN_TYPE);
        reconMap.put("APPROVALDECLINEDINDICATOR", Column.RESULT_CODE);

        reconMap.put("MSFAMOUNT", ReconFileAdapter.Column.BANK_COMMISSION);
        reconMap.put("GST", ReconFileAdapter.Column.BANK_CGST);
        reconMap.put("INTERCHANGE", Column.BANK_CARDSCHEME);
        reconMap.put("DESTINATION", Column.CARD_CATEGORY);
        reconMap.put("PAYMENTMETHOD", ReconFileAdapter.Column.CARD_TYPE);
        reconMap.put("MERCHANTCATEGORYCODE", Column.MCC);
        reconMap.put("TERMINALCODE", ReconFileAdapter.Column.TERMINAL_CODE);
        reconMap.put("MERCHANTCODE", ReconFileAdapter.Column.MERCHANT_CODE);
        reconMap.put("STORECODE", Column.STORE_CODE);
        reconMap.put("STORETRADINGNAME", Column.STORE_TRADINGNAME);
        reconMap.put("TRANSACTIONCURRENCYCODE", Column.TXN_CURR);

        costParamMap.put(ReconFileAdapter.Column.BANK_COMMISSION, true);
        costParamMap.put(ReconFileAdapter.Column.BANK_CGST, true);
        costParamMap.put(ReconFileAdapter.Column.BANK_CARDSCHEME, true);
        costParamMap.put(ReconFileAdapter.Column.CARD_CATEGORY, true);
        costParamMap.put(ReconFileAdapter.Column.CARD_TYPE, true);
        costParamMap.put(ReconFileAdapter.Column.MCC, true);
        costParamMap.put(ReconFileAdapter.Column.TERMINAL_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.MERCHANT_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.STORE_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.STORE_TRADINGNAME, true);
        costParamMap.put(ReconFileAdapter.Column.TXN_CURR, true);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        Map<String, List<String>> csvMap = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = null;

        // Number of sheets to be traversed of the uploaded workbook
        int noOfSheets = 1;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvMap = extractDataSheets(adapter.getProcessingFileHandle(), noOfSheets);
            columnMap = mapColumns(adapter, csvMap.get(SHEETNAME), reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvMap.get(SHEETNAME), columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int highestKey = getHighestKey(columnMap);
        int resultCodeColumn = reconAdapter.getResultCodeColumnNumber(columnMap);
        int txnTypeColumn = reconAdapter.getColumnNumberDRCR(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);

                // Check if current row string is empty or if row column length
                // is less than the highest key of the columnMap
                if (StringUtils.isBlank(row) || cellArr.length <= highestKey) {
                    continue;
                }

                // Check if row resultCode is Approved or not
                String resultCode = reconAdapter.getTxnType(resultCodeColumn, cellArr);
                if (!resultCode.equalsIgnoreCase(CAPTURE_TRANSACTION)) {
                    continue;
                }

                // Check for the txn type and segregate the refund and charging
                // rows
                String txnTypeValue = reconAdapter.getTxnType(txnTypeColumn, cellArr);
                if (txnTypeValue.equalsIgnoreCase(REFUND)) {
                    setRefundValues(reconAdapter, cellArr, columnMap, canBankTxnIdStartWithZero());
                } else if (txnTypeValue.equalsIgnoreCase(CHARGING)) {
                    setChargingValues(reconAdapter, cellArr, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    private void setChargingValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        DecimalFormat df = new DecimalFormat("#.####");
        Double intnlAmount = 0.0;
        String cardCategory = "";
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();
                    if (columnMap.containsKey(columnIndex)) {
                        switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                        case GROSS_AMT:
                            intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case AUTH_CODE:
                            entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case RRN:
                            entry.setRRN(AdapterUtil.checkApostrophe(cell));
                            break;
                        case BANK_COMMISSION:
                            entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CGST:
                            entry.setBankGST(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CARDSCHEME:
                            entry.setBankCardScheme(AdapterUtil.checkApostrophe(cell));
                            break;
                        case CARD_CATEGORY:
                            cardCategory = AdapterUtil.checkApostrophe(cell);
                            break;
                        case CARD_TYPE:
                            entry.setBankCardType(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MCC:
                            entry.setMCCCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TERMINAL_CODE:
                            entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case STORE_CODE:
                            entry.setStoreCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        case STORE_TRADINGNAME:
                            entry.setStoreTradingName(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TXN_CURR:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (StringUtils.isBlank(entry.getAuthCode())) {
                entry.setAuthCode("0");
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRRN())) {
                entry.setRRN("0");
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getGrossAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            if (cardCategory != null && cardCategory.toLowerCase().indexOf("international") >= 0)
                entry.setBankInternational((byte) 1);
            else
                entry.setBankInternational((byte) 0);
            entry.setDisc(0.0);
            entry.setNet(0.0);
            entry.setSTax(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setChargingValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForCharging(entry);
        reconAdapter.chargingWriteData(entry);
    }

    public void setRefundValues(ReconFileAdapter reconAdapter, String[] row, Map<Integer, Enum<Column>> columnMap,
            boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        DecimalFormat df = new DecimalFormat("#.####");
        String cardCategory = "";
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();

                    if (columnMap.containsKey(columnIndex)) {
                        switch ((Column) columnMap.get(columnIndex)) {
                        case RRN:
                            entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                                    .checkApostrophe(cell))));
                            break;
                        case GROSS_AMT:
                            Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_COMMISSION:
                            entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CGST:
                            entry.setBankGST(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CARDSCHEME:
                            entry.setBankCardScheme(AdapterUtil.checkApostrophe(cell));
                            break;
                        case CARD_CATEGORY:
                            cardCategory = AdapterUtil.checkApostrophe(cell);
                            break;
                        case CARD_TYPE:
                            entry.setBankCardType(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MCC:
                            entry.setMCCCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TERMINAL_CODE:
                            entry.setTerminalCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case STORE_CODE:
                            entry.setStoreCode(AdapterUtil.checkApostrophe(cell));
                            entry.setMbid(AdapterUtil.checkApostrophe(cell));
                            break;
                        case STORE_TRADINGNAME:
                            entry.setStoreTradingName(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TXN_CURR:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRrn())) {
                entry.setRrn("0");
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getRefundAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            if (cardCategory != null && cardCategory.toLowerCase().indexOf("international") >= 0)
                entry.setBankInternational((byte) 1);
            else
                entry.setBankInternational((byte) 0);
            entry.setNeftNo(0.0);
            entry.setStatus(SUCCESS);
            entry.setTxnAmount(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setRefundValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForRefund(entry);
        reconAdapter.refundWriteData(entry);
    }
}
