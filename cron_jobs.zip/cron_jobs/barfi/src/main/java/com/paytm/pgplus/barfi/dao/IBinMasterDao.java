package com.paytm.pgplus.barfi.dao;

import com.paytm.pgplus.barfi.model.BinMaster;

import java.util.List;
import java.util.Set;

/**
 * @author Sakshi Jain
 */

public interface IBinMasterDao {

    List<BinMaster> fetchBinDetails(Set<Integer> binList);

    void saveBinMasterList(List<BinMaster> binMasterList);

    void updateBinMasterList(List<BinMaster> binMasterList);
}
