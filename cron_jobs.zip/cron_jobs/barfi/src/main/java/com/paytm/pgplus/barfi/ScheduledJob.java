package com.paytm.pgplus.barfi;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Initiates Scheduled Operations
 * 
 * @author agrim bansal
 *
 */
public class ScheduledJob {

    private static final Logger LOGGER = LogManager.getLogger(ScheduledJob.class);

    public static void main(String args[]) throws InterruptedException {

        LOGGER.info("Initiating Scheduler");

        @SuppressWarnings("resource")
        ApplicationContext context = new ClassPathXmlApplicationContext("spring-context.xml");

        LOGGER.info("Scheduler Initiated {}", context.getApplicationName());
    }
}