package com.paytm.pgplus.barfi.model;

import lombok.Data;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author Himanshu Sardana
 * @since 05 Feb 2016
 */
@Data
@Entity
@Table(name = "offline_refund_txn")
public class OfflineRefundTxn implements Serializable/* ,CsvExportable */{

    /**
     *
     */
    private static final long serialVersionUID = -3892220064455129542L;

    @Basic(optional = false)
    @Column(name = "ID", nullable = false, updatable = false)
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "TRANS_ID", length = 100)
    private String transId;

    @Column(name = "EXT_SERIAL_NUM", length = 20)
    private String extSerialNum;

    @Column(name = "BANK_CODE", length = 20)
    private String bankCode;

    @Column(name = "TRACE_NUMBER", length = 10)
    private String traceNumber;

    @Column(name = "AUTH_CODE", length = 64)
    private String authCode;

    @Column(name = "RRN_CODE", length = 32)
    private String rrnCode;

    @Column(name = "BANK_REFERENCE_NUMBER", length = 32)
    private String bankReferenceNumber;

    @Column(name = "MERCHANT_ID", length = 32)
    private String merchantId;

    @Column(name = "MERCHANT_NAME", length = 128)
    private String merchantName;

    @Column(name = "MERCHANT_TRANS_ID", length = 64)
    private String merchantTransId;

    @Column(name = "MERCHANT_MBID", length = 32)
    private String merchantMbid;

    @Column(name = "ORIG_TXN_TYPE", length = 64)
    private String origTxnType;

    @Column(name = "ORIG_EXT_SERIAL_NUM", length = 20)
    private String origExtSerialNum;

    @Column(name = "ORIG_TXN_CURRENCY", length = 3)
    private String origTxnCurrency;

    @Column(name = "ORIG_TXN_AMOUNT")
    private BigDecimal origTxnAmount;

    @Column(name = "REFUND_CURRENCY", length = 3)
    private String refundCurrency;

    @Column(name = "REFUND_AMOUNT")
    private BigDecimal refundAmount;

    @Column(name = "REFUND_CREATION_TIME")
    private Date refundCreationTime;

    @Column(name = "ORIG_TXN_CREATION_TIME")
    private Date origTxnCreationTime;

    @Column(name = "FILE_ID", length = 20)
    private Long fileId;

    @Column(name = "RESULT_CODE_ID", length = 20)
    private String resultCodeId;

    @Column(name = "RESULT_CODE", length = 50)
    private String resultCode;

    @Column(name = "RESULT_STATUS", length = 50)
    private String resultStatus;

    @Column(name = "RESULT_MESSAGE")
    @Type(type = "text")
    private String resultMsg;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "created_on", nullable = false)
    private Date createdOn;

    @Basic(optional = false)
    @Column(name = "updated_on")
    @Temporal(TemporalType.TIMESTAMP)
    @UpdateTimestamp
    private Date updatedOn;

    @Column(name = "TID")
    private String tid;

    @Column(name = "STAN")
    private String stan;

    @Column(name = "INTERCHANGE")
    private String interchange;

    @Column(name = "MASKED_CARD_NO")
    private String maskedCardNo;

    @Column(name = "CARD_TYPE")
    private String cardType;

    @Column(name = "CARD_NO")
    private String cardNo;

    @Column(name = "TENURE")
    private Long tenure;

}
