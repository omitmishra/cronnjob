package com.paytm.pgplus.barfi.util;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Agrim
 *
 */

public class ZipUtil {

    private static final Logger LOGGER = LogManager.getLogger(ZipUtil.class);

    /**
     * Extracts Zip contents in the target folder
     * 
     * @param zipLocation
     * @param tragetFolder
     * @throws Exception
     * @throws ZipException
     */
    public static void extractZip(String zipLocation, String destination) throws Exception {
        ZipFile zipFile;
        try {
            zipFile = new ZipFile(zipLocation);
            zipFile.extractAll(destination);
            LOGGER.info("File unzipped successfully {}", zipLocation);
        } catch (ZipException e) {
            throw new Exception("Error in unzipping file", e);
        }
    }

}
