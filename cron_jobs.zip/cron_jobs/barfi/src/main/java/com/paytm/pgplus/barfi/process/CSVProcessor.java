package com.paytm.pgplus.barfi.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Agrim
 * @author Shubham
 *
 */

public interface CSVProcessor extends FileProcessor {

    /**
     * Using bufferReader to extract data from the file. Should be used when the
     * file is in CSV format, or plain simple text format.
     * 
     * @param File
     *            Unprocessed file directly from bank
     * @return List of Strings extracted data from file in list form
     */
    public default List<String> extractData(File file) throws IOException {

        List<String> csvList = new ArrayList<>();
        try (BufferedReader bufferReader = new BufferedReader(new FileReader(file))) {
            String bufferReaderStr = null;
            while ((bufferReaderStr = bufferReader.readLine()) != null) {
                if (!bufferReaderStr.isEmpty())
                    csvList.add(bufferReaderStr);
            }
        }
        return csvList;
    }

}
