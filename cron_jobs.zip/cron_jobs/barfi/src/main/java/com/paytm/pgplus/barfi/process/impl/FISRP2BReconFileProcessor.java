package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;

/**
 * @author Agrim
 *
 */

@Component(value = "FISRP2BReconFileProcessor")
public class FISRP2BReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(FISRP2BReconFileProcessor.class);
    private static final String DELIMITER = ",";
    private static final String COLHEAD = "TRANSACTION_DATE";
    private static final String SUCCESS_TRANSACTION_STATUS = "success";
    private static final String FAIL_TRANSACTION_STATUS = "failure";

    private static Map<String, Enum<ReconFileAdapter.Column>> chargingReconMap = new HashMap<>();

    static {

        chargingReconMap.put("AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        chargingReconMap.put("BANK_REF_ID", ReconFileAdapter.Column.BANK_TXN_ID);
        chargingReconMap.put("RRN", ReconFileAdapter.Column.RRN);
        chargingReconMap.put("TRANSACTION_REQ_ID", ReconFileAdapter.Column.TXN_ID);
        chargingReconMap.put("TRANSACTION_STATUS", ReconFileAdapter.Column.RESULT_CODE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            chargingColumnMap = mapColumns(adapter, csvList, chargingReconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, chargingColumnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int resultCodeColumn = getColumnNumberResultCode(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= resultCodeColumn) {
                    continue;
                }

                String resultCode = getResultCode(resultCodeColumn, row);
                if (resultCode.equalsIgnoreCase(SUCCESS_TRANSACTION_STATUS)) {
                    setChargingValues(reconAdapter, row, columnMap);
                }
                if (resultCode.equalsIgnoreCase(FAIL_TRANSACTION_STATUS)) {
                    setChargingValuesForFail(reconAdapter, row, columnMap);
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    private void setChargingValues(ReconFileAdapter reconAdapter, String[] row, Map<Integer, Enum<Column>> columnMap) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case GROSS_AMT:
                    entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case RRN:
                    entry.setRRN(AdapterUtil.replaceNoneValueWithEmptyStr(AdapterUtil.checkApostrophe(cell)));
                    entry.setBankTxnId(canBankTxnIdStartWithZero() ? AdapterUtil
                            .replaceNoneValueWithEmptyStr((AdapterUtil.checkApostrophe(cell))) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.replaceNoneValueWithEmptyStr(AdapterUtil
                                    .checkApostrophe(cell))));
                    break;
                default:
                    break;
                }
            }
        }
        entry.setAuthCode("0");
        entry.setDisc(0.0);
        entry.setMerchantCode("0");
        entry.setNet(0.0);
        entry.setSTax(0.0);

        reconAdapter.chargingWriteData(entry);
    }

    private void setChargingValuesForFail(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<Column>> columnMap) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
            String cell = AdapterUtil.removeQuotes(row[columnIndex]);
            if (StringUtils.isBlank(cell)) {
                continue;
            }
            cell = cell.trim();
            if (columnMap.containsKey(columnIndex)) {
                switch ((Column) columnMap.get(columnIndex)) {
                case GROSS_AMT:
                    entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                    break;
                case TXN_ID:
                    entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                    break;
                case RRN:
                    entry.setRRN(AdapterUtil.replaceNoneValueWithEmptyStr(AdapterUtil.checkApostrophe(cell)));
                    entry.setBankTxnId(canBankTxnIdStartWithZero() ? AdapterUtil
                            .replaceNoneValueWithEmptyStr((AdapterUtil.checkApostrophe(cell))) : AdapterUtil
                            .stripLeadingZeros(AdapterUtil.replaceNoneValueWithEmptyStr(AdapterUtil
                                    .checkApostrophe(cell))));
                    break;
                default:
                    break;
                }
            }
        }
        entry.setAuthCode("0");
        entry.setDisc(0.0);
        entry.setMerchantCode("0");
        entry.setNet(0.0);
        entry.setSTax(0.0);

        reconAdapter.chargingWriteDataForFail(entry);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    private String getResultCode(int colNo, String[] row) {
        return AdapterUtil.removeQuotes(row[colNo]).trim();
    }

    private int getColumnNumberResultCode(Map<Integer, Enum<Column>> columnMap) {
        for (Map.Entry<Integer, Enum<Column>> entry : columnMap.entrySet()) {
            if (Column.RESULT_CODE.equals(entry.getValue())) {
                return entry.getKey();
            }
        }
        return -1;
    }

}
