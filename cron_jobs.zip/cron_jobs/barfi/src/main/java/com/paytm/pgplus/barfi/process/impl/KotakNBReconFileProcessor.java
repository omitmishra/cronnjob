package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 * @author Jay Tiwari
 * @author saurabhmalviya
 *
 */

@Component(value = "KotakNBReconFileProcessor")
public class KotakNBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(KotakNBReconFileProcessor.class);

    private static final String DELIMITER = ",";

    private static Map<Integer, Enum<ReconFileAdapter.Column>> chargingMap;
    private static Map<Integer, Enum<ReconFileAdapter.Column>> refundMap;

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            chargingMap = mapColumnsCharging();
            refundMap = mapColumnsRefund();
            parseAndWrite(adapter, csvList, chargingMap, refundMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private static Map<Integer, Enum<Column>> mapColumnsCharging() {
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<Integer, Enum<ReconFileAdapter.Column>>();
        columnMap.put(9, Column.TXN_TYPE);
        columnMap.put(6, ReconFileAdapter.Column.GROSS_AMT);
        columnMap.put(8, ReconFileAdapter.Column.TXN_ID);
        columnMap.put(11, ReconFileAdapter.Column.BANK_TXN_ID);
        return columnMap;
    }

    private static Map<Integer, Enum<Column>> mapColumnsRefund() {
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<Integer, Enum<ReconFileAdapter.Column>>();
        columnMap.put(9, Column.TXN_TYPE);
        columnMap.put(6, ReconFileAdapter.Column.GROSS_AMT);
        columnMap.put(8, ReconFileAdapter.Column.TXN_ID);
        columnMap.put(11, ReconFileAdapter.Column.BANK_TXN_ID);
        return columnMap;
    }

    /**
     *
     * @param reconAdapter
     * @param csvList
     * @param chargingMap
     * @param refundMap
     * @param delimiter
     * @throws Exception
     */
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> chargingMap, Map<Integer, Enum<Column>> refundMap, String delimiter)
            throws Exception {

        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length < 9) {
                    continue;
                }
                if (row[9].equalsIgnoreCase("C"))
                    reconAdapter.setChargingValues(row, chargingMap, canBankTxnIdStartWithZero());
                else if (row[9].equalsIgnoreCase("D"))
                    reconAdapter.setRefundValues(row, refundMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }
}
