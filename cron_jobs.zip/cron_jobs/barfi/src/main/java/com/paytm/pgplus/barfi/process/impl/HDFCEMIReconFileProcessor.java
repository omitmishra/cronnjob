package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Nitin Kumar Bhola
 *
 */

@Component(value = "HDFCEMIReconFileProcessor")
public class HDFCEMIReconFileProcessor implements Processable, XLSProcessor {

    private static final Logger LOGGER = LogManager.getLogger(HDFCEMIReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "S.no";
    private static final String CHARGING_SUCCESS = "Payout done";
    private static final String REFUND_SUCCESS = "Refund/Cancelation";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {
        reconMap.put("TU REF#", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("Amt", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("Track id", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("Remarks", ReconFileAdapter.Column.RESULT_CODE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, String delimiter) throws Exception {

        // Get largest key from hashmap
        int highestKey = getHighestKey(columnMap);

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int resultCodeColNo = reconAdapter.getResultCodeColumnNumber(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);
                if (StringUtils.isBlank(row) || cellArr.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, cellArr))) {
                    continue;
                }

                if (CHARGING_SUCCESS.equalsIgnoreCase(reconAdapter.getTxnType(resultCodeColNo, cellArr))) {
                    reconAdapter.setChargingValues(cellArr, columnMap, canBankTxnIdStartWithZero());
                } else if (REFUND_SUCCESS.equalsIgnoreCase(reconAdapter.getTxnType(resultCodeColNo, cellArr))) {
                    String cell = AdapterUtil.removeQuotes(cellArr[colNo]);
                    double amt = Double.parseDouble(cell);
                    if (amt < 0)
                        reconAdapter.setRefundValues(cellArr, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }
    }
}
