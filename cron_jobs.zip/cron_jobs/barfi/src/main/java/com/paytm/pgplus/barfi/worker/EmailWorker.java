package com.paytm.pgplus.barfi.worker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.paytm.pgplus.barfi.queue.producer.EmailProducer;
import com.paytm.pgplus.rabbitmq.communication.models.EmailInfo;

import freemarker.template.Template;

@Component(value = "emailWorker")
public class EmailWorker {

    @Autowired
    EmailProducer emailProducer;

    public void sendMail(String[] sendTo, String subject, String text) {
        EmailInfo emailInfo = new EmailInfo();
        emailInfo.setTo(sendTo);
        emailInfo.setCc(null);
        emailInfo.setBcc(null);
        emailInfo.setSubject(subject);
        emailInfo.setMessage(text);
        emailProducer.publish(emailInfo);
    }

    public void sendMail(String[] sendTo, String subject, Object infoMap, Template template) throws Exception {

        EmailInfo emailInfo = new EmailInfo();
        emailInfo.setTo(sendTo);
        emailInfo.setCc(null);
        emailInfo.setBcc(null);
        emailInfo.setSubject(subject);
        String text = getFreeMarkerTemplateContent(infoMap, template);
        emailInfo.setMessage(text);

        emailProducer.publish(emailInfo);

    }

    public String getFreeMarkerTemplateContent(Object statistics, Template template) throws Exception {
        StringBuilder content = new StringBuilder();
        content.append(FreeMarkerTemplateUtils.processTemplateIntoString(template, statistics));
        return content.toString();
    }

}
