package com.paytm.pgplus.barfi.report;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component(value = "dailyReportGenerator")
public class DailyReportGenerator {

    private static final Logger LOGGER = LoggerFactory.getLogger(DailyReportGenerator.class);
    private String SUCCESS = "SUCCESS";
    private String FAIL = "FAIL";
    private String logString = "<tr bgcolor=\"#f1f1f1\"><th></th><th width=\"10%\">{}</th><th width=\"15%\">{}</th><th width=\"15%\">{}</th><th width=\"10%\">{}</th><th width=\"10%\">{}</th><th width=\"5%\">{}</th></tr>";

    /**
     * logs a success entry for report
     * 
     * @param bank
     * @param file
     * @param time
     * @param chargingCount
     * @param refundCount
     */
    public void logSuccessEntry(String bank, String file, String time, String chargingCount, String refundCount) {

        LOGGER.info(logString, bank, file, time, chargingCount, refundCount, SUCCESS);

    }

    /**
     * logs a fail entry for report
     * 
     * @param bank
     * @param file
     * @param time
     */
    public void logFailEntry(String bank, String file, String time) {

        LOGGER.info(logString, bank, file, time, StringUtils.EMPTY, StringUtils.EMPTY, FAIL);

    }

    /**
     * Logs a blank, for forced rollover of statistics_log
     */
    public void logBlank() {

        LOGGER.info(StringUtils.EMPTY);

    }

}