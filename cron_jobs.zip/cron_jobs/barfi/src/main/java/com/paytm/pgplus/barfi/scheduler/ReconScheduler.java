package com.paytm.pgplus.barfi.scheduler;

import com.paytm.pgplus.barfi.Task;
import com.paytm.pgplus.barfi.TaskExecutor;
import com.paytm.pgplus.barfi.service.SlackHelper;
import com.paytm.pgplus.barfi.util.FileUtil;
import com.paytm.pgplus.barfi.util.ReloadableProperties;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.File;
import java.nio.file.Paths;
import java.util.TimerTask;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SLASH;

/**
 * @author Agrim
 * @author Shubham
 *
 */

@Component
@EnableScheduling
@PropertySource("classpath:barfi.properties")
public class ReconScheduler extends TimerTask {

    private static final Logger LOGGER = LogManager.getLogger(ReconScheduler.class);

    @Autowired
    private TaskExecutor taskExecutor;

    @Autowired
    private Configuration freemarkerConfiguration;

    @Scheduled(cron = "${recon.scheduler.cron.expression}")
    public void run() {

        boolean barfiPPBLUPIZipSupportEnable = Boolean.parseBoolean(ReloadableProperties.getInstance().getStringValue(
                "barfi.ppbl.upi.zip.file.support.enable"));
        int reconSchedulerEnable = ReloadableProperties.getInstance().getIntValue("recon.scheduler.enable");
        String unprocessedDirPath = ReloadableProperties.getInstance().getStringValue("location.raw.unprocessed.dir");
        if (reconSchedulerEnable == 1) {
            LOGGER.info("RECON Scheduler start");
            Template template = null;
            try {
                template = freemarkerConfiguration.getTemplate("alertstemplate.ftl");
            } catch (Exception e) {
                LOGGER.error("Could not load e-mail template", e);
            }

            String[] directories = FileUtil.getAllSubDirectories(unprocessedDirPath);

            for (String dir : directories) {
                if (dir.equalsIgnoreCase("PPB-NB") || dir.equalsIgnoreCase("PEDC-EDC")
                        || dir.equalsIgnoreCase("PPBL-CC+DC")) {
                    dir = dir.concat(SLASH).concat(dir);
                    processFilesInPath(unprocessedDirPath + SLASH + dir, template);
                } else if (dir.equalsIgnoreCase("Paytm_Payment_Bank_Limited")) {
                    String[] subDirectories = FileUtil.getAllSubDirectories(unprocessedDirPath + SLASH + dir);
                    for (String subDir : subDirectories) {
                        processFilesInPath(unprocessedDirPath + SLASH + dir + SLASH + subDir, template);
                    }
                } else if (dir.equalsIgnoreCase("PPBL-BANK_TRANSFER")) {
                    String[] subDirectories = FileUtil.getAllSubDirectories(unprocessedDirPath + SLASH + dir);
                    for (String subDir : subDirectories) {
                        if(subDir.equalsIgnoreCase("PPSL")){
                            processFilesInPath(unprocessedDirPath + SLASH + dir + SLASH + subDir, template);
                        }
                    }
                } else if (dir.equalsIgnoreCase("PPBL-UPI") && barfiPPBLUPIZipSupportEnable) {
                    File file = null;
                    File folder = new File(unprocessedDirPath + SLASH + dir);
                    File[] listOfFiles = folder.listFiles();
                    for (int i = 0; i < listOfFiles.length; i++) {
                        try {
                            if (listOfFiles[i].isFile()) {
                                String filePath = folder + SLASH + listOfFiles[i].getName();
                                file = new File(filePath);
                                int currentDateHour = LocalDateTime.now().getHourOfDay();
                                int fileDateHour = new LocalDateTime(file.lastModified()).getHourOfDay();
                                LOGGER.info("Current Hour {} and file Hour {}", currentDateHour, fileDateHour);
                                if (StringUtils.isNotEmpty(filePath) && filePath.endsWith("zip") && !filePath.contains("PG_Paid_V1")) {
                                    LOGGER.info("PPBL UPI ZIP file Found {}", filePath);
                                    if(currentDateHour > fileDateHour) {
                                        FileUtil.unzip(filePath, folder.getAbsolutePath());
                                        FileUtil.deleteFile(file);
                                        try {
                                            Thread.sleep(5000);
                                        } catch (InterruptedException e) {
                                            LOGGER.error("Exception occured {} ", e);
                                        }
                                    }else{
                                        LOGGER.info("Waiting to complete at least one hour to unzip the file");
                                        return;
                                    }
                                }else{
                                    //Since it's consolidated file hence we deleted
                                    LOGGER.info("Node file path deleted {}", filePath);
                                    FileUtil.deleteFile(file);
                                }
                            }
                        } catch (Exception e) {
                            LOGGER.error("Exception occured for unzipping PPBL-UPI file {}", e);
                            SlackHelper
                                    .sendAlertToBoStatic("Critical: Exception occured for unzipping PPBL-UPI file {} "
                                            + e.getMessage());
                        }
                    }
                    processFilesInPath(unprocessedDirPath + SLASH + dir, template);
                } else {
                    processFilesInPath(unprocessedDirPath + SLASH + dir, template);
                }
            }
            LOGGER.info("RECON Scheduler end");
        }
    }

    private void processFilesInPath(String path, Template template) {

        File folder = new File(path);
        File[] listOfFiles = folder.listFiles();
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {
                String filePath = path + SLASH + listOfFiles[i].getName();
                try {
                    taskExecutor.submit(new Task(new File(filePath), template));
                } catch (Exception e) {
                    LOGGER.error("raw file not found at location '{}' ", filePath);
                    LOGGER.error(e.getMessage(), e);
                }
            }
        }

    }
}