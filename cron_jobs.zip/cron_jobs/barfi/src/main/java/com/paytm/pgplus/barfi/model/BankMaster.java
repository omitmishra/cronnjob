package com.paytm.pgplus.barfi.model;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.UpdateTimestamp;

import javax.persistence.*;
import java.util.Date;

/**
 * @author Sakshi Jain
 */

@Setter
@Getter
@Entity
@Table(name = "BANK_MASTER")
public class BankMaster {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "BANK_ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer bankId;

    @Column(name = "BANK_NAME")
    private String bankName;

    @Column(name = "BANK_CODE")
    private String bankCode;

    @Column(name = "STATUS")
    private Integer status;

    @Column(name = "BANK_DISPLAY_NAME")
    private String bankDisplayName;

    @Column(name = "BANK_KEY")
    private String bankKey;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATED_DATE", nullable = false, updatable = false)
    private Date createdOn = new Date();

    @Column(name = "CREATED_BY")
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "MODIFIED_DATE", nullable = false)
    @UpdateTimestamp
    private Date updatedOn = new Date();

    @Column(name = "MODIFIED_BY")
    private Long updatedBy;

    @Column(name = "BANK_WAP_LOGO")
    private String bankWapLogo;

    @Column(name = "ALIPAY_CODE")
    private String alipayCode;

    @Column(name = "BANK_WEB_LOGO")
    private String bankWebLogo;

    @Column(name = "STANDARD_BANK_CODE")
    private String standardBankCode;
}