package com.paytm.pgplus.barfi.dao.impl;

import com.paytm.pgplus.barfi.dao.IOfflineRefundTxnDao;
import com.paytm.pgplus.barfi.model.OfflineRefundTxn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

import static com.paytm.pgplus.barfi.constants.QueriesHelper.HqlQuery.OFFLINE_REFUND_TXN_ID_BY_AUTH_CODE_AND_BANK_TID;

@Repository("offlineRefundTxnDaoImpl")
public class OfflineRefundTxnDaoImpl extends BaseAbstractDao<OfflineRefundTxn, Integer> implements IOfflineRefundTxnDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(OfflineRefundTxnDaoImpl.class);;

    @Transactional(readOnly = true)
    @Override
    public List<OfflineRefundTxn> fetchTransactionId(final List<String> authCodeList, final List<String> bankTidList) {
        LOGGER.info("Fetching data from EDC batch");

        final List<OfflineRefundTxn> txnList = this.findByHqlQuery(OFFLINE_REFUND_TXN_ID_BY_AUTH_CODE_AND_BANK_TID,
                new Object[] { authCodeList, bankTidList });
        if (txnList != null) {
            LOGGER.info("Size of data from DB: " + txnList.size());
            return txnList;
        }
        return null;
    }
}