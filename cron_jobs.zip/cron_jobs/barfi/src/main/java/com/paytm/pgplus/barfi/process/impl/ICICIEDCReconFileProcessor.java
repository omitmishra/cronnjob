package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.constants.Constants;
import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.*;

/**
 * @author Sakshi Jain
 */

@Component(value = "ICICIEDCReconFileProcessor")
public class ICICIEDCReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(ICICIEDCReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "SUPER MID";
    private static final String CLEARED = "CLEARED";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    private static Map<String, String> txtTypeSet = new HashMap<>();

    static {
        txtTypeSet.put(Constants.PAYTM_CHARGING, "PURCHASE");
        txtTypeSet.put(Constants.PAYTM_REFUND, "REFUND");

        reconMap.put("AMOUNT", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("TRANSACTION STATUS", ReconFileAdapter.Column.RESULT_CODE);
        reconMap.put("CUSTOM DATA", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("RET_REF_NUM", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("TRANSACTION TYPE", ReconFileAdapter.Column.TXN_TYPE);
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList;
        Map<Enum<ReconFileAdapter.Column>, Integer> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = columnNameToTxnIdMap(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWriteAllColumnIntegerMap(adapter, csvList, columnMap, DELIMITER, CLEARED, txtTypeSet);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }
}
