package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author amankumar
 */

@Component(value = "DENANBReconFileProcessor")
public class DENANBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(DENANBReconFileProcessor.class);
    private static final String DELIMITER = "\\^";

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return false;
    }

    @Override
    public void process(ReconFileAdapter adapter) {
        List<String> csvList = null;

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = mapColumns();

        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            csvList = fixAuthCodeTraceId(csvList);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private Map<Integer, Enum<ReconFileAdapter.Column>> mapColumns() {

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
        columnMap.put(3, ReconFileAdapter.Column.GROSS_AMT);
        columnMap.put(1, ReconFileAdapter.Column.TXN_ID);
        columnMap.put(2, ReconFileAdapter.Column.BANK_TXN_ID);
        columnMap.put(6, ReconFileAdapter.Column.AUTH_CODE);
        return columnMap;
    }

    private List<String> fixAuthCodeTraceId(List<String> csvList) {
        List<String> updatedCSVList = new ArrayList<>();
        for (String row : csvList) {
            StringBuffer s = new StringBuffer(row);
            s.replace(s.lastIndexOf("^"), s.lastIndexOf("^") + 1, "/");
            updatedCSVList.add(s.toString());
        }
        return updatedCSVList;
    }

}
