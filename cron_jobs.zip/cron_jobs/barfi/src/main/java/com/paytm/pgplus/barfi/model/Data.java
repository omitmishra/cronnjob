package com.paytm.pgplus.barfi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Data {

    @JacksonXmlText
    private String data;

    public String get() {
        return data;
    }

    @Override
    public String toString() {
        return "Data [data=" + data + "]";
    }

    public void setData(String data) {
        this.data = data;
    }

}
