package com.paytm.pgplus.barfi.dao.impl;

import com.paytm.pgplus.barfi.constants.QueriesHelper;
import com.paytm.pgplus.barfi.dao.IBinMasterDao;
import com.paytm.pgplus.barfi.model.BinMaster;
import com.paytm.pgplus.barfi.model.QueryParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

/**
 * @author Sakshi Jain
 */

@Repository("binMasterDao")
public class BinMasterDaoImpl extends BaseAbstractDao<BinMaster, Integer> implements IBinMasterDao {

    private static final Logger LOGGER = LoggerFactory.getLogger(BinMasterDaoImpl.class);

    /**
     * @param binSet
     *            Set<Integer>
     * @return Bin master list
     */
    @Override
    @Transactional(readOnly = true)
    public List<BinMaster> fetchBinDetails(Set<Integer> binSet) {
        List<BinMaster> binMasterList;
        LOGGER.info("Fetching data from BinMaster");

        QueryParam queryParam;
        queryParam = new QueryParam(QueriesHelper.HqlQuery.BIN_DETAILS_BY_BIN_NUMBER);
        queryParam.getParam().add(binSet);
        binMasterList = findByHqlQuery(queryParam.getQuery().toString(), queryParam.getParam().toArray());

        return binMasterList;
    }

    /**
     * @param binMasterList
     *            List<BinMaster>
     */
    @Override
    @Transactional(readOnly = false)
    public void saveBinMasterList(List<BinMaster> binMasterList) {
        saveBatch(binMasterList);
    }

    /**
     * @param binMasterList
     *            List<BinMaster>
     */
    @Override
    @Transactional(readOnly = false)
    public void updateBinMasterList(List<BinMaster> binMasterList) {
        updateBatch(binMasterList);
    }
}