package com.paytm.pgplus.barfi.process.impl;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSOldFormatProcessor;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

@Component(value = "PAGGCCReconFileProcessor")
public class PAGGCCReconFileProcessor implements Processable, XLSOldFormatProcessor {

    private static final Logger LOGGER = LogManager.getLogger(PAGGCCReconFileProcessor.class);

    private static final String DELIMITER = ",";
    private static final String COLHEAD = "Request ID";
    private static final String REFUND = "refund";
    private static final String CHARGING = "capture";

    private static Map<String, Enum<ReconFileAdapter.Column>> chargingReconMap = new HashMap<>();
    private static Map<String, Enum<ReconFileAdapter.Column>> refundReconMap = new HashMap<>();
    private static Map<Enum<ReconFileAdapter.Column>, Boolean> costParamMap = new HashMap<>();

    static {
        chargingReconMap.put("Transaction ID", ReconFileAdapter.Column.TXN_ID);
        chargingReconMap.put("Amount", ReconFileAdapter.Column.GROSS_AMT);
        chargingReconMap.put("PayU ID", ReconFileAdapter.Column.BANK_TXN_ID);
        chargingReconMap.put("Bank Reference No", ReconFileAdapter.Column.RRN);
        chargingReconMap.put("Requested Action", ReconFileAdapter.Column.TXN_TYPE);

        refundReconMap.put("Token", ReconFileAdapter.Column.TXN_ID);
        refundReconMap.put("Amount", ReconFileAdapter.Column.GROSS_AMT);
        refundReconMap.put("Request ID", ReconFileAdapter.Column.BANK_TXN_ID);
        refundReconMap.put("Bank Reference No", ReconFileAdapter.Column.RRN);
        refundReconMap.put("Requested Action", ReconFileAdapter.Column.TXN_TYPE);

        chargingReconMap.put("Service Fee", ReconFileAdapter.Column.BANK_COMMISSION);
        chargingReconMap.put("Service Tax", ReconFileAdapter.Column.BANK_CGST);
        chargingReconMap.put("IssuingBank", ReconFileAdapter.Column.ONUS_INDC);
        chargingReconMap.put("Mode", ReconFileAdapter.Column.BANK_CARDSCHEME);
        chargingReconMap.put("Payment Type", ReconFileAdapter.Column.CARD_TYPE);
        chargingReconMap.put("International/Domestic", ReconFileAdapter.Column.CARD_CATEGORY);
        chargingReconMap.put("PG MID", ReconFileAdapter.Column.MERCHANT_CODE);
        chargingReconMap.put("Merchant UTR", ReconFileAdapter.Column.TXN_CURR);

        refundReconMap.put("Service Fee", ReconFileAdapter.Column.BANK_COMMISSION);
        refundReconMap.put("Service Tax", ReconFileAdapter.Column.BANK_CGST);
        refundReconMap.put("IssuingBank", ReconFileAdapter.Column.ONUS_INDC);
        refundReconMap.put("Mode", ReconFileAdapter.Column.BANK_CARDSCHEME);
        refundReconMap.put("Payment Type", ReconFileAdapter.Column.CARD_TYPE);
        refundReconMap.put("International/Domestic", ReconFileAdapter.Column.CARD_CATEGORY);
        refundReconMap.put("PG MID", ReconFileAdapter.Column.MERCHANT_CODE);
        refundReconMap.put("Merchant UTR", ReconFileAdapter.Column.TXN_CURR);

        costParamMap.put(ReconFileAdapter.Column.BANK_COMMISSION, true);
        costParamMap.put(ReconFileAdapter.Column.BANK_CGST, true);
        costParamMap.put(ReconFileAdapter.Column.ONUS_INDC, true);
        costParamMap.put(ReconFileAdapter.Column.BANK_CARDSCHEME, true);
        costParamMap.put(ReconFileAdapter.Column.CARD_TYPE, true);
        costParamMap.put(ReconFileAdapter.Column.MERCHANT_CODE, true);
        costParamMap.put(ReconFileAdapter.Column.CARD_CATEGORY, true);
        costParamMap.put(ReconFileAdapter.Column.TXN_CURR, true);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> refColumnMap;
        Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            chargingColumnMap = mapColumns(adapter, csvList, chargingReconMap, DELIMITER, COLHEAD);
            refColumnMap = mapColumns(adapter, csvList, refundReconMap, DELIMITER, COLHEAD);
            parseAndWrite(adapter, csvList, chargingColumnMap, refColumnMap, DELIMITER, CHARGING, REFUND);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<ReconFileAdapter.Column>> chargingColumnMap,
            Map<Integer, Enum<ReconFileAdapter.Column>> refundColumnMap, String delimiter, String charging,
            String refund) throws Exception {

        int colNo = reconAdapter.getColumnNumberDRCR(chargingColumnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(delimiter);
                if (StringUtils.isBlank(r) || row.length <= colNo) {
                    continue;
                }
                if (refund.equals(reconAdapter.getTxnType(colNo, row))) {
                    setRefundValues(reconAdapter, row, refundColumnMap, canBankTxnIdStartWithZero());
                }
                if (charging.equals(reconAdapter.getTxnType(colNo, row))) {
                    setChargingValues(reconAdapter, row, chargingColumnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    public void setRefundValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        DecimalFormat df = new DecimalFormat("#.####");
        String cardScheme = "";
        String cardType = "";
        String cardCategory = "";
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();

                    if (columnMap.containsKey(columnIndex)) {
                        switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                        case RRN:
                            entry.setRrn(AdapterUtil.setZeroIfNotNumeric(AdapterUtil.setZeroIfBlank(AdapterUtil
                                    .checkApostrophe(cell))));
                            break;
                        case GROSS_AMT:
                            Double intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setRefundAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;

                        case BANK_COMMISSION:
                            entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CGST:
                            entry.setBankGST(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case ONUS_INDC:
                            // entry.setOnusIndicator(AdapterUtil.checkApostrophe(cell));
                            // asked by tarunay to remove
                            break;
                        case BANK_CARDSCHEME:
                            cardScheme = AdapterUtil.checkApostrophe(cell);
                            break;
                        case CARD_TYPE:
                            cardType = AdapterUtil.checkApostrophe(cell);
                            break;
                        case CARD_CATEGORY:
                            cardCategory = AdapterUtil.checkApostrophe(cell);
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TXN_CURR:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;

                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRrn())) {
                entry.setRrn("0");
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getRefundAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            if (cardScheme != null) {
                if (cardScheme.toLowerCase().indexOf("visa") >= 0)
                    entry.setBankCardScheme("Visa");
                else if (cardScheme.toLowerCase().indexOf("rupay") >= 0)
                    entry.setBankCardScheme("Rupay");
                else if (cardScheme.toLowerCase().indexOf("master") >= 0)
                    entry.setBankCardScheme("Mastercard");
                else
                    entry.setBankCardScheme("Diner");
            }
            if (cardCategory != null) {
                if (cardCategory.toLowerCase().indexOf("international") >= 0)
                    entry.setBankInternational((byte) 1);
                else
                    entry.setBankInternational((byte) 0);

                if (cardCategory.toLowerCase().indexOf("corporate") >= 0)
                    entry.setBankCorporate((byte) 1);
                else
                    entry.setBankCorporate((byte) 0);
            }
            entry.setBankCardType(cardType);
            entry.setNeftNo(0.0);
            entry.setStatus(SUCCESS);
            entry.setTxnAmount(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setRefundValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForRefund(entry);
        reconAdapter.refundWriteData(entry);
    }

    private void setChargingValues(ReconFileAdapter reconAdapter, String[] row,
            Map<Integer, Enum<ReconFileAdapter.Column>> columnMap, boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        DecimalFormat df = new DecimalFormat("#.####");
        Double intnlAmount = 0.0;
        String cardScheme = "";
        String cardType = "";
        String cardCategory = "";
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();
                    if (columnMap.containsKey(columnIndex)) {
                        switch ((ReconFileAdapter.Column) columnMap.get(columnIndex)) {
                        case GROSS_AMT:
                            intnlAmount = (null != entry.getIntnlAmount()) ? entry.getIntnlAmount() : 0.0;
                            entry.setGrossAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))) + intnlAmount);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case BANK_TXN_ID:
                            // If bankTxnId can start with zero in processed,
                            // then
                            // do
                            // not strip leading zeroes
                            entry.setBankTxnId(canBankTxnIdStartWithZero ? AdapterUtil.checkApostrophe(cell)
                                    : AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        case INTNL:
                            entry.setIntnlAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case AUTH_CODE:
                            entry.setAuthCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case RRN:
                            entry.setRRN(AdapterUtil.checkApostrophe(cell));
                            break;
                        case BANK_COMMISSION:
                            entry.setBankComissionAmount(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case BANK_CGST:
                            entry.setBankGST(Math.abs(Double.parseDouble(cell.replaceAll(",", ""))));
                            break;
                        case ONUS_INDC:
                            // entry.setOnusIndicator(AdapterUtil.checkApostrophe(cell));
                            // asked by tarunay to remove
                            break;
                        case BANK_CARDSCHEME:
                            cardScheme = AdapterUtil.checkApostrophe(cell);
                            break;
                        case CARD_TYPE:
                            cardType = AdapterUtil.checkApostrophe(cell);
                            break;
                        case CARD_CATEGORY:
                            cardCategory = AdapterUtil.checkApostrophe(cell);
                            break;
                        case MERCHANT_CODE:
                            entry.setMerchantCode(AdapterUtil.checkApostrophe(cell));
                            break;
                        case TXN_CURR:
                            entry.setUdf1(AdapterUtil.checkApostrophe(cell));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMap.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (StringUtils.isBlank(entry.getAuthCode())) {
                entry.setAuthCode("0");
            }
            if (StringUtils.isBlank(entry.getBankTxnId())) {
                entry.setBankTxnId("0");
            }
            if (StringUtils.isBlank(entry.getRRN())) {
                entry.setRRN("0");
            }
            entry.setBankComissionPerc(new Double(df.format(entry.getBankComissionAmount() / entry.getGrossAmount())));
            entry.setBankVAT(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankCess(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankServiceTax()
                    + entry.getBankCess());
            if (cardScheme != null) {
                if (cardScheme.toLowerCase().indexOf("visa") >= 0)
                    entry.setBankCardScheme("Visa");
                else if (cardScheme.toLowerCase().indexOf("rupay") >= 0)
                    entry.setBankCardScheme("Rupay");
                else if (cardScheme.toLowerCase().indexOf("master") >= 0)
                    entry.setBankCardScheme("Mastercard");
                else
                    entry.setBankCardScheme("Diner");
            }
            if (cardCategory != null) {
                if (cardCategory.toLowerCase().indexOf("international") >= 0)
                    entry.setBankInternational((byte) 1);
                else
                    entry.setBankInternational((byte) 0);
                if (cardCategory.toLowerCase().indexOf("corporate") >= 0)
                    entry.setBankCorporate((byte) 1);
                else
                    entry.setBankCorporate((byte) 0);
            }
            entry.setBankCardType(cardType);
            entry.setDisc(0.0);
            entry.setNet(0.0);
            entry.setSTax(0.0);
        } catch (Exception e) {
            LOGGER.error("Exception in setChargingValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
            costFieldError = true;
        }
        if (costFieldError)
            entry = reconAdapter.resetCostParametersForCharging(entry);
        reconAdapter.chargingWriteData(entry);
    }
}
