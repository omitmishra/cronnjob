package com.paytm.pgplus.barfi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
@JacksonXmlRootElement(localName = "Workbook")
public class Workbook {

    @Override
    public String toString() {
        return "Workbook [worksheet=" + worksheet + "]";
    }

    @JacksonXmlProperty(localName = "Worksheet")
    private Worksheet worksheet;

    public Worksheet getWorksheet() {
        return worksheet;
    }

    public void setWorksheet(Worksheet worksheet) {
        this.worksheet = worksheet;
    }

}
