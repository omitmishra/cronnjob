package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

/**
 *
 * @author saurabh.malviya
 *
 */

@Component(value = "JSBNBReconFileProcessor")
public class JSBNBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(JSBNBReconFileProcessor.class);

    private static final String DELIMITER = "\\^";

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns();
            parseAndWriteCharging(adapter, csvList, columnMap);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    /**
     *
     * @param reconAdapter
     * @param csvList
     * @param columnMap
     * @param delimiter
     * @throws Exception
     */

    private void parseAndWriteCharging(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap) throws Exception {
        int recordIdentifier = 3;
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String r = csvList.get(rowNum);
                String[] row = r.split(DELIMITER);
                if (StringUtils.isBlank(r)) {
                    continue;
                }
                if (("N").equalsIgnoreCase(row[recordIdentifier])) {
                    continue;
                }
                if (row[1].isEmpty()) {
                    continue;
                }
                reconAdapter.setChargingValues(row, columnMap, canBankTxnIdStartWithZero());
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    private Map<Integer, Enum<Column>> mapColumns() {

        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();

        columnMap.put(2, ReconFileAdapter.Column.GROSS_AMT);
        columnMap.put(0, ReconFileAdapter.Column.TXN_ID);
        columnMap.put(1, ReconFileAdapter.Column.BANK_TXN_ID);
        return columnMap;
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }

}
