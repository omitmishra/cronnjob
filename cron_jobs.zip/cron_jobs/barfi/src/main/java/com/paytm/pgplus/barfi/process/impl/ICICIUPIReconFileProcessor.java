package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.process.XLSXProcessor;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

/**
 * @author Agrim
 *
 */

@Component(value = "ICICIUpiReconFileProcessor")
public class ICICIUPIReconFileProcessor implements Processable, XLSXProcessor {

    private static final Logger LOGGER = LogManager.getLogger(ICICIUPIReconFileProcessor.class);

    private static final String DELIMITER = "\\|";
    private static final String COLHEAD = "accountNumber";

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("merchantTranID", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("bankTranID", ReconFileAdapter.Column.BANK_TXN_ID);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            parseAndWriteCharging(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }
}
