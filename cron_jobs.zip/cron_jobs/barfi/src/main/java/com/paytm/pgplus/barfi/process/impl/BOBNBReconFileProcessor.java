package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.paytm.pgplus.barfi.exception.PaytmBarfiException;
import org.apache.commons.collections4.MapUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;
import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;

/*
 * @author= Ashu Vaidwan
 */

@Component(value = "BOBNBReconFileProcessor")
public class BOBNBReconFileProcessor implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(BOBNBReconFileProcessor.class);
    private static final String DELIMITER = "\\|";
    private static final String[] COLHEADS = { "Sr.No", "Sr. no" };

    private static Map<String, Enum<ReconFileAdapter.Column>> reconMap = new HashMap<>();

    static {

        reconMap.put("paytmTxnId", ReconFileAdapter.Column.TXN_ID);
        reconMap.put("Transaction Amount", ReconFileAdapter.Column.GROSS_AMT);
        reconMap.put("Bank_reff_No", ReconFileAdapter.Column.BANK_TXN_ID);
        reconMap.put("AccountNo", ReconFileAdapter.Column.AUTH_CODE);
    }

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = null;
        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumnsforColheads(csvList, adapter);
            parseAndWriteCharging(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    public Map<Integer, Enum<ReconFileAdapter.Column>> mapColumnsforColheads(List<String> csvList,
            ReconFileAdapter adapter) throws IOException, PaytmBarfiException {
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = null;
        for (String COLHEAD : COLHEADS) {
            try {
                columnMap = mapColumns(adapter, csvList, reconMap, DELIMITER, COLHEAD);
            } catch (PaytmBarfiException e) {
                LOGGER.info("Unable to create Column map- colHead {}", COLHEAD);
            }
        }
        if (MapUtils.isEmpty(columnMap)) {
            throw new PaytmBarfiException(" Exception - Process Failed due to missing column heads, FileName  "
                    + adapter.fileName);
        }
        return columnMap;
    }

    @Override
    public boolean canBankTxnIdStartWithZero() {
        return true;
    }
}
