package com.paytm.pgplus.barfi.process.impl;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.paytm.pgplus.barfi.process.CSVProcessor;
import com.paytm.pgplus.barfi.vo.ProcessedChargingRow;
import com.paytm.pgplus.barfi.vo.ProcessedRefundRow;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Component;

import com.paytm.pgplus.barfi.process.Processable;
import com.paytm.pgplus.barfi.util.AdapterUtil;
import com.paytm.pgplus.barfi.util.ReconFileAdapter;
import com.paytm.pgplus.barfi.util.ReconFileAdapter.Column;

import static com.paytm.pgplus.barfi.util.AdapterConstants.SUCCESS;

/**
 * @author himanshu4.garg
 */

@Component(value = "AMEXBankCardReconFileProcessorV2")
public class AMEXCCReconFileProcessorV2 implements Processable, CSVProcessor {

    private static final Logger LOGGER = LogManager.getLogger(AMEXCCReconFileProcessorV2.class);

    private static final String DELIMITER = ",";
    private static final short TRANSACTION_COLUMN = 0;
    private static final String TRANSACTION = "TRANSACTN";
    private static final String TXNPRICING = "TXNPRICING";
    private static Map<String, List<ProcessedChargingRow>> pricingMap = new HashMap<>();
    private static Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<>();
    private static Map<Integer, Enum<ReconFileAdapter.Column>> columnMapPricing = new HashMap<>();;
    private static Map<String, Boolean> costErrorMap = new HashMap<>();
    private static Map<Enum<ReconFileAdapter.Column>, Boolean> costParamMap = new HashMap<>();

    @Override
    public void process(ReconFileAdapter adapter) {

        List<String> csvList = null;

        try {
            LOGGER.info("Filename: {}", adapter.fileName);
            csvList = extractData(adapter.getProcessingFileHandle());
            columnMap = mapColumns();
            columnMapPricing = mapPricingColumn();
            extractPricingData(adapter, csvList, columnMapPricing, DELIMITER);
            parseAndWrite(adapter, csvList, columnMap, DELIMITER);
            LOGGER.info("File '{}' Processed Successfully", adapter.fileName);
            adapter.markSuccess();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail("Error in reading file " + adapter.fileName);
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            adapter.markFail(e.getMessage());
        }
    }

    private static Map<Integer, Enum<Column>> mapColumns() {
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<Integer, Enum<ReconFileAdapter.Column>>();
        columnMap.put(17, ReconFileAdapter.Column.GROSS_AMT);
        columnMap.put(12, ReconFileAdapter.Column.TXN_ID);
        columnMap.put(6, ReconFileAdapter.Column.MERCHANT_CODE);
        return columnMap;
    }

    private static Map<Integer, Enum<Column>> mapPricingColumn() {
        Map<Integer, Enum<ReconFileAdapter.Column>> columnMap = new HashMap<Integer, Enum<ReconFileAdapter.Column>>();
        columnMap.put(9, Column.TXN_ID);
        columnMap.put(17, Column.BANK_COMMISSION);
        columnMap.put(18, Column.GROSS_AMT);
        costParamMap.put(Column.BANK_COMMISSION, true);
        costParamMap.put(Column.GROSS_AMT, true);
        return columnMap;
    }

    @Override
    public void parseAndWrite(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMap, String delimiter) throws Exception {

        int colNo = reconAdapter.getColumnNumberAmount(columnMap);
        int highestKey = getHighestKey(columnMap);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);
                if (StringUtils.isBlank(row) || cellArr.length <= highestKey) {
                    continue;
                }
                if (!NumberUtils.isParsable(reconAdapter.getTxnType(colNo, cellArr))) {
                    continue;
                }
                if (!TRANSACTION.equalsIgnoreCase(reconAdapter.getTxnType(TRANSACTION_COLUMN, cellArr))) {
                    continue;
                }
                if (reconAdapter.getTxnType(colNo, cellArr).startsWith("-")) {
                    setRefundValues(reconAdapter, cellArr, columnMap, canBankTxnIdStartWithZero());
                } else {
                    setChargingValues(reconAdapter, cellArr, columnMap, canBankTxnIdStartWithZero());
                }
            } catch (Exception e) {
                throw new Exception("File " + reconAdapter.fileName + " parsing error at line " + rowNum, e);
            }
        }

    }

    public void setChargingValues(ReconFileAdapter reconAdapter, String[] row, Map<Integer, Enum<Column>> columnMap,
            boolean canBankTxnIdStartWithZero) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        List<ProcessedChargingRow> pricingList = null;
        DecimalFormat df = new DecimalFormat("#.####");
        DecimalFormat df1 = new DecimalFormat("#.##");
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                if (StringUtils.isBlank(cell)) {
                    continue;
                }
                cell = cell.trim();
                if (columnMap.containsKey(columnIndex)) {
                    switch ((Column) columnMap.get(columnIndex)) {
                    case GROSS_AMT:
                        entry.setGrossAmount((Math.abs(Double.parseDouble(cell.replaceAll(",", "")))) / 100);
                        break;
                    case TXN_ID:
                        entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        break;
                    case MERCHANT_CODE:
                        entry.setMerchantCode(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        entry.setMbid(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        break;
                    default:
                        break;
                    }
                }
            }

            entry.setAuthCode("0");
            entry.setBankTxnId("0");
            entry.setRRN("0");
            entry.setDisc(0.0);
            entry.setNet(0.0);
            entry.setSTax(0.0);
            Double MDR = 0.0;
            Double GST = 0.0;
            Double bankCommissionPerc = 0.0;
            if (!StringUtils.isBlank(entry.getTxnId())) {
                if (pricingMap.containsKey(entry.getTxnId())) {
                    pricingList = pricingMap.get(entry.getTxnId());
                    int count = 0;
                    int pricingDataCount = pricingList.size();
                    for (int pricingDataNum = 0; pricingDataNum < pricingDataCount; pricingDataNum++) {
                        if (count % 2 == 0) {
                            MDR = MDR + pricingList.get(pricingDataNum).getGrossAmount();
                            bankCommissionPerc = bankCommissionPerc
                                    + pricingList.get(pricingDataNum).getBankComissionPerc();
                        } else {
                            GST = GST + pricingList.get(pricingDataNum).getGrossAmount();
                        }
                        count++;
                    }
                }
            }
            entry.setBankComissionPerc(new Double(df.format(bankCommissionPerc)));
            entry.setBankComissionAmount(new Double(df1.format(MDR)));
            entry.setBankGST(new Double(df1.format(GST)));
            entry.setBankVAT(0.0);
            entry.setBankCess(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankCess()
                    + entry.getBankServiceTax());
            entry.setBankCardType("Credit Card");
        } catch (Exception e) {
            LOGGER.error("Exception in setChargingValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
        }
        if (costErrorMap.containsKey(entry.getTxnId()))
            entry = reconAdapter.resetCostParametersForCharging(entry);
        reconAdapter.chargingWriteData(entry);
    }

    public void setRefundValues(ReconFileAdapter reconAdapter, String[] row, Map<Integer, Enum<Column>> columnMap,
            boolean canBankTxnIdStartWithZero) {

        ProcessedRefundRow entry = new ProcessedRefundRow();
        List<ProcessedChargingRow> pricingList = null;
        DecimalFormat df = new DecimalFormat("#.####");
        DecimalFormat df1 = new DecimalFormat("#.##");
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                if (StringUtils.isBlank(cell)) {
                    continue;
                }
                cell = cell.trim();

                if (columnMap.containsKey(columnIndex)) {
                    switch ((Column) columnMap.get(columnIndex)) {
                    case GROSS_AMT:
                        entry.setRefundAmount((Math.abs(Double.parseDouble(cell.replaceAll(",", "")))) / 100);
                        break;
                    case TXN_ID:
                        entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        break;
                    case MERCHANT_CODE:
                        entry.setMerchantCode(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                        break;
                    default:
                        break;
                    }
                }
            }

            entry.setBankTxnId("0");
            entry.setRrn("0");
            entry.setNeftNo(0.0);
            entry.setStatus(SUCCESS);
            entry.setTxnAmount(0.0);

            Double MDR = 0.0;
            Double GST = 0.0;
            Double bankCommissionPerc = 0.0;
            if (!StringUtils.isBlank(entry.getTxnId())) {
                if (pricingMap.containsKey(entry.getTxnId())) {
                    pricingList = pricingMap.get(entry.getTxnId());
                    int count = 0;
                    int pricingDataCount = pricingList.size();
                    for (int pricingDataNum = 0; pricingDataNum < pricingDataCount; pricingDataNum++) {
                        if (count % 2 == 0) {
                            MDR = MDR + pricingList.get(pricingDataNum).getGrossAmount();
                            bankCommissionPerc = bankCommissionPerc
                                    + pricingList.get(pricingDataNum).getBankComissionPerc();
                        } else {
                            GST = GST + pricingList.get(pricingDataNum).getGrossAmount();
                        }
                        count++;
                    }
                }
            }
            entry.setBankComissionPerc(new Double(df.format(bankCommissionPerc)));
            entry.setBankComissionAmount(new Double(df1.format(MDR)));
            entry.setBankGST(new Double(df1.format(GST)));
            entry.setBankVAT(0.0);
            entry.setBankCess(0.0);
            entry.setBankServiceTax(0.0);
            entry.setBankTotalTax(entry.getBankGST() + entry.getBankVAT() + entry.getBankCess()
                    + entry.getBankServiceTax());
            entry.setBankCardType("Credit Card");
        } catch (Exception e) {
            LOGGER.error("Exception in setRefundValues for TxnId : {} | {} ", entry.getTxnId(), e.getMessage());
        }
        if (costErrorMap.containsKey(entry.getTxnId()))
            entry = reconAdapter.resetCostParametersForRefund(entry);
        reconAdapter.refundWriteData(entry);
    }

    public void extractPricingData(ReconFileAdapter reconAdapter, List<String> csvList,
            Map<Integer, Enum<Column>> columnMapPricing, String delimiter) {

        int highestKey = getHighestKey(columnMapPricing);
        int rowEnd = csvList.size();
        for (int rowNum = 0; rowNum < rowEnd; rowNum++) {
            try {
                String row = csvList.get(rowNum);
                String[] cellArr = row.split(delimiter);
                if (StringUtils.isBlank(row) || cellArr.length <= highestKey) {
                    continue;
                }
                if (!TXNPRICING.equalsIgnoreCase(reconAdapter.getTxnType(TRANSACTION_COLUMN, cellArr))) {
                    continue;
                }
                extractValues(reconAdapter, cellArr, columnMapPricing);
            } catch (Exception e) {
                LOGGER.error("Exception while extracting pricing data | {} ", e.getMessage());
            }
        }
    }

    public void extractValues(ReconFileAdapter reconAdapter, String[] row, Map<Integer, Enum<Column>> columnMapPricing) {
        ProcessedChargingRow entry = new ProcessedChargingRow();
        List<ProcessedChargingRow> txnPricingList = null;
        boolean costFieldError = false;
        try {
            for (int columnIndex = 0; columnIndex < row.length; columnIndex++) {
                try {
                    String cell = AdapterUtil.removeQuotes(row[columnIndex]);
                    if (StringUtils.isBlank(cell)) {
                        continue;
                    }
                    cell = cell.trim();
                    if (columnMapPricing.containsKey(columnIndex)) {
                        switch ((Column) columnMapPricing.get(columnIndex)) {
                        case GROSS_AMT:
                            entry.setGrossAmount((Double.parseDouble(cell.replaceAll(",", ""))) / 1000000);
                            break;
                        case BANK_COMMISSION:
                            entry.setBankComissionPerc((Double.parseDouble(cell.replaceAll(",", ""))) / 100000);
                            break;
                        case TXN_ID:
                            entry.setTxnId(AdapterUtil.stripLeadingZeros(AdapterUtil.checkApostrophe(cell)));
                            break;
                        default:
                            break;
                        }
                    }
                } catch (Exception ex) {
                    LOGGER.error("Exception inside for loop for column {} | {} ",
                            (ReconFileAdapter.Column) columnMap.get(columnIndex), ex.getMessage());
                    if (costParamMap.containsKey((ReconFileAdapter.Column) columnMapPricing.get(columnIndex)))
                        costFieldError = true;
                }
            }
            if (costFieldError) {
                if (Strings.isNotEmpty(entry.getTxnId())) {
                    costErrorMap.put(entry.getTxnId(), true);
                }
            } else {
                if (Strings.isNotEmpty(entry.getTxnId()) && entry.getGrossAmount() != 0.0) {
                    if (pricingMap.containsKey(entry.getTxnId())) {
                        txnPricingList = pricingMap.get(entry.getTxnId());
                    } else {
                        txnPricingList = new ArrayList<>();
                    }
                    txnPricingList.add(entry);
                    pricingMap.put(entry.getTxnId(), txnPricingList);
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception while extracting pricing data for tnx {} | {} ", entry.getTxnId(), e.getMessage());
        }
    }
}
