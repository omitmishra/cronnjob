package com.paytm.pgplus.apirisk.worker;

import com.paytm.pgplus.apirisk.queue.producer.EmailProducer;
import com.paytm.pgplus.rabbitmq.communication.models.EmailInfo;
import freemarker.template.Configuration;
import freemarker.template.Template;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import javax.mail.MessagingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 * Copyright (c) 2016. Paytm - All Rights Reserved.
 *
 * - Unauthorized copying of this file, via any medium is strictly prohibited. -
 * This file is Proprietary and Confidential.
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

/**
 * Created by prashantkumar, vivekkumar on 9/27/16.
 */
@Component
public class EmailWorker {

	private static final Logger	LOGGER	= LoggerFactory.getLogger(EmailWorker.class);

	@Autowired
	EmailProducer emailProducer;

	@Autowired
	private Configuration		freemarkerConfiguration;

	public void sendMail(String[] sendTo, String[] cc, String[] bcc, String subject, String msg, Map<String,Double> infoMap) throws MessagingException {

		EmailInfo emailInfo = new EmailInfo();
		String[] filteredReceipent = filter(sendTo);
		if(filteredReceipent.length > 0) {
			emailInfo.setTo(filteredReceipent);
		}
		String[] filteredCc = filter(cc);
		if(filteredCc.length > 0) {
			emailInfo.setCc(filteredCc);
		}
		String[] filteredBcc = filter(bcc);
		if(filteredBcc.length > 0) {
			emailInfo.setBcc(filteredBcc);
		}
		emailInfo.setSubject(subject);
		String text = getFreeMarkerTemplateContent(infoMap);
		emailInfo.setMessage(text);

		emailProducer.publishChange(emailInfo);
		LOGGER.info(" Email Sent successfully ...");
	}

	public void sendMail(String[] sendTo, String[] cc, String[] bcc, String subject, String msg, Object infoMap, Template template)
			throws MessagingException {

		EmailInfo emailInfo = new EmailInfo();
		String[] filteredReceipent = filter(sendTo);
		if(filteredReceipent.length > 0) {
			emailInfo.setTo(filteredReceipent);
		}
		String[] filteredCc = filter(cc);
		if(filteredCc.length > 0) {
			emailInfo.setCc(filteredCc);
		}
		String[] filteredBcc = filter(bcc);
		if(filteredBcc.length > 0) {
			emailInfo.setBcc(filteredBcc);
		}
		emailInfo.setSubject(subject);
		String text = getFreeMarkerTemplateContent(infoMap, template);
		emailInfo.setMessage(text);

		emailProducer.publishChange(emailInfo);
		LOGGER.info(" Email Sent successfully ...");
	}

	public String[] filter(String[] list) {
		List<String> result = new ArrayList<>();
		if(list != null) {
			for (int i = 0; i < list.length; i++) {
				if(StringUtils.isBlank(list[i])) {
					continue;
				}
				result.add(list[i]);
			}
		}
		if(!result.isEmpty())
			return result.toArray(new String[result.size()]);
		else
			return new String[0];
	}

	public String getFreeMarkerTemplateContent(Map<String,Double> statistics) {
		StringBuilder content = new StringBuilder();
		try {
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerConfiguration.getTemplate("emailtemplate.ftl"),
					statistics));
			return content.toString();
		} catch (Exception e) {
			LOGGER.error("Exception occured while processing fmtemplate: ", e);
		}
		return "";
	}

	public String getFreeMarkerTemplateContent(Object statistics, Template template) {
		StringBuilder content = new StringBuilder();
		try {
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(template, statistics));
			return content.toString();
		} catch (Exception e) {
			LOGGER.error("Exception occured while processing fmtemplate: ", e);
		}
		return "";
	}

}
