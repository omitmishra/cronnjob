/**
 *
 */
package com.paytm.pgplus.apirisk.queue.service.impl;

import com.paytm.pgplus.apirisk.queue.service.IQueueService;
import com.paytm.pgplus.rabbitmq.enums.EnumRoutingKey;
import com.paytm.pgplus.rabbitmq.service.IRabbitmqProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/*
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *   Copyright (c) 2016. Paytm - All Rights Reserved.
 *
 *      - Unauthorized copying of this file, via any medium is strictly prohibited.
 *      - This file is Proprietary and Confidential.
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

/**
 * @author prashant
 */
@Component
public class QueueServiceImpl implements IQueueService {

    private static final Logger LOGGER = LoggerFactory.getLogger(QueueServiceImpl.class);

    @Autowired
    IRabbitmqProducer rabbitmqProducer;

    @Override
    public void pushData(String key, Object requestBody) {
        LOGGER.info("Request received for pushing data in queue at key {}", key);

        EnumRoutingKey node = EnumRoutingKey.getNode(key);

        if (null != node) {
            LOGGER.debug("Sending : {} ", requestBody);
            rabbitmqProducer.produce(node, requestBody);
            LOGGER.debug("Data Sent to queue successfully");
        }
    }
}