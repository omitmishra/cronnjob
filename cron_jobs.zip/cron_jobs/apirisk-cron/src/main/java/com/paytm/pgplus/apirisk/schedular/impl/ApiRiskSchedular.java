package com.paytm.pgplus.apirisk.schedular.impl;

import com.paytm.pgplus.apirisk.schedular.ISchedularTask;
import com.paytm.pgplus.apirisk.worker.EmailWorker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Created by prashant on 2/16/17.
 */
@Component
@ConditionalOnProperty(prefix = "schedular.apirisk", name = "enable", havingValue = "true")
public class ApiRiskSchedular implements ISchedularTask {

    private static final Logger LOGGER = LoggerFactory.getLogger(ApiRiskSchedular.class);

    @Autowired
    EmailWorker emailWorker;

    @Scheduled(fixedRate = 100)
    @Override
    public void task() {
        LOGGER.info(" Calling schedular ...");

//        emailWorker.sendMail();
    }
}
