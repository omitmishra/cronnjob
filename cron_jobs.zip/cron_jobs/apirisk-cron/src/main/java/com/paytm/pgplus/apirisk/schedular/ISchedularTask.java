package com.paytm.pgplus.apirisk.schedular;

/*
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *   Copyright (c) 2016. Paytm - All Rights Reserved.
 *
 *      - Unauthorized copying of this file, via any medium is strictly prohibited.
 *      - This file is Proprietary and Confidential.
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

/**
 * Created by prashantkumar on 10/25/16.
 */
public interface ISchedularTask {

    void task();

}
