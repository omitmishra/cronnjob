package com.paytm.pgplus.apirisk.queue.producer;

import com.paytm.pgplus.apirisk.queue.service.IQueueService;
import com.paytm.pgplus.rabbitmq.communication.models.EmailInfo;
import com.paytm.pgplus.rabbitmq.enums.EnumRoutingKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/*
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 *   Copyright (c) 2016. Paytm - All Rights Reserved.
 *
 *      - Unauthorized copying of this file, via any medium is strictly prohibited.
 *      - This file is Proprietary and Confidential.
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 */

/**
 * Created by prashant on 11/16/16.
 */
@Component
public class EmailProducer {

    @Autowired
    IQueueService queueService;

    public void publishChange(EmailInfo object) {
        queueService.pushData(EnumRoutingKey.EMAIL_CG_NOTIFY.getValue(), object);
    }

}
